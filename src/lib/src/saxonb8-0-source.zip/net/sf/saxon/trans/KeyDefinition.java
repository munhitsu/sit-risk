package net.sf.saxon.trans;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.pattern.Pattern;

import java.io.Serializable;
import java.text.Collator;

/**
  * Corresponds to a single key definition.<P>
  * @author Michael H. Kay
  */

public class KeyDefinition implements Serializable {

    private Pattern match;          // the match pattern
    private Expression use;         // the use expression
    private Collator collation;     // the collating sequence, when type=string
    private String collationName;   // the collation URI

    /**
    * Constructor to create a key definition
    */

    public KeyDefinition(Pattern match, Expression use, String collationName, Collator collation) {
        this.match = match;
        this.use = use;
        this.collation = collation;
        this.collationName = collationName;
    }

    /**
    * Get the match pattern for the key definition
     * @return the pattern specified in the "match" attribute of the xsl:key declaration
    */

    public Pattern getMatch() {
        return match;
    }

    /**
    * Get the use expression for the key definition
     * @return the expression specified in the "use" attribute of the xsl:key declaration
    */

    public Expression getUse() {
        return use;
    }

    /**
    * Get the collation name for this key definition.
    * @return the collation name (the collation URI)
    */

    public String getCollationName() {
        return collationName;
    }

    /**
    * Get the collation.
     * @return the collation
    */

    public Collator getCollation() {
        return collation;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file except PB-SYNC section.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions marked PB-SYNC are Copyright (C) Peter Bryant (pbryant@bigfoot.com). All Rights Reserved.
//
// Contributor(s): Michael Kay, Peter Bryant.
//
