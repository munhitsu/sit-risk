package net.sf.saxon.query;

import net.sf.saxon.expr.BindingReference;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.VariableDeclaration;
import net.sf.saxon.expr.TypeChecker;
import net.sf.saxon.expr.RoleLocator;
import net.sf.saxon.instruct.DefiningVariable;
import net.sf.saxon.instruct.GeneralVariable;
import net.sf.saxon.instruct.Param;
import net.sf.saxon.instruct.Variable;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.xpath.XPathException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Class to hold compile-time information about an XQuery global variable
 * or parameter
 */

public class GlobalVariableDefinition implements VariableDeclaration {

    private List references = new ArrayList();
    private SequenceType requiredType;
    private Expression value;
    private int fingerprint;
    private boolean isParameter;
    private String variableName;
    private int lineNumber;


    public void setRequiredType(SequenceType type) {
        requiredType = type;
    }

    public void setFingerprint(int fingerprint) {
        this.fingerprint = fingerprint;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }

    public void setValueExpression(Expression val) {
        this.value = val;
    }

    public void setIsParameter(boolean b) {
        isParameter = b;
    }

    public void registerReference(BindingReference ref) {
        references.add(ref);
    }

    public int getVariableFingerprint() {
        return fingerprint;
    }

    public GeneralVariable compile(StaticQueryContext env, int slot) throws XPathException {

        DefiningVariable var;
        if (isParameter) {
            var = new Param();
            var.setRequiredParam(value==null);
        } else {
            var = new Variable();
        }
        if (value != null) {
            RoleLocator role =
                new RoleLocator(RoleLocator.VARIABLE, variableName, 0);
            Expression value2 = TypeChecker.staticTypeCheck(
                                    value.simplify(),
                                    requiredType,
                                    false,
                                    role   );
            var.setSelect(value2);

            // the value expression may declare local variables
            int slots = XQueryFunction.allocateSlots(value2, 0);
            if (slots > 0) {
                env.allocateLocalSlots(slots);
                var.setContainsLocals(true);
            }
        }
        var.setVariableFingerprint(fingerprint);
        var.setRequiredType(requiredType);
        var.setGlobal(true);
        var.setVariableName(variableName);
        var.setSlotNumber(slot);
        var.setSourceLocation(0, lineNumber);

        Iterator iter = references.iterator();
        while (iter.hasNext()) {
            BindingReference binding = (BindingReference)iter.next();
            binding.setStaticType(requiredType, null, 0);
            binding.fixup(var);
        }

        return var;
    }
}
