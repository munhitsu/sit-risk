package net.sf.saxon.query;

import net.sf.saxon.Controller;
import net.sf.saxon.Configuration;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.instruct.*;
import net.sf.saxon.om.*;
import net.sf.saxon.xpath.XPathEvaluator;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;
import java.util.*;
import java.io.OutputStream;

/**
 * XQueryExpression represents a compiled query. This object is immutable and thread-safe,
 * the same compiled query may be executed many times in series or in parallel. The object
 * can be created only by using the compileQuery method of the QueryProcessor class.
 *
 * <p>Various methods are provided for evaluating the query, with different options for
 * delivery of the results.</p>
 */
public class XQueryExpression {

    private Expression expression;
    private Executable executable;

    // The documentInstruction is a document{...} wrapper around the expression as written by the user
    private DocumentInstr documentInstruction;

    /**
    * The constructor is protected, to ensure that instances can only be
    * created using the compileQuery() methods of QueryProcessor
    */

    protected XQueryExpression(Expression exp, Executable exec, StaticQueryContext staticEnv, Configuration config) {
        expression = exp;
        executable = exec;
        executable.setConfiguration(config);
        executable.setDefaultCollationName(staticEnv.getDefaultCollationName());
        executable.setCollationTable(staticEnv.getAllCollations());
        executable.setSlotSpace(staticEnv.getNumberOfGlobalVariables(),
                staticEnv.getNumberOfLocalVariables());
        String[] modules = new String[1];
        modules[0] = staticEnv.getSystemId();
        executable.setModuleArray(modules);
    }

    protected void setDocumentInstruction(DocumentInstr doc) {
        documentInstruction = doc;
    }

    /**
     * Execute a the compiled Query, returning the results as a List.
     * @param env Provides the dynamic query evaluation context
     * @return The results of the expression, as a List. The List represents the sequence
     * of items returned by the expression. Each item in the list will either be an
     * object representing a node, or an object representing an atomic value.
     * For the types of Java object that may be returned, see the description of the
     * {@link net.sf.saxon.xpath.XPathEvaluator#evaluate evaluate} method
     * of class XPathProcessor
     */

    public List evaluate(DynamicQueryContext env) throws TransformerException {
        SequenceIterator iterator = iterator(env);
        ArrayList list = new ArrayList();
        while (true) {
            Item item = iterator.next();
            if (item == null) {
                return list;
            }
            list.add(XPathEvaluator.convert(item));
        }
    }

    /**
     * Execute the compiled Query, returning the first item in the result.
     * This is useful where it is known that the expression will only return
     * a singleton value (for example, a single node, or a boolean).
     * @param env Provides the dynamic query evaluation context
     * @return The first item in the sequence returned by the expression. If the expression
     * returns an empty sequence, this method returns null. Otherwise, it returns the first
     * item in the result sequence, represented as a Java object using the same mapping as for
     * the {@link XQueryExpression#evaluate evaluate} method
     */

    public Object evaluateSingle(DynamicQueryContext env) throws TransformerException {
        SequenceIterator iterator = iterator(env);
        Item item = iterator.next();
        if (item == null) {
            return null;
        }
        return XPathEvaluator.convert(item);
    }

    /**
     * Get an iterator over the results of the expression. This returns results without
     * any conversion of the returned items to "native" Java classes. The iterator will
     * deliver a sequence of Item objects, each item being either a NodeInfo (representing
     * a node) or an AtomicValue (representing an atomic value).
     *
     * <p>To get the results of the query in the form of an XML document in which each
     * item is wrapped by an element indicating its type, use:</p>
     *
     * <p><code>QueryResult.wrap(iterator(env))</code></p>
     *
     * <p>To serialize the results to a file, use the QueryResult.serialize() method.</p>
     *
     * @param env Provides the dynamic query evaluation context
     * @return an iterator over the results of the query. The class SequenceIterator
     * is modeled on the standard Java Iterator class, but has extra functionality
     * and can throw exceptions when errors occur.
     * @throws XPathException if a dynamic error occurs in evaluating the query. Some
     * dynamic errors will not be reported by this method, but will only be reported
     * when the individual items of the result are accessed using the returned iterator.
     */

    public SequenceIterator iterator(DynamicQueryContext env) throws TransformerException {
        Controller controller = getController();
        initializeController(env, controller);

        try {
            NodeInfo node = env.getContextNode();
            if (node != null) {
                controller.makeContext(node);
                controller.setPrincipalSourceDocument(node.getDocumentRoot());
            }
            Bindery bindery = controller.getBindery();
            bindery.openStackFrame();
            controller.defineGlobalParameters(bindery);
            XPathContext context = controller.newXPathContext();
            SequenceIterator iterator = expression.iterate(context);
            //controller.getBindery().closeStackFrame();
            return new ErrorReportingIterator(iterator, controller.getErrorListener());
        } catch (XPathException err) {
            TransformerException terr = err;
            while (terr.getException() instanceof TransformerException) {
                terr = (TransformerException)terr.getException();
            }
            controller.getErrorListener().error(terr);
            throw terr;
//            // if the error handler suppresses the exception, return an empty sequence
//            return EmptyIterator.getInstance();
        }
    }

    private void initializeController(DynamicQueryContext env, Controller controller) {
        HashMap parameters = env.getParameters();
        if (parameters != null) {
            Iterator iter = parameters.keySet().iterator();
            while (iter.hasNext()) {
                String paramName = (String)iter.next();
                Object paramValue = parameters.get(paramName);
                controller.setParameter(paramName, paramValue);
            }
        }

        controller.setURIResolver(env.getURIResolver());
        controller.setErrorListener(env.getErrorListener());
    }

    /**
     * Run the query, sending the results directly to a JAXP Result object. This way of executing
     * the query is most efficient in the case of queries that produce a single document (or parentless
     * element) as their output, because it avoids constructing the result tree in memory: instead,
     * it is piped straight to the serializer.
     * @param env the dynamic query context
     * @param result the destination for the results of the query. The query is effectively wrapped
     * in a document{} constructor, so that the items in the result are concatenated to form a single
     * document; this is then written to the requested Result destination, which may be (for example)
     * a DOMResult, a SAXResult, or a StreamResult
     * @param outputProperties Supplies serialization properties, in JAXP format, if the result is to
     * be serialized. This parameter can be defaulted to null.
     * @throws TransformerException if the query fails.
     */

    public void run(DynamicQueryContext env, Result result, Properties outputProperties) throws TransformerException {
        if (outputProperties == null) {
            outputProperties = new Properties();
        }
        Controller controller = getController();
        initializeController(env, controller);
        Bindery bindery = controller.getBindery();
        bindery.openStackFrame();
        controller.defineGlobalParameters(bindery);

        boolean mustClose = (result instanceof StreamResult &&
            ((StreamResult)result).getOutputStream() == null);
        controller.changeOutputDestination(outputProperties, result, true, Validation.PRESERVE, null);

        // Run the query
        try {
            documentInstruction.process(controller.newXPathContext());
        } catch (TransformerException err) {
            controller.getErrorListener().fatalError(err);
        }

        bindery.closeStackFrame();
        controller.resetOutputDestination(null);
        if (mustClose && result instanceof StreamResult) {
            OutputStream os = ((StreamResult)result).getOutputStream();
            if (os != null) {
                try {
                    os.close();
                } catch (java.io.IOException err) {
                    throw new TransformerException(err);
                }
            }
        }

    }

    /**
     * Get a controller that can be used to execute functions in this compiled query.
     * Functions in the query module can be found using {@link StaticQueryContext#getUserDefinedFunction}.
     * They can then be called directly from the Java application using {@link net.sf.saxon.instruct.UserFunction#call}
     * The same Controller can be used for a series of function calls.
     */

    public Controller getController() {
        Controller controller = new Controller(executable.getConfiguration());
        controller.setExecutable(executable);
        executable.initialiseBindery(controller.getBindery());
        return controller;
    }

    /**
     * Diagnostic method: display a representation of the compiled query on the
     * System.err output stream.
     */

    public void explain(NamePool pool) {
        System.err.println("============ Compiled Expression ============");
        expression.display(10, pool);
        System.err.println("=============================================");
    }

    /**
     * ErrorReportingIterator is an iterator that wraps a base iterator and reports
     * any exceptions that are raised to the ErrorListener
     */

    private static class ErrorReportingIterator implements SequenceIterator {
        private SequenceIterator base;
        private ErrorListener listener;

        public ErrorReportingIterator(SequenceIterator base, ErrorListener listener) {
            this.base = base;
            this.listener = listener;
        }

        public Item next() throws XPathException {
            try {
                return base.next();
            } catch (XPathException e1) {
                try {
                    listener.error(e1);
                } catch (TransformerException e2) {}
                throw e1;
            }
        }

        public Item current() {
            return base.current();
        }

        public int position() {
            return base.position();
        }

        public SequenceIterator getAnother() throws XPathException {
            return new ErrorReportingIterator(base.getAnother(), listener);
        }

    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.

// The Initial Developer of the Original Code is Michael H. Kay
//
// The line marked PB-SYNC is by Peter Bryant (pbryant@bigfoot.com). All Rights Reserved.
//
// Contributor(s): Michael Kay, Peter Bryant, David Megginson
//

