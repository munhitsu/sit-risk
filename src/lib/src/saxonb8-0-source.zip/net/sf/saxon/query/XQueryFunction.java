package net.sf.saxon.query;

import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.RangeVariableDeclaration;
import net.sf.saxon.expr.Assignation;
import net.sf.saxon.expr.TypeChecker;
import net.sf.saxon.expr.UserFunctionCall;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.RoleLocator;
import net.sf.saxon.instruct.FunctionSignature;
import net.sf.saxon.instruct.UserFunction;
import net.sf.saxon.instruct.UserFunctionParameter;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.om.NamePool;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class XQueryFunction implements FunctionSignature {
    int fingerprint;
    String displayName;
    List arguments;
    SequenceType resultType;
    Expression body = null;
    List references = new ArrayList();
    int lineNumber;
    UserFunction compiledFunction = null;

    public int getFunctionFingerprint() {
        return fingerprint;
    }

    public SequenceType getResultType() {
        return resultType;
    }

    public SequenceType[] getArgumentTypes() {
        SequenceType[] types = new SequenceType[arguments.size()];
        for (int i=0; i<arguments.size(); i++) {
            types[i] = ((RangeVariableDeclaration)arguments.get(i)).getRequiredType();
        }
        return types;
    }

    public int getNumberOfArguments() {
        return arguments.size();
    }

    public void registerReference(UserFunctionCall ufc) {
        references.add(ufc);
    }

    public UserFunction compile(StaticQueryContext env) throws XPathException.Static {

        try {
            // If a query function is imported into several modules, then the compile()
            // method will be called once for each importing module. If the compiled
            // function already exists, then this is a repeat call, and the only thing
            // needed is to fix up references to the function from within the importing
            // module.

            if (compiledFunction == null) {
                // first create a UserFunctionParameter object for each declared
                // argument of the function, and bind the references to that argument

                Iterator iter = arguments.iterator();
                int slot = 0;
                while (iter.hasNext()) {
                    RangeVariableDeclaration decl = (RangeVariableDeclaration)iter.next();
                    UserFunctionParameter param = new UserFunctionParameter();
                    param.setSlotNumber(slot++);
                    param.setVariableName(decl.getVariableName());
                    param.setRequiredType(decl.getRequiredType());
                    decl.fixupReferences(param);
                }

                // type-check the body of the function

                body = body.simplify().analyze(env);
                RoleLocator role =
                        new RoleLocator(RoleLocator.FUNCTION_RESULT, displayName, 0);
                body = TypeChecker.staticTypeCheck(body, resultType, false, role);
                int slots = allocateSlots(body, slot);
                env.allocateLocalSlots(slots);

                compiledFunction = new UserFunction(body);
                compiledFunction.setFunctionName(displayName);
                compiledFunction.setLineNumber(lineNumber);
                compiledFunction.setSystemId(env.getBaseURI());

                // mark tail calls within the function body

                ExpressionTool.markTailFunctionCalls(body);

            }

            // bind all references to this function to the UserFunction object

            fixupReferences();
            return compiledFunction;
        } catch (XPathException e) {
            if (e instanceof XPathException.Static) {
                throw (XPathException.Static)e;
            } else {
                throw new XPathException.Static(e);
            }
        }
    }

    /**
     * Fix up references to this function
     */

    public void fixupReferences() throws XPathException {
        Iterator iter = references.iterator();
        while (iter.hasNext()) {
            UserFunctionCall ufc = (UserFunctionCall)iter.next();
            ufc.setFunction(this, compiledFunction);
        }

        // clear the list of references, so that more can be added in another module
        references = new ArrayList();

    }

    /**
     * Allocate slot numbers to range variables
     */

    protected static int allocateSlots(Expression exp, int nextFree) {
        if (exp instanceof Assignation) {
            ((Assignation)exp).setSlotNumber(nextFree++);
        }
        Expression[] children = exp.getSubExpressions();
        for (int i=0; i<children.length; i++) {
            nextFree = allocateSlots(children[i], nextFree);
        }
        return nextFree;

        // Note, we allocate a distinct slot to each range variable, even if the
        // scopes don't overlap. This isn't strictly necessary, but might help
        // debugging.
    }

    public void explain(NamePool pool) {
        System.err.println("define function " + displayName + " {");
        body.display(1, pool);
        System.err.println("}");
    }

    /**
     * Get the callable compiled function contained within this XQueryFunction definition.
     */

    public UserFunction getUserFunction() {
        return compiledFunction;
    }

}
