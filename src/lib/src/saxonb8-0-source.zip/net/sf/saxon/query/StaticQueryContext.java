package net.sf.saxon.query;
import net.sf.saxon.Configuration;
import net.sf.saxon.Loader;
import net.sf.saxon.expr.*;
import net.sf.saxon.functions.SystemFunction;
import net.sf.saxon.functions.XSLTFunction;
import net.sf.saxon.instruct.NamespaceContext;
import net.sf.saxon.instruct.UserFunction;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NamespaceConstant;
import net.sf.saxon.om.QNameException;
import net.sf.saxon.om.Validation;
import net.sf.saxon.om.NamespaceResolver;
import net.sf.saxon.sort.CodepointCollator;
import net.sf.saxon.sort.CollationFactory;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.GlobalValidationContext;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.ValidationContext;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 * StaticQueryContext is the implementation of StaticContext used when processing XQuery
 * expressions. Note that some of the methods are intended for use internally by the
 * query processor itself.
 *
 * <p>Note that a StaticQueryContext object may be initialized with
     * context information that the query can use, but it is also modified when a query is compiled against
     * it: for example, namespaces, variables, and functions declared in the query prolog are registered in
     * the static context. Therefore, a StaticQueryContext object should not be used to compile more
     * than one query. </p>
*/

public class StaticQueryContext implements StaticContext {

	private Configuration config;
    private NamePool namePool;
	private HashMap passiveNamespaces;
    private Stack activeNamespaces;
	private HashMap collations;
	private HashMap variables;
    private HashMap functions;
    private HashSet importedSchemata;
    private List unboundFunctionCalls;
	private String defaultCollationName;
    private String defaultFunctionNamespace;
    private short defaultElementNamespace;
    private String baseURI;
    private int localStackFrameSize;
    private int numberOfGlobalVariables;
                    // the number of global variables declared in this module and in all modules
                    // imported into this module, whether or not the variables themselves are imported
    private String moduleNamespace;
    private short moduleNamespaceURICode;
    private Stack validationModeStack;
    private Stack validationContextStack;

	/**
	* Create a StaticQueryContext using the default NamePool
	*/

	public StaticQueryContext(Configuration config) {
        this.config = config;
        this.namePool = config.getNamePool();
        reset();
	}

    /**
     * Reset the state of this StaticQueryContext to an uninitialized state
     */

    public void reset() {
        passiveNamespaces = new HashMap();
        activeNamespaces = new Stack();
        collations = new HashMap();
        variables = new HashMap();
        numberOfGlobalVariables = 0;
        functions = new HashMap();
        importedSchemata = new HashSet();
        unboundFunctionCalls = new ArrayList();
        defaultFunctionNamespace = NamespaceConstant.FN;
        defaultElementNamespace = NamespaceConstant.NULL_CODE;
        localStackFrameSize = 0;
        moduleNamespace = null;
        moduleNamespaceURICode = 0;

        // Set up a "default default" collation based on the Java locale
        String lang = Locale.getDefault().getLanguage();
        defaultCollationName = "http://saxon.sf.net/collation?lang=" + lang + ";strength=tertiary";
        try {
            declareCollation(defaultCollationName, CollationFactory.makeCollationFromURI(defaultCollationName));
        } catch (TransformerException err) {
            defaultCollationName = CodepointCollator.URI;
            declareCollation(defaultCollationName, CodepointCollator.getInstance());
        }

        // Set up initial validation mode and context
        validationModeStack = new Stack();
        validationModeStack.push(
                (config.isSchemaAware() ?
                    new Integer(Validation.LAX) :
                    new Integer(Validation.STRIP)));
        validationContextStack = new Stack();
        validationContextStack.push(GlobalValidationContext.getInstance());
        clearNamespaces();
    }

    /**
     * Set the Configuration options
     */

    public void setConfiguration(Configuration config) {
        this.config = config;
    }

    /**
     * Get the Configuration options
     */

    public Configuration getConfiguration() {
        return config;
    }

	/**
	* Declare a namespace whose prefix can be used in expressions. This is
     * a passive namespace, it won't be copied into the result tree. Passive
     * namespaces are never undeclared, and active namespaces override them.
	* @param prefix The namespace prefix. Must not be null.
	* @param uri The namespace URI. Must not be null.
	*/

	protected void declarePassiveNamespace(String prefix, String uri) {
	    if (prefix==null) {
	        throw new NullPointerException("Null prefix supplied to declarePassiveNamespace()");
	    }
	    if (uri==null) {
	        throw new NullPointerException("Null namespace URI supplied to declarePassiveNamespace()");
	    }
		passiveNamespaces.put(prefix, uri);
		namePool.allocateNamespaceCode(prefix, uri);
	}

    /**
     * Declare an active namespace
     */

    protected void declareActiveNamespace(String prefix, String uri) {
	    if (prefix==null) {
	        throw new NullPointerException("Null prefix supplied to declareActiveNamespace()");
	    }
	    if (uri==null) {
	        throw new NullPointerException("Null namespace URI supplied to declareActiveNamespace()");
	    }

        int nscode = namePool.allocateNamespaceCode(prefix, uri);
        ActiveNamespace entry = new ActiveNamespace();
        entry.prefix = prefix;
        entry.uri = uri;
        entry.code = nscode;
		activeNamespaces.push(entry);

        if (prefix.equals("")) {
            defaultElementNamespace = (short)(nscode & 0xffff);
        }

    }

	/**
	* Undeclare the most recently-declared active namespace
	*/

	public void undeclareNamespace() {
        activeNamespaces.pop();
	}

	/**
	* Clear all the declared namespaces, except for the standard ones (xml, saxon, etc)
	*/

	public void clearNamespaces() {
        if (passiveNamespaces != null) {
            passiveNamespaces.clear();
            declarePassiveNamespace("xml", NamespaceConstant.XML);
            declarePassiveNamespace("saxon", NamespaceConstant.SAXON);
            declarePassiveNamespace("xs", NamespaceConstant.SCHEMA);
            declarePassiveNamespace("fn", NamespaceConstant.FN);
            declarePassiveNamespace("xdt", NamespaceConstant.XDT);
            declarePassiveNamespace("xsi", NamespaceConstant.SCHEMA_INSTANCE);
            declarePassiveNamespace("local", NamespaceConstant.LOCAL);
            declarePassiveNamespace("", "");
        }
	}

    /**
     * Get the URI for a prefix.
     * This method is used by the XQuery parser to resolve namespace prefixes.
     * @param prefix The prefix
     * @return the corresponding namespace URI
     * @throws XPathException if the prefix has not been declared
    */

    public String getURIForPrefix(String prefix) throws XPathException {
    	String uri = checkURIForPrefix(prefix);
    	if (uri==null) {
    		throw new XPathException.Static("Prefix " + prefix + " has not been declared");
    	}
    	return uri;
    }

    /**
     * Get the URI for a prefix if there is one, return null if not.
     * This method is used by the XQuery parser to resolve namespace prefixes.
     * @param prefix The prefix
     * @return the corresponding namespace URI, or null if the prefix has not
     * been declared.
    */

    public String checkURIForPrefix(String prefix) {
        // Search the active namespaces first, then the passive ones.
        for (int i=activeNamespaces.size()-1; i>=0; i--) {
            if (((ActiveNamespace)activeNamespaces.get(i)).prefix.equals(prefix)) {
                return ((ActiveNamespace)activeNamespaces.get(i)).uri;
            }
        }
    	return (String)passiveNamespaces.get(prefix);
    }

    /**
     * Get an array containing the namespace codes of all active
     * namespaces.
     */

    public int[] getActiveNamespaceCodes() {
        int[] nscodes = new int[activeNamespaces.size()];
        int used = 0;
        HashSet prefixes = new HashSet();
        for (int n=activeNamespaces.size()-1; n>=0; n--) {
            ActiveNamespace an = (ActiveNamespace)activeNamespaces.get(n);
            if (!prefixes.contains(an.prefix)) {
                prefixes.add(an.prefix);
                nscodes[used++] = an.code;
            }
        }
        if (used < nscodes.length) {
            int[] nscodes2 = new int[used];
            System.arraycopy(nscodes, 0, nscodes2, 0, used);
            nscodes = nscodes2;
        }
        return nscodes;
    }

    /**
    * Get a copy of the Namespace Context. This method is used internally
     * by the query parser when a construct is encountered that needs
     * to save the namespace context for use at run-time.
    */

    public NamespaceResolver getNamespaceContext() {
        int[] active = getActiveNamespaceCodes();
        int[] nscodes = new int[passiveNamespaces.size() + active.length];

        int used = 0;
        for (Iterator iter = passiveNamespaces.keySet().iterator(); iter.hasNext(); ) {
            String prefix = (String)iter.next();
            String uri = (String)passiveNamespaces.get(prefix);
            nscodes[used++] = namePool.getNamespaceCode(prefix, uri);;
        }
        for (int a=0; a<active.length; a++) {
            nscodes[used++] = active[a];
        }
//        if (used < nscodes.length) {
//            int[] nscodes2 = new int[used];
//            System.arraycopy(nscodes, 0, nscodes2, 0, used);
//            nscodes = nscodes2;
//        }
        return new NamespaceContext(nscodes, namePool);
    }

    /**
     * Get the default function namespace
     * @return the default function namespace (defaults to the fn: namespace)
     */

    public String getDefaultFunctionNamespace() {
        return defaultFunctionNamespace;
    }

    /**
     * Set the default function namespace
     * @param defaultFunctionNamespace The namespace to be used for unprefixed function calls
     */

    public void setDefaultFunctionNamespace(String defaultFunctionNamespace) {
        this.defaultFunctionNamespace = defaultFunctionNamespace;
    }

    /**
     * Set the default element namespace
     */

    protected void setDefaultElementNamespace(String uri) {
        int nscode = namePool.allocateNamespaceCode("", uri);
        defaultElementNamespace = (short)(nscode & 0xffff);
        declarePassiveNamespace("", uri);
    }

    /**
    * Get the default XPath namespace, as a namespace URI code that can be looked up in the NamePool
    */

    public short getDefaultElementNamespace() {
        return defaultElementNamespace;
    }

    /**
     * Set the namespace for a library module
     */

    public void setModuleNamespace(String uri) {
        moduleNamespace = uri;
        moduleNamespaceURICode = namePool.getCodeForURI(uri);
    }

    /**
     * Get the namespace of the current library module.
     * @return the module namespace, or null if this is a main module
     */

    public String getModuleNamespace() {
        return moduleNamespace;
    }

    /**
     * Get the namesapce code of the current library module.
     * @return the module namespace, or null if this is a main module
     */

    public short getModuleNamespaceCode() {
        return moduleNamespaceURICode;
    }

    /**
    * Declare a named collation. Collations are only available in a query if this method
     * has been called externally to declare the collation and associate it with an
     * implementation, in the form of a Java Comparator. The default collation is the
     * Unicode codepoint collation, unless otherwise specified.
    * @param name The name of the collation (technically, a URI)
    * @param comparator The Java Comparator used to implement the collating sequence
    */

    public void declareCollation(String name, Comparator comparator) {
        collations.put(name, comparator);
    }

    /**
     * Set the default collation. The collation that is specified must be one that has
     * been previously registered using the declareCollation() method.
     * @param name The collation name
     * @throws XPathException if the collation name has not been registered
     */

    public void declareDefaultCollation(String name) throws XPathException {
        Comparator c = getCollation(name);
        if (c==null) {
            throw new XPathException.Static("Collation " + name + " is not recognized");
        }
        defaultCollationName = name;
    }

    /**
    * Get a named collation.
    * @return the collation identified by the given name, as set previously using declareCollation.
    * Return null if no collation with this name is found.
    */

    public Comparator getCollation(String name) {
        Comparator c = (Comparator)collations.get(name);
        if (c != null) {
            return c;
        }
        try {
            return CollationFactory.makeCollationFromURI(name);
        } catch (TransformerException e) {
            return null;
        }
    }

    /**
    * Get the name of the default collation.
    * @return the name of the default collation; or the name of the codepoint collation
    * if no default collation has been defined
    */

    public String getDefaultCollationName() {
        if (defaultCollationName != null) {
            return defaultCollationName;
        } else {
            return CodepointCollator.URI;
        }
    }

    /**
     * Get a HashMap that maps all registered collations to Comparators.
     * Note that this returns a snapshot copy of the data held by the static context.
     * This method is provided for internal use by the query processor.
     */

    public HashMap getAllCollations() {
        return new HashMap(collations);
    }

    /**
    * Declare a global variable. A variable must be declared before an expression referring
    * to it is compiled. Global variables are normally declared in the Query Prolog, but
    * they can also be predeclared using this API.
    */

    public void declareVariable(VariableDeclaration var) throws XPathException.Static {
        int key = var.getVariableFingerprint();
        Integer keyObj = new Integer(key);
        if (variables.get(keyObj) != null) {
            throw new XPathException.Static(
                    "Duplicate definition of global variable " + var.getVariableName());
        }
        variables.put(keyObj, var);
    }

    /**
     * Fixup all references to global variables. This method is for internal use by
     * the Query Parser only.
     */

    public void fixupGlobalVariables(int firstSlot) throws XPathException.Static {
        int slot = firstSlot;
        Iterator iter = variables.values().iterator();
        while (iter.hasNext()) {
            Object obj = iter.next();
            GlobalVariableDefinition var = (GlobalVariableDefinition)obj;
            try {
                var.compile(this, slot++);
                numberOfGlobalVariables++;
            } catch (XPathException err) {
                if (err instanceof XPathException.Static) {
                    throw (XPathException.Static)err;
                } else {
                    throw new XPathException.Static(err);
                }
            }
        }
    }

    /**
     * Get an iterator over the variables defined in this module
     * @return an Iterator, whose items are VariableDeclaration objects.  It returns
     * all variables known to this module including those imported from elsewhere; they
     * can be distinguished by their namespace.
     */

    public Iterator getVariableDeclarations() {
        return variables.values().iterator();
    }

    /**
     * Get the number of global variables. This method is for internal use.
     */

    public int getNumberOfGlobalVariables() {
        return numberOfGlobalVariables;
    }

    /**
     * Set the number of global variables. This method is for internal use.
     */

    public void setNumberOfGlobalVariables(int n) {
        numberOfGlobalVariables = n;
    }

    /**
     * Ensure that enough slots are available in each stack frame for local variables.
     * This method is for internal use.
     */

    public void allocateLocalSlots(int n) {
        if (n > localStackFrameSize) {
            localStackFrameSize = n;
        }
    }

    /**
     * Get the maximum number of local variables in any stack frame.
     * This method is for internal use.
     */

    public int getNumberOfLocalVariables() {
        return localStackFrameSize;
    }

    /**
    * Get the NamePool used for compiling expressions
    */

    public NamePool getNamePool() {
        return namePool;
    }

    /**
    * Issue a compile-time warning. This method is used during XPath expression compilation to
    * output warning conditions. The default implementation writes the message to System.err. To
    * change the destination of messages, create a subclass of StandaloneContext that overrides
    * this method.
    */

    public void issueWarning(String s) {
        System.err.println(s);
    }

    /**
     * Set the Base URI of the query
     */

    public void setBaseURI(String baseURI) {
        this.baseURI = baseURI;
    }

    /**
    * Get the system ID of the container of the expression. Used to construct error messages.
    * @return the Base URI
    */

    public String getSystemId() {
        return baseURI;
    }

    /**
    * Get the Base URI of the query, for resolving any relative URI's used
    * in the expression.
    * Used by the document() function.
    * @return "" always
    */

    public String getBaseURI() {
        return baseURI;
    }

    /**
    * Get the line number of the expression within that container.
    * Used to construct error messages.
    * @return -1 always
    */

    public int getLineNumber() {
        return -1;
    }


    /**
    * Bind a variable used in a query to the expression in which it is declared.
    * This method is provided for use by the XQuery parser, and it should not be called by the user of
    * the API, or overridden, unless variables are to be declared using a mechanism other than the
    * declareVariable method of this class.
    */

    public VariableDeclaration bindVariable(int fingerprint) throws XPathException.Static {

        VariableDeclaration var = (VariableDeclaration)variables.get(new Integer(fingerprint));
        if (var==null) {
            throw new XPathException.Static("Undeclared variable in query");
        } else {
            return var;
        }
    }

    /**
     * Register a user-defined XQuery function
     */

    public void declareFunction(XQueryFunction function) throws XPathException.Static {
        // Note: XQuery does not allow two user-defined functions
        // with same name, different arity
        int key = function.getFunctionFingerprint();
        Integer keyObj = new Integer(key);
        if (functions.get(keyObj) != null) {
            throw new XPathException.Static("Duplicate definition of function " +
                    namePool.getDisplayName(key));
        }
        if (moduleNamespace != null &&
                namePool.getURICode(key) != moduleNamespaceURICode) {
            throw new XPathException.Static("Function " + namePool.getDisplayName(key) +
                                            " is not defined in the module namespace"
                                            );
        }
        functions.put(keyObj, function);
    }

    /**
     * Identify a (namespace-prefixed) function appearing in the expression. This
     * method is called by the XQuery parser to resolve function calls found within
     * the query.
     * <p>Note that a function call may appear earlier in the query than the definition
     * of the function to which it is bound. Unlike XSLT, we cannot search forwards to
     * find the function definition. Binding of function calls is therefore a two-stage
     * process; at the time the function call is parsed, we simply register it as
     * pending; subsequently at the end of query parsing all the pending function
     * calls are resolved. Another consequence of this is that we cannot tell at the time
     * a function call is parsed whether it is a call to an internal (XSLT or XQuery)
     * function or to an extension function written in Java.
     * @return an Expression representing the function call. This will normally be
     * a FunctionCall, but it may be rewritten as some other expression.
     * @throws XPathException if the function call is invalid, either because it is
     * an unprefixed call to a non-system function, or because it is calling a system
     * function that is available in XSLT only. A prefixed function call that cannot
     * be recognized at this stage is assumed to be a forwards reference, and is bound
     * later when bindUnboundFunctionCalls() is called.
    */

    public Expression bindFunction(String qname, Expression[] arguments) throws XPathException {
        String[] parts;
        try {
            parts = Name.getQNameParts(qname);
        } catch (QNameException e) {
            throw new XPathException.Static("Invalid function name. " + e.getMessage());
        }
        String uri;
        if (parts[0] == null || parts[0].equals("")) {
            uri = getDefaultFunctionNamespace();
        } else {
            uri = getURIForPrefix(parts[0]);
        }
        if (uri.equals(NamespaceConstant.FN)) {
            FunctionCall f = SystemFunction.makeSystemFunction(parts[1]);
            if (f==null) {
                throw new XPathException.Static("Unknown system function: " + qname);
            }
            if (f instanceof XSLTFunction) {
                throw new XPathException.Static("Function " + qname + " is available only in XSLT");
            }
            f.setArguments(arguments);
            return f;

        } else {        // the function name is prefixed
            int namecode = namePool.allocate(parts[0], uri, parts[1]);
            int fingerprint = namecode & 0xfffff;

            // Try for a constructor function for a built-in type

            if (uri.equals(NamespaceConstant.SCHEMA) || uri.equals(NamespaceConstant.SCHEMA_DATATYPES)
                    || uri.equals(NamespaceConstant.XDT)) {
                // it's a constructor function: treat it as shorthand for a cast expression
                if (arguments.length != 1) {
                    throw new XPathException.Static("A constructor function must have exactly one argument");
                }
                AtomicType type = (AtomicType)Type.getBuiltInItemType(uri, parts[1]);
                if (type==null) {
                    throw new XPathException.Static("Unknown constructor function: " + qname);
                }
                return new CastExpression(arguments[0], type, false);

            }

           // Now see if it's a constructor function for a user-defined type

            if (arguments.length == 1) {
                SchemaType st = getConfiguration().getSchemaType(fingerprint);
                if (st != null && st instanceof AtomicType) {
                    return new CastExpression(arguments[0], (AtomicType)st, false);
                }
            }

            // Some extension functions are specially recognized

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "evaluate")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:evaluate");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "expression")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:expression");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "parse")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:parse");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "serialize")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:serialize");
                f.setArguments(arguments);
                return f;
            }

            // Next, see if we can bind a Java method

			Class className = null;
			try {
			    className = getExternalJavaClass(uri);
			} catch (Exception err) {
			    throw new XPathException.Static("Cannot load external Java class", err);
			}

			if (className!=null) {
                if (!config.isAllowExternalFunctions()) {
                    throw new XPathException.Static("External functions are disabled");
                }
                FunctionProxy fp = new FunctionProxy();
                fp.setConfiguration(config);
                fp.setArguments(arguments);
                fp.setFunctionName(className, parts[1], arguments.length);
                return fp;
			}


            UserFunctionCall ufc = new UserFunctionCall();
            ufc.setFingerprint(fingerprint);
            ufc.setArguments(arguments);
            unboundFunctionCalls.add(ufc);
            return ufc;
        }
    }

    /**
     * Bind function calls that could not be bound when first encountered. These
     * will either be forwards references to functions declared later in the query,
     * or errors. This method is for internal use.
     * @throws XPathException.Static if a function call refers to a function that has
     * not been declared
     */

    protected void bindUnboundFunctionCalls() throws XPathException.Static {
        Iterator iter = unboundFunctionCalls.iterator();
        while (iter.hasNext()) {
            UserFunctionCall ufc = (UserFunctionCall)iter.next();
            int fingerprint = ufc.getFingerprint();

            // TODO: XQuery may now allow multiple functions with same name, different arity?
            // (not allowed in March 2004 draft)

//            int arity = ufc.getNumberOfArguments();

            // First try user-written functions

            Integer key = new Integer(fingerprint);
            XQueryFunction fd = (XQueryFunction)functions.get(key);
            if (fd != null) {
                ufc.setStaticType(fd.getResultType());
                fd.registerReference(ufc);
            } else {
                throw new XPathException.Static("Function " +
                        namePool.getDisplayName(fingerprint) +
                        " has not been declared",
                        ExpressionTool.getLocator(ufc));
            }
        }

         /*

            // We've failed - no implementation of this function was found

            throw new XPathException.Static("Unknown function: " + qname);

        }  */

    }

    /**
     * Get an iterator over the Functions defined in this module
     * @return an Iterator, whose items are {@link XQueryFunction} objects. It returns
     * all function known to this module including those imported from elsewhere; they
     * can be distinguished by their namespace.
     */

    public Iterator getFunctionDefinitions() {
        return functions.values().iterator();
    }

    /**
     * Fixup all references to global functions. This method is called
     * on completion of query parsing. Each XQueryFunction is required to
     * bind all references to that function to the object representing the run-time
     * executable code of the function.
     * <p>
     * This method is for internal use.
     */

    protected void fixupGlobalFunctions() throws XPathException.Static {
        Iterator iter = functions.values().iterator();
        while (iter.hasNext()) {
            XQueryFunction fn = (XQueryFunction)iter.next();
            fn.compile(this);
        }
    }

    /**
     * Output "explain" information about each declared function
     */

     public void explainGlobalFunctions() throws XPathException {
        Iterator iter = functions.values().iterator();
        while (iter.hasNext()) {
            XQueryFunction fn = (XQueryFunction)iter.next();
            fn.explain(getNamePool());
        }
    }

    /**
     * Get the function with a given name and arity. This method is provided so that XQuery functions
     * can be called directly from a Java application. Note that there is no type checking or conversion
     * of arguments when this is done: the arguments must be provided in exactly the form that the function
     * signature declares them.
     * @param uri the uri of the function name
     * @param localName the local part of the function name
     * @param arity the number of arguments. Currently not used, because the implementation
     * does not allow several functions with the same name and different arity.
     */

    public UserFunction getUserDefinedFunction(String uri, String localName, int arity) {
        Integer key = new Integer(namePool.allocate("", uri, localName));
        XQueryFunction function = (XQueryFunction)functions.get(key);
        if (function==null) {
            return null;
        }
        return function.getUserFunction();
    }

    /**
    * Get an external Java class corresponding to a given namespace prefix, if there is
    * one.
    * @param uri The namespace URI corresponding to the prefix used in the function call.
    * @return the Java class name if a suitable class exists, otherwise return null.
    */

    private Class getExternalJavaClass(String uri) {

        // Try to get a Saxon or EXSLT extension function
        Class c = FunctionProxy.getVendorExtensionClass(uri);

        if (c != null) {
            return c;
        }

        // Failing that, try to identify a class directly from the URI
        // support the URN format java:full.class.Name

        try {
            if (uri.startsWith("java:")) {
                return Loader.getClass(uri.substring(5));
            }
        } catch (TransformerException err) {
            // if it fails, we'll just get a "function not declared" message
            return null;
        }
        return null;
    }

    /**
     * Determine whether Backwards Compatible Mode is used
     * @return false; XPath 1.0 compatibility mode is not supported in XQuery
     */

    public boolean isInBackwardsCompatibleMode() {
        return false;
    }

    /**
     * Add an imported schema to this static context.
     * @param targetNamespace The target namespace of the schema to be added
     */

    public void addImportedSchema(String targetNamespace) {
        if (importedSchemata == null) {
            importedSchemata = new HashSet();
        }
        importedSchemata.add(targetNamespace);
    }

    /**
     * Get the schema for a given namespace, if it has been imported
     * @param namespace The namespace of the required schema. Supply "" for
     * a no-namespace schema.
     * @return The schema if found, or null if not found.
     */

    public boolean isImportedSchema(String namespace) {
        if (importedSchemata == null) {
            return false;
        }
        return importedSchemata.contains(namespace);
    }

    /**
     * Add a new validation mode to the stack of validation modes
     */

    public void pushValidationMode(int mode) {
        validationModeStack.push(new Integer(mode));
    }

    /**
     * Remove the validation mode currently at the top of the stack
     */

    public void popValidationMode() {
        validationModeStack.pop();
    }

    /**
     * Get the current validation mode
     */

    public int getValidationMode() {
        return ((Integer)validationModeStack.peek()).intValue();
    }

    /**
     * Add a new validation context to the stack of validation contexts
     */

    public void pushValidationContext(ValidationContext context) {
        validationContextStack.push(context);
    }

    /**
     * Remove the validation context currently at the top of the stack
     */

    public void popValidationContext() {
        validationContextStack.pop();
    }

    /**
     * Get the current validation context
     */

    public ValidationContext getValidationContext() {
        return (ValidationContext)validationContextStack.peek();
    }

    /**
     * Set the validation context to a local element declaration within
     * the current validation context
     */

    public void setContainedValidationContext(int fingerprint)
            throws XPathException{
        ValidationContext nvc = getConfiguration().getContainedValidationContext(
                getValidationContext(), fingerprint, false);
        pushValidationContext(nvc);
    }

    /**
     * Load another query module
     */

    protected StaticQueryContext loadModule(String namespaceURI, String locationURI, int firstGlobalSlot)
    throws XPathException.Static {

        StaticQueryContext mod = config.getQueryLibraryModule(namespaceURI);
        if (mod != null) {
            allocateLocalSlots(mod.getNumberOfLocalVariables());
            return mod;
        }

        if (locationURI == null) {
            throw new XPathException.Static(
                    "import module must either specify a known namespace or a location");
        }
        // Resolve relative URI

        URL absoluteURL;
        if (baseURI==null) {    // no base URI available
            try {
                // the href might be an absolute URL
                absoluteURL = new URL(locationURI);
            } catch (MalformedURLException err) {
                // it isn't
                throw new XPathException.Static("Cannot resolve URI (no base URI available)", err);
            }
        } else {
            try {
                absoluteURL = new URL(new URL(baseURI), locationURI);
            } catch (MalformedURLException err) {
                throw new XPathException.Static("Cannot resolve relative URI", err);
            }
        }
        try {
            InputStream is = absoluteURL.openStream();
            BufferedReader reader = new BufferedReader(
                                        new InputStreamReader(is));

            StringBuffer sb = new StringBuffer();
            char[] buffer = new char[2048];
            int actual=0;
            while (true) {
                actual = reader.read(buffer, 0, 2048);
                if (actual<0) break;
                sb.append(buffer, 0, actual);
            }
            StaticQueryContext module = new StaticQueryContext(config);
            module.setBaseURI(absoluteURL.toString());
            QueryParser qp = new QueryParser();
            qp.parseLibraryModule(sb.toString(), module, firstGlobalSlot);
            if (module.getModuleNamespace() == null) {
                throw new XPathException.Static(
                        "Imported module must be a library module");
            }
            if (!module.getModuleNamespace().equals(namespaceURI)) {
                throw new XPathException.Static(
                        "Imported module's namespace does not match requested namespace");
            }
            config.addQueryLibraryModule(module);
            allocateLocalSlots(module.getNumberOfLocalVariables());
            return module;
        } catch (java.io.IOException ioErr) {
            throw new XPathException.Static(ioErr);
        }
    }

    /**
     * Inner class containing information about an active namespace entry
     */

    public static class ActiveNamespace {
        public String prefix;
        public String uri;
        public int code;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
