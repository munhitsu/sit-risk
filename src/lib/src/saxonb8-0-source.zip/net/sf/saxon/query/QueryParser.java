package net.sf.saxon.query;

import net.sf.saxon.Configuration;
import net.sf.saxon.Err;
import net.sf.saxon.expr.*;
import net.sf.saxon.functions.StringJoin;
import net.sf.saxon.functions.SystemFunction;
import net.sf.saxon.instruct.*;
import net.sf.saxon.om.*;
import net.sf.saxon.sort.FixedSortKeyDefinition;
import net.sf.saxon.sort.TupleExpression;
import net.sf.saxon.sort.TupleSorter;
import net.sf.saxon.style.AttributeValueTemplate;
import net.sf.saxon.type.GlobalValidationContext;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.ValidationContext;
import net.sf.saxon.value.*;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.*;

/**
 * This class defines extensions to the XPath parser to handle the additional
 * syntax supported in XQuery
 */
public class QueryParser extends ExpressionParser {

    private boolean preserveSpace = false;
        // false unless declare xmlspace = "preserve"

    private int errorCount = 0;

    private Executable executable;

    /**
     * Create an XQueryExpression
     */

    public XQueryExpression makeXQueryExpression(String query,
                                                        StaticQueryContext staticContext,
                                                        Configuration config) throws XPathException {
        Executable exec = new Executable();
        setExecutable(exec);
        Expression exp = parseQuery(query, 0, Tokenizer.EOF, staticContext);
        XQueryExpression queryExp = new XQueryExpression(exp, exec, staticContext, config);
        DocumentInstr docInstruction;
        if (exp instanceof DocumentInstr) {
            docInstruction = (DocumentInstr)exp;
        } else {
            docInstruction = new DocumentInstr(false, null, staticContext.getSystemId());
            makeContentConstructor(exp, docInstruction, 1);
        }
        queryExp.setDocumentInstruction(docInstruction);
        return queryExp;
    }

    /**
     * Parse a top-level Query.
     * Prolog? Expression
     * @param queryString   The text of the query
     * @param start         Offset of the start of the query
     * @param terminator    Token expected to follow the query (usually Tokenizer.EOF)
     * @param env           The static context
     * @exception net.sf.saxon.xpath.XPathException if the expression contains a syntax error
     * @return the Expression object that results from parsing
     */

    public final Expression parseQuery(String queryString,
                                       int start,
                                       int terminator,
                                       StaticQueryContext env) throws XPathException {
        this.env = env;
        numberOfRangeVariables = 0;
        t = new Tokenizer();
        t.recognizePragmas = true;
	    t.tokenize(queryString, start, -1);
        parseVersionDeclaration();
        parseProlog();
        Expression exp = parseExpression();
        if (t.currentToken != terminator) {
            grumble("Unexpected token " + currentTokenDisplay() + " beyond end of query");
        }
        if (errorCount==0) {
            try {
                setLocation(exp);
                env.bindUnboundFunctionCalls();
                env.fixupGlobalVariables(env.getNumberOfGlobalVariables());
                env.fixupGlobalFunctions();
                exp = exp.simplify();
                exp = exp.analyze(env);
                int slots = ExpressionTool.allocateSlots(exp, 0);
                env.allocateLocalSlots(slots);
            } catch (XPathException err) {
                try {
                    env.getConfiguration().getErrorListener().fatalError(err);
                } catch (TransformerException err2) {
                    if (err2 instanceof XPathException) {
                        throw (XPathException)err2;
                    } else {
                        throw new XPathException.Static(err2);
                    }
                }
            }
        }
        if (errorCount==0) {
            return exp;
        } else {
            throw new XPathException.Static("Query Parsing failed");
        }
    }

    /**
     * Parse a library module.
     * Prolog? Expression
     * @param queryString   The text of the library module.
     * @param env           The static context. The result of parsing
     * a library module is that the static context is populated with a set of function
     * declarations and variable declarations. Each library module must have its own
     * static context objext.
     * @param firstSlot     The integer position of the first slot to be allocated to global variables
     * declared in this module
     * @throws XPathException.Static if the expression contains a syntax error
     */

    public final void parseLibraryModule(String queryString, StaticQueryContext env, int firstSlot)
    throws XPathException.Static {
        this.env = env;
        numberOfRangeVariables = 0;
        t = new Tokenizer();
	    t.tokenize(queryString, 0, -1);
        parseVersionDeclaration();
        parseModuleDeclaration();
        parseProlog();
        if (errorCount == 0) {
            env.bindUnboundFunctionCalls();
            env.fixupGlobalVariables(firstSlot);
            env.fixupGlobalFunctions();
        }
        if (errorCount != 0) {
            throw new XPathException.Static("Query parsing failed");
        }
    }

     /**
     * Report a parsing error
     *
     * @param message the error message
     * @exception XPathException.Static always thrown: an exception containing the
     *     supplied message
     */

    protected void grumble(String message) throws XPathException.Static {
        errorCount++;
        String s = t.recentText();
        int line = t.getLineNumber();
        String lineInfo = "on line " + line + " ";
        String module = ((StaticQueryContext)env).getModuleNamespace();
        lineInfo += (module==null ? "" : "of " + module + " ");
        String prefix = getLanguage() + " syntax error " + lineInfo +
                    (message.startsWith("...") ? "near" : "in") +
                     " `" + s + "`:\n    ";
         XPathException exception = new XPathException.Static(prefix + message);
         try {
             env.getConfiguration().getErrorListener().error(exception);
         } catch (TransformerException err) {
             if (err instanceof XPathException.Static) {
                 throw (XPathException.Static) err;
             } else {
                 throw new XPathException.Static(err);
             }
         }
         throw new XPathException.Static("XQuery syntax error");
    }

    /**
     * Set location information on an expression. At present this consists of a simple
     * line number. Needed mainly for XQuery. This version of the method supplies an
     * explicit line number.
     */

    protected void setLocation(Expression exp, int line, Executable executable) {
        if (exp instanceof ComputedExpression) {
            ((ComputedExpression)exp).setLineNumber((short)line);
        }
        if (exp instanceof Instruction) {
            ((Instruction)exp).setSourceLocation(0, line);
            ((Instruction)exp).setExecutable(executable);
        }
    }

    /**
     * Get the executable containing this expression. Returns null for XPath: needed only for XQuery
     */

    public Executable getExecutable() {
        return executable;
    }

    /**
     * Set the executable used for this query expression
     */

    public void setExecutable(Executable exec) {
        executable = exec;
    }

     /**
     * Parse the version declaration if present.
     * @throws XPathException.Static  in the event of a syntax error.
     */
    private void parseVersionDeclaration() throws XPathException.Static {
        if (t.currentToken == Tokenizer.XQUERY_VERSION) {
            nextToken();
            expect(Tokenizer.STRING_LITERAL);
            if (!(t.currentTokenValue.equals("1.0"))) {
                grumble("XQuery version must be 1.0");
            }
            nextToken();
            expect(Tokenizer.SEMICOLON);
            nextToken();
        }
     }

    /**
     * In a library module, parse the module declaration
     * Syntax: <"module" "namespace"> prefix "=" uri ";"
     * @throws XPathException.Static  in the event of a syntax error.
     */

    private void parseModuleDeclaration() throws XPathException.Static {
        expect(Tokenizer.MODULE_NAMESPACE);
        nextToken();
        expect(Tokenizer.NAME);
        String prefix = t.currentTokenValue;
        nextToken();
        expect(Tokenizer.EQUALS);
        nextToken();
        expect(Tokenizer.STRING_LITERAL);
        String uri = t.currentTokenValue;
        nextToken();
        expect(Tokenizer.SEMICOLON);
        nextToken();
        ((StaticQueryContext)env).declarePassiveNamespace(prefix, uri);
        ((StaticQueryContext)env).setModuleNamespace(uri);
    }

    /**
     * Parse the query prolog. This method, and its subordinate methods which handle
     * individual declarations in the prolog, cause the static context to be updated
     * with relevant context information. On exit, t.currentToken is the first token
     * that is not recognized as being part of the prolog.
     * @throws XPathException.Static  in the event of a syntax error.
     */

    private void parseProlog() throws XPathException.Static {
        boolean allowSetters = true;
        boolean allowModuleDecl = true;
        while (true) {
            try {
                if (t.currentToken == Tokenizer.MODULE_NAMESPACE) {
                    String uri = ((StaticQueryContext)env).getModuleNamespace();
                    if (uri==null) {
                        grumble("Module declaration should not be used in a main module");
                    } else {
                        grumble("Module declaration appears more than once");
                    }
                    if (!allowModuleDecl) {
                        grumble("Module declaration must precede other declarations in the query prolog");
                    }
                }
                allowModuleDecl = false;
                if (t.currentToken == Tokenizer.DECLARE_NAMESPACE) {
                    allowSetters = false;
                    parseNamespaceDeclaration();
                } else if (t.currentToken == Tokenizer.DECLARE_DEFAULT) {
                    nextToken();
                    expect(Tokenizer.NAME);
                    if (!allowSetters) {
                        grumble("'declare default " + t.currentTokenValue +
                                "' must appear earlier in the query prolog");
                    }
                    if (t.currentTokenValue == "element") {
                        parseDefaultElementNamespace();
                    } else if (t.currentTokenValue == "function") {
                        parseDefaultFunctionNamespace();
                    } else if (t.currentTokenValue == "collation") {
                        parseDefaultCollation();
                    } else {
                        grumble("After 'declare default', expected 'element', 'function', or 'collation'");
                    }
                } else if (t.currentToken == Tokenizer.DECLARE_XMLSPACE) {
                    if (!allowSetters) {
                        grumble("'declare xmlspace' must appear earlier in the query prolog");
                    }
                    parseXmlSpaceDeclaration();
                } else if (t.currentToken == Tokenizer.DECLARE_BASEURI) {
                    if (!allowSetters) {
                        grumble("'declare base-uri' must appear earlier in the query prolog");
                    }
                    parseBaseURIDeclaration();
                } else if (t.currentToken == Tokenizer.IMPORT_SCHEMA) {
                    allowSetters = false;
                    parseSchemaImport();
                } else if (t.currentToken == Tokenizer.IMPORT_MODULE) {
                    allowSetters = false;
                    parseModuleImport();
                } else if (t.currentToken == Tokenizer.DECLARE_VARIABLE) {
                    allowSetters = false;
                    parseVariableDeclaration();
                } else if (t.currentToken == Tokenizer.DECLARE_FUNCTION) {
                    allowSetters = false;
                    parseFunctionDeclaration();
                } else if (t.currentToken == Tokenizer.DECLARE_VALIDATION) {
                    if (!allowSetters) {
                        grumble("'declare validation' must appear earlier in the query prolog");
                    }
                    parseValidationDeclaration();
                } else {
                    break;
                }
                expect(Tokenizer.SEMICOLON);
                nextToken();
            } catch (XPathException.Static err) {
                // we've reported an error, attempt to recover by skipping to the
                // next semicolon
                while (t.currentToken != Tokenizer.SEMICOLON) {
                    nextToken();
                    if (t.currentToken == Tokenizer.EOF) {
                        return;
                    } else if (t.currentToken == Tokenizer.RCURLY) {
                        t.lookAhead();
                    } else if (t.currentToken == Tokenizer.TAG) {
                        parsePseudoXML(true);
                    }
                }
                nextToken();
            }
        }
    }

    private void parseDefaultCollation() throws XPathException.Static {
        // <"default" "collation"> StringLiteral
        nextToken();
        expect(Tokenizer.STRING_LITERAL);
        String uri = t.currentTokenValue;
        try {
            ((StaticQueryContext)env).declareDefaultCollation(uri);
        } catch (XPathException err) {
            grumble(err.getMessage());
        }
        nextToken();
    }

    /**
     * Parse the "declare xmlspace" declaration.
     * Syntax: <"declare" "xmlspace"> ("preserve" | "strip")
     * @throws XPathException.Static
     */

    private void parseXmlSpaceDeclaration() throws XPathException.Static {
        nextToken();
        //expect(Tokenizer.EQUALS);
        //t.setState(t.BARE_NAME_STATE);
        //nextToken();
        expect(Tokenizer.NAME);
        if (t.currentTokenValue.equals("preserve")) {
            preserveSpace = true;
        } else if (t.currentTokenValue.equals("strip")) {
            preserveSpace = false;
        } else {
            grumble("xmlspace must be 'preserve' or 'strip'");
        }
        //t.setState(t.DEFAULT_STATE);
        nextToken();
    }

    /**
     * Parse the "declare validation" declaration.
     * Syntax: <"declare" "validation"> ("strict" | "lax" | "skip")
     * @throws XPathException.Static
     */

    private void parseValidationDeclaration() throws XPathException.Static {
        nextToken();
        expect(Tokenizer.NAME);
        int val;
        if (t.currentTokenValue.equals("strict")) {
            val = Validation.STRICT;
        } else if (t.currentTokenValue.equals("lax")) {
            val = Validation.LAX;
        } else if (t.currentTokenValue.equals("skip")) {
            val = Validation.STRIP;
        } else {
            grumble("default validation mode must be 'strict', 'lax', or 'skip'");
            val = Validation.STRIP;
        }
        ((StaticQueryContext)env).pushValidationMode(val);
        nextToken();
    }

    /**
     * Parse (and process) the schema import declaration.
     * SchemaImport ::=	"import" "schema" SchemaPrefix? StringLiteral ("at" StringLiteral)?
     * SchemaPrefix ::=	("namespace" NCName "=") | ("default" "element" "namespace")
     */

    private void parseSchemaImport() throws XPathException.Static {
        if (!env.getConfiguration().isSchemaAware()) {
            grumble("To import a schema, you need the schema-aware version of Saxon");
        }
        String prefix = null;
        String namespaceURI = null;
        String locationURI = null;
        nextToken();
        if (isKeyword("namespace")) {
            nextToken();
            expect(Tokenizer.NAME);
            prefix = t.currentTokenValue;
            nextToken();
            expect(Tokenizer.EQUALS);
            nextToken();
        } else if (isKeyword("default")) {
            nextToken();
            if (!isKeyword("element")) {
                grumble("In 'import schema', expected 'element namespace'");
            }
            nextToken();
            if (!isKeyword("namespace")) {
                grumble("In 'import schema', expected keyword 'namespace'");
            }
            nextToken();
            prefix = "";
        }
        if (t.currentToken == Tokenizer.STRING_LITERAL) {
            namespaceURI = t.currentTokenValue;
            nextToken();
            if (isKeyword("at")) {
                nextToken();
                expect(Tokenizer.STRING_LITERAL);
                locationURI = t.currentTokenValue;
                nextToken();
            } else if (t.currentToken != Tokenizer.SEMICOLON) {
                grumble("After the target namespace URI, expected 'at' or ';'");
            }
        } else {
            grumble("After 'import schema', expected 'namespace', 'default', or a string-literal");
        }
        if (prefix != null) {
            if (prefix.equals("")) {
                ((StaticQueryContext)env).setDefaultElementNamespace(namespaceURI);
            } else {
                ((StaticQueryContext)env).declarePassiveNamespace(prefix, namespaceURI);
            }
        }

        // Do the importing


        Configuration config = env.getConfiguration();
        if (config.getSchema(namespaceURI)==null) {
            if (locationURI != null) {
                try {
                    namespaceURI = config.readSchema(env.getBaseURI(), locationURI, namespaceURI);
                } catch (TransformerException err) {
                    grumble("Error in schema. " + err.getMessage());
                }
            } else {
                grumble("Unable to locate requested schema");
            }
        }
        ((StaticQueryContext)env).addImportedSchema(namespaceURI);


    }


    /**
     * Parse (and expand) the module import declaration.
     * Syntax: <"import" "module" ("namespace" NCName "=")? uri ("at" uri)? ";"
     */

    private void parseModuleImport() throws XPathException.Static {
        StaticQueryContext thisModule = (StaticQueryContext)env;
        String prefix = null;
        String moduleURI = null;
        String locationURI = null;
        nextToken();
        if (t.currentToken == Tokenizer.NAME && t.currentTokenValue == "namespace") {
            nextToken();
            expect(Tokenizer.NAME);
            prefix = t.currentTokenValue;
            nextToken();
            expect(Tokenizer.EQUALS);
            nextToken();
        }
        if (t.currentToken == Tokenizer.STRING_LITERAL) {
            moduleURI = t.currentTokenValue;
            nextToken();
            if (isKeyword("at")) {
                nextToken();
                expect(Tokenizer.STRING_LITERAL);
                locationURI = t.currentTokenValue;
                nextToken();
            }
        } else {
            grumble("After 'import module', expected 'namespace' or a string-literal");
        }
        if (prefix != null) {
            thisModule.declarePassiveNamespace(prefix, moduleURI);
        }
        String thisModuleNS = thisModule.getModuleNamespace();
        if (thisModuleNS != null && thisModuleNS.equals(moduleURI)) {
            grumble("A module cannot import itself");
        }
        StaticQueryContext importedModule =
                thisModule.loadModule(moduleURI, locationURI, thisModule.getNumberOfGlobalVariables());

        // Do the importing

        short ns = importedModule.getModuleNamespaceCode();
        NamePool pool = env.getNamePool();
        Iterator it = importedModule.getFunctionDefinitions();
        while (it.hasNext()) {
            XQueryFunction def = (XQueryFunction)it.next();
            // don't import functions transitively
            if (pool.getURICode(def.getFunctionFingerprint()) == ns) {
                thisModule.declareFunction(def);
            }
        }
        it = importedModule.getVariableDeclarations();
        while (it.hasNext()) {
            VariableDeclaration def = (VariableDeclaration)it.next();
            // don't import variables transitively
            if (pool.getURICode(def.getVariableFingerprint()) == ns) {
                thisModule.declareVariable(def);
            }
        }
        thisModule.setNumberOfGlobalVariables(
                thisModule.getNumberOfGlobalVariables() +
                importedModule.getNumberOfGlobalVariables());

    }

    /**
     * Parse the Base URI declaration.
     * Syntax: <"declare" "base-uri"> string-literal
     * @throws XPathException.Static
     */

    private void parseBaseURIDeclaration() throws XPathException.Static {
        if (haveSeenBaseURI) {
            grumble("Base URI Declaration may only appear once");
        }
        haveSeenBaseURI = true;
        nextToken();
        expect(Tokenizer.STRING_LITERAL);
        String uri = t.currentTokenValue;
        ((StaticQueryContext)env).setBaseURI(uri);
        nextToken();
    }

    private boolean haveSeenBaseURI = false;

    /**
     * Parse the "default function namespace" declaration.
     * Syntax: <"declare" "default" "element" "namespace"> StringLiteral
     * @throws XPathException.Static to indicate a syntax error
     */

    private void parseDefaultFunctionNamespace() throws XPathException.Static {
        nextToken();
        expect(Tokenizer.NAME);
        if (!t.currentTokenValue.equals("namespace")) {
            grumble("After 'declare default function', expected 'namespace'");
        }
        nextToken();
        expect(Tokenizer.STRING_LITERAL);
        String uri = t.currentTokenValue;
        ((StaticQueryContext)env).setDefaultFunctionNamespace(uri);
        //t.setState(t.DEFAULT_STATE);
        nextToken();
    }

    /**
     * Parse the "default element namespace" declaration.
     * Syntax: <"declare" "default" "element" "namespace"> StringLiteral
     * @throws XPathException.Static  to indicate a syntax error
     */

    private void parseDefaultElementNamespace() throws XPathException.Static {
        nextToken();
        expect(Tokenizer.NAME);
        if (!t.currentTokenValue.equals("namespace")) {
            grumble("After 'declare default element', expected 'namespace'");
        }
        nextToken();
        expect(Tokenizer.STRING_LITERAL);
        String uri = t.currentTokenValue;
        ((StaticQueryContext)env).setDefaultElementNamespace(uri);
        //t.setState(t.DEFAULT_STATE);
        nextToken();
    }

    /**
     * Parse a namespace declaration in the Prolog.
     * Syntax: <"declare" "namespace"> NCName "=" StringLiteral
     * @throws XPathException.Static
     */

    private void parseNamespaceDeclaration() throws XPathException.Static {
        nextToken();
        expect(Tokenizer.NAME);
        String prefix = t.currentTokenValue;
        if (!XMLChar.isValidNCName(prefix)) {
            grumble("Invalid namespace prefix " + Err.wrap(prefix));
        }
        nextToken();
        expect(Tokenizer.EQUALS);
        nextToken();
        expect(Tokenizer.STRING_LITERAL);
        String uri = t.currentTokenValue;
        ((StaticQueryContext)env).declarePassiveNamespace(prefix, uri);
        //t.setState(t.DEFAULT_STATE);
        nextToken();
    }

    /**
     * Parse a global variable definition.
     *     <"declare" "variable" "$"> VarName TypeDeclaration?
     *         (("{" Expr "}") | "external")
     * @throws XPathException.Static
     */

    private void parseVariableDeclaration() throws XPathException.Static {
        GlobalVariableDefinition var = new GlobalVariableDefinition();
        var.setLineNumber(t.getLineNumber());
        nextToken();
        expect(Tokenizer.DOLLAR);
        t.setState(t.BARE_NAME_STATE);
        nextToken();
        expect(Tokenizer.NAME);
        String varName = t.currentTokenValue;
        var.setVariableName(varName);
        int varNameCode = makeNameCode(t.currentTokenValue, false);
        int varFingerprint = varNameCode & 0xfffff;
        var.setFingerprint(varFingerprint);

        nextToken();
        SequenceType requiredType = SequenceType.ANY_SEQUENCE;
        if (isKeyword("as")) {
            t.setState(t.SEQUENCE_TYPE_STATE);
            nextToken();
            requiredType = parseSequenceType();
        }
        var.setRequiredType(requiredType);

        //t.setState(t.BARE_NAME_STATE);
        if (t.currentToken == Tokenizer.LCURLY) {
            t.setState(t.DEFAULT_STATE);
            nextToken();
            Expression exp = parseExpression();
            var.setIsParameter(false);
            var.setValueExpression(exp);
            expect(Tokenizer.RCURLY);
            lookAhead();  // must be done manually after an RCURLY
        } else if (t.currentToken == Tokenizer.NAME) {
            if (t.currentTokenValue.equals("external")) {
                var.setIsParameter(true);
            } else {
                grumble("Variable must either be initialized or be declared as external");
            }
        } else {
            grumble("Expected '{' or 'external' in variable declaration");
        }
        //t.setState(t.DEFAULT_STATE);
        nextToken();

        // we recognize the pragma (:: pragma saxon:default value ::) where value is a numeric or string literal
        AtomicValue defaultValue = null;
        while (t.lastPragma != null) {
            try {
                StringTokenizer tok = new StringTokenizer(t.lastPragma);
                t.lastPragma = null;
                if (tok.hasMoreTokens()) {
                    String qname = tok.nextToken();
                    String[] parts = Name.getQNameParts(qname);
                    if (!parts[1].equals("default")) break;
                    try {
                        if (!env.getURIForPrefix(parts[0]).equals(NamespaceConstant.SAXON)) {
                            break;
                        }
                    } catch (XPathException err) {
                        grumble("Unrecognized namespace prefix in pragma name {" + qname + "}");
                        break;
                    }
                }
                if (tok.hasMoreTokens()) {
                    String value = tok.nextToken();
                    if (value.charAt(0)=='"' || value.charAt(0)=='\'') {
                        defaultValue = new StringValue(value.substring(1, value.length()-1));
                    } else {
                        try {
                            defaultValue = new StringValue(value).convert(Type.NUMBER);
                        } catch (XPathException e) {
                            grumble("Default value of query parameter must be a string or numeric literal");
                        }
                    }
                }
            } catch (QNameException err) { }
        }
        var.setRequiredType(requiredType);
        if (defaultValue != null) {
            var.setValueExpression(defaultValue);
        }
        StaticQueryContext qenv = (StaticQueryContext)env;
        if (qenv.getModuleNamespace() != null &&
                env.getNamePool().getURICode(varFingerprint) != qenv.getModuleNamespaceCode()) {
            grumble("Variable " + Err.wrap(varName, Err.VARIABLE) + " is not defined in the module namespace");
        }
        try {
            qenv.declareVariable(var);
        } catch (XPathException e) {
            grumble(e.getMessage());
        }
    }

    /**
     * Parse a function declaration.
     * <p>Syntax:<br/>
     * <"declare" "function"> <QName "("> ParamList? (")" | (<")" "as"> SequenceType))
     *       (EnclosedExpr | "external")
     * </p>
     * <p>On entry, the "define function" has already been recognized</p>
     * @throws XPathException.Static if a syntax error is found
     */

    private void parseFunctionDeclaration() throws XPathException.Static {
        // the next token should be the < QNAME "("> pair
        nextToken();
        expect(Tokenizer.FUNCTION);

        if (t.currentTokenValue.indexOf(':') < 0) {
            grumble("Saxon requires user-defined functions to have a namespace prefix");
        }

        XQueryFunction func = new XQueryFunction();
        func.displayName = t.currentTokenValue;
        func.fingerprint = makeNameCode(t.currentTokenValue, false) & 0xfffff;
        func.arguments = new ArrayList();
        func.resultType = SequenceType.ANY_SEQUENCE;
        func.body = null;
        func.lineNumber = t.getLineNumber();


        nextToken();
        HashSet paramNames = new HashSet();
        while (t.currentToken != Tokenizer.RPAR) {
            //     ParamList   ::=     Param ("," Param)*
            //     Param       ::=     "$" VarName  TypeDeclaration?
            expect(Tokenizer.DOLLAR);
            nextToken();
            expect(Tokenizer.NAME);
            String argName = t.currentTokenValue;
            int fingerprint = makeNameCode(argName, false) & 0xfffff;
            Integer f = new Integer(fingerprint);
            if (paramNames.contains(f)) {
                grumble("Duplicate parameter name " + Err.wrap(t.currentTokenValue, Err.VARIABLE));
            }
            paramNames.add(f);
            SequenceType paramType = SequenceType.ANY_SEQUENCE;
            nextToken();
            if (t.currentToken == Tokenizer.NAME && t.currentTokenValue.equals("as")) {
                nextToken();
                paramType = parseSequenceType();
            }

            RangeVariableDeclaration arg = new RangeVariableDeclaration();
            arg.setVariableFingerprint(fingerprint);
            arg.setRequiredType(paramType);
            arg.setVariableName(argName);
            func.arguments.add(arg);
            declareRangeVariable(arg);
            if (t.currentToken == Tokenizer.RPAR) {
                break;
            } else if (t.currentToken == Tokenizer.COMMA) {
                nextToken();
            } else {
                grumble("Expected ',' or ')' after function argument, found '" +
                        Tokenizer.tokens[t.currentToken] + "'");
            }
        }
        t.setState(t.BARE_NAME_STATE);
        nextToken();
        if (isKeyword("as")) {
            t.setState(t.SEQUENCE_TYPE_STATE);
            nextToken();
            func.resultType = parseSequenceType();
        }
        if (isKeyword("external")) {
            grumble("Saxon does not allow external functions to be declared");
        } else {
            expect(Tokenizer.LCURLY);
            t.setState(t.DEFAULT_STATE);
            nextToken();
            func.body = parseExpression();
            expect(Tokenizer.RCURLY);
            lookAhead();  // must be done manually after an RCURLY
        }
        for (int i=0; i<func.arguments.size(); i++) {
            undeclareRangeVariable();
        }
        t.setState(t.DEFAULT_STATE);
        nextToken();

        StaticQueryContext qenv = (StaticQueryContext)env;
        if (qenv.getModuleNamespace() != null &&
                env.getNamePool().getURICode(func.fingerprint) != qenv.getModuleNamespaceCode()) {
            grumble("Function " + Err.wrap(func.displayName, Err.FUNCTION) + " is not defined in the module namespace");
        }
        try {
            qenv.declareFunction(func);
        } catch (XPathException e) {
            grumble(e.getMessage());
        }

    }

    /**
     * Parse a FLWOR expression. This replaces the XPath "for" expression.
     * Full syntax:
     * <p>
     * [41] FLWORExpr ::=  (ForClause  | LetClause)+
     *                     WhereClause? OrderByClause?
     *                     "return" ExprSingle
     * [42] ForClause ::=  <"for" "$"> VarName TypeDeclaration? PositionalVar? "in" ExprSingle
     *                     ("," "$" VarName TypeDeclaration? PositionalVar? "in" ExprSingle)*
     * [43] PositionalVar  ::= "at" "$" VarName
     * [44] LetClause ::= <"let" "$"> VarName TypeDeclaration? ":=" ExprSingle
     *                    ("," "$" VarName TypeDeclaration? ":=" ExprSingle)*
     * [45] WhereClause  ::= "where" Expr
     * [46] OrderByClause ::= (<"order" "by"> | <"stable" "order" "by">) OrderSpecList
     * [47] OrderSpecList ::= OrderSpec  ("," OrderSpec)*
     * [48] OrderSpec     ::=     ExprSingle  OrderModifier
     * [49] OrderModifier ::= ("ascending" | "descending")?
     *                        (<"empty" "greatest"> | <"empty" "least">)?
     *                        ("collation" StringLiteral)?
     * </p>
     * @exception XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected Expression parseForExpression() throws XPathException.Static {
        Expression whereCondition = null;
        //boolean stableOrder = false;
        List clauseList = new ArrayList();
        while (true) {
            if (t.currentToken == Tokenizer.FOR) {
                parseForClause(clauseList);
            } else if (t.currentToken == Tokenizer.LET) {
                parseLetClause(clauseList);
            } else {
                break;
            }
        }
        if (t.currentToken==Tokenizer.WHERE || isKeyword("where")) {
            nextToken();
            whereCondition = parseExpression();
        }
        if (isKeyword("stable")) {
            // we read the "stable" keyword but ignore it; Saxon ordering is always stable
            nextToken();
            if (!isKeyword("order")) {
                grumble("'stable' must be followed by 'order by'");
            }
        }
        List sortSpecList = null;
        if (isKeyword("order")) {
            t.setState(t.BARE_NAME_STATE);
            nextToken();
            if (!isKeyword("by")) {
                grumble("'order' must be followed by 'by'");
            }
            t.setState(t.DEFAULT_STATE);
            nextToken();
            sortSpecList = parseSortDefinition();
        }
        expect(Tokenizer.RETURN);
        t.setState(t.DEFAULT_STATE);
        nextToken();
        Expression action = parseExprSingle();

        // if there is a "where" condition, we implement this by wrapping an if/then/else
        // around the "return" expression. No clever optimization yet!

        if (whereCondition != null) {
             action = new IfExpression(whereCondition, action, EmptySequence.getInstance());
             setLocation(action);
        }

        // If there is an order by clause, we modify the "return" expression so that it
        // returns a tuple containing the actual return value, plus the value of
        // each of the sort keys. We then wrap the entire FLWR expression inside a
        // TupleSorter that sorts the stream of tuples according to the sort keys,
        // discarding the sort keys and returning only the true result. The tuple
        // is implemented as a Java object wrapped inside an ObjectValue, which is
        // a general-purpose wrapper for objects that don't fit in the XPath type system.

        if (sortSpecList != null) {
            TupleExpression exp = new TupleExpression(1+sortSpecList.size());
            setLocation(exp);
            exp.setExpression(0, action);
            for (int i=0; i<sortSpecList.size(); i++) {
                try {
                    Expression sk =
                            TypeChecker.staticTypeCheck(
                                    ((SortSpec)sortSpecList.get(i)).sortKey,
                                    SequenceType.OPTIONAL_ATOMIC,
                                    false,
                                    new RoleLocator(RoleLocator.ORDER_BY, "FLWR", i));
                    exp.setExpression(i+1, sk);
                } catch (XPathException.Type err) {
                    grumble(err.getMessage());
                }
            }
            action = exp;
        }

        for (int i = clauseList.size()-1; i>=0; i--) {
            Object clause = clauseList.get(i);
            if (clause instanceof ExpressionParser.ForClause) {
                ExpressionParser.ForClause fc = (ExpressionParser.ForClause)clause;
                ForExpression exp = new ForExpression();
                exp.setVariableDeclaration(fc.rangeVariable);
                exp.setPositionVariable(fc.positionVariable);
                exp.setLineNumber((short)fc.lineNumber);
                exp.setSequence(fc.sequence);
                exp.setAction(action);
                action = exp;
            } else {
                LetClause lc = (LetClause)clause;
                LetExpression exp = new LetExpression();
                exp.setVariableDeclaration(lc.variable);
                exp.setLineNumber((short)lc.lineNumber);
                exp.setSequence(lc.value);
                exp.setAction(action);
                action = exp;
            }
        }

        // Now wrap the whole expression in a TupleSorter if there is a sort
        // specification

        if (sortSpecList != null) {
            FixedSortKeyDefinition[] keys = new FixedSortKeyDefinition[sortSpecList.size()];
            for (int i=0; i<sortSpecList.size(); i++) {
                SortSpec spec = (SortSpec)sortSpecList.get(i);
                FixedSortKeyDefinition key = new FixedSortKeyDefinition();
                key.setSortKey(((SortSpec)sortSpecList.get(i)).sortKey);
                key.setOrder(new StringValue(spec.ascending ? "ascending" : "descending"));
                key.setEmptyFirst(spec.ascending ? spec.emptyLeast : !spec.emptyLeast);
                try {
                    if (spec.collation != null) {
                        key.setCollation(env.getCollation(spec.collation));
                    }
                    key.bindComparer();
                    keys[i] = key;
                } catch (XPathException e) {
                    grumble(e.getMessage());
                }
            }
            TupleSorter sorter = new TupleSorter(action, keys);
            setLocation(sorter);
            action = sorter;
        }

        // undeclare all the range variables

        for (int i = clauseList.size()-1; i>=0; i--) {
            Object clause = clauseList.get(i);
            if ((clause instanceof ExpressionParser.ForClause) &&
                    ((ExpressionParser.ForClause)clause).positionVariable != null) {
                    // undeclare the "at" variable if it was declared
                undeclareRangeVariable();
            }
                // undeclare the primary variable
            undeclareRangeVariable();
        }

        return action;

    }

    /**
     * Parse a ForClause.
     * <p>
     * [42] ForClause ::=  <"for" "$"> VarName TypeDeclaration? PositionalVar? "in" ExprSingle
     *                     ("," "$" VarName TypeDeclaration? PositionalVar? "in" ExprSingle)*
     * </p>
     * @param clauseList - the components of the parsed ForClause are appended to the
     * supplied list
     * @throws XPathException.Static
     */
    private void parseForClause(List clauseList) throws XPathException.Static {
        do {
            ExpressionParser.ForClause clause = new ExpressionParser.ForClause();
            clause.lineNumber = t.getLineNumber();
            clauseList.add(clause);
            nextToken();
            expect(Tokenizer.DOLLAR);
            nextToken();
            expect(Tokenizer.NAME);
            String var = t.currentTokenValue;

            RangeVariableDeclaration v = new RangeVariableDeclaration();
            v.setVariableFingerprint(makeNameCode(var, false) & 0xfffff);
            v.setRequiredType(SequenceType.SINGLE_ITEM);
            v.setVariableName(var);
            clause.rangeVariable = v;
            nextToken();

            if (isKeyword("as")) {
                nextToken();
                SequenceType type = parseSequenceType();
                v.setRequiredType(type);
                if (type.getCardinality() != StaticProperty.EXACTLY_ONE) {
                    grumble("Cardinality of range variable must be exactly one");
                }
            }
            clause.positionVariable = null;
            if (isKeyword("at")) {
                nextToken();
                expect(Tokenizer.DOLLAR);
                nextToken();
                expect(Tokenizer.NAME);
                RangeVariableDeclaration pos = new RangeVariableDeclaration();
                pos.setVariableFingerprint(makeNameCode(t.currentTokenValue, false) & 0xfffff);
                pos.setRequiredType(SequenceType.SINGLE_INTEGER);
                pos.setVariableName(t.currentTokenValue);
                clause.positionVariable = pos;
                declareRangeVariable(pos);
                nextToken();
            }
            expect(Tokenizer.IN);
            nextToken();
            clause.sequence = parseExprSingle();
            declareRangeVariable(clause.rangeVariable);
            if (clause.positionVariable != null) {
                declareRangeVariable(clause.positionVariable);
            }
        } while (t.currentToken==Tokenizer.COMMA);
    }

    /**
     * Parse a LetClause.
     * <p>
     * [44] LetClause ::= <"let" "$"> VarName TypeDeclaration? ":=" ExprSingle
     *                    ("," "$" VarName TypeDeclaration? ":=" ExprSingle)*
     * </p>
     * @param clauseList - the components of the parsed LetClause are appended to the
     * supplied list
     * @throws XPathException.Static
     */
    private void parseLetClause(List clauseList) throws XPathException.Static {
        do {
            LetClause clause = new LetClause();
            clause.lineNumber = t.getLineNumber();
            clauseList.add(clause);
            nextToken();
            expect(Tokenizer.DOLLAR);
            nextToken();
            expect(Tokenizer.NAME);
            String var = t.currentTokenValue;

            RangeVariableDeclaration v = new RangeVariableDeclaration();
            v.setVariableFingerprint(makeNameCode(var, false) & 0xfffff);
            v.setRequiredType(SequenceType.ANY_SEQUENCE);
            v.setVariableName(var);
            clause.variable = v;
            nextToken();

            if (isKeyword("as")) {
                nextToken();
                v.setRequiredType(parseSequenceType());
            }

            expect(Tokenizer.ASSIGN);
            nextToken();
            clause.value = parseExprSingle();
            declareRangeVariable(v);
        } while (t.currentToken==Tokenizer.COMMA);
    }

    private static class LetClause {
        public RangeVariableDeclaration variable;
        public Expression value;
        public int lineNumber;
    }

    /**
     * Parse the "order by" clause.
     * [46] OrderByClause ::= (<"order" "by"> | <"stable" "order" "by">) OrderSpecList
     * [47] OrderSpecList ::= OrderSpec  ("," OrderSpec)*
     * [48] OrderSpec     ::=     ExprSingle  OrderModifier
     * [49] OrderModifier ::= ("ascending" | "descending")?
     *                        (<"empty" "greatest"> | <"empty" "least">)?
     *                        ("collation" StringLiteral)?
     * @return a list of sort specifications (SortSpec), one per sort key
     * @throws XPathException.Static
     */
    private List parseSortDefinition() throws XPathException.Static {
        List sortSpecList = new ArrayList();
        while (true) {
            SortSpec sortSpec = new SortSpec();
            sortSpec.sortKey = parseExprSingle();
            sortSpec.ascending = true;
            sortSpec.emptyLeast = true;
            sortSpec.collation = env.getDefaultCollationName();
            //t.setState(t.BARE_NAME_STATE);
            if (isKeyword("ascending")) {
                nextToken();
            } else if (isKeyword("descending")) {
                sortSpec.ascending = false;
                nextToken();
            }
            if (isKeyword("empty")) {
                nextToken();
                if (isKeyword("greatest")) {
                    sortSpec.emptyLeast = false;
                    nextToken();
                } else if (isKeyword("least")) {
                    sortSpec.emptyLeast = true;
                    nextToken();
                } else {
                    grumble("'empty' must be followed by 'greatest' or 'least'");
                }
            }
            if (isKeyword("collation")) {
                nextToken();
                expect(Tokenizer.STRING_LITERAL);
                sortSpec.collation = t.currentTokenValue;
                nextToken();
            }
            sortSpecList.add(sortSpec);
            if (t.currentToken == Tokenizer.COMMA) {
                nextToken();
            } else {
                break;
            }
        }
        return sortSpecList;
    }

    private static class SortSpec {
        public Expression sortKey;
        public boolean ascending;
        public boolean emptyLeast;
        public String collation;
    }

    /**
     * Parse a Typeswitch Expression.
     * This construct is XQuery-only.
     * TypeswitchExpr   ::=
     *       "typeswitch" "(" Expr ")"
     *            CaseClause+
     *            "default" ("$" VarName)? "return" ExprSingle
     * CaseClause   ::=
     *       "case" ("$" VarName "as")? SequenceType "return" Expr
     */

    protected Expression parseTypeswitchExpression() throws XPathException.Static {

        // On entry, the "(" has already been read

        nextToken();
        Expression operand = parseExpression();
        List types = new ArrayList();
        List actions = new ArrayList();
        expect(Tokenizer.RPAR);
        nextToken();

        // The code generated takes the form:
        //    let $zzz := operand return
        //    if ($zzz instance of t1) then action1
        //    else ($zzz instance of t2) then action2
        //    else default-action
        //
        // If a variable is declared in a case clause or default clause,
        // then "action-n" takes the form
        //    let $v as type := $zzz return action-n

        LetExpression outerLet = new LetExpression();

        RangeVariableDeclaration gen = new RangeVariableDeclaration();
        gen.setVariableFingerprint(makeNameCode("typeswitchVar", false) & 0xfffff);
        gen.setRequiredType(SequenceType.ANY_SEQUENCE);
        gen.setVariableName("typeswitchVar");

        outerLet.setVariableDeclaration(gen);
        outerLet.setSequence(operand);

        while (t.currentToken == Tokenizer.CASE) {
            SequenceType type;
            Expression action;
            nextToken();
            if (t.currentToken == Tokenizer.DOLLAR) {
                nextToken();
                expect(Tokenizer.NAME);
                String var = t.currentTokenValue;
                nextToken();
                expect(Tokenizer.NAME);
                if (!t.currentTokenValue.equals("as")) {
                    grumble("After 'case $" + var + "', expected 'as'");
                }
                nextToken();
                type = parseSequenceType();
                action = parseTypeswitchReturnClause(var, type, gen);

            } else {
                type = parseSequenceType();
                t.treatCurrentAsOperator();
                expect(Tokenizer.RETURN);
                nextToken();
                action = parseExprSingle();
            }
            types.add(type);
            actions.add(action);
        }
        if (types.size() == 0) {
            grumble("At least one case clause is required in a typeswitch");
        }
        expect(Tokenizer.DEFAULT);
        nextToken();
        Expression defaultAction;
        if (t.currentToken == Tokenizer.DOLLAR) {
            nextToken();
            expect(Tokenizer.NAME);
            String var = t.currentTokenValue;
            nextToken();
            defaultAction = parseTypeswitchReturnClause(var, SequenceType.ANY_SEQUENCE, gen);
        } else {
            t.treatCurrentAsOperator();
            expect(Tokenizer.RETURN);
            nextToken();
            defaultAction = parseExprSingle();
        }

        Expression lastAction = defaultAction;
        for (int i=types.size()-1; i>=0; i--) {
            IfExpression ife =
                    new IfExpression(
                            new InstanceOfExpression(
                                    new VariableReference(gen),
                                    (SequenceType)types.get(i)
                            ),
                            (Expression)actions.get(i),
                            lastAction);
            lastAction = ife;
        }
        outerLet.setAction(lastAction);
        return outerLet;
    }

    private Expression parseTypeswitchReturnClause(String var, SequenceType type, RangeVariableDeclaration gen) throws XPathException.Static {
        Expression action;
        t.treatCurrentAsOperator();
        expect(Tokenizer.RETURN);
        nextToken();

        RangeVariableDeclaration v = new RangeVariableDeclaration();
        v.setVariableFingerprint(makeNameCode(var, false) & 0xfffff);
        v.setRequiredType(type);
        v.setVariableName(var);

        declareRangeVariable(v);
        action = parseExprSingle();
        undeclareRangeVariable();

        LetExpression innerLet = new LetExpression();
        innerLet.setVariableDeclaration(v);
        innerLet.setSequence(new VariableReference(gen));
        innerLet.setAction(action);
        action = innerLet;
        return action;
    }

    /**
     * Parse a Validate Expression.
     * This construct is XQuery-only. The syntax allows:
     *   validate mode? context? { Expr }
     *   mode ::= "strict" | "lax" | "skip"
     *   context ::= "global" | "context" schemaContext
     */

    protected Expression parseValidateExpression() throws XPathException.Static {
        int mode = ((StaticQueryContext)env).getValidationMode();
        ValidationContext context = ((StaticQueryContext)env).getValidationContext();
        if (t.currentToken == Tokenizer.VALIDATE_STRICT ||
                t.currentToken == Tokenizer.VALIDATE_LAX ||
                t.currentToken == Tokenizer.VALIDATE_SKIP) {
            switch (t.currentToken) {
            case Tokenizer.VALIDATE_STRICT:
                mode = Validation.STRICT;
                break;
            case Tokenizer.VALIDATE_LAX:
                mode = Validation.LAX;
                break;
            case Tokenizer.VALIDATE_SKIP:
                mode = Validation.STRIP;
                break;
            }
            nextToken();

            if (t.currentToken == Tokenizer.KEYWORD_CURLY &&
                    t.currentTokenValue.equals("global")) {
                context = GlobalValidationContext.getInstance();
            } else if (isKeyword("context")) {
                nextToken();
                context = parseValidationContext();
                //nextToken();
            } else if (t.currentToken == Tokenizer.LCURLY) {
                // Use existing validation context
            }
            nextToken();
        } else if (t.currentToken == Tokenizer.VALIDATE_GLOBAL) {
            context = GlobalValidationContext.getInstance();
            nextToken();
            expect(Tokenizer.LCURLY);
            nextToken();
        } else if (t.currentToken == Tokenizer.VALIDATE_CONTEXT) {
            nextToken();
            context = parseValidationContext();
            nextToken();
        } else {
            // shouldn't be here...
        }

        ((StaticQueryContext)env).pushValidationMode(mode);
        ((StaticQueryContext)env).pushValidationContext(context);

        Expression exp = parseExpression();
        if (exp instanceof FixedElement || exp instanceof DocumentInstr) {
            // no need to invoke extra validation, it will be done automatically
        } else {
            // the expression must be a single element or document node. The type-
            // checking machinery can't handle a union type, so we just check that it's
            // a node for now. Because we are reusing XSLT copy-of code, we need
            // an ad-hoc check that the node is of the right kind.
            try {
                exp = TypeChecker.staticTypeCheck(
                                    exp,
                                    SequenceType.SINGLE_NODE,
                                    false,
                                    new RoleLocator(RoleLocator.TYPE_OP, "validate", 0));
            } catch (XPathException.Type err) {
                grumble(err.getMessage());
            }
            exp = new CopyOf(exp, true, mode, null);
            setLocation(exp);
            ((CopyOf)exp).setRequireDocumentOrElement(true);
            ((CopyOf)exp).setValidationContext(context);
        }

        expect(Tokenizer.RCURLY);
        t.lookAhead();      // always done manually after an RCURLY
        nextToken();
        ((StaticQueryContext)env).popValidationMode();
        ((StaticQueryContext)env).popValidationContext();
        return exp;
    }

    /**
     * Parse a validation context.
     * Syntax ( qname | type(qname) ) ( '/' qname )*
     */

    public ValidationContext parseValidationContext() throws XPathException.Static {
        //ValidationContext context = ((StaticQueryContext)env).getValidationContext();
        ValidationContext context = GlobalValidationContext.getInstance();
        Configuration config = env.getConfiguration();
        int fingerprint = -1;
        boolean isType = false;
        if (t.currentToken == Tokenizer.TYPETEST) {
            isType = true;
            nextToken();
            expect(Tokenizer.NAME);
            fingerprint = makeNameCode(t.currentTokenValue, true) & 0xfffff;
            nextToken();
            expect(Tokenizer.RPAR);
            //nextToken();
        } else {
            fingerprint = makeNameCode(t.currentTokenValue, true) & 0xfffff;
        }

        while (true) {
            try {
                context = config.getContainedValidationContext(context, fingerprint, isType);
            } catch (XPathException err) {
                grumble(err.getMessage());
                return null;
            }
            isType = false;
            if (context.isVoidValidationContext()) {
                grumble("Element " + Err.wrap(t.currentTokenValue, Err.ELEMENT) +
                        " cannot be used as validation context: element is undefined or has simple content");
            }
            if (t.currentToken == Tokenizer.KEYWORD_CURLY) {
                break;
            } else {
                nextToken();
                if (t.currentToken == Tokenizer.LCURLY) {
                    break;
                } else if (t.currentToken == Tokenizer.SLASH) {
                    nextToken();
                    fingerprint = makeNameCode(t.currentTokenValue, true) & 0xfffff;
                } else {
                    grumble("expected '/' or '{'");
                    return null;
                }
            }
        }
        return context;
    }

   /**
    * Parse a node constructor. This is allowed only in XQuery. This method handles
    * both the XML-like "direct" constructors, and the XQuery-based "computed"
    * constructors.
    * @return an Expression for evaluating the parsed constructor
    * @throws XPathException.Static in the event of a syntax error.
    */

    protected Expression parseConstructor() throws XPathException.Static {
        int line = t.getLineNumber();
        switch (t.currentToken) {
            case Tokenizer.TAG:
                Expression tag = parsePseudoXML(false);
                lookAhead();
                t.setState(t.OPERATOR_STATE);
                nextToken();
                return tag;
            case Tokenizer.KEYWORD_CURLY:
                String nodeKind = t.currentTokenValue;
                if (nodeKind.equals("validate")) {
                    return parseValidateExpression();

                } else if (nodeKind.equals("document")) {
                    nextToken();
                    Expression content = parseExpression();
                    expect(Tokenizer.RCURLY);
                    lookAhead();  // must be done manually after an RCURLY
                    nextToken();
                    DocumentInstr doc = new DocumentInstr(false, null, env.getBaseURI());
                    makeContentConstructor(content, doc, line);
                    return doc;

               } else if (nodeKind.equals("element")) {
                   nextToken();
                   // get the expression that yields the element name
                   Expression name = parseExpression();
                   expect(Tokenizer.RCURLY);
                   lookAhead();  // must be done manually after an RCURLY
                   nextToken();
                   expect(Tokenizer.LCURLY);
                   t.setState(Tokenizer.DEFAULT_STATE);
                   nextToken();
                   Expression content = null;
                   if (t.currentToken != Tokenizer.RCURLY) {
                       // get the expression that yields the element content
                       content = parseExpression();
                       // if the child expression creates another element,
                       // suppress validation, as the parent already takes care of it
                       if (content instanceof ElementCreator) {
                           ((ElementCreator)content).setValidationMode(Validation.PRESERVE);
                       }
                       expect(Tokenizer.RCURLY);
                   }
                   lookAhead();  // done manually after an RCURLY
                   nextToken();

                   ExprInstruction inst;
                   if (name instanceof Value) {
                       // if element name is supplied as a literal, treat it like a direct element constructor
                       int nameCode;
                       if (name instanceof StringValue) {
                           String lex = ((StringValue)name).getStringValue();
                           nameCode = makeNameCode(lex, true);
                       } else if (name instanceof QNameValue) {
                           nameCode = env.getNamePool().allocate("",
                                                                 ((QNameValue)name).getNamespaceURI(),
                                                                 ((QNameValue)name).getLocalName());
                       } else {
                           grumble("Element name must be either a string or a QName");
                           return null;
                       }
                       inst = new FixedElement(nameCode,
                                                ((StaticQueryContext)env).getActiveNamespaceCodes(),
                                                null,
                                                null,
                                                ((StaticQueryContext)env).getValidationMode());
                   } else {
                       // it really is a computed element constructor: save the namespace context
                       inst = new Element(name, null,
                               ((StaticQueryContext)env).getNamespaceContext(),
                               null, null,
                               ((StaticQueryContext)env).getValidationMode());
                   }

                   makeContentConstructor(content, inst, line);
                   if (env.getConfiguration().getTraceListener() != null) {
                       inst = new TraceInstruction(inst);
                   }
                   return inst;

               } else if (nodeKind.equals("attribute")) {
                   nextToken();
                   Expression name = parseExpression();
                   expect(Tokenizer.RCURLY);
                   lookAhead();  // must be done manually after an RCURLY
                   nextToken();
                   expect(Tokenizer.LCURLY);
                   t.setState(Tokenizer.DEFAULT_STATE);
                   nextToken();
                   Expression content = null;
                   if (t.currentToken != Tokenizer.RCURLY) {
                       content = parseExpression();
                       expect(Tokenizer.RCURLY);
                   }
                   lookAhead();  // after an RCURLY
                   nextToken();
                   Attribute att = new Attribute(
                           name,
                           null,
                           ((StaticQueryContext) env).getNamespaceContext(),
                           Validation.STRIP,
                           null,
                           -1);
                   att.setRejectDuplicates();
                   makeSimpleContent(content, att, line);
                   return att;

               } else if (nodeKind.equals("text")) {
                   nextToken();
                   if (t.currentToken == Tokenizer.RCURLY) {
                       lookAhead(); // after an RCURLY
                       nextToken();
                       return EmptySequence.getInstance();
                   } else {
                       Expression value = parseExpression();
                       expect(Tokenizer.RCURLY);
                       lookAhead(); // after an RCURLY
                       nextToken();
                       ValueOf vof = new ValueOf(stringify(value), false);
                       setLocation(vof, line, executable);
                       return vof;
                   }
               } else if (nodeKind.equals("comment")) {
                   nextToken();
                   if (t.currentToken == Tokenizer.RCURLY) {
                       lookAhead(); // after an RCURLY
                       nextToken();
                       return EmptySequence.getInstance();
                   } else {
                       Expression value = parseExpression();
                       expect(Tokenizer.RCURLY);
                       lookAhead(); // after an RCURLY
                       nextToken();
                       Comment com = new Comment();
                       makeSimpleContent(value, com, line);
                       return com;
                   }
               } else if (nodeKind.equals("processing-instruction")) {
                   nextToken();
                   Expression name = parseExpression();
                   expect(Tokenizer.RCURLY);
                   lookAhead();  // must be done manually after an RCURLY
                   nextToken();
                   expect(Tokenizer.LCURLY);
                   t.setState(Tokenizer.DEFAULT_STATE);
                   nextToken();
                   Expression content = null;
                   if (t.currentToken != Tokenizer.RCURLY) {
                       content = parseExpression();
                       expect(Tokenizer.RCURLY);
                   }
                   lookAhead();  // after an RCURLY
                   nextToken();
                   ProcessingInstruction pi = new ProcessingInstruction(name);
                   makeSimpleContent(content, pi, line);
                   return pi;

               } else {
                   grumble("Unrecognized node constructor " + t.currentTokenValue + "{}");

               }
           case Tokenizer.ELEMENT_QNAME:
               int nameCode = makeNameCode(t.currentTokenValue, true);
               Expression content = null;
               nextToken();
               if (t.currentToken != Tokenizer.RCURLY) {
                   content = parseExpression();
                   expect(Tokenizer.RCURLY);
               }
               lookAhead();  // after an RCURLY
               nextToken();
               FixedElement el2 = new FixedElement(nameCode,
                                                ((StaticQueryContext)env).getActiveNamespaceCodes(),
                                                null,
                                                null,
                                                ((StaticQueryContext)env).getValidationMode());
               makeContentConstructor(content, el2, line);
               if (env.getConfiguration().getTraceListener() != null) {
                   return new TraceInstruction(el2);
               }
               return el2;
           case Tokenizer.ATTRIBUTE_QNAME:
               int attNameCode = makeNameCode(t.currentTokenValue, false);
               //Expression attName = new StringValue(t.currentTokenValue);
               Expression attContent = null;
               nextToken();
               if (t.currentToken != Tokenizer.RCURLY) {
                   attContent = parseExpression();
                   expect(Tokenizer.RCURLY);
               }
               lookAhead();  // after an RCURLY
               nextToken();
               FixedAttribute att2 = new FixedAttribute(attNameCode,
                                                            Validation.STRIP,
                                                            null,
                                                            -1);
               att2.setRejectDuplicates();
               makeSimpleContent(attContent, att2, line);
               return att2;
           case Tokenizer.PI_QNAME:
               Expression piName = new StringValue(t.currentTokenValue);
               Expression piContent = null;
               nextToken();
               if (t.currentToken != Tokenizer.RCURLY) {
                   piContent = parseExpression();
                   expect(Tokenizer.RCURLY);
               }
               lookAhead();  // after an RCURLY
               nextToken();
               ProcessingInstruction pi2 = new ProcessingInstruction(piName);
               makeSimpleContent(piContent, pi2, line);
               return pi2;
       }
       return null;
    }

    /**
     * Make the instructions for the children of a node with simple content (attribute, text, PI, etc)
     * @param content
     * @param inst
     * @param line
     */

    private void makeSimpleContent(Expression content, SimpleNodeConstructor inst, int line) {
        if (content == null) {
            inst.setSelect(StringValue.EMPTY_STRING);
        } else {
            inst.setSelect(stringify(content));
        }
        setLocation(inst, line, executable);
    }

    /**
     * Make a sequence of instructions as the children of an element-construction instruction.
     * The idea here is to convert an XPath expression that "pulls" the content into a sequence
     * of XSLT-style instructions that push nodes directly onto the subtree, thus reducing the
     * need for copying of intermediate nodes.
     * @param content The content of the element as an expression
     * @param inst The element-construction instruction (Element or FixedElement)
     * @param line the line number in the query
     */
    private void makeContentConstructor(Expression content, ExprInstruction inst, int line) {
        if (content == null) {
            inst.setChildren(null);
        } else if (content instanceof AppendExpression) {
            List instructions = new ArrayList();
            convertAppendExpression((AppendExpression)content, instructions);
            inst.setChildren((Instr[])instructions.toArray(new Instr[instructions.size()]));
        } else if (content instanceof Instr) {
            Instr children[] = {(Instr)content};
            inst.setChildren(children);
        } else {
            Instruction[] children = new Instruction[1];
            SequenceInstruction seq = new SequenceInstruction(content, null);
            children[0] = seq;
            setLocation(seq, line, executable);
            inst.setChildren(children);
        }
        //InstructionWrapper wrap = new InstructionWrapper(el);
        setLocation(inst, line, executable);
    }

    /**
     * Convert an append expression into an equivalent sequence of instructions
     */

    private void convertAppendExpression(AppendExpression exp, List instructions) {
        Expression[] sub = exp.getSubExpressions();
        for (int i=0; i<sub.length; i++) {
            if (sub[i] instanceof AppendExpression) {
                convertAppendExpression((AppendExpression)sub[i], instructions);
            } else if (sub[i] instanceof Instr) {
                instructions.add(sub[i]);
            } else {
                SequenceInstruction seq = new SequenceInstruction(sub[i], null);
                if (sub[i] instanceof ComputedExpression) {
                    setLocation(seq, ((ComputedExpression)sub[i]).getLineNumber(), executable);
                } else {
                    setLocation(seq, exp.getLineNumber(), executable);
                }
                instructions.add(seq);
            }
        }
    }

    /**
     * Parse pseudo-XML syntax in direct element constructors, comments, CDATA, etc.
     * This is handled by reading single characters from the Tokenizer until the
     * end of the tag (or an enclosed expression) is enountered.
     * This method is also used to read an end tag. Because an end tag is not an
     * expression, the method in this case returns a StringValue containing the
     * contents of the end tag.
     * @param allowEndTag  true if the context allows an End Tag to appear here
     * @return an Expression representing the result of parsing the constructor.
     * If an end tag was read, its contents will be returned as a StringValue.
     */

    private Expression parsePseudoXML(boolean allowEndTag) throws XPathException.Static {
        Expression exp = null;
        int line = t.getLineNumber();
        char c = t.nextChar();
        switch (c) {
            case '!':
                c = t.nextChar();
                if (c=='-') {
                    exp = parseCommentConstructor();
                } else if (c=='[') {
                    exp = parseCDATAConstructor();
                } else {
                    grumble("Expected '--' or '[CDATA[' after '<!'");
                }
                break;
            case '?':
                exp = parsePIConstructor();
                break;
            case '/':
                if (allowEndTag) {
                    StringBuffer sb = new StringBuffer();
                    while (true) {
                        c = t.nextChar();
                        if (c == '>') break;
                        sb.append(c);
                    }
                    return new StringValue(sb);
                } else {
                    grumble("Unmatched XML end tag");
                }
                break;
            default:
                t.unreadChar();
                exp = parseDirectElementConstructor();
        }
        setLocation(exp, line, executable);
        return exp;
    }

    private Expression parseDirectElementConstructor() throws XPathException.Static {
        char c;
        StringBuffer buff = new StringBuffer();
        int namespaceCount = 0;
        while (true) {
            c = t.nextChar();
            if (c==' ' || c=='\n' || c=='\r' || c=='\t' || c=='/' || c=='>') {
                break;
            }
            buff.append(c);
        }
        String elname = buff.toString();
        HashMap attributes = new HashMap();
        while (true) {
            // loop through the attributes
            // We must process namespace declaration attributes first;
            // their scope applies to all preceding attribute names and values.
            // But finding the delimiting quote of an attribute value requires the
            // XPath expressions to be parsed, because they may contain nested quotes.
            // So we parse in "scanOnly" mode, which ignores any undeclared namespace
            // prefixes, use the result of this parse to determine the length of the
            // attribute value, save the value, and reparse it when all the namespace
            // declarations have been dealt with.
            c = skipSpaces(c);
            if (c=='/' || c=='>') {
                break;
            }
            buff.setLength(0);
            // read the attribute name
            while (true) {
                buff.append(c);
                c = t.nextChar();
                if (c==' ' || c=='\n' || c=='\r' || c=='\t' || c=='=') {
                    break;
                }
            }
            String attName = buff.toString();
            if (!Name.isQName(attName)) {
                grumble("Invalid attribute name " + Err.wrap(attName, Err.ATTRIBUTE));
            }
            c = skipSpaces(c);
            expectChar(c, '=');
            c = t.nextChar();
            c = skipSpaces(c);

            Expression avt;
            try {
                avt = AttributeValueTemplate.make(t.input, t.inputIndex, c, env, rangeVariables, true);
            } catch (XPathException err) {
                throw err.makeStatic();
            }
            // by convention, this returns the end position when called with scanOnly set
            int end = (int)((IntegerValue)avt).getValue();
            String val = t.input.substring(t.inputIndex, end);
            t.inputIndex = end + 1;
            // on return, the current character is the closing quote
            c = t.nextChar();
            if (!(c==' ' || c=='\n' || c=='\r' || c=='\t' || c=='/' || c=='>')) {
                grumble("There must be whitespace after every attribute except the last");
            }
            if (attName.equals("xmlns") || attName.startsWith("xmlns:")) {
                if (val.indexOf('{')>=0) {
                    grumble("Namespace URI must be a constant value");
                }
                String prefix, uri;
                if (attName.equals("xmlns")) {
                    prefix = "";
                    uri = val;
                } else {
                    prefix = attName.substring(6);
                    uri = val;
                    if (uri.equals("")) {
                        grumble("Namespace URI must not be empty");
                    }
                }
                namespaceCount++;
                ((StaticQueryContext)env).declareActiveNamespace(prefix, uri);
            }
            attributes.put(attName, val);
        }
        String namespace = null;
        int elNameCode = 0;
        try {
            String[] parts = Name.getQNameParts(elname);
            namespace =  ((StaticQueryContext)env).checkURIForPrefix(parts[0]);
            if (namespace == null) {
                grumble("Undeclared prefix in element name " + Err.wrap(elname, Err.ELEMENT));
            }
            elNameCode = env.getNamePool().allocate(parts[0], namespace, parts[1]);
        } catch (QNameException e) {
            grumble("Invalid element name " + Err.wrap(elname, Err.ELEMENT));
        }
        int validationMode = ((StaticQueryContext)env).getValidationMode();
        ValidationContext validationContext = ((StaticQueryContext)env).getValidationContext();
        if (validationMode == Validation.STRICT && validationContext.isVoidValidationContext()) {
            grumble("Element " + Err.wrap(elname, Err.ELEMENT) + " is not permitted in the current validation context");
        }
        FixedElement elInst = new FixedElement(
                            elNameCode,
                            ((StaticQueryContext)env).getActiveNamespaceCodes(),
                            null,
                            null,
                            validationMode);


        setLocation(elInst);
        if (env.getConfiguration().isSchemaAware()) {
            elInst.setValidationContext(validationContext);
            try {
                ((StaticQueryContext)env).setContainedValidationContext(elNameCode & 0xfffff);
            } catch (XPathException err) {
                grumble(err.getMessage());
            }
        }

        List contents = new ArrayList();

        for (Iterator iter = attributes.keySet().iterator(); iter.hasNext();) {
            String attName = (String)iter.next();
            String attValue = (String)attributes.get(attName);

            if (attName.equals("xmlns") || attName.startsWith("xmlns:")) {
                // do nothing
            } else {
                int attNameCode = 0;
                String attNamespace = null;
                try {
                    String[] parts = Name.getQNameParts(attName);
                    attNamespace =  ((StaticQueryContext)env).checkURIForPrefix(parts[0]);
                    if (attNamespace == null) {
                        grumble("Undeclared prefix in attribute name " + Err.wrap(attName, Err.ATTRIBUTE));
                    }
                    attNameCode = env.getNamePool().allocate(parts[0], attNamespace, parts[1]);
                } catch (QNameException e) {
                    grumble("Invalid attribute name " + Err.wrap(attName, Err.ATTRIBUTE));
                }

                FixedAttribute attInst = new FixedAttribute(attNameCode,
                                                            Validation.STRIP,
                                                            null,
                                                            -1);

                setLocation(attInst);
                Expression select;
                try {
                    select = AttributeValueTemplate.make(attValue+(char)0,
                                                                0,
                                                                (char)0,
                                                                env,
                                                                rangeVariables,
                                                                false);
                } catch (XPathException err) {
                    throw err.makeStatic();
                }
                attInst.setSelect(select);
                attInst.setRejectDuplicates();
                setLocation(attInst);
                contents.add(attInst);
            }
        }
        if (c=='/') {
            // empty element tag
            expectChar(t.nextChar(), '>');
        } else {
            readElementContent(elname, contents);
        }
        Instr[] elk = new Instr[contents.size()];
        for (int i=0; i<contents.size(); i++) {
            if (contents.get(i) instanceof Instr) {
                // if the child expression creates another element,
                // suppress validation, as the parent already takes care of it
                // TODO: optimize this down through conditional expressions, FLWR expressions, etc
                if (validationMode != Validation.STRIP &&
                        contents.get(i) instanceof ElementCreator &&
                        ((ElementCreator)contents.get(i)).getValidationMode() == validationMode) {
                    ((ElementCreator)contents.get(i)).setValidationMode(Validation.PRESERVE);
                }
                elk[i] = (Instr)contents.get(i);
            } else {
                SequenceInstruction seq = new SequenceInstruction((Expression)contents.get(i), null);
                setLocation(seq);
                elk[i] = seq;
                // If we get a construct like {"a"}{"b"}, we mustn't output a space between the "a" and the "b".
                // To prevent this we set a special bit on the xsl:sequence instruction generated.
                if (i+1 < contents.size() && !(contents.get(i) instanceof Instruction)) {
                    seq.setCloseTextNode(true);
                }
            }
        }
        elInst.setChildren(elk);
        setLocation(elInst);

        // reset the in-scope namespaces to what they were before

        for (int n=0; n<namespaceCount; n++) {
            ((StaticQueryContext)env).undeclareNamespace();
        }

        if (env.getConfiguration().isSchemaAware()) {
            ((StaticQueryContext)env).popValidationContext();
        }

        if (env.getConfiguration().getTraceListener() != null) {
            return new TraceInstruction(elInst);
        } else {
            return elInst;
        }
    }

    private void readElementContent(String startTag, List components) throws XPathException.Static {
        try {
            while (true) {
                // read all the components of the element value
                StringBuffer text = new StringBuffer();
                char c;
                boolean containsEntities = false;
                while (true) {
                    c = t.nextChar();
                    if (c == '<') {
                        break;
                    } else if (c == '&') {
                        text.append(readEntityReference());
                        containsEntities = true;
                    } else if (c == '}') {
                        c = t.nextChar();
                        if (c != '}') {
                            grumble("'}' must be written as '}}' within element content");
                        }
                        text.append(c);
                    } else if (c == '{') {
                        c = t.nextChar();
                        if (c != '{') {
                            c = '{';
                            break;
                        }
                        text.append(c);
                    } else {
                        text.append(c);
                    }
                }
                if (text.length() > 0 &&
                        (containsEntities | preserveSpace | !Navigator.isWhite(text) )) {
                    ValueOf inst = new ValueOf(new StringValue(text.toString()), false);
                    setLocation(inst);
                    components.add(inst);
                }
                if (c != '<') {
                    // we read an '{' indicating an enclosed expression
                    t.unreadChar();
                    t.setState(t.DEFAULT_STATE);
                    lookAhead();
                    nextToken();
                    Expression exp = parseExpression();
                    components.add(exp);
                    expect(Tokenizer.RCURLY);
                } else {
                    // c == '<'
                    Expression exp = parsePseudoXML(true);
                    // An end tag can appear here, and is returned as a string value
                    if (exp instanceof StringValue) {
                        String endTag = ((StringValue)exp).getStringValue().trim();
                        if (endTag.equals(startTag)) {
                            return;
                        } else {
                            grumble("end tag </" + endTag +
                                    "> does not match start tag <" + startTag + ">");
                        }
                    } else {
                        components.add(exp);
                    }
                }
            }
        } catch (StringIndexOutOfBoundsException err) {
            grumble("No closing end tag found for direct element constructor");
        }
    }

    private Expression parsePIConstructor() throws XPathException.Static {
        try {
            StringBuffer pi = new StringBuffer();
            int firstSpace = -1;
            while (!pi.toString().endsWith("?>")) {
                char c = t.nextChar();
                if (firstSpace < 0 && " \t\r\n".indexOf(c) >= 0) {
                    firstSpace = pi.length();
                }
                pi.append(c);
            }
            pi.setLength(pi.length() - 2);

            String target;
            String data = "";
            if (firstSpace < 0) {
                target = pi.toString();
            } else {
                target = pi.substring(0, firstSpace);
                data = pi.substring(firstSpace+1).trim();
            }

            if (!XMLChar.isValidNCName(target)) {
                grumble("Invalid processing instruction name " + Err.wrap(target));
            }

            ProcessingInstruction instruction =
                    new ProcessingInstruction(new StringValue(target));
            instruction.setSelect(new StringValue(data));
            setLocation(instruction);
            return instruction;
        } catch (StringIndexOutOfBoundsException err) {
            grumble("No closing '?>' found for processing instruction");
            return null;
        }
    }

    private Expression parseCDATAConstructor() throws XPathException.Static {
        try {
            char c;
            // CDATA section
            c = t.nextChar();
            expectChar(c, 'C');
            c = t.nextChar();
            expectChar(c, 'D');
            c = t.nextChar();
            expectChar(c, 'A');
            c = t.nextChar();
            expectChar(c, 'T');
            c = t.nextChar();
            expectChar(c, 'A');
            c = t.nextChar();
            expectChar(c, '[');
            StringBuffer cdata = new StringBuffer();
            while (!cdata.toString().endsWith("]]>")) {
                cdata.append(t.nextChar());
            }
            String content = cdata.substring(0, cdata.length()-3);
            ValueOf inst = new ValueOf(new StringValue(content), false);
            //InstructionWrapper wrap = new InstructionWrapper(inst);
            setLocation(inst);
            return inst;
        } catch (StringIndexOutOfBoundsException err) {
            grumble("No closing ']]>' found for CDATA section");
            return null;
        }
    }

    private Expression parseCommentConstructor() throws XPathException.Static {
        try {
            char c = t.nextChar();;
            // XML-like comment
            expectChar(c, '-');
            StringBuffer comment = new StringBuffer();
            while (!comment.toString().endsWith("--")) {
                comment.append(t.nextChar());
            }
            if (t.nextChar() != '>') {
                grumble("'--' is not permitted in an XML comment");
            }
            String commentText = comment.substring(0, comment.length()-2);
            Comment instruction = new Comment();
            instruction.setSelect(new StringValue(commentText));
            //InstructionWrapper wrap = new InstructionWrapper(instruction);
            setLocation(instruction);
            return instruction;
        } catch (StringIndexOutOfBoundsException err) {
            grumble("No closing '-->' found for comment constructor");
            return null;
        }
    }

//    private Expression readAttributeValue(Tokenizer t, char delimiter) throws XPathException.Static {
//        try {
//            List components = new ArrayList();
//            while (true) {
//                // read all the components of the attribute value
//                StringBuffer text = new StringBuffer();
//                char c;
//                while (true) {
//                    c = t.nextChar();
//                    if (c == delimiter) {
//                        break;
//                    }
//                    if (c == '<') {
//                        grumble("�<� must be escaped within an attribute value");
//                    } else if (c == '&') {
//                        text.append(readEntityReference());
//                    } else if (c == '}') {
//                        c = t.nextChar();
//                        if (c != '}') {
//                            grumble("�}� must be written as �}}� within an attribute value");
//                        }
//                        text.append(c);
//                    } else if (c == '{') {
//                        c = t.nextChar();
//                        if (c != '{') {
//                            t.unreadChar();
//                            break;
//                        }
//                        text.append(c);
//                    } else {
//                        text.append(c);
//                    }
//                }
//                if (text.length() > 0) {
//                    components.add(new StringValue(text));
//                }
//                if (c == delimiter) break;
//                lookAhead();
//                nextToken();
//                Expression exp = parseExpression();
//                components.add(stringify(exp));
//                expect(Tokenizer.RCURLY);
//            }
//
//            // is the list of components empty?
//
//            int nr = components.size();
//            if (nr==0) {
//                return StringValue.EMPTY_STRING;
//            }
//
//            // is it a single component?
//
//            if (nr==1) {
//                return ((Expression)components.get(0)).simplify();
//            }
//
//            // otherwise, return an expression that concatenates the components
//
//    		Concat fn = (Concat)SystemFunction.makeSystemFunction("concat");
//    		Expression[] args = new Expression[nr];
//            args = (Expression[])components.toArray(args);
//    		fn.setArguments(args);
//    		return fn.simplify();
//
//
//        } catch (StringIndexOutOfBoundsException err) {
//            grumble("No closing delimiter found for attribute constructor");
//            return null;
//        }
//    }

    /**
     * Convert an expression so it generates a space-separated sequence of strings
     */

    private Expression stringify(Expression exp) {
        exp = new Atomizer(exp);
        exp = new AtomicSequenceConverter(exp, Type.STRING_TYPE);

        StringJoin fn = (StringJoin)SystemFunction.makeSystemFunction("string-join");
        Expression[] args = new Expression[2];
        args[0] = exp;
        args[1] = new StringValue(" ");
        fn.setArguments(args);
        return fn;
    }

    /**
     * Method to make a string literal from a token identified as a string
     * literal. This is trivial in XPath, but in XQuery the method is overridden
     * to identify pseudo-XML character and entity references
     * @param token
     * @return The string value of the string literal, after dereferencing entity and
     * character references
     */

    protected StringValue makeStringLiteral(String token) throws XPathException.Static {
        if (token.indexOf('&') == -1) {
            return new StringValue(token);
        } else {
            StringBuffer sb = new StringBuffer();
            for (int i=0; i<token.length(); i++) {
                char c = token.charAt(i);
                if (c == '&') {
                    int semic = token.indexOf(';', i);
                    if (semic < 0) {
                        grumble("No closing ';' found for entity or character reference");
                    } else {
                        String entity = token.substring(i+1, semic);
                        sb.append(analyzeEntityReference(entity));
                        i = semic;
                    }
                } else {
                    sb.append(c);
                }
            }
            return new StringValue(sb);
        }
    }

    /**
     * Read a pseudo-XML character reference or entity reference.
     * @return The character represented by the character or entity reference. Note
     * that this is a string rather than a char because a char only accommodates characters
     * up to 65535.
     * @throws XPathException.Static if the character or entity reference is not well-formed
     */

    private String readEntityReference() throws XPathException.Static {
        try {
            StringBuffer sb = new StringBuffer();
            while (true) {
                char c = t.nextChar();
                if (c == ';') break;
                sb.append(c);
            }
            String entity = sb.toString();
            return analyzeEntityReference(entity);
        } catch (StringIndexOutOfBoundsException err) {
            grumble("No closing ';' found for entity or character reference");
        }
        return null;     // to keep the Java compiler happy
    }

    private String analyzeEntityReference(String entity) throws XPathException.Static {
        if (entity.equals("lt")) {
            return "<";
        } else if (entity.equals("gt")) {
            return ">";
        } else if (entity.equals("amp")) {
            return "&";
        } else if (entity.equals("quot")) {
            return "\"";
        } else if (entity.equals("apos")) {
            return "'";
        } else if (entity.length() < 2 || entity.charAt(0) != '#') {
            grumble("invalid entity reference &" + entity + ";");
            return null;
        } else {
            entity = entity.toLowerCase();
            return parseCharacterReference(entity);
        }
    }

    private String parseCharacterReference(String entity) throws XPathException.Static {
        int value = 0;
        if (entity.charAt(1) == 'x') {
            for (int i = 2; i < entity.length(); i++) {
                int digit = "0123456789abcdef".indexOf(entity.charAt(i));
                if (digit < 0) {
                    grumble("invalid character '" + entity.charAt(i) + "' in hex character reference");
                }
                value = (value * 16) + digit;
            }
        } else {
            for (int i = 1; i < entity.length(); i++) {
                int digit = "0123456789".indexOf(entity.charAt(i));
                if (digit < 0) {
                    grumble("invalid character '" + entity.charAt(i) + "' in decimal character reference");
                }
                value = (value * 10) + digit;
            }
        }
        // following code borrowed from AElfred
        // check for character refs being legal XML
        if ((value < 0x0020
                && !(value == '\n' || value == '\t' || value == '\r'))
                || (value >= 0xD800 && value <= 0xDFFF)
                || value == 0xFFFE || value == 0xFFFF
                || value > 0x0010ffff)
            grumble("Invalid XML character reference x"
                    + Integer.toHexString(value));

        // Check for surrogates: 00000000 0000xxxx yyyyyyyy zzzzzzzz
        //  (1101|10xx|xxyy|yyyy + 1101|11yy|zzzz|zzzz:
        if (value <= 0x0000ffff) {
            // no surrogates needed
            return "" + (char) value;
        } else if (value <= 0x0010ffff) {
            value -= 0x10000;
            // > 16 bits, surrogate needed
            return "" + ((char) (0xd800 | (value >> 10)))
                    + ((char) (0xdc00 | (value & 0x0003ff)));
        } else {
            // too big for surrogate
            grumble("Character reference x" + Integer.toHexString(value) + " is too large");
        }
        return null;
    }

    /**
     * Lookahead one token, catching any exception thrown by the tokenizer. This
     * method is only called from the query parser when switching from character-at-a-time
     * mode to tokenizing mode
     */

    private void lookAhead() throws XPathException.Static {
        try {
            t.lookAhead();
        } catch (XPathException err) {
            grumble(err.getMessage());
        }
    }

    /**
     * Skip whitespace.
     * @param c the current character
     * @return the first character after any whitespace
     */

    private char skipSpaces(char c) {
        while (c==' ' || c=='\n' || c=='\r' || c=='\t') {
            c = t.nextChar();
        }
        return c;
    }

    /**
     * Test whether the current character is the expected character.
     * @param actual    The character that was read
     * @param expected  The character that was expected
     * @throws XPathException.Static if they are different
     */

    private void expectChar(char actual, char expected) throws XPathException.Static {
        if (actual != expected) {
            grumble("Expected '" + expected + "', found '" + actual + "'");
        }
    }

    /**
     * Get the current language (XPath or XQuery)
     */

    protected String getLanguage() {
        return "XQuery";
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
