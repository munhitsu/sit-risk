package net.sf.saxon.style;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.SequenceInstruction;
import net.sf.saxon.instruct.Template;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.trans.Mode;
import net.sf.saxon.trans.RuleManager;
import net.sf.saxon.tree.AttributeCollection;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerConfigurationException;
import java.util.StringTokenizer;

/**
* An xsl:template element in the style sheet.
*/

public final class XSLTemplate extends StyleElement {

    private int[] modeNameCodes;
    private int templateFingerprint = -1;
    private Pattern match;
    private boolean prioritySpecified;
    private double priority;
    private Procedure procedure = new Procedure();
    private boolean needsStackFrame;
    private Template compiledTemplate = new Template();
    private SequenceType requiredType = null;

    /**
    * Determine whether this type of element is allowed to contain a template-body
    * @return true: yes, it may contain a template-body
    */

    public boolean mayContainSequenceConstructor() {
        return true;
    }

    /**
    * Return the fingerprint for the name of this template. Note that this may
     * be called before prepareAttributes has been called.
    */

    public int getTemplateFingerprint() {

    	//We use -1 to mean "not yet evaluated"

        try {
        	if (templateFingerprint==-1) {
        		// allow for forwards references
        		String nameAtt = getAttributeValue(StandardNames.NAME);
        		if (nameAtt!=null) {
        			templateFingerprint =
                		makeNameCode(nameAtt.trim()) & 0xfffff;
                }
            }
            return templateFingerprint;
        } catch (NamespaceException err) {
            return -1;          // the errors will be picked up later
        } catch (XPathException err) {
            return -1;
        }
    }

    /**
     * Determine the type of item returned by this template
     * @return the item type returned
     */

    protected ItemType getReturnedItemType() {
        if (requiredType==null) {
            return getCommonChildItemType();
        } else {
            return requiredType.getPrimaryType();
        }
    }

    private int getMinImportPrecedence() {
        return ((XSLStyleSheet)getDocumentElement()).getMinImportPrecedence();
    }

    public void prepareAttributes() throws TransformerConfigurationException {

		String modeAtt = null;
		String nameAtt = null;
		String priorityAtt = null;
		String matchAtt = null;
        String asAtt = null;

		AttributeCollection atts = getAttributeList();

		for (int a=0; a<atts.getLength(); a++) {
			int nc = atts.getNameCode(a);
			String f = getNamePool().getClarkName(nc);
			if (f==StandardNames.MODE) {
        		modeAtt = atts.getValue(a).trim();
			} else if (f==StandardNames.NAME) {
        		nameAtt = atts.getValue(a).trim();
			} else if (f==StandardNames.MATCH) {
        		matchAtt = atts.getValue(a);
			} else if (f==StandardNames.PRIORITY) {
        		priorityAtt = atts.getValue(a).trim();
        	} else if (f==StandardNames.AS) {
        		asAtt = atts.getValue(a);
        	} else {
        		checkUnknownAttribute(nc);
        	}
        }
        try {
            if (modeAtt==null) {
                modeNameCodes = new int[1];
                modeNameCodes[0] = -1;
            } else {
                if (matchAtt==null) {
                    compileError("The mode attribute must be absent if the match attribute is absent");
                }
                // mode is a space-separated list of mode names, or "#default", or "#all"

                int count = 0;
                boolean allModes = false;
                StringTokenizer st = new StringTokenizer(modeAtt);
                while (st.hasMoreTokens()) {
                    st.nextToken();
                    count++;
                }

                if (count==0) {
                    compileError("The mode attribute must not be empty");
                }

                modeNameCodes = new int[count];
                count = 0;
                st = new StringTokenizer(modeAtt);
                while (st.hasMoreTokens()) {
                    String s = st.nextToken();
                    if (s.equals("#default")) {
                        modeNameCodes[count++] = Mode.DEFAULT_MODE;
                    } else if (s.equals("#all")) {
                        allModes = true;
                        modeNameCodes[count++] = Mode.ALL_MODES;
                    } else {
                        modeNameCodes[count++] = makeNameCode(s);
                    }
                }
                if (allModes && (count>1)) {
                    compileError("mode='#all' cannot be combined with other modes");
                }
            }

            if (nameAtt!=null) {
                templateFingerprint = makeNameCode(nameAtt.trim()) & 0xfffff;
            }
        } catch (NamespaceException err) {
            compileError(err.getMessage());
        } catch (XPathException err) {
            compileError(err.getMessage());
        }

        prioritySpecified = (priorityAtt != null);
        if (prioritySpecified) {
            if (matchAtt==null) {
                compileError("The priority attribute must be absent if the match attribute is absent");
            }
            try {
                priority = new Double(priorityAtt.trim()).doubleValue();
            } catch (NumberFormatException err) {
                compileError("Invalid numeric value for priority (" + priority + ")");
            }
        }

        if (matchAtt != null) {
            match = makePattern(matchAtt);
        }

        if (match==null && nameAtt==null)
            compileError("xsl:template must have a name or match attribute (or both)");

        if (asAtt != null) {
            requiredType = makeSequenceType(asAtt);
        }

	}


    public void validate() throws TransformerConfigurationException {
        checkTopLevel();

        // the check for duplicates is now done in the buildIndexes() method of XSLStyleSheet
        typeCheck("match", match);
        markTailCalls();
    }

    /**
    * Mark tail-recursive calls on templates and functions.
    */

    public void markTailCalls() {
        if (requiredType == null) {
            // don't attempt tail call optimization if the return type needs checking
            StyleElement last = getLastChildInstruction();
            if (last != null) {
                last.markTailCalls();
            }
        }
    }

    /**
    * Compile: this registers the template with the rule manager, and ensures
    * space is available for local variables
    */

    public Instruction compile(Executable exec) throws TransformerConfigurationException {

        SequenceInstruction body = new SequenceInstruction(null, requiredType);
        compileChildren(exec, body);

        needsStackFrame = (procedure.getNumberOfVariables() > 0);
        compiledTemplate.init ( body,
                                needsStackFrame,
                                getPrecedence(),
                                getMinImportPrecedence(),
                                getSystemId(),
                                getLineNumber());

        if (match!=null) {
            RuleManager mgr = getPrincipalStyleSheet().getRuleManager();
            for (int i=0; i<modeNameCodes.length; i++) {
                int nc = modeNameCodes[i];
                Mode mode = mgr.getMode(nc);
                if (nc != Mode.DEFAULT_MODE && nc != Mode.ALL_MODES) {
                    mode.setModeName(getTargetNamePool().getDisplayName(nc));
                                // used for tracing only
                }
                if (prioritySpecified) {
                    mgr.setHandler(match, compiledTemplate, mode, getPrecedence(), priority);
                } else {
                    mgr.setHandler(match, compiledTemplate, mode, getPrecedence());
                }
            }
        }

        getPrincipalStyleSheet().allocateLocalSlots(procedure.getNumberOfVariables());

        return null;

    }


    /**
    * Get associated Procedure (for details of stack frame)
    */

    public Procedure getProcedure() {
        return procedure;
    }

    /**
    * Get the compiled template
    */

    public Template getCompiledTemplate() {
        return compiledTemplate;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
