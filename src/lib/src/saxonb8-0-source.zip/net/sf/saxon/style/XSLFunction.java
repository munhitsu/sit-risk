package net.sf.saxon.style;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.LetExpression;
import net.sf.saxon.expr.RangeVariableDeclaration;
import net.sf.saxon.expr.RoleLocator;
import net.sf.saxon.expr.TypeChecker;
import net.sf.saxon.expr.UserFunctionCall;
import net.sf.saxon.instruct.*;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.pattern.NoNodeTest;
import net.sf.saxon.tree.AttributeCollection;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.EmptySequence;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerConfigurationException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
* Handler for xsl:function elements in stylesheet (XSLT 2.0). <BR>
* Attributes: <br>
* name gives the name of the function
* saxon:memo-function=yes|no indicates whether it acts as a memo function.
*/

public class XSLFunction extends StyleElement implements FunctionSignature {

    private int functionFingerprint = -1;
    private SequenceType resultType;
    private String functionName;
    private Procedure procedure = new Procedure();
    private boolean memoFunction = false;
    private boolean override = true;
    private int numberOfArguments = -1;  // -1 means not yet known

    // List of UserFunctionCall objects that reference this XSLFunction
    List references = new ArrayList();

    /**
    * Method called by UserFunctionCall to register the function call for
    * subsequent fixup.
     * @param ref the UserFunctionCall to be registered
    */

    public void registerReference(UserFunctionCall ref) {
        references.add(ref);
    }

    public void prepareAttributes() throws TransformerConfigurationException {

		AttributeCollection atts = getAttributeList();

        String nameAtt = null;
        String asAtt = null;

		for (int a=0; a<atts.getLength(); a++) {
			int nc = atts.getNameCode(a);
			String f = getNamePool().getClarkName(nc);
            if (f==StandardNames.NAME) {
				nameAtt = atts.getValue(a).trim();
				if (nameAtt.indexOf(':')<0) {
					compileError("Function name must have a namespace prefix");
				}
				try {
				    int functionCode = makeNameCode(nameAtt.trim());
        		    functionFingerprint = functionCode & 0xfffff;
        		} catch (NamespaceException err) {
        		    compileError(err.getMessage());
        		} catch (XPathException err) {
                    compileError(err.getMessage());
                }
        	} else if (f==StandardNames.AS) {
        		asAtt = atts.getValue(a);
            } else if (f==StandardNames.OVERRIDE) {
                String overrideAtt = atts.getValue(a).trim();
                if (overrideAtt.equals("yes")) {
                    override = true;
                } else if (overrideAtt.equals("no")) {
                    override = false;
                } else {
                    compileError("override must be 'yes' or 'no'");
                }
            } else if (f==StandardNames.SAXON_MEMO_FUNCTION) {
                String memoAtt = atts.getValue(a).trim();
                if (memoAtt.equals("yes")) {
                    memoFunction = true;
                } else if (memoAtt.equals("no")) {
                    memoFunction = false;
                } else {
                    compileError("saxon:memo-function must be 'yes' or 'no'");
                }
        	} else {
        		checkUnknownAttribute(nc);
        	}
        }

        if (nameAtt == null) {
            reportAbsence("name");
        }

        if (asAtt == null) {
            resultType = SequenceType.ANY_SEQUENCE;
        } else {
            resultType = makeSequenceType(asAtt);
        }

        functionName = nameAtt;
    }

    /**
    * Determine whether this type of element is allowed to contain a template-body.
    * @return true: yes, it may contain a general template-body
    */

    public boolean mayContainSequenceConstructor() {
        return true;
    }

    /**
    * Is override="yes"?.
    * @return true if override="yes" was specified, otherwise false
    */

    public boolean isOverriding() {
        return override;
    }

    /**
    * Notify all references to this function of the data type.
     * @throws TransformerConfigurationException
    */

    public void fixupReferences() throws TransformerConfigurationException {
        Iterator iter = references.iterator();
        while (iter.hasNext()) {
            ((UserFunctionCall)iter.next()).setStaticType(resultType);
        }
        super.fixupReferences();
    }

    public void validate() throws TransformerConfigurationException {

        // check the element is at the top level of the stylesheet

        checkTopLevel();
        getNumberOfArguments();

        // check that this function is not a duplicate of another

        XSLStyleSheet root = getPrincipalStyleSheet();
        List toplevel = root.getTopLevel();
        for (int i=toplevel.size()-1; i>=0; i--) {
            Object child = toplevel.get(i);
            if (child instanceof XSLFunction &&
                    !(child == this) &&
                    ((XSLFunction)child).getFunctionFingerprint() == getFunctionFingerprint() &&
                    ((XSLFunction)child).getNumberOfArguments() == numberOfArguments &&
                    ((XSLFunction)child).getPrecedence() == getPrecedence()) {
                compileError("Duplicate function declaration");
            }
        }
        //markTailCalls();
    }

    /**
    * Get the type of the context item within this instruction
    */

    public ItemType getContextItemType() {
        // Context item will be undefined
        return NoNodeTest.getInstance();
    }

    /**
     * Determine whether the function body can be compiled as a single expression.
     * This is true if the body consists (after the xsl:param elements) of a sequence
     * of xsl:variable instructions followed by an xsl:sequence instruction, all
     * satisfying certain conditions.
     * @return true if the function satisfies these constraints
     */

    private boolean isCompilableAsExpression() {
        int state = 0;
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                return true;
            }
            if (child.getNodeKind() == Type.TEXT) {
                return false;
            }
            if (child instanceof XSLParam && state==0) {
                // OK
            } else if (child instanceof XSLVariable && state<2) {
                if (child.hasChildNodes()) {
                    return false;
                }
                state = 1;
            } else if (child instanceof XSLSequence && state<2) {
                if (child.hasChildNodes()) {
                    return false;
                }
                state = 2;
            } else {
                return false;
            }
        }
    }

    /**
     * Compile the function definition to create an executable representation
     * @return an Instruction, or null. The instruction returned is actually
     * rather irrelevant; the compile() method has the side-effect of binding
     * all references to the function to the executable representation. This may
     * be a FunctionInstr or a UserFunction depending on the complexity of the
     * function body.
     * @throws TransformerConfigurationException
     */

    public Instruction compile(Executable exec) throws TransformerConfigurationException {

        getPrincipalStyleSheet().allocateLocalSlots(procedure.getNumberOfVariables());

        if (isCompilableAsExpression()) {
            compileAsExpression(exec);
        } else {
            compileAsTemplate(exec);
        }
        return null;
    }

    /**
     * Compile the function into a UserFunction object, which treats the function
     * body as a single XPath expression. This involves recursively translating
     * xsl:variable declarations into let expressions, withe the action part of the
     * let expression containing the rest of the function body.
     * The UserFunction that is created will be linked from all calls to
     * this function, so nothing else needs to be done with the result. If there are
     * no calls to it, the compiled function will be garbage-collected away.
     * @throws TransformerConfigurationException
     */

    private void compileAsExpression(Executable exec) throws TransformerConfigurationException {
        SequenceInstruction body = new SequenceInstruction(null, resultType);
        Instruction[] allChildren = compileChildren(exec, body);
        List executableChildren = new ArrayList();
        for (int i=0; i<allChildren.length; i++) {
            // Don't include the xsl:param elements
            if (!(allChildren[i] instanceof Param)) {
                executableChildren.add(allChildren[i]);
            }
        }
        Expression exp = convertToExpression(executableChildren, 0);
        try {
            // We omit the exp.analyze() phase because it leads to duplicate
            // reporting of type errors: the variables from which the expression
            // was constructed have already been validated. Unfortunately this
            // also means that no further optimization is carried out.
            // exp = exp.analyze(staticContext);
            if (resultType != null) {
                RoleLocator role =
                        new RoleLocator(RoleLocator.FUNCTION_RESULT, functionName, 0);
                exp = TypeChecker.staticTypeCheck(exp, resultType, false, role);
            }
        } catch (XPathException err) {
            compileError(err);
        }
        // exp.display(10);
        UserFunction fn = new UserFunction(exp);
        fn.setFunctionName(functionName);
        fn.setLineNumber(getLineNumber());
        fn.setSystemId(getSystemId());
        fixupInstruction(fn);
    }

    /**
     * This internal routine is called recursively to process one xsl:variable
     * instruction and create one let expression. The variable declared in the xsl:variable
     * becomes the range variable of the let expression, and the rest of the instruction
     * sequence becomes the action (return) part of the let expression.
     * @param instructions The list of instructions
     * @param offset The place in the list where processing is to start
     * @return the LetExpression that results from the translation
     */

    private Expression convertToExpression(List instructions, int offset) {
        if (instructions.size() <= offset) {
            return EmptySequence.getInstance();
        }
        Instr start = (Instr)instructions.get(offset);
        if (start instanceof TraceInstruction) {
            start = ((TraceInstruction)start).getChildren()[0];
        }
        if (start instanceof Expression) {
            return (Expression)start;
        } else if (start instanceof Variable) {
            final Variable ovar = (Variable)start;
            LetExpression let = new LetExpression();
            RangeVariableDeclaration var = new RangeVariableDeclaration();
            var.setRequiredType(ovar.getRequiredType());
            var.setVariableFingerprint(ovar.getVariableFingerprint());
            var.setVariableName(ovar.getVariableName());
            let.setVariableDeclaration(var);
            let.setSequence(ovar.getSelectExpression());
            let.setSlotNumber(((Variable)start).getSlotNumber());
            let.setAction(convertToExpression(instructions, offset+1));
            return let;
        } else if (start instanceof SequenceInstruction) {
            Expression select = ((SequenceInstruction)start).getSelectExpression();
            ExpressionTool.markTailFunctionCalls(select);
            return select;
        } else {
            throw new AssertionError(
                    "Function contains inappropriate instructions for compiling as an expression");
        }
    }

    /**
     * Compile the function as sequence of instructions (a FunctionInstr) object. This
     * is done when the simpler UserFunction object cannot be used.
     * The compiled function is linked to all the calls on the function; nothing is returned.
     * @throws TransformerConfigurationException
     */

    private void compileAsTemplate(Executable exec) throws TransformerConfigurationException {

        SequenceInstruction body = new SequenceInstruction(null, resultType);
        Instruction[] allChildren = compileChildren(exec, body);
        List executableChildren = new ArrayList();
        for (int i=0; i<allChildren.length; i++) {
            // Don't include the xsl:param elements
            if (!(allChildren[i] instanceof Param)) {
                executableChildren.add(allChildren[i]);
            }
        }
        Instruction[] newChildren = new Instruction[executableChildren.size()];
        newChildren = (Instruction[])executableChildren.toArray(newChildren);

        body.setChildren(newChildren);

        FunctionInstr compiledFunction = new FunctionInstr();
        compiledFunction.initialize( body,
                                     getBaseURI(),
                                     functionName,
                                     memoFunction );
        compiledFunction.setLineNumber(getLineNumber());
        fixupInstruction(compiledFunction);
        //return compiledFunction;
    }

    /**
    * Fixup all function references.
     * @param compiledFunction the Instruction representing this function in the compiled code
     * @throws TransformerConfigurationException if an error occurs.
    */

    private void fixupInstruction(CallableFunction compiledFunction)
    throws TransformerConfigurationException {
        try {
            Iterator iter = references.iterator();
            while (iter.hasNext()) {
                ((UserFunctionCall)iter.next()).setFunction(this, compiledFunction);
            }
        } catch (XPathException err) {
            compileError(err);
        }
    }

    /**
     * Get associated Procedure (for details of stack frame).
     * @return the associated Procedure object
     */

    public Procedure getProcedure() {
        return procedure;
    }

    /**
     * Get the fingerprint of the name of this function.
     * @return the fingerprint of the name
     */

    public int getFunctionFingerprint() {
        if (functionFingerprint==-1) {
            // this is a forwards reference to the function
            try {
        	    prepareAttributes();
        	} catch (TransformerConfigurationException err) {
        	    return -1;              // we'll report the error later
        	}
        }
        return functionFingerprint;
    }

    /**
     * Get the type of value returned by this function
     * @return the declared result type, or the inferred result type
     * if this is more precise
     */
    public SequenceType getResultType() {
        return resultType;
    }

    /**
     * Get the number of arguments declared by this function (that is, its arity).
     * @return the arity of the function
     */

    public int getNumberOfArguments() {
        if (numberOfArguments == -1) {
            numberOfArguments = 0;
            AxisIterator kids = iterateAxis(Axis.CHILD);
            while (true) {
                Item child = kids.next();
                if (child instanceof XSLParam) {
                    numberOfArguments++;
                } else {
                    return numberOfArguments;
                }
            }
        }
        return numberOfArguments;
    }

    /**
     * Get the required types of the arguments
     * @return an array of SequenceType objects, representing the required types of
     * each of the formal arguments
     */

    public SequenceType[] getArgumentTypes() {
        SequenceType[] types = new SequenceType[getNumberOfArguments()];
        int count = 0;
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo node = (NodeInfo)kids.next();
            if (node == null) {
                return types;
            }
            if (node instanceof XSLParam) {
                types[count++] = ((XSLParam)node).getRequiredType();
            }
        }
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
