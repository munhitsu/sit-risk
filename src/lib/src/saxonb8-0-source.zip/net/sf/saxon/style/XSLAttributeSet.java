package net.sf.saxon.style;
import net.sf.saxon.instruct.AttributeSet;
import net.sf.saxon.instruct.Block;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.tree.AttributeCollection;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerConfigurationException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
* An xsl:attribute-set element in the stylesheet. <br>
*/

public class XSLAttributeSet extends StyleElement {

    int fingerprint;
                // the name of this attribute set, as a Name object

    String use;
                // the value of the use-attribute-sets attribute, as supplied

    Procedure procedure = new Procedure();
                // needed if variables are used

    List attributeSetElements = null;
                // list of XSLAttributeSet objects referenced by this one

    AttributeSet[] useAttributeSets = null;
                // compiled instructions for the attribute sets used by this one

    AttributeSet instruction = new AttributeSet();
                // the instruction representing this attribute set

    int referenceCount = 0;
                // number of references to this attribute set

    boolean validated = false;

    public int getAttributeSetFingerprint() {
        return fingerprint;
    }

    public AttributeSet getInstruction() {
        return instruction;
    }

    public void incrementReferenceCount() {
        referenceCount++;
    }

    public void prepareAttributes() throws TransformerConfigurationException {

		String name = null;
		use = null;

		AttributeCollection atts = getAttributeList();

		for (int a=0; a<atts.getLength(); a++) {
			int nc = atts.getNameCode(a);
			String f = getNamePool().getClarkName(nc);
			if (f==StandardNames.NAME) {
        		name = atts.getValue(a).trim();
        	} else if (f==StandardNames.USE_ATTRIBUTE_SETS) {
        		use = atts.getValue(a);
        	} else {
        		checkUnknownAttribute(nc);
        	}
        }

        if (name==null) {
            reportAbsence("name");
            return;
        }

        try {
            fingerprint = makeNameCode(name.trim()) & 0xfffff;
        } catch (NamespaceException err) {
            compileError(err.getMessage());
        } catch (XPathException err) {
            compileError(err.getMessage());
        }

    }

    public void validate() throws TransformerConfigurationException {

        if (validated) return;

        checkTopLevel();

        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            Item child = kids.next();
            if (child == null) {
                break;
            }
            if (!(child instanceof XSLAttribute)) {
                compileError("Only xsl:attribute is allowed within xsl:attribute-set");
            }
        }

        if (use!=null) {
            // identify any attribute sets that this one refers to

            attributeSetElements = new ArrayList();
            useAttributeSets = getAttributeSets(use, attributeSetElements);

            // check for circularity

            for (Iterator it=attributeSetElements.iterator(); it.hasNext();) {
                ((XSLAttributeSet)it.next()).checkCircularity(this);
            }
        }

        validated = true;
    }

    /**
    * Check for circularity: specifically, check that this attribute set does not contain
    * a direct or indirect reference to the one supplied as a parameter
    */

    public void checkCircularity(XSLAttributeSet origin) throws TransformerConfigurationException {
        if (this==origin) {
            compileError("The definition of the attribute set is circular");
        } else {
            if (!validated) {
                // if this attribute set isn't validated yet, we don't check it.
                // The circularity will be detected when the last attribute set in the cycle
                // gets validated
                return;
            }
            if (attributeSetElements != null) {
                for (Iterator it=attributeSetElements.iterator(); it.hasNext();) {
                    ((XSLAttributeSet)it.next()).checkCircularity(origin);
                }
            }
        }
    }

    /**
    * Get associated Procedure (for details of stack frame)
    */

    public Procedure getProcedure() {
        return procedure;
    }

    public Instruction compile(Executable exec) throws TransformerConfigurationException {
        if (referenceCount > 0 ) {
            getPrincipalStyleSheet().allocateLocalSlots(procedure.getNumberOfVariables());
            boolean needsStackFrame = (procedure.getNumberOfVariables() > 0);
            Block body = new Block();
            compileChildren(exec, body);
            instruction.initialize(useAttributeSets, body, needsStackFrame);
            return null;
        } else {
            return null;
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
