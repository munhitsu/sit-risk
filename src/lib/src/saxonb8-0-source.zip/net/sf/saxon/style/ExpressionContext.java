package net.sf.saxon.style;
import net.sf.saxon.expr.*;
import net.sf.saxon.functions.StandardFunction;
import net.sf.saxon.functions.SystemFunction;
import net.sf.saxon.instruct.NamespaceContext;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NamespaceConstant;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.om.QNameException;
import net.sf.saxon.query.XQueryFunction;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.type.Type;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.Configuration;

import javax.xml.transform.TransformerException;
import java.util.Comparator;

/**
* An ExpressionContext represents the context for an XPath expression written
* in the stylesheet.
*/

public class ExpressionContext implements StaticContext {

	private StyleElement element;
	private NamePool namePool;

	public ExpressionContext(StyleElement styleElement) {
		element = styleElement;
		namePool = styleElement.getTargetNamePool();	// the namepool used at run-time
	}

    /**
     * Get the system configuration
     */

    public Configuration getConfiguration() {
        return element.getPreparedStyleSheet().getConfiguration();
    }

    /**
    * Issue a compile-time warning
    */

    public void issueWarning(String s) {
        element.issueWarning(s);
    }

    /**
    * Get the NamePool used for compiling expressions
    */

    public NamePool getNamePool() {
        return namePool;
    }

    /**
    * Get the System ID of the entity containing the expression (used for diagnostics)
    */

    public String getSystemId() {
    	return element.getSystemId();
    }

    /**
    * Get the line number of the expression within its containing entity
    * Returns -1 if no line number is available
    */

    public int getLineNumber() {
    	return element.getLineNumber();
    }

    /**
    * Get the Base URI of the element containing the expression, for resolving any
    * relative URI's used in the expression.
    * Used by the document() function.
    */

    public String getBaseURI() {
        return element.getBaseURI();
    }

    /**
    * Get the URI for a prefix, using this Element as the context for namespace resolution.
    * The default namespace will not be used when the prefix is empty.
    * @param prefix The prefix
    * @throws XPathException if the prefix is not declared
    */

    public String getURIForPrefix(String prefix) throws XPathException {
        try {
            return element.getURIForPrefix(prefix, false);
        } catch (NamespaceException err) {
            throw new XPathException.Static(err);
        }
    }

    /**
    * Get a copy of the Namespace Context
    */

    public NamespaceContext getNamespaceContext() {
        return element.makeNamespaceContext();
    }

    /**
    * Get a fingerprint for a name, using this as the context for namespace resolution
    * @param qname The name as written, in the form "[prefix:]localname"
    * @param useDefault Defines the action when there is no prefix. If true, use
    * the default namespace URI (as for element names). If false, use no namespace URI
    * (as for attribute names).
    * @return -1 if the name is not already present in the name pool
    */

    public int getFingerprint(String qname, boolean useDefault) throws XPathException {

        String[] parts;
        try {
            parts = Name.getQNameParts(qname);
        } catch (QNameException err) {
            throw new XPathException.Static(err.getMessage());
        }
        String prefix = parts[0];
        if (prefix.equals("")) {
            String uri = "";

            if (useDefault) {
                uri = getURIForPrefix(prefix);
            }

			return namePool.getFingerprint(uri, qname);

        } else {

            String uri = getURIForPrefix(prefix);
			return namePool.getFingerprint(uri, parts[1]);
        }
    }

    /**
    * Bind a variable to an object that can be used to refer to it
    * @param fingerprint The fingerprint of the variable name
    * @return a VariableDeclaration object that can be used to identify it in the Bindery
    * @throws XPathException.Static if the variable has not been declared
    */

    public VariableDeclaration bindVariable(int fingerprint) throws XPathException.Static {
 	    return element.bindVariable(fingerprint);
    }

    /**
    * Identify a function appearing in an expression. Following XSLT rules, this method doesn't
    * throw a static error if no function with the given name exists, unless the name is
    * unprefixed. Rather, it returns an error expression that will fail at run-time if
    * the function is actually called.
    */

    public Expression bindFunction(String qname, Expression[] arguments) throws XPathException {

        String prefix;
        String uri;
        String localName;

        try {
            String[] parts = Name.getQNameParts(qname);
            prefix = parts[0];
            uri = getURIForPrefix(parts[0]);
            localName = parts[1];
        } catch (QNameException e) {
            throw new XPathException.Dynamic("Invalid function name: " + e);
        }

        if (prefix.equals("") || uri.equals(NamespaceConstant.FN)) {

            FunctionCall f = SystemFunction.makeSystemFunction(localName);
            if (f==null) {
                return new ErrorExpression(
                            new XPathException.Dynamic("Unknown system function: " + qname));
            }
            f.setArguments(arguments);
            return f;

        } else {        // the function name is prefixed

            boolean debug = element.getPreparedStyleSheet().getConfiguration().
                                isTraceExternalFunctions();

            if (debug) {
                System.err.println("Resolving external function call to " + qname);
            }

            int namecode = namePool.allocate(prefix, uri, localName);
            int fingerprint = namecode & 0xfffff;

            // First see if there is a stylesheet function with override=yes

            XSLFunction ssf = getStyleSheetFunction(fingerprint, arguments.length);
            if (ssf != null) {
                if (ssf.isOverriding()) {

                    if (debug) {
                        System.err.println("Found a stylesheet function with override='yes'");
                    }

                    UserFunctionCall fc = new UserFunctionCall();
                    ssf.registerReference(fc);
                    fc.setFingerprint(fingerprint);
                    fc.setArguments(arguments);
                    return fc;
                }
            }

            // Some extension functions are specially recognized

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "evaluate")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:evaluate");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "expression")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:expression");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "eval")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:eval");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "parse")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:parse");
                f.setArguments(arguments);
                return f;
            }

            if (fingerprint==namePool.getFingerprint(NamespaceConstant.SAXON, "serialize")) {
                FunctionCall f = SystemFunction.makeSystemFunction("saxon:serialize");
                f.setArguments(arguments);
                return f;
            }

            // Now try for a constructor function for a built-in type

            if (uri.equals(NamespaceConstant.SCHEMA) || uri.equals(NamespaceConstant.SCHEMA_DATATYPES)
                    || uri.equals(NamespaceConstant.XDT)) {
                // it's a constructor function: treat it as shorthand for a cast expression
                if (arguments.length != 1) {
                    throw new XPathException.Static("A constructor function must have exactly one argument");
                }
                AtomicType type = (AtomicType)Type.getBuiltInItemType(uri, localName);
                if (type==null) {
                    return new ErrorExpression(
                                new XPathException.Dynamic("Unknown constructor function: " + qname));
                }
                if (debug) {
                    System.err.println("Found a constructor for a built-in atomic type");
                }

                return new CastExpression(arguments[0], type, false);

            }

            // Now see if it's a constructor function for a user-defined type

            if (arguments.length == 1) {
                SchemaType st = getConfiguration().getSchemaType(fingerprint);
                if (st != null && st instanceof AtomicType) {
                    return new CastExpression(arguments[0], (AtomicType)st, false);
                }
            }

            // Now see if there's an imported XQuery function (using saxon:import-query)

            XSLStyleSheet top = element.getPrincipalStyleSheet();
            XQueryFunction qf = top.bindXQueryFunction(fingerprint);
            if (qf != null) {
                UserFunctionCall fc = new UserFunctionCall();
                qf.registerReference(fc);
                fc.setFingerprint(fingerprint);
                fc.setArguments(arguments);
                return fc;
            }

            // Next, see if we can bind a Java method

			Class className = null;
			try {
			    className = getExternalJavaClass(uri);
			} catch (Exception err) {
                if (debug) {
                    System.err.println("Failed to load a Java class for URI " + uri + ": " + err.getMessage());
                }
			}

			if (className!=null) {
                FunctionProxy fp = new FunctionProxy();
                fp.setConfiguration(element.getPreparedStyleSheet().getConfiguration());
                if (debug) {
                    System.err.println("Found a Java class");
                }
                fp.setArguments(arguments);
                fp.setFunctionName(className, localName, arguments.length);
                return fp;
			}

            // Finally, see if there is a non-overriding stylesheet function

            if (ssf != null) {
                if (debug) {
                    System.err.println("Found a stylesheet function with override='no'");
                }
                UserFunctionCall fc = new UserFunctionCall();
                ssf.registerReference(fc);
                fc.setFingerprint(fingerprint);
                fc.setArguments(arguments);
                return fc;
            }

            // We've failed - no implementation of this function was found

            if (debug) {
                System.err.println("Failed to find any function matching " + qname);
            }

            return new ErrorExpression(
                          new XPathException.Dynamic("No function found matching " +
                                    qname + " with " + showArgumentCount(arguments.length)));

        }


    }

//    public FunctionSignature getFunctionSignature(int fingerprint, int arity) {
//        return getStyleSheetFunction(fingerprint, arity);
//    }

    private String showArgumentCount(int n) {
        if (n==0) {
           return "no arguments";
        } else if (n==1) {
           return "one argument";
        } else {
           return n + " arguments";
        }
    }

	/*
    * Get a FunctionCall declared using an xsl:function element in the stylesheet
    * @param fingerprint the fingerprint of the name of the function
    * @param arity the number of arguments in the function call. The value -1
    * indicates that any arity will do (this is used to support the function-available() function).
    * @return the FunctionCall object represented by this xsl:function; or null if not found
    */

    private XSLFunction getStyleSheetFunction(int fingerprint, int arity) {
    	return element.getStyleSheetFunction(fingerprint, arity);
    }

    /**
    * Get an external Java class corresponding to a given namespace prefix, if there is
    * one.
    * @param uri The namespace URI corresponding to the prefix used in the function call.
    * @return the Java class name if a suitable class exists, otherwise return null.
    */

    private Class getExternalJavaClass(String uri) throws TransformerException {
        // First try to use a saxon:script element if there is one

        XSLStyleSheet sse = element.getPrincipalStyleSheet();
        Class c = sse.getExternalJavaClass(uri);

        if (c != null) {
            return c;
        }

        c = FunctionProxy.getVendorExtensionClass(uri);

        if (c != null) {
            return c;
        }

        if (!sse.getPreparedStyleSheet().getConfiguration().isAllowExternalFunctions()) {
            throw new TransformerException("Calls to external functions have been disabled");
        }

        // Failing that, try to extract a class directly from the URI
        return FunctionProxy.getImplicitJavaClass(uri);
    }

    /**
    * Determine if an extension element is available
    * @throws XPathException if the name is invalid or the prefix is not declared
    */

    public boolean isElementAvailable(String qname) throws XPathException {
        try {
            String[] parts = Name.getQNameParts(qname);
            String uri = getURIForPrefix(parts[0]);

            return element.getPreparedStyleSheet().
                                getStyleNodeFactory().isElementAvailable(uri, parts[1]);
        } catch (QNameException e) {
            throw new XPathException.Static("Invalid element name. " + e.getMessage());
        }
    }

    /**
    * Determine if a function is available. This method is used to implement
     * function-available() in the common case that the argument is known
     * at compile-time. For the dynamic implementation, see functions.Available.
     * @param qname the function name
     * @param arity the required arity; set to -1 if any arity will do
     * @see net.sf.saxon.functions.Available
    */

    public boolean isFunctionAvailable(String qname, long arity) throws XPathException {
        try {
            String[] parts = Name.getQNameParts(qname);
            String uri = getURIForPrefix(parts[0]);
            String localName = parts[1];
        	if (parts[0].equals("") || uri.equals(NamespaceConstant.FN)) {
        		StandardFunction.Entry entry =
                            StandardFunction.getFunction(localName);
                return (entry != null &&
                          (arity == -1 ||
                            (arity >= entry.minArguments && arity <= entry.maxArguments)));
        	}

            // Some extension functions are specially recognized

            if (uri.equals(NamespaceConstant.SAXON)) {
                if (localName.equals("evaluate")) return (arity<0 || arity>0);
                if (localName.equals("expression")) return (arity<0 || arity==1);
                if (localName.equals("eval")) return (arity<0 || arity>0);
                if (localName.equals("parse")) return (arity<0 || arity==1);
                if (localName.equals("serialize")) return (arity<0 || arity==2);
            }

    		int fingerprint = getFingerprint(qname, false);

    		if (fingerprint>=0) {
    			XSLFunction f = getStyleSheetFunction(fingerprint, (int)arity);
    			if (f!=null) return true;
    		}

          	Class theClass = getExternalJavaClass(uri);
          	if (theClass==null) {
          	    return false;
          	}

        	FunctionProxy fp = new FunctionProxy();
        	//fp.setArguments(ComputedExpression.NO_ARGUMENTS);
        	return fp.setFunctionName(theClass, localName, (int)arity);
        } catch (QNameException err) {
            throw new XPathException.Static("Invalid function name. " + err.getMessage());
        } catch (Exception err) {
            return false;
        }
	}

    /**
    * Get a named collation.
    * @param name The name of the required collation. Supply null to get the default collation.
    * @return the collation; or null if the required collation is not found.
    */

    public Comparator getCollation(String name) throws XPathException {
        return element.getPrincipalStyleSheet().findCollation(name);
    }

    /**
    * Get the default collation. Return null if no default collation has been defined
    */

    public String getDefaultCollationName() {
        return element.getPrincipalStyleSheet().getDefaultCollationName();
    }

    /**
    * Get the default XPath namespace, as a namespace code that can be looked up in the NamePool
    */

    public short getDefaultElementNamespace() {
        return element.getDefaultXPathNamespace();
    }

    /**
    * Determine whether Backwards Compatible Mode is used
    */

    public boolean isInBackwardsCompatibleMode() {
        return element.backwardsCompatibleModeIsEnabled();
    }

    public boolean isImportedSchema(String namespace) {
        return getXSLStyleSheet().isImportedSchema(namespace);
    }

    /**
    * Get the XSLStyleSheet object
    */

    public XSLStyleSheet getXSLStyleSheet() {
        return element.getPrincipalStyleSheet();
    }

    public StyleElement getStyleElement() {
        return element;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
