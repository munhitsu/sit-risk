package net.sf.saxon.style;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.ResultDocument;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.om.Validation;
import net.sf.saxon.tree.AttributeCollection;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerConfigurationException;
import java.util.Properties;

/**
* An xsl:result-document (formerly saxon:output) element in the stylesheet. <BR>
* The xsl:result-document element takes an attribute href="filename". The filename will
* often contain parameters, e.g. {position()} to ensure that a different file is produced
* for each element instance. <BR>
* There is a further attribute "name" which determines the format of the
* output file, it identifies the name of an xsl:output element containing the output
* format details.
*/

public class XSLResultDocument extends StyleElement {

    private Expression href;
    private int format = -1;     // fingerprint of required xsl:output element
    private int validationAction = Validation.STRIP;
    private SchemaType schemaType = null;

    /**
    * Determine whether this node is an instruction.
    * @return true - it is an instruction
    */

    public boolean isInstruction() {
        return true;
    }

    /**
    * Determine whether this type of element is allowed to contain a template-body
    * @return true: yes, it may contain a template-body
    */

    public boolean mayContainSequenceConstructor() {
        return true;
    }

    public void prepareAttributes() throws TransformerConfigurationException {
		AttributeCollection atts = getAttributeList();

        String formatAttribute = null;
        String hrefAttribute = null;
        String validationAtt = null;
        String typeAtt = null;

		for (int a=0; a<atts.getLength(); a++) {
			int nc = atts.getNameCode(a);
			String f = getNamePool().getClarkName(nc);
			if (f==StandardNames.FORMAT) {
        		formatAttribute = atts.getValue(a).trim();
        	} else if (f==StandardNames.HREF) {
        		hrefAttribute = atts.getValue(a).trim();
            } else if (f==StandardNames.VALIDATION) {
                validationAtt = atts.getValue(a).trim();
            } else if (f==StandardNames.TYPE) {
                typeAtt = atts.getValue(a).trim();
        	} else {
        		checkUnknownAttribute(nc);
        	}
        }

        if (hrefAttribute==null) {
            //href = StringValue.EMPTY_STRING;
        } else {
            href = makeAttributeValueTemplate(hrefAttribute);
        }

        if (formatAttribute!=null) {
            try {
                format = makeNameCode(formatAttribute.trim()) & 0xfffff;
            } catch (NamespaceException err) {
                compileError(err.getMessage());
            } catch (XPathException err) {
                compileError(err.getMessage());
            }
        }

        if (validationAtt==null) {
            validationAction = getContainingStyleSheet().getDefaultValidation();
        } else {
            validationAction = Validation.getCode(validationAtt);
            if (validationAction != Validation.STRIP && !getConfiguration().isSchemaAware()) {
                compileError("To perform validation, a schema-aware XSLT processor is needed");
            }
            if (validationAction == Validation.INVALID) {
                compileError("Invalid value of validation attribute");
            }
        }
        if (typeAtt!=null) {
            if (!getConfiguration().isSchemaAware()) {
                compileError("The type attribute is available only with a schema-aware XSLT processor");
            }
            schemaType = getSchemaType(typeAtt);
        }

        if (typeAtt != null && validationAtt != null) {
            compileError("validation and type attributes are mutually exclusive");
        }
    }

    public void validate() throws TransformerConfigurationException {
        checkWithinTemplate();
        if (!getPreparedStyleSheet().getConfiguration().isAllowExternalFunctions()) {
            compileError("xsl:result-document is disabled when extension functions are disabled");
        }
        href = typeCheck("href", href);
    }

    public Instruction compile(Executable exec) throws TransformerConfigurationException {
        Properties props = null;
        try {
            props = getPrincipalStyleSheet().gatherOutputProperties(format);
        } catch (TransformerConfigurationException err) {
            compileError("Named output format has not been defined");
            return null;
        }

        Instruction inst = new ResultDocument(props,
                                              href,
                                              getBaseURI(),
                                              validationAction,
                                              schemaType);
        compileChildren(exec, inst);
        return inst;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Additional Contributor(s): Brett Knights [brett@knightsofthenet.com]
//
