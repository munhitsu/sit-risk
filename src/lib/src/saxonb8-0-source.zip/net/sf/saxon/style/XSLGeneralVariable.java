package net.sf.saxon.style;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.RoleLocator;
import net.sf.saxon.expr.TypeChecker;
import net.sf.saxon.instruct.DocumentInstr;
import net.sf.saxon.instruct.GeneralVariable;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.instruct.TraceInstruction;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.Axis;
import net.sf.saxon.tree.AttributeCollection;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.value.EmptySequence;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.pattern.NoNodeTest;
import net.sf.saxon.pattern.NodeKindTest;

import javax.xml.transform.TransformerConfigurationException;

/**
* This class defines common behaviour across xsl:variable, xsl:param, and xsl:with-param
*/

public abstract class XSLGeneralVariable extends StyleElement  {

    protected int variableFingerprint = -1;
    protected Expression select = null;
    protected SequenceType requiredType = null;
    protected String constantText = null;
    protected boolean global;
    protected Procedure procedure = null;  // used only for global variables
    protected boolean assignable = false;
    protected boolean redundant = false;
    protected boolean requiredParam = false;
    protected boolean tunnel = false;
    //protected Class validationClass = null;
        // TODO: this class uses a different mechanism from xsl:result-document
        // to set type-information. Both could do it the same way, using OutputProperties.
    private boolean textonly;

    //private static final int[] treeSizeParameters = {50, 10, 5, 200};
        // estimated size of a temporary tree: {nodes, attributes, namespaces, characters}

    /**
     * Determine the type of item returned by this instruction (only relevant if
     * it is an instruction).
     * @return the item type returned. This is EMPTY for a variable: we are not
     * interested in the type of the variable, but in what the xsl:variable constributes
     * to the result of the sequence constructor it is part of.
     */

    protected ItemType getReturnedItemType() {
        return NoNodeTest.getInstance();
    }
    /**
    * Determine whether this type of element is allowed to contain a template-body
    * @return true: yes, it may contain a template-body
    */

    public boolean mayContainSequenceConstructor() {
        return true;
    }

    protected boolean allowsAsAttribute() {
        return true;
    }

    protected boolean allowsTunnelAttribute() {
        return false;
    }

    protected boolean allowsValue() {
        return true;
    }

    protected boolean allowsRequired() {
        return false;
    }

    /**
    * Test whether it is permitted to assign to the variable using the saxon:assign
    * extension element. This will only be true if the extra attribute saxon:assignable="yes"
    * is present.
    */

    public boolean isAssignable() {
        return assignable;
    }

    public boolean isTunnelParam() {
        return tunnel;
    }

    public boolean isRequiredParam() {
        return requiredParam;
    }

    /**
    * Get the display name of the variable.
    */

    public String getVariableName() {
    	return getAttributeValue(StandardNames.NAME);
    }

    /**
    * Mark this global variable as redundant. This is done before prepareAttributes is called.
    */

    public void setRedundant() {
        redundant = true;
    }

    /**
    * Get the fingerprint of the variable name
    */

    public int getVariableFingerprint() {

        // if an expression has a forwards reference to this variable, getVariableFingerprint() can be
        // called before prepareAttributes() is called. We need to allow for this. But we'll
        // deal with any errors when we come round to processing this attribute, to avoid
        // duplicate error messages

        // TODO: this won't establish the requiredType in time to optimize an expression containing
        // a forwards reference to the variable

        if (variableFingerprint==-1) {
            String nameAttribute = getAttributeValue(StandardNames.NAME);
            if (nameAttribute==null) {
                return -1;              // we'll report the error later
            }
            try {
                variableFingerprint = makeNameCode(nameAttribute.trim()) & 0xfffff;
            } catch (NamespaceException err) {
                variableFingerprint = -1;
            } catch (XPathException err) {
                variableFingerprint = -1;
            }
        }
        return variableFingerprint;
    }

    public void prepareAttributes() throws TransformerConfigurationException {

        getVariableFingerprint();

		AttributeCollection atts = getAttributeList();

		String selectAtt = null;
        String assignAtt = null;
        String nameAtt = null;
        String asAtt = null;
        String requiredAtt = null;
        String tunnelAtt = null;

		for (int a=0; a<atts.getLength(); a++) {
			int nc = atts.getNameCode(a);
			String f = getNamePool().getClarkName(nc);
			if (f==StandardNames.NAME) {
        		nameAtt = atts.getValue(a).trim();
        	} else if (f==StandardNames.SELECT) {
        		selectAtt = atts.getValue(a);
        	} else if (f==StandardNames.AS && allowsAsAttribute()) {
        		asAtt = atts.getValue(a);
        	} else if (f==StandardNames.REQUIRED && allowsRequired()) {
        		requiredAtt = atts.getValue(a).trim();
            } else if (f==StandardNames.TUNNEL && allowsTunnelAttribute()) {
        		tunnelAtt = atts.getValue(a).trim();
        	} else if (f==StandardNames.SAXON_ASSIGNABLE && this instanceof XSLVariableDeclaration) {
        		assignAtt = atts.getValue(a).trim();
        	} else {
        		checkUnknownAttribute(nc);
        	}
        }

        if (nameAtt==null) {
            reportAbsence("name");
        } else {
            try {
                variableFingerprint = makeNameCode(nameAtt.trim()) & 0xfffff;
            } catch (NamespaceException err) {
                compileError(err.getMessage());
            } catch (XPathException err) {
                compileError(err.getMessage());
            }
        }

        if (selectAtt!=null) {
            if (!allowsValue()) {
                compileError("Function parameters cannot have a default value");
            }
            select = makeExpression(selectAtt);
        }

        if (assignAtt!=null && assignAtt.equals("yes")) {
            assignable=true;
        }

        if (requiredAtt!=null) {
            if (requiredAtt.equals("yes")) {
                requiredParam = true;
            } else if (requiredAtt.equals("no")) {
                requiredParam = false;
            } else {
                compileError("The attribute 'required' must be set to 'yes' or 'no'");
            }
        }

        if (tunnelAtt!=null) {
            if (tunnelAtt.equals("yes")) {
                tunnel = true;
            } else if (tunnelAtt.equals("no")) {
                tunnel = false;
            } else {
                compileError("The attribute 'tunnel' must be set to 'yes' or 'no'");
            }
        }

        if (asAtt!=null) {
            requiredType = makeSequenceType(asAtt);
        }
    }

    public void validate() throws TransformerConfigurationException {
        global = (getParentNode() instanceof XSLStyleSheet);

        if (global) {
            procedure = new Procedure();
        }
        if (select!=null && hasChildNodes()) {
            compileError("An " + getDisplayName() + " element with a select attribute must be empty");
        }

        checkAgainstRequiredType(requiredType);

        if (select==null && allowsValue()) {
            textonly = true;
            AxisIterator kids = iterateAxis(Axis.CHILD);
            NodeInfo first = (NodeInfo)kids.next();
            if (first == null) {
                if (requiredType == null) {
                    select = StringValue.EMPTY_STRING;
                } else {
                    if (this instanceof XSLParam) {
                        if (!requiredParam) {
                            if (Cardinality.allowsZero(requiredType.getCardinality())) {
                                select = EmptySequence.getInstance();
                            } else {
                                requiredParam = true;
                            }
                        }
                    } else {
                        if (Cardinality.allowsZero(requiredType.getCardinality())) {
                            select = EmptySequence.getInstance();
                        } else {
                            compileError("Default value () is not valid for the declared type");
                        }
                    }
                }
            } else {
                if (kids.next() == null) {
                    // there is exactly one child node
                    if (first.getNodeKind() == Type.TEXT) {
                        // it is a text node: optimize for this case
                        constantText = first.getStringValue();
                    }
                }

                // Determine if the temporary tree can only contain text nodes
                textonly = (getCommonChildItemType() == NodeKindTest.TEXT);
            }
        }
        select = typeCheck("select", select);
    }

    /**
     * Method called for parameters of call-template to check the type of the actual
     * parameter against the type of the required parameter
     * @param required The type required by the signature of the called template
     */

    protected void checkAgainstRequiredType(SequenceType required)
    throws TransformerConfigurationException {
        try {
            RoleLocator role =
                    new RoleLocator(RoleLocator.VARIABLE, getVariableName(), 0);
            if (requiredType!=null) {
                // check that the expression is consistent with the required type

                if (select != null) {
                    select = TypeChecker.staticTypeCheck(select, requiredType, false, role);
                } else {
                    // TODO: check the type of the instruction sequence statically
                }
            }
        } catch (XPathException err) {
            compileError(err);
        }
    }

    /**
    * Initialize - common code called from the compile() method of all subclasses
    */

    protected void initializeInstruction(Executable exec, GeneralVariable var)
    throws TransformerConfigurationException {

        var.init(   select,
                    requiredType,
                    variableFingerprint);
        var.setGlobal(global);
        var.setAssignable(assignable);
        var.setRequiredParam(requiredParam);
        var.setTunnel(tunnel);
        var.setContainsLocals(global && procedure.getNumberOfVariables()>0);

        // handle the "temporary tree" case by creating a Document sub-instruction
        // to construct and return a document node.
        if (hasChildNodes() && requiredType==null) {
            DocumentInstr doc = new DocumentInstr(textonly, constantText, getBaseURI());
            compileChildren(exec, doc);
            var.setSelect(doc);
        } else {
            compileChildren(exec, var);
        }
    }

    /**
    * Get associated Procedure (for details of stack frame, if this is a global variable containing
    * local variable declarations)
    */

    public Procedure getProcedure() {
        return procedure;
    }

    /**
     * Set additional trace properties appropriate to the kind of instruction. This
     * implementation adds the name attribute
     */

    protected void setAdditionalTraceProperties(TraceInstruction trace) {
        trace.setProperty("name", getVariableName());
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
