package net.sf.saxon.style;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.value.IntegerValue;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.type.Type;
import net.sf.saxon.expr.*;
import net.sf.saxon.functions.SystemFunction;
import net.sf.saxon.functions.StringJoin;
import net.sf.saxon.functions.Concat;
import net.sf.saxon.query.StaticQueryContext;
import net.sf.saxon.query.QueryParser;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
* This class represents an attribute value template. The class allows an AVT to be parsed, and
* can construct an Expression that returns the effective value of the AVT.
*
* This is an abstract class that is never instantiated, it contains static methods only.
*/

public abstract class AttributeValueTemplate {

    private AttributeValueTemplate() {}


    /**
     * Static factory method to create an AVT from an XSLT string representation.
     * Also used to handle the equivalent construct (direct attribute constructors)
     * in XQuery.
    */

    public static Expression make(String avt,
                                  int start,
                                  char terminator,
                                  StaticContext env,
                                  Stack rangeVariables,
                                  boolean scanOnly) throws XPathException {

        List components = new ArrayList();

        int i0, i1, i2, i8, i9, len, last;
        last = start;
        len = avt.length();
        while (last < len) {
            i2 = avt.indexOf(terminator, last);
            i0 = avt.indexOf("{", last);
            i1 = avt.indexOf("{{", last);
            i8 = avt.indexOf("}", last);
            i9 = avt.indexOf("}}", last);

            if ((i0 < 0 || i2 < i0) && (i8 < 0 || i2 < i8)) {   // found end of string
                components.add(new StringValue(avt.substring(last, i2)));
                last = i2;
                break;
            } else if (i8 >= 0 && (i0 < 0 || i8 < i0)) {             // found a "}"
                if (i8 != i9) {                        // a "}" that isn't a "}}"
                    throw new XPathException.Static(
                            "Closing curly brace in attribute value template \"" + avt + "\" must be doubled");
                }
                components.add(new StringValue(avt.substring(last, i8 + 1)));
                last = i8 + 2;
            } else if (i1 >= 0 && i1 == i0) {              // found a doubled "{{"
                components.add(new StringValue(avt.substring(last, i1 + 1)));
                last = i1 + 2;
            } else if (i0 >= 0) {                        // found a single "{"
                if (i0 > last) {
                    components.add(new StringValue(avt.substring(last, i0)));
                }
                Expression exp;
                ExpressionParser parser;
                if (env instanceof StaticQueryContext) {
                    parser = new QueryParser();
                } else {
                    parser = new ExpressionParser();
                }
                parser.setScanOnly(scanOnly);
                if (rangeVariables != null) {
                    parser.setRangeVariableStack(rangeVariables);
                }
                exp = parser.parse(avt, i0 + 1, Tokenizer.RCURLY, env);
                if (!scanOnly) {
                    exp = exp.simplify();
                }
                last = parser.getTokenizer().currentTokenStartIndex + 1;

                if (env.isInBackwardsCompatibleMode()) {
                    components.add(makeFirstItem(exp));
                } else {
                    components.add(makeStringJoin(exp));
                }

            } else {
                throw new IllegalStateException("Internal error parsing AVT");
            }
        }

        // if this is simply a prescan, return the position of the end of the
        // AVT, so we can parse it properly later

        if (scanOnly) {
            return new IntegerValue(last);
        }

        // is it empty?

        if (components.size() == 0) {
            return StringValue.EMPTY_STRING;
        }

        // is it a single component?

        if (components.size() == 1) {
            return ((Expression) components.get(0)).simplify();
        }

        // otherwise, return an expression that concatenates the components

        Concat fn = (Concat) SystemFunction.makeSystemFunction("concat");
        Expression[] args = new Expression[components.size()];
        components.toArray(args);
        fn.setArguments(args);
        return fn.simplify();

    }

    /**
    * Make a string-join expression that concatenates the string-values of items in
    * a sequence with intervening spaces. This may be simplified later as a result
    * of type-checking.
    */

    private static Expression makeStringJoin(Expression exp) {
        //Expression exp = ExpressionTool.make(expression, env, 0, Tokenizer.RCURLY);

        exp = new Atomizer(exp);
        exp = new AtomicSequenceConverter(exp, Type.STRING_TYPE);

		StringJoin fn = (StringJoin)SystemFunction.makeSystemFunction("string-join");
		Expression[] args = new Expression[2];
		args[0] = exp;
		args[1] = new StringValue(" ");
		fn.setArguments(args);
		return fn;
    }

    /**
    * Make an expression that extracts the first item of a sequence, after atomization
    */

    private static Expression makeFirstItem(Expression exp) {
        if (!Type.isSubType(exp.getItemType(), Type.ANY_ATOMIC_TYPE)) {
            exp = new Atomizer(exp);
        }
        if (Cardinality.allowsMany(exp.getCardinality())) {
            exp = new FirstItemExpression(exp);
        }
        if (!Type.isSubType(exp.getItemType(), Type.STRING_TYPE)) {
            exp = new AtomicSequenceConverter(exp, Type.STRING_TYPE);
        }
        return exp;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
