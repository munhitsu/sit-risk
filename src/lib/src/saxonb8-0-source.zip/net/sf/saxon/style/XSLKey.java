package net.sf.saxon.style;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.RoleLocator;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.expr.TypeChecker;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.NamespaceException;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.trans.KeyDefinition;
import net.sf.saxon.trans.KeyManager;
import net.sf.saxon.tree.AttributeCollection;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerConfigurationException;
import java.text.Collator;
import java.util.Comparator;

/**
* Handler for xsl:key elements in stylesheet. <br>
*/

public class XSLKey extends StyleElement  {

    private int keyFingerprint = -1;
    private Pattern match;
    private Expression use;
    private String collationName;

    public void prepareAttributes() throws TransformerConfigurationException {

        String nameAtt = null;
        String matchAtt = null;
        String useAtt = null;

		AttributeCollection atts = getAttributeList();

		for (int a=0; a<atts.getLength(); a++) {
			int nc = atts.getNameCode(a);
			String f = getNamePool().getClarkName(nc);
			if (f==StandardNames.NAME) {
        		nameAtt = atts.getValue(a).trim();
        	} else if (f==StandardNames.USE) {
        		useAtt = atts.getValue(a);
        	} else if (f==StandardNames.MATCH) {
        		matchAtt = atts.getValue(a);
        	//} else if (f==StandardNames.AS) {
        	//	typeAtt = atts.getValue(a);
        	} else if (f==StandardNames.COLLATION) {
        		collationName = atts.getValue(a).trim();
        	} else {
        		checkUnknownAttribute(nc);
        	}
        }

        if (nameAtt==null) {
            reportAbsence("name");
            return;
        }
        try {
            keyFingerprint = makeNameCode(nameAtt.trim()) & 0xfffff;
        } catch (NamespaceException err) {
            compileError(err.getMessage());
        } catch (XPathException err) {
            compileError(err.getMessage());
        }

        if (matchAtt==null) {
            reportAbsence("match");
            matchAtt = "*";
        }
        match = makePattern(matchAtt);

        if (useAtt==null) {
            reportAbsence("use");
            useAtt = ".";
        }
        use = makeExpression(useAtt);
    }

    public void validate() throws TransformerConfigurationException {
        checkTopLevel();
        checkEmpty();
        try {
            if (use==null) return;  // error already reported
            RoleLocator role =
                new RoleLocator(RoleLocator.INSTRUCTION, "xsl:key/use", 0);
            use = TypeChecker.staticTypeCheck(
                            use,
                            new SequenceType(Type.ANY_ATOMIC_TYPE, StaticProperty.ALLOWS_ZERO_OR_MORE),
                            false, role);
        } catch (XPathException err) {
            compileError(err);
        }

        use = typeCheck("use", use);
        match = typeCheck("match", match);

     }

    public Instruction compile(Executable exec) throws TransformerConfigurationException {

        Collator collator = null;
        if (collationName != null) {
            Comparator comp = getPrincipalStyleSheet().findCollation(collationName);
            if (comp==null) {
                 compileError("The collation name '" + collationName + "' has not been defined");
            }
            if (!(comp instanceof Collator)) {
                compileError("The collation used for xsl:key must be a java.text.Collator");
            }
            collator = (Collator)comp;
        }

        KeyManager km = getPrincipalStyleSheet().getKeyManager();
        KeyDefinition keydef = new KeyDefinition(match, use, collationName, collator);
        try {
            km.setKeyDefinition(keyFingerprint, keydef);
        } catch (TransformerConfigurationException err) {
            compileError(err);
        }
        return null;
    }

}
//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
