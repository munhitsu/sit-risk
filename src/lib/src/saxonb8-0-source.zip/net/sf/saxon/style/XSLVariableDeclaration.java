package net.sf.saxon.style;
import net.sf.saxon.expr.Binding;
import net.sf.saxon.expr.BindingReference;
import net.sf.saxon.expr.VariableDeclaration;

import net.sf.saxon.value.Value;
import net.sf.saxon.value.SequenceType;

import javax.xml.transform.TransformerConfigurationException;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;


/**
* Generic class for xsl:variable and xsl:param elements. <br>
*/

public abstract class XSLVariableDeclaration extends XSLGeneralVariable implements VariableDeclaration {

    private int slotNumber;

    // List of VariableReference objects that reference this XSLVariableDeclaration
    List references = new ArrayList();

    public int getSlotNumber() {
        return slotNumber;
    }

    /**
    * Get the static type of the variable.
    */

    public abstract SequenceType getRequiredType();

    /**
    * Method called by VariableReference to register the variable reference for
    * subsequent fixup
    */

    public void registerReference(BindingReference ref) {
        references.add(ref);
    }

    /**
    * Determine whether this node is an instruction.
    * @return true - it is an instruction (well, it can be, anyway)
    */

    public boolean isInstruction() {
        return true;
    }

    /**
    * Notify all references to this variable of the data type
    */

    public void fixupReferences() throws TransformerConfigurationException {
        SequenceType type = getRequiredType();
        Iterator iter = references.iterator();
        while (iter.hasNext()) {
            Value constantValue = null;
            int properties = 0;
            if (this instanceof XSLVariable && !isAssignable()) {
                if (select instanceof Value) {
                    constantValue = (Value)select;
                }
                if (select != null) {
                    properties = select.getSpecialProperties();
                }
            }
            ((BindingReference)iter.next()).setStaticType(type, constantValue, properties);
        }
        super.fixupReferences();
    }

    /**
    * Check that the variable is not already declared, and allocate a slot number
    */

    public void validate() throws TransformerConfigurationException {
        super.validate();
        if (global) {
            if (!redundant) {
                slotNumber = getPrincipalStyleSheet().allocateSlotNumber();
            }
        } else {
            checkWithinTemplate();
            Procedure p = getOwningProcedure();
            if (p==null) {
                compileError("Local variable must be declared within a template or function");
            } else {
                slotNumber = p.allocateSlotNumber();
            }
        }
        // Check for duplication
            // Global variables are checked at the XSLStyleSheet level
            // For local variables, duplicates are now allowed
            // For parameters, XSLParam and XSLWithParam do their own checks
            // checkDuplicateDeclaration();
    }

    /**
    * Notify all variable references of the Binding instruction
    */

    protected void fixupBinding(Binding binding) {
        Iterator iter = references.iterator();
        while (iter.hasNext()) {
            ((BindingReference)iter.next()).fixup(binding);
        }
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
