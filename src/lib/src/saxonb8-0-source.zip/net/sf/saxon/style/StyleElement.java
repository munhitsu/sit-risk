package net.sf.saxon.style;
import net.sf.saxon.Configuration;
import net.sf.saxon.PreparedStyleSheet;
import net.sf.saxon.expr.*;
import net.sf.saxon.instruct.*;
import net.sf.saxon.om.*;
import net.sf.saxon.pattern.LocationPathPattern;
import net.sf.saxon.pattern.NoNodeTest;
import net.sf.saxon.pattern.NodeKindTest;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.sort.SortKeyDefinition;
import net.sf.saxon.tree.ElementWithAttributes;
import net.sf.saxon.type.*;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.value.DecimalValue;
import net.sf.saxon.xpath.XPathException;
import org.xml.sax.Locator;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.math.BigDecimal;

/**
* Abstract superclass for all element nodes in the stylesheet. <BR>
* Note: this class implements Locator. The element
* retains information about its own location in the stylesheet, which is useful when
* an XSL error is found.
*/

public abstract class StyleElement extends ElementWithAttributes
        implements Locator {

    protected short[] extensionNamespaces = null;		// a list of URI codes
    private short[] excludedNamespaces = null;		// a list of URI codes
    protected BigDecimal version = null;
    protected StaticContext staticContext = null;
    protected TransformerConfigurationException validationError = null;
    protected int reportingCircumstances = REPORT_ALWAYS;
    protected String defaultXPathNamespace = null;
    private int lineNumber;     // maintained here because it's more efficient
                                // than using the lineNumberMap

    // Conditions under which an error is to be reported

    public final static int REPORT_ALWAYS = 1;
    public final static int REPORT_UNLESS_FORWARDS_COMPATIBLE = 2;
    public final static int REPORT_IF_INSTANTIATED = 3;

    /**
    * Constructor
    */

    public StyleElement() {}

    /**
    * Get the namepool to be used at run-time, this namepool holds the names used in
    * all XPath expressions and patterns
    */

    public NamePool getTargetNamePool() {
        return getPrincipalStyleSheet().getTargetNamePool();
    }

    /**
    * Get the configuration
    */

    protected Configuration getConfiguration() {
        return getPreparedStyleSheet().getConfiguration();
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
    * Make this node a substitute for a temporary one previously added to the tree. See
    * StyleNodeFactory for details. "A node like the other one in all things but its class".
    * Note that at this stage, the node will not yet be known to its parent, though it will
    * contain a reference to its parent; and it will have no children.
    */

    public void substituteFor(StyleElement temp) {
        this.parent = temp.parent;
        this.attributeList = temp.attributeList;
        this.namespaceList = temp.namespaceList;
        this.nameCode = temp.nameCode;
        this.sequence = temp.sequence;
        this.extensionNamespaces = temp.extensionNamespaces;
        this.excludedNamespaces = temp.excludedNamespaces;
        this.version = temp.version;
        this.root = temp.root;
        this.staticContext = temp.staticContext;
        this.validationError = temp.validationError;
        this.reportingCircumstances = temp.reportingCircumstances;
        this.lineNumber = temp.lineNumber;
    }

	/**
	* Set a validation error
	*/

	protected void setValidationError(TransformerException reason,
	                                  int circumstances) {
	    if (reason instanceof TransformerConfigurationException) {
		    validationError = (TransformerConfigurationException)reason;
		} else {
		    validationError = new TransformerConfigurationException(reason);
		}
		reportingCircumstances = circumstances;
	}

    /**
    * Determine whether this node is an instruction. The default implementation says it isn't.
    */

    public boolean isInstruction() {
        return false;
    }

    /**
     * Determine the type of item returned by this instruction (only relevant if
     * it is an instruction). Default implementation returns Type.ITEM, indicating
     * that we don't know, it might be anything.
     * @return the item type returned
     */

    protected ItemType getReturnedItemType() {
        return AnyItemType.getInstance();
    }

    /**
     * Get the most general type of item returned by the children of this instruction
     * @return the lowest common supertype of the item types returned by the children
     */

    protected ItemType getCommonChildItemType() {
        ItemType t = NoNodeTest.getInstance();
        AxisIterator children = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo next = (NodeInfo)children.next();
            if (next == null) {
                return t;
            }
            if (next instanceof StyleElement) {
                t = Type.getCommonSuperType(t, ((StyleElement)next).getReturnedItemType());
            } else {
                t = Type.getCommonSuperType(t, NodeKindTest.TEXT);
            }
            if (t==AnyItemType.getInstance()) {
                return t;       // no point looking any further
            }
        }
    }
    /**
     * Mark tail-recursive calls on templates and functions.
     * For most instructions, this does nothing.
    */

    public void markTailCalls() {
        // no-op
    }

    /**
    * Determine whether this type of element is allowed to contain a sequence constructor
    */

    public boolean mayContainSequenceConstructor() {
        return false;
    }

    /**
    * Determine whether this type of element is allowed to contain an xsl:fallback
     * instruction
    */

    public boolean mayContainFallback() {
        return mayContainSequenceConstructor();
    }

	/**
	* Get the containing XSLStyleSheet element
	*/

	public XSLStyleSheet getContainingStyleSheet() {
		NodeInfo next = this;
		while (!(next instanceof XSLStyleSheet)) {
			next = next.getParent();
		}
		return (XSLStyleSheet)next;
	}

    /**
    * Get the import precedence of this stylesheet element.
    */

    public int getPrecedence() {
        return getContainingStyleSheet().getPrecedence();
    }

    /**
    * Get the URI for a namespace prefix using the in-scope namespaces for
    * this element in the stylesheet
    * @param prefix The namespace prefix: may be the empty string
    * @param useDefault True if the default namespace is to be used when the
    * prefix is "".
    * @throws NamespaceException if the prefix is not declared
    */

    public String getURIForPrefix(String prefix, boolean useDefault) throws NamespaceException {
        if (prefix.equals("") && !useDefault) {
            return "";
        } else {
            short uricode = getURICodeForPrefix(prefix);
            return getNamePool().getURIFromURICode(uricode);
        }
    }

    /**
     * Make a NameCode, using this Element as the context for namespace resolution, and
     * registering the code in the namepool. If the name is unprefixed, the
     * default namespace is <b>not</b> used.
     * @param qname The name as written, in the form "[prefix:]localname". The name must have
     * already been validated as a syntactically-correct QName.
     * @throws XPathException if the qname is not a lexically-valid QName, or if the name
     * is in a reserved namespace.
     * @throws NamespaceException if the prefix of the qname has not been declared
    */

    public final int makeNameCode(String qname)
    throws XPathException, NamespaceException {

		NamePool namePool = getTargetNamePool();
        String[] parts;
        try {
            parts = Name.getQNameParts(qname);
        } catch (QNameException err) {
            throw new XPathException.Static(err.getMessage());
        }
		String prefix = parts[0];
        if (prefix.equals("")) {
			return namePool.allocate(prefix, (short)0, qname);

        } else {

            String uri = getURIForPrefix(prefix, false);
            if (NamespaceConstant.isReserved(uri)) {
                throw new XPathException.Static("Namespace prefix " + prefix + " refers to a reserved namespace");
            }
			return namePool.allocate(prefix, uri, parts[1]);
        }

	}

    /**
    * Make a NamespaceContext object representing the list of in-scope namespaces. The NamePool
    * used for numeric codes in the NamespaceContext will be the target name pool.
    */

    public NamespaceContext makeNamespaceContext() {
        // Get the namespace codes relative to the stylesheet namepool
        int[] oldCodes = getNamespaceCodes();
        int[] newCodes = new int[oldCodes.length];
        NamePool oldPool = getNamePool();
        NamePool newPool = getTargetNamePool();
        for (int i=0; i<oldCodes.length; i++) {
            String prefix = oldPool.getPrefixFromNamespaceCode(oldCodes[i]);
            String uri = oldPool.getURIFromNamespaceCode(oldCodes[i]);
            newCodes[i] = newPool.allocateNamespaceCode(prefix, uri);
        }
        return new NamespaceContext(newCodes, newPool);
    }

    /**
    * Process the attributes of this element and all its children
    */

    public void processAllAttributes() throws TransformerConfigurationException {
        staticContext = new ExpressionContext(this);
        processAttributes();
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                return;
            }
            if (child instanceof StyleElement) {
                ((StyleElement)child).processAllAttributes();
            }
        }
    }

    /**
     * Get an attribute value given the Clark name of the attribute (that is,
     * the name in {uri}local format).
     */

    public String getAttributeValue(String clarkName) {
        int fp = getNamePool().allocateClarkName(clarkName);
        return getAttributeValue(fp);
    }

    /**
    * Process the attribute list for the element. This is a wrapper method that calls
    * prepareAttributes (provided in the subclass) and traps any exceptions
    */

    public final void processAttributes() throws TransformerConfigurationException {
        try {
            prepareAttributes();
        } catch (TransformerConfigurationException err) {
        	if (forwardsCompatibleModeIsEnabled()) {
        		setValidationError(err, REPORT_IF_INSTANTIATED);
        	} else {
            	compileError(err);
            }
        }
    }

    /**
    * Check whether an unknown attribute is permitted.
    * @param nc The name code of the attribute name
    */

    protected void checkUnknownAttribute(int nc) throws TransformerConfigurationException {
    	if (forwardsCompatibleModeIsEnabled()) {
    		// then unknown attributes are permitted and ignored
    		return;
    	}
    	String attributeURI = getNamePool().getURI(nc);
    	String elementURI = getURI();
//    	int attributeFingerprint = nc & 0xfffff;
        String clarkName = getNamePool().getClarkName(nc);

    	// allow xsl:extension-element-prefixes etc on an extension element

    	if (isInstruction() &&
    		 clarkName.startsWith("{" + NamespaceConstant.XSLT) &&
    		 !(elementURI.equals(NamespaceConstant.XSLT)) &&
    		 (clarkName.endsWith("}xpath-default-namespace" ) ||
    		  clarkName.endsWith("}extension-element-prefixes") ||
    		  clarkName.endsWith("}exclude-result-prefixes") ||
    		  clarkName.endsWith("}version"))) {
    		return;
    	}

    	// allow standard attributes on an XSLT element

    	if (elementURI.equals(NamespaceConstant.XSLT) &&
    		 (clarkName == StandardNames.XPATH_DEFAULT_NAMESPACE ||
    		  clarkName == StandardNames.EXTENSION_ELEMENT_PREFIXES ||
    		  clarkName == StandardNames.EXCLUDE_RESULT_PREFIXES ||
    		  clarkName == StandardNames.VERSION)) {
    		return;
    	}

    	if (attributeURI.equals("") || attributeURI.equals(NamespaceConstant.XSLT)) {
			compileError("Attribute {" + getNamePool().getDisplayName(nc) +
				 "} is not allowed on this element");
        }
    }


    /**
    * Set the attribute list for the element. This is called to process the attributes (note
    * the distinction from processAttributes in the superclass).
    * Must be supplied in a subclass
    */

    public abstract void prepareAttributes() throws TransformerConfigurationException;

    /**
     * Find the last child instruction of this instruction. Returns null if
     * there are no child instructions, or if the last child is a text node.
    */

    protected StyleElement getLastChildInstruction() {
        StyleElement last = null;
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                return last;
            }
            if (child instanceof StyleElement) {
                last = (StyleElement)child;
            } else {
                last = null;
            }
        }
    }

	/**
	* Make an expression in the context of this stylesheet element
	*/

	public Expression makeExpression(String expression)
	throws TransformerConfigurationException {
	    try {
    		return ExpressionTool.make(expression,
                                       staticContext,
                                       0, Tokenizer.EOF);
        } catch(XPathException err) {
            if (!forwardsCompatibleModeIsEnabled()) {
                compileError(err);
            }
            return new ErrorExpression(err);
        }
	}

	/**
	* Make a pattern in the context of this stylesheet element
	*/

	public Pattern makePattern(String pattern)
	throws TransformerConfigurationException {
	    try {
		    return Pattern.make(pattern, staticContext);
        } catch(XPathException err) {
            compileError(err);
            return NoNodeTest.getInstance();
        }
	}

	/**
	* Make an attribute value template in the context of this stylesheet element
	*/

	public Expression makeAttributeValueTemplate(String expression)
	throws TransformerConfigurationException {
	    try {
		    return AttributeValueTemplate.make(expression + (char)0, 0, (char)0, staticContext, null, false);
        } catch(XPathException err) {
            compileError(err);
            return new StringValue(expression);
        }
	}

    /**
    * Process an attribute whose value is a SequenceType
    */

    public SequenceType makeSequenceType(String sequenceType)
    throws TransformerConfigurationException {
        if (staticContext==null) {
            staticContext = new ExpressionContext(this);
        }
	    try {
	        ExpressionParser parser = new ExpressionParser();
    		return parser.parseSequenceType(sequenceType, staticContext);
        } catch(XPathException err) {
            compileError(err);
            // recovery path after reporting an error, e.g. undeclared namespace prefix
            return SequenceType.ANY_SEQUENCE;
        }
	}

    /**
    * Process the [xsl:]extension-element-prefixes attribute if there is one
    * @param nc the Clark name  of the attribute required
    */

    protected void processExtensionElementAttribute(String nc)
    throws TransformerConfigurationException {
        String ext = getAttributeValue(nc);
        if (ext!=null) {
        	// go round twice, once to count the values and next to add them to the array
        	int count = 0;
            StringTokenizer st1 = new StringTokenizer(ext);
            while (st1.hasMoreTokens()) {
                st1.nextToken();
                count++;
            }
			extensionNamespaces = new short[count];
			count = 0;
            StringTokenizer st2 = new StringTokenizer(ext);
            while (st2.hasMoreTokens()) {
                String s = st2.nextToken();
                if (s.equals("#default")) {
                	s = "";
                }
                try {
                    short uriCode = getURICodeForPrefix(s);
                    extensionNamespaces[count++] = uriCode;
                } catch (NamespaceException err) {
                    extensionNamespaces = null;
                    compileError(err.getMessage());
                }
            }
        }
    }

    /**
    * Process the [xsl:]exclude-result-prefixes attribute if there is one
    * @param nc the Clark name of the attribute required
    */

    protected void processExcludedNamespaces(String nc)
    throws TransformerConfigurationException {
        String ext = getAttributeValue(nc);
        if (ext!=null) {
            if (ext.trim().equals("#all")) {
                int[] codes = getNamespaceCodes();
                excludedNamespaces = new short[codes.length];
                for (int i = 0; i < codes.length; i++) {
                    excludedNamespaces[i] = (short)(codes[i] & 0xffff);
                }
            } else {
                // go round twice, once to count the values and next to add them to the array
                int count = 0;
                StringTokenizer st1 = new StringTokenizer(ext);
                while (st1.hasMoreTokens()) {
                    st1.nextToken();
                    count++;
                }
                excludedNamespaces = new short[count];
                count = 0;
                StringTokenizer st2 = new StringTokenizer(ext);
                while (st2.hasMoreTokens()) {
                    String s = st2.nextToken();
                    if (s.equals("#default")) {
                        s = "";
                    } else if (s.equals("#all")) {
                        compileError("In exclude-result-prefixes, cannot mix #all with other values");
                    }
                    try {
                        short uriCode = getURICodeForPrefix(s);
                        excludedNamespaces[count++] = uriCode;
                    } catch (NamespaceException err) {
                        excludedNamespaces = null;
                        compileError(err.getMessage());
                    }
                }
            }
        }
    }

    /**
    * Process the [xsl:]version attribute if there is one
    * @param nc the Clark name of the attribute required
    */

    protected void processVersionAttribute(String nc) throws TransformerConfigurationException {
        String v = getAttributeValue(nc);
        if (v!=null) {
            try {
                version = new DecimalValue(v).getValue();
            } catch (XPathException err) {
                throw new TransformerConfigurationException("The version attribute must be a decimal literal");
            }
        }
    }

    /**
    * Get the numeric value of the version number on this element,
    * or inherited from its ancestors
    */

    public BigDecimal getVersion() {
        if (version==null) {
            NodeInfo node = (NodeInfo)getParentNode();
            if (node instanceof StyleElement) {
                version = ((StyleElement)node).getVersion();
            } else {
                version = new BigDecimal("2.0");    // defensive programming
            }
        }
        return version;
    }

    /**
    * Determine whether forwards-compatible mode is enabled for this element
    */

    public boolean forwardsCompatibleModeIsEnabled() {
        return getVersion().compareTo(BigDecimal.valueOf(2)) > 0;
    }

    /**
    * Determine whether backwards-compatible mode is enabled for this element
    */

    public boolean backwardsCompatibleModeIsEnabled() {
        return getVersion().compareTo(BigDecimal.valueOf(2)) < 0;
    }

    /**
    * Check whether a particular extension element namespace is defined on this node.
    * This checks this node only, not the ancestor nodes.
    * The implementation checks whether the prefix is included in the
    * [xsl:]extension-element-prefixes attribute.
    * @param uriCode the namespace URI code being tested
    */

    protected boolean definesExtensionElement(short uriCode) {
    	if (extensionNamespaces==null) {
    		return false;
    	}
    	for (int i=0; i<extensionNamespaces.length; i++) {
    		if (extensionNamespaces[i] == uriCode) {
    			return true;
    		}
    	}
        return false;
    }

    /**
    * Check whether a namespace uri defines an extension element. This checks whether the
    * namespace is defined as an extension namespace on this or any ancestor node.
    * @param uriCode the namespace URI code being tested
    */

    public boolean isExtensionNamespace(short uriCode) {
        NodeInfo anc = this;
        while (anc instanceof StyleElement) {
            if (((StyleElement)anc).definesExtensionElement(uriCode)) {
                return true;
            }
            anc = anc.getParent();
        }
        return false;
    }

    /**
    * Check whether this node excludes a particular namespace from the result.
    * This method checks this node only, not the ancestor nodes.
    * @param uriCode the code of the namespace URI being tested
    */

    protected boolean definesExcludedNamespace(short uriCode) {
    	if (excludedNamespaces==null) {
    		return false;
    	}
    	for (int i=0; i<excludedNamespaces.length; i++) {
    		if (excludedNamespaces[i] == uriCode) {
    			return true;
    		}
    	}
        return false;
    }

    /**
    * Check whether a namespace uri defines an namespace excluded from the result.
    * This checks whether the namespace is defined as an excluded namespace on this
    * or any ancestor node.
    * @param uriCode the code of the namespace URI being tested
    */

    public boolean isExcludedNamespace(short uriCode) {
		if (uriCode==NamespaceConstant.XSLT_CODE) return true;
        if (isExtensionNamespace(uriCode)) return true;
        NodeInfo anc = this;
        while (anc instanceof StyleElement) {
            if (((StyleElement)anc).definesExcludedNamespace(uriCode)) {
                return true;
            }
            anc = anc.getParent();
        }
        return false;
    }

    /**
    * Process the [xsl:]default-xpath-namespace attribute if there is one
    * @param nc the Clark name of the attribute required
    */

    protected void processDefaultXPathNamespaceAttribute(String nc) throws TransformerConfigurationException {
        String v = getAttributeValue(nc);
        if (v!=null) {
            defaultXPathNamespace = v;
        }
    }

    /**
    * Get the default XPath namespace code applicable to this element
    */

    protected short getDefaultXPathNamespace() {
        NodeInfo anc = this;
        while (anc instanceof StyleElement) {
            String x = ((StyleElement)anc).defaultXPathNamespace;
            if (x != null) {
                return getTargetNamePool().allocateCodeForURI(x);
            }
            anc = anc.getParent();
        }
        return NamespaceConstant.NULL_CODE;
                // indicates that the default namespace is the null namespace
    }

    /**
     * Get the Schema type definition for a type named in the stylesheet (in a
     * "type" attribute).
     * @throws TransformerConfigurationException if the type is not declared in an
     * imported schema, or is not a built-in type
    */

    public SchemaType getSchemaType(String typeAtt) throws TransformerConfigurationException {
        try {
            String[] parts = Name.getQNameParts(typeAtt);
            String lname = parts[1];
            String uri;
            if (parts[0].equals("")) {
                // Name is unprefixed: use the default-xpath-namespace
                short uricode = getDefaultXPathNamespace();
                uri = getTargetNamePool().getURIFromURICode(uricode);
                nameCode = getTargetNamePool().allocate(parts[0], uricode, lname);
            } else {
                uri = getURIForPrefix(parts[0], false);

            }
            int nameCode = getTargetNamePool().allocate(parts[0], uri, lname);
            if (uri.equals(NamespaceConstant.SCHEMA)) {
                SchemaType t = BuiltInSchemaFactory.getSchemaType(StandardNames.getFingerprint(uri, lname));
                if (t==null) {
                    compileError("Unknown built-in type " + typeAtt);
                    return null;
                }
                t.setFingerprint(nameCode & 0xfffff);
                return t;
            } else if (uri.equals(NamespaceConstant.XDT)) {
                ItemType t = Type.getBuiltInItemType(uri, lname);
                if (t==null) {
                    if (lname.equals("untyped")) {
                        compileError("Cannot validate a node as 'untyped'");
                    } else {
                        compileError("Unknown built-in type " + typeAtt);
                    }
                }
                ((SimpleType)t).setFingerprint(nameCode & 0xfffff);
                return (SimpleType)t;
            }

            // not a built-in type: look in the imported schemas

            if (!getPrincipalStyleSheet().isImportedSchema(uri)) {
                compileError("There is no imported schema for the namespace of type " + typeAtt);
                return null;
            }
            SchemaType stype = getConfiguration().getSchemaType(nameCode & 0xfffff);
            if (stype == null) {
                compileError("There is no type named " + typeAtt + " in an imported schema");
            }
            return stype;

        } catch (NamespaceException err) {
            compileError("Namespace prefix for type annotation is undeclared");
        } catch (QNameException err) {
            compileError("Invalid type name. " + err.getMessage());
        }
        return null;
    }

    /**
     * Get the type annotation to use for a given schema type
     */

    public int getTypeAnnotation(SchemaType schemaType) {
        if (schemaType != null) {
            return schemaType.getFingerprint();
        } else {
            return -1;
        }
    }

    /**
    * Check that the stylesheet element is valid. This is called once for each element, after
    * the entire tree has been built. As well as validation, it can perform first-time
    * initialisation. The default implementation does nothing; it is normally overriden
    * in subclasses.
    */

    public void validate() throws TransformerConfigurationException {}

    /**
     * Hook to allow additional validation of a parent element immediately after its
     * children have been validated.
     */

    public void postValidate() throws TransformerConfigurationException {}

    /**
    * Type-check an expression. This is called to check each expression while the containing
    * instruction is being validated. It is not just a static type-check, it also adds code
    * to perform any necessary run-time type checking and/or conversion.
    */

    public Expression typeCheck(String name, Expression exp) throws TransformerConfigurationException {
        if (exp==null) return null;
        try {
            exp = exp.analyze(staticContext);
            if (isExplaining()) {
                System.err.println("Attribute '" + name + "' of element '" + getDisplayName() + "' at line " + getLineNumber() + ":");
                System.err.println("Static type: " + new SequenceType(exp.getItemType(), exp.getCardinality()));
                System.err.println("Optimized expression tree:"); exp.display(10, getNamePool());
            }
            allocateSlots(exp);
            return exp;
        } catch (XPathException.Dynamic err) {
            // we can't report a dynamic error such as divide by zero unless the expression
            // is actually executed.
            return new ErrorExpression(err);
        } catch (XPathException err) {
            compileError(err);
            return exp;
        }
    }

    public void allocateSlots(Expression exp) {
        Procedure procedure = getOwningProcedure();
        if (procedure==null || this instanceof XSLTemplate) {
            // this expression is not part of an XSLT procedure, so it needs
            // its own stack frame to contain its variables. The second test
            // deals with expressions in the match pattern of an xsl:template,
            // which are evaluated without a stack frame having been created
            // (test CNFR12, CNFR23)
            //createStackFrame = true;
            int highWater = ExpressionTool.allocateSlots(exp, 0);
            getContainingStyleSheet().allocateLocalSlots(highWater);
        } else {
            int firstSlot = procedure.getNumberOfVariables();
            int highWater = ExpressionTool.allocateSlots(exp, firstSlot);
            if (highWater > firstSlot) {
                getContainingStyleSheet().allocateLocalSlots(highWater);
                procedure.setNumberOfVariables(highWater);
                // This algorithm is not very efficient because it never reuses
                // a slot when a variable goes out of scope. But at least it is safe.
                // Note that range variables within XPath expressions need to maintain
                // a slot until the instruction they are part of finishes, e.g. in
                // xsl:for-each.
            }
        }
    }

    private boolean isExplaining() {
        String s = getAttributeValue(StandardNames.SAXON_EXPLAIN);
        return ("yes".equals(s));
    }

    /**
    * Type-check a pattern. This is called to check each pattern while the containing
    * instruction is being validated. It is not just a static type-check, it also adds code
    * to perform any necessary run-time type checking and/or conversion.
    */

    public Pattern typeCheck(String name, Pattern pat) throws TransformerConfigurationException {
        if (pat==null) return null;
        try {
            return pat.typeCheck(staticContext);
        } catch (XPathException.Dynamic err) {
            // we can't report a dynamic error such as divide by zero unless the pattern
            // is actually executed. We don't have an error pattern available, so we
            // construct one
            LocationPathPattern errpat = new LocationPathPattern();
            errpat.addFilter(new ErrorExpression(err));
            return errpat;
        } catch (XPathException err) {
            throw new TransformerConfigurationException("Error in " + name + " pattern", err);
        }
    }

    /**
    * Fix up references from XPath expressions. Overridden for function declarations
    * and variable declarations
    */

    public void fixupReferences() throws TransformerConfigurationException {
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                return;
            }
            if (child instanceof StyleElement) {
                ((StyleElement)child).fixupReferences();
            }
        }
    }

    /**
     * Get the owning Procedure definition, if this is a local variable
     * @return the Procedure associated with the containing Function, Template, etc,
     * or null if there is no such containing Function, Template etc.
    */

    public Procedure getOwningProcedure() {
        NodeInfo node = this;
        while (true) {
            NodeInfo next = node.getParent();
            if (next instanceof XSLStyleSheet) {
                if (node instanceof XSLTemplate) {
                    return ((XSLTemplate)node).getProcedure();
                } else if (node instanceof XSLGeneralVariable) {
                    return ((XSLGeneralVariable)node).getProcedure();
                } else if (node instanceof XSLFunction) {
                    return ((XSLFunction)node).getProcedure();
                } else if (node instanceof XSLAttributeSet) {
                    return ((XSLAttributeSet)node).getProcedure();
                } else {
                    return null;
                }
            }
            node=next;
        }
    }


    /**
    * Recursive walk through the stylesheet to validate all nodes
    */

    public void validateSubtree() throws TransformerConfigurationException {
        if (validationError!=null) {
            if (reportingCircumstances == REPORT_ALWAYS) {
                compileError(validationError);
            } else if (reportingCircumstances == REPORT_UNLESS_FORWARDS_COMPATIBLE
                          && !forwardsCompatibleModeIsEnabled()) {
                compileError(validationError);
            }
        } //else {
            try {
                validate();
            } catch (TransformerConfigurationException err) {
            	if (forwardsCompatibleModeIsEnabled()) {
            		setValidationError(err, REPORT_IF_INSTANTIATED);
            	} else {
                	compileError(err);
                }
            }

            validateChildren();
            postValidate();
        //}
    }

    /**
    * Validate the children of this node, recursively. Overridden for top-level
    * data elements.
    */

    protected void validateChildren() throws TransformerConfigurationException {
        AxisIterator kids = iterateAxis(Axis.CHILD);
        StyleElement lastChild = null;
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                break;
            }
            if (child instanceof StyleElement) {
                ((StyleElement)child).validateSubtree();
                lastChild = (StyleElement)child;
            }
        }
        if (lastChild instanceof XSLVariable &&
                !(this instanceof XSLStyleSheet)) {
            lastChild.compileWarning(
                    "A variable with no following sibling instructions has no effect");
        }
    }

    /**
    * Default preprocessing method does nothing. It is implemented for those top-level elements
    * that can be evaluated before the source document is available, for example xsl:key,
    * xsl:attribute-set, xsl:template, xsl:decimal-format
    */

    //public void preprocess() throws TransformerConfigurationException {}

    /**
    * Get the principal XSLStyleSheet node. This gets the principal style sheet, i.e. the
    * one originally loaded, that forms the root of the import/include tree
    */

    protected XSLStyleSheet getPrincipalStyleSheet() {
        XSLStyleSheet sheet = getContainingStyleSheet();
        while (true) {
            XSLStyleSheet next = sheet.getImporter();
            if (next==null) return sheet;
            sheet = next;
        }
    }

    /**
    * Get the PreparedStyleSheet object.
    * @return the PreparedStyleSheet to which this stylesheet element belongs
    */

    public PreparedStyleSheet getPreparedStyleSheet() {
        return getPrincipalStyleSheet().getPreparedStyleSheet();
    }

    /**
    * Check that the stylesheet element is within a sequence constructor
    * @throws TransformerConfigurationException if not within a sequence constructor
    */

    public void checkWithinTemplate() throws TransformerConfigurationException {
        StyleElement parent = (StyleElement)getParentNode();
        if (!parent.mayContainSequenceConstructor()) {
            compileError("Element must only be used within a sequence constructor");
        }
    }

    /**
    * Convenience method to check that the stylesheet element is at the top level
    * @throws TransformerConfigurationException if not at top level
    */

    public void checkTopLevel() throws TransformerConfigurationException {
        if (!(getParentNode() instanceof XSLStyleSheet)) {
            compileError("Element must only be used at top level of stylesheet");
        }
    }

    /**
    * Convenience method to check that the stylesheet element is not at the top level
    * @throws TransformerConfigurationException if it is at the top level
    */

//    public void checkNotTopLevel() throws TransformerConfigurationException {
//        if (getParentNode() instanceof XSLStyleSheet) {
//            compileError("Element must not be used at top level of stylesheet");
//        }
//    }

    /**
    * Convenience method to check that the stylesheet element is empty
    * @throws TransformerConfigurationException if it is not empty
    */

    public void checkEmpty() throws TransformerConfigurationException {
        if (hasChildNodes()) {
            compileError("Element must be empty");
        }
    }

    /**
    * Convenience method to report the absence of a mandatory attribute
    * @throws TransformerConfigurationException if the attribute is missing
    */

    public void reportAbsence(String attribute)
    throws TransformerConfigurationException {
        compileError("Element must have a \"" + attribute + "\" attribute");
    }


    /**
    * Get the static type of the context item in the content constructor
     * contained by this element.
    * @return the static type of the context item, or
     * Type.EMPTY if it is known that there will be no context item
    */

    public ItemType getContextItemType() {
        // TODO: not currently used
        // this is overridden where better information is available
        if (isTopLevel()) {
            return NodeKindTest.DOCUMENT;
        } else {
            return ((StyleElement)getParent()).getContextItemType();
        }
    }

    /**
    * Compile the instruction on the stylesheet tree into an executable instruction
    * for use at run-time.
    * @return either an Instruction, or null. The value null is returned when compiling an instruction
     * that returns a no-op, or when compiling a top-level object such as an xsl:template that compiles
     * into something other than an instruction.
    */

    public abstract Instruction compile(Executable exec) throws TransformerConfigurationException;

    /**
    * Compile the children of this instruction on the stylesheet tree, adding the
    * subordinate instructions to the parent instruction on the execution tree.
     * @return the array of children
    */

    public Instruction[] compileChildren(Executable exec, Instruction inst) throws TransformerConfigurationException {
        inst.setExecutable(exec);
        XSLStyleSheet top = getPrincipalStyleSheet();
        List list = new ArrayList();
        AxisIterator kids = iterateAxis(Axis.CHILD);
        // System.err.println("Setting contents of instruction " + inst.getInstructionName());
	    while (true) {
            NodeInfo node = (NodeInfo)kids.next();
            if (node == null) {
                break;
            }
    		if (node.getNodeKind() == Type.TEXT) {
    		    // handle literal text nodes by generating an xsl:text instruction
    		    Text text = new Text(false);
                text.setExecutable(exec);
    		    text.setSelect(new StringValue(node.getStringValue()));
      			text.setSourceLocation(top.putModuleNumber(node.getSystemId()),
      			                                node.getLineNumber());
    		    list.add(text);
    		} else if (node instanceof StyleElement) {
    		    StyleElement snode = (StyleElement)node;
    		    if (snode.validationError != null) {
    		    	fallbackProcessing(exec, snode, list);
    		    } else {
    		        Instruction child = snode.compile(exec);
    		        if (child != null) {
                        child.setExecutable(exec);
                        child.setSourceLocation(top.putModuleNumber(snode.getSystemId()),
                                            snode.getLineNumber());
                        if (getConfiguration().getTraceListener() != null) {
                            child = snode.makeTraceInstruction(child);
                            child.setExecutable(exec);
                        }
                        list.add(child);

                    }
        		}
    		}
	    }
	    Instruction[] array = new Instruction[list.size()];
        array = (Instruction[])list.toArray(array);
	    inst.setChildren(array);
        return array;
	}

    /**
     * Create a trace instruction to wrap a real instruction
     */

    private TraceInstruction makeTraceInstruction(Instruction child) {
        if (child instanceof TraceInstruction) {
            return (TraceInstruction)child;
            // this can happen, for example, after optimizing a compile-time xsl:if
        }
        TraceInstruction trace = new TraceInstruction(child);
        setAdditionalTraceProperties(trace);
        return trace;
    }

    /**
     * Set additional trace properties appropriate to the kind of instruction. Default
     * implementation does nothing.
     */

    protected void setAdditionalTraceProperties(TraceInstruction trace) {}

	/**
	 * Perform fallback processing. Generate fallback code for an extension
     * instruction that is not recognized by the implementation.
     * @param instruction The unknown extension instruction
     * @param list a List to be populated with instructions. The method
     * creates one Block instruction for each xsl:fallback found.
	*/

	protected void fallbackProcessing(Executable exec, StyleElement instruction, List list)
	throws TransformerConfigurationException {
        // process any xsl:fallback children; if there are none,
        // generate code to report the original failure reason
        boolean foundFallback = false;
        AxisIterator kids = instruction.iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                break;
            }
            if (child instanceof XSLFallback) {
                foundFallback = true;
                XSLStyleSheet top = getPrincipalStyleSheet();
                Block fallback = new Block();
                fallback.setSourceLocation(top.putModuleNumber(child.getSystemId()),
      			                                child.getLineNumber());
      			fallback.setInstructionName(Block.FALLBACK);
                ((XSLFallback)child).compileChildren(exec, fallback);
                list.add(fallback);
            }
        }

        if (!foundFallback) {
        	list.add(new DeferredError(instruction.validationError, instruction.getDisplayName()));
        }

	}

    /**
    * Construct sort keys for a SortedIterator
     * @return an array of SortKeyDefinition objects if there are any sort keys;
     * or null if there are none.
    */

    protected SortKeyDefinition[] makeSortKeys() {
        // handle sort keys if any

        int numberOfSortKeys = 0;
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while(true) {
            Item child = kids.next();
            if (child == null) {
                break;
            }
            if (child instanceof XSLSort) {
                numberOfSortKeys++;
            }
        }

        if (numberOfSortKeys > 0) {
            SortKeyDefinition[] keys = new SortKeyDefinition[numberOfSortKeys];
            kids = iterateAxis(Axis.CHILD);
            int k=0;
            while(true) {
                NodeInfo child = (NodeInfo)kids.next();
                if (child==null) {
                    break;
                }
                if (child instanceof XSLSort) {
                    keys[k++] = ((XSLSort)child).getSortKeyDefinition();
                }
            }
            return keys;

        } else {
            return null;
        }
    }

    /**
    * Get the list of attribute-sets associated with this element.
    * This is used for xsl:element, xsl:copy, xsl:attribute-set, and on literal
    * result elements
    * @param use: the original value of the [xsl:]use-attribute-sets attribute
    * @param list: an empty list to hold the list of XSLAttributeSet elements in the stylesheet tree.
    * Or null, if these are not required.
    * @return an array of AttributeList instructions representing the compiled attribute sets
    */

    protected AttributeSet[] getAttributeSets(String use, List list)
    throws TransformerConfigurationException {

        if (list == null) {
            list = new ArrayList();
        }

        XSLStyleSheet stylesheet = getPrincipalStyleSheet();
        List toplevel = stylesheet.getTopLevel();

        StringTokenizer st = new StringTokenizer(use);
        while (st.hasMoreTokens()) {
            String asetname = st.nextToken();
            int fprint;
            try {
                fprint = makeNameCode(asetname) & 0xfffff;
            } catch (NamespaceException err) {
                compileError(err.getMessage());
                fprint = -1;
            } catch (XPathException err) {
                compileError(err.getMessage());
                fprint = -1;
            }
            boolean found = false;

            // search for the named attribute set, using all of them if there are several with the
            // same name

            for (int i=0; i<toplevel.size(); i++) {
                if (toplevel.get(i) instanceof XSLAttributeSet) {
                    XSLAttributeSet t = (XSLAttributeSet)toplevel.get(i);
                    if (t.getAttributeSetFingerprint() == fprint) {
                        list.add(t);
                        found = true;
                    }
                }
            }

            if (!found) {
                compileError("No attribute-set exists named " + asetname);
            }
        }

        AttributeSet[] array = new AttributeSet[list.size()];
        for (int i=0; i<list.size(); i++) {
            XSLAttributeSet aset = (XSLAttributeSet)list.get(i);
            aset.incrementReferenceCount();
            array[i] = aset.getInstruction();
        }
        return array;
    }

    /**
    * Get the list of xsl:with-param elements for a calling element (apply-templates,
    * call-template, apply-imports, next-match). This method can be used to get either
     * the tunnel parameters, or the non-tunnel parameters.
     * @param tunnel true if the tunnel="yes" parameters are wanted, false to get
     * the non-tunnel parameters
    */

    protected WithParam[] getWithParamInstructions(Executable exec, boolean tunnel) throws TransformerConfigurationException {
        int count = 0;
        AxisIterator kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                break;
            }
            if (child instanceof XSLWithParam) {
                XSLWithParam wp = (XSLWithParam)child;
                if (wp.isTunnelParam() == tunnel) {
                    count++;
                }
            }
        }
        WithParam[] array = new WithParam[count];
        count = 0;
        kids = iterateAxis(Axis.CHILD);
        while (true) {
            NodeInfo child = (NodeInfo)kids.next();
            if (child == null) {
                return array;
            }
            if (child instanceof XSLWithParam) {
                XSLWithParam wp = (XSLWithParam)child;
                if (wp.isTunnelParam() == tunnel) {
                    array[count++] = (WithParam)wp.compile(exec);
                }

            }
        }
    }

    /**
    * Construct an exception with diagnostic information
    */

    protected void compileError(TransformerException error)
    throws TransformerConfigurationException {

        // Set the location of the error if there is not current location information,
        // or if the current location information is local to the XPath expression
        if (error.getLocator()==null || error.getLocator() instanceof ExpressionLocation) {
            error.setLocator(this);
        }
        PreparedStyleSheet pss = getPreparedStyleSheet();
        try {
            if (pss==null) {
                // it is null before the stylesheet has been fully built
                throw error;
            } else {
                pss.reportError(error);
            }
        } catch (TransformerException err2) {
            if (err2 instanceof TransformerConfigurationException) {
                throw (TransformerConfigurationException)err2;
            }
            if (err2.getException() instanceof TransformerConfigurationException) {
                throw (TransformerConfigurationException)err2.getException();
            }
            TransformerConfigurationException tce = new TransformerConfigurationException(error);
            tce.setLocator(this);
            throw tce;
        }
    }

    protected void compileError(String message)
    throws TransformerConfigurationException {
        TransformerConfigurationException tce =
            new TransformerConfigurationException(message);
        tce.setLocator(this);
        compileError(tce);
    }

    protected void compileWarning(String message)
    throws TransformerConfigurationException {
        TransformerConfigurationException tce =
            new TransformerConfigurationException(message);
        tce.setLocator(this);
        PreparedStyleSheet pss = getPreparedStyleSheet();
        if (pss!=null) {
            pss.reportWarning(tce);
        }
    }

    /**
    * Construct an exception with diagnostic information
    */

    protected void issueWarning(TransformerException error) {
        if (error.getLocator()==null) {
            error.setLocator(this);
        }
        PreparedStyleSheet pss = getPreparedStyleSheet();
        if (pss!=null) {
            // it is null before the stylesheet has been fully built - ignore it
            pss.reportWarning(error);
        }
    }

    protected void issueWarning(String message) {
        TransformerConfigurationException tce =
            new TransformerConfigurationException(message);
        tce.setLocator(this);
        issueWarning(tce);
    }

    /**
    * Test whether this is a top-level element
    */

    public boolean isTopLevel() {
        return (getParentNode() instanceof XSLStyleSheet);
    }

    /**
    * Bind a variable used in this element to the compiled form of the XSLVariable element in which it is
    * declared
    * @param fingerprint The fingerprint of the name of the variable
    * @return the XSLVariableDeclaration (that is, an xsl:variable or xsl:param instruction) for the variable
    * @throws XPathException.Static if the variable has not been declared
    */

    public XSLVariableDeclaration bindVariable(int fingerprint) throws XPathException.Static {
        XSLVariableDeclaration binding = getVariableBinding(fingerprint);
        if (binding==null) {
            throw new XPathException.Static("Variable " + getTargetNamePool().getDisplayName(fingerprint) + " has not been declared");
        }
        return binding;
    }

    /**
    * Bind a variable used in this element to the declaration in the stylesheet
    * @param fprint The absolute name of the variable (prefixed by namespace URI)
    * @return the XSLVariableDeclaration, or null if it has not been declared
    */

    public XSLVariableDeclaration getVariableBinding(int fprint) {
        NodeInfo curr = this;
        NodeInfo prev = this;

        // first search for a local variable declaration
        if (!isTopLevel()) {
            AxisIterator preceding = curr.iterateAxis(Axis.PRECEDING_SIBLING);
            while (true) {
                curr = (NodeInfo)preceding.next();
                while (curr == null) {
                    curr = prev.getParent();
                    prev = curr;
                    if (curr.getParent() instanceof XSLStyleSheet) {
                        break;   // top level
                    }
                    preceding = curr.iterateAxis(Axis.PRECEDING_SIBLING);
                    curr = (NodeInfo)preceding.next();
                }
                if (curr.getParent() instanceof XSLStyleSheet) break;
                if (curr instanceof XSLVariableDeclaration) {
                    XSLVariableDeclaration var = (XSLVariableDeclaration)curr;
                    if (var.getVariableFingerprint()==fprint) {
                        return var;
                    }
                }
            }
        }

        // Now check for a global variable
        // we rely on the search following the order of decreasing import precedence.

        XSLStyleSheet root = getPrincipalStyleSheet();
        XSLVariableDeclaration var = root.getGlobalVariable(fprint);
        return var;
    }

    /**
    * List the variables that are in scope for this stylesheet element.
    * Designed for a debugger, not used by the processor.
    * @return two Enumeration of Strings, the global ones [0] and the local ones [1]
    */



    /**
    * Get a FunctionCall declared using an xsl:function element in the stylesheet
    * @param fingerprint the fingerprint of the name of the function
    * @param arity the number of arguments in the function call. The value -1
    * indicates that any arity will do (this is used to support the function-available() function).
    * @return the XSLFunction object representing the function declaration
     * in the stylesheet, or null if no such function is defined.
    */

    public XSLFunction getStyleSheetFunction(int fingerprint, int arity) {

        // we rely on the search following the order of decreasing import precedence.

        XSLStyleSheet root = getPrincipalStyleSheet();
        List toplevel = root.getTopLevel();
        for (int i=toplevel.size()-1; i>=0; i--) {
            Object child = toplevel.get(i);
            if (child instanceof XSLFunction &&
                    ((XSLFunction)child).getFunctionFingerprint() == fingerprint &&
                    (arity==-1 || ((XSLFunction)child).getNumberOfArguments() == arity)) {
                XSLFunction func = (XSLFunction)child;
                return func;
            }
        }
        return null;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
