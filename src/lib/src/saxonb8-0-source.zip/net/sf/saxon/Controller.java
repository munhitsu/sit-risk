package net.sf.saxon;
import net.sf.saxon.dom.DocumentWrapper;
import net.sf.saxon.event.*;
import net.sf.saxon.expr.FunctionProxy;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.instruct.Bindery;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.instruct.RegexIterator;
import net.sf.saxon.instruct.TailCall;
import net.sf.saxon.instruct.Template;
import net.sf.saxon.instruct.TerminationException;
import net.sf.saxon.om.*;
import net.sf.saxon.sort.GroupIterator;
import net.sf.saxon.tinytree.TinyBuilder;
import net.sf.saxon.trace.SaxonEventMulticaster;
import net.sf.saxon.trace.TraceListener;
import net.sf.saxon.trans.DecimalFormatManager;
import net.sf.saxon.trans.KeyManager;
import net.sf.saxon.trans.Mode;
import net.sf.saxon.trans.RuleManager;
import net.sf.saxon.tree.TreeBuilder;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.EmptySequence;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.value.Value;
import net.sf.saxon.xpath.XPathException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXParseException;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import java.io.PrintStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Properties;

/**
 * <B>Controller</B> processes an XML file, calling registered node handlers
 * when appropriate to process its elements, character content, and attributes.
 * This is Saxon's implementation of the JAXP Transformer class<P>
 *
 * @author Michael H. Kay
 */

public class Controller extends Transformer {

    private Configuration config;
    private DocumentInfo principalSourceDocument;
    private Bindery bindery;                // holds values of global and local variables
    private NamePool namePool;
    private DecimalFormatManager decimalFormatManager;
    private Emitter messageEmitter;
    private RuleManager ruleManager;
    private Properties outputProperties;
    private SequenceReceiver currentOutputter;
    private ParameterSet parameters;
    private PreparedStyleSheet preparedStyleSheet;
    private TraceListener traceListener; // e.g.
    private boolean tracingPaused;
    private URIResolver standardURIResolver;
    private URIResolver userURIResolver;
    private Result principalResult;
    private String principalResultURI;
    private OutputURIResolver outputURIResolver;
    private ErrorListener errorListener;
    private Executable executable;
    private int recoveryPolicy = Configuration.RECOVER_WITH_WARNINGS;
    private int temporaryDestinationDepth = 0;
    private int treeModel = Builder.TINY_TREE;
    private boolean disableStripping = false;
    private Template initialTemplate = null;

    private DocumentPool sourceDocumentPool;
    private HashMap userDataTable;
    private boolean lineNumbering;
    private GregorianCalendar currentDateTime;
    private int initialMode = -1;

    // variables previously part of XSLTContext

    private SequenceIterator currentIterator = null;
    private Mode currentMode = null;
    private Template currentTemplate = null;
    private GroupIterator currentGroupIterator = null;
    private NodeInfo lastRememberedNode = null;
    private int lastRememberedNumber = -1;
    private RegexIterator currentRegexIterator = null;

    /**
     * Create a Controller and initialise variables. Constructor is protected,
     * the Controller should be created using newTransformer() in the PreparedStyleSheet
     * class.
     *
     * @param config The Configuration used by this Controller
     */

    public Controller(Configuration config) {
        this.config = config;
        init();
    }

    private void init() {
        bindery = new Bindery();
		namePool = NamePool.getDefaultNamePool();
        standardURIResolver = new StandardURIResolver(config);
        userURIResolver = config.getURIResolver();

        outputURIResolver = config.getOutputURIResolver();
        errorListener = config.getErrorListener();
        if (errorListener instanceof StandardErrorListener) {
            // if using a standard error listener, make a fresh one
            // for each transformation, because it is stateful
            PrintStream ps = ((StandardErrorListener)errorListener).getErrorOutput();
            errorListener = new StandardErrorListener();
            ((StandardErrorListener)errorListener).setErrorOutput(ps);
            ((StandardErrorListener)errorListener).setRecoveryPolicy(
                    config.getRecoveryPolicy());
        }
        sourceDocumentPool = new DocumentPool();
        userDataTable = new HashMap();

        TraceListener tracer = config.getTraceListener();
        if (tracer!=null) {
            addTraceListener(tracer);
        }

        if (config.isLineNumbering()) {
            setLineNumbering(true);
        }

        setTreeModel(config.getTreeModel());

    }

    public Configuration getConfiguration() {
        return config;
    }

    /**
     * Set the initial mode for the transformation.
     *
     * @param expandedModeName the name of the initial mode.  The mode is
     *     supplied as an expanded QName, that is "localname" if there is no
     *     namespace, or "{uri}localname" otherwise
     */

    public void setInitialMode(String expandedModeName) {
        if (expandedModeName==null) return;
        if (expandedModeName.equals("")) return;
        initialMode = namePool.allocateClarkName(expandedModeName);
    }


    //////////////////////////////////////////////////////////////////////////
    // Methods to process the tree
    //////////////////////////////////////////////////////////////////////////


    /**
     * Process a Document.<p>
     * This method is intended for use when performing a pure Java transformation,
     * without a stylesheet. Where there is an XSLT stylesheet, use transformDocument()
     * or transform() instead: those methods set up information from the stylesheet before calling
     * run(). <p>
     * The process starts by calling the registered node
     * handler to process the supplied node. Note that the same document can be processed
     * any number of times, typically with different node handlers for each pass. The NodeInfo
     * will typically be the root of a tree built using net.sf.saxon.event.Builder.<p>
     *
     * @param node The node at which processing should start
     * @exception TransformerException if the transformation fails for any
     *     reason
     */

    public void run(NodeInfo node) throws TransformerException
    {
        principalSourceDocument = node.getDocumentRoot();
        if (principalSourceDocument == null) {
            throw new TransformerException("Source tree must be rooted at a document node");
        }
        makeContext(node);
        TailCall tc = applyTemplates(
                            SingletonIterator.makeIterator(node),
                            getRuleManager().getMode(initialMode),
                            null, null);
        while (tc != null) {
            tc = tc.processLeavingTail(this);
        }
    }

    /**
     * Process selected nodes using the handlers registered for a particular
     * mode.
     *
     * @exception TransformerException if any dynamic error occurs
     * @param iterator an Iterator over the nodes to be processed, in the
     *     correct (sorted) order
     * @param mode Identifies the processing mode. It should match the
     *     mode defined when the element handler was registered using
     *     setHandler with a mode parameter. Set this parameter to null to
     *     invoke the default mode.
     * @param parameters A ParameterSet containing the parameters to
     *     the handler/template being invoked. Specify null if there are no
     *     parameters.
     * @return a TailCall returned by the last template to be invoked, or null,
     *     indicating that there are no outstanding tail calls.
     */

    public TailCall applyTemplates( SequenceIterator iterator,
                                Mode mode,
                                ParameterSet parameters,
                                ParameterSet tunnelParameters)
                                throws TransformerException {
        SequenceIterator savedIterator = getCurrentIterator();
        Mode savedMode = getCurrentMode();
        TailCall tc = null;

        // Iterate over this sequence

        if (isTracing()) {

            setCurrentIterator(iterator);
            setCurrentMode(mode);
            while(true) {
                // process any tail calls returned from previous nodes
                while (tc != null) {
                    tc = tc.processLeavingTail(this);
                }

                NodeInfo node = (NodeInfo)iterator.next();
                        // We can assume it's a node - we did static type checking
                if (node == null) break;

                // find the node handler [i.e., the template rule] for this node

                Template eh = ruleManager.getTemplateRule(node, mode, this);

                if (eh==null) {             // Use the default action for the node
                                            // No need to open a new stack frame!
                    defaultAction(node, parameters, tunnelParameters);

                } else {
                    if (tunnelParameters != null || eh.needsStackFrame()) {
                        bindery.openStackFrame(parameters, tunnelParameters);
                        traceListener.startCurrentItem(node);
                        tc = eh.processLeavingTail(this);
                        traceListener.endCurrentItem(node);
                        bindery.closeStackFrame();
                    } else {
                        traceListener.startCurrentItem(node);
                        tc = eh.processLeavingTail(this);
                        traceListener.endCurrentItem(node);
                    }
                }
            }
            setCurrentMode(savedMode);
            setCurrentIterator(savedIterator);

        } else {    // not tracing

            setCurrentIterator(iterator);
            setCurrentMode(mode);
            while(true) {

                // process any tail calls returned from previous nodes
                while (tc != null) {
                    tc = tc.processLeavingTail(this);
                }

                NodeInfo node = (NodeInfo)iterator.next();
                        // We can assume it's a node - we did static type checking
                if (node == null) break;

                // find the node handler [i.e., the template rule] for this node

                Template eh = ruleManager.getTemplateRule(node, mode, this);

                if (eh==null) {             // Use the default action for the node
                                            // No need to open a new stack frame!
                    defaultAction(node, parameters, tunnelParameters);

                } else {
                    if (tunnelParameters != null || eh.needsStackFrame()) {
                        bindery.openStackFrame(parameters, tunnelParameters);
                        tc = eh.processLeavingTail(this);
                        bindery.closeStackFrame();
                    } else {
                        tc = eh.processLeavingTail(this);
                    }
                }
            }
            setCurrentMode(savedMode);
            setCurrentIterator(savedIterator);
        }
        // return the TailCall returned from the last node processed
        return tc;
    }

    /**
     * Perform the built-in template action for a given node.
     *
     * @param node the node to be processed
     * @param parameters the parameters supplied to apply-templates
     * @param tunnelParams the tunnel parameters to be passed through
     * @exception TransformerException if any dynamic error occurs
     */

    private void defaultAction(NodeInfo node, ParameterSet parameters, ParameterSet tunnelParams) throws TransformerException {
        switch(node.getNodeKind()) {
            case Type.DOCUMENT:
            case Type.ELEMENT:
                SequenceIterator iter = node.iterateAxis(Axis.CHILD);
	            TailCall tc = applyTemplates(iter, getCurrentMode(), parameters, tunnelParams);
                while (tc != null) {
                    tc = tc.processLeavingTail(this);
                }
	            return;
	        case Type.TEXT:
	            // NOTE: I tried changing this to use the text node's copy() method, but
	            // performance was worse
	        case Type.ATTRIBUTE:
	            getReceiver().characters(node.getStringValue(), 0);
	            return;
	        case Type.COMMENT:
	        case Type.PROCESSING_INSTRUCTION:
	        case Type.NAMESPACE:
	            // no action
	            return;
        }
    }

    /**
     * Apply a template imported from the stylesheet containing the current template.
     *
     * @param min the minimum import precedence of template rules to be
     *     considered
     * @param max the maximum import precedence of template rules to be
     *      considered
     * @param params parameters supplied to xsl:apply-imports
     * @param tunnelParams tunnel parameters supplied to xsl:apply-imports (directly
     * or indirectly)
     * @exception TransformerException if any dynamic error occurs
     */

    public void applyImports(int min, int max, ParameterSet params, ParameterSet tunnelParams)
    throws TransformerException {
        Mode mode = getCurrentMode();
        if (getCurrentIterator()==null) {
            throw new TransformerException("There is no context item");
        }
        Item currentItem = getCurrentIterator().current();
        if (!(currentItem instanceof NodeInfo)) {
            throw new TransformerException("Cannot call xsl:apply-imports when context item is not a node");
        }
        NodeInfo node = (NodeInfo)currentItem;
        Template nh = ruleManager.getTemplateRule(node, mode, min, max, this);

		if (nh==null) {             // use the default action for the node
            defaultAction(node, params, tunnelParams);
        } else {
            bindery.openStackFrame(params, tunnelParams);
            nh.process(this);
            bindery.closeStackFrame();
        }
    }

    /**
     * Apply the next matching template.
     *
     * @param params parameters supplied to the xsl:next-match instruction
     * @param tunnelParams tunnel parameters supplied to xsl:apply-imports (directly
     * or indirectly)
     * @exception TransformerException
     */

    public void nextMatch(ParameterSet params, ParameterSet tunnelParams) throws TransformerException {
        Template currentTemplate = getCurrentTemplate();
        if (currentTemplate==null) {
            throw new TransformerException("There is no current template rule");
        }
        Mode mode = getCurrentMode();
        if (getCurrentIterator()==null) {
            throw new TransformerException("There is no context item");
        }
        Item currentItem = getCurrentIterator().current();
        if (!(currentItem instanceof NodeInfo)) {
            throw new TransformerException("Cannot call xsl:next-match when context item is not a node");
        }
        NodeInfo node = (NodeInfo)currentItem;
        Template nh = ruleManager.getNextMatchHandler(node, mode, currentTemplate, this);

		if (nh==null) {             // use the default action for the node
            defaultAction(node, params, tunnelParams);
        } else {
            bindery.openStackFrame(params, tunnelParams);
            nh.process(this);
            bindery.closeStackFrame();
        }
    }

    ////////////////////////////////////////////////////////////////////////////////
    // Methods for managing output destinations and formatting
    ////////////////////////////////////////////////////////////////////////////////

    /**
     * Set the output properties for the transformation.  These
     * properties will override properties set in the templates
     * with xsl:output.
     *
     * @param properties the output properties to be used for the
     *     transformation
     */

    public void setOutputProperties(Properties properties) {
        Enumeration keys = properties.propertyNames();
        while(keys.hasMoreElements()) {
            String key = (String)keys.nextElement();
            setOutputProperty(key, properties.getProperty(key));
        }
    }

    /**
     * Get the output properties for the transformation.
     *
     * @return the output properties being used for the transformation,
     *     including properties defined in the stylesheet for the unnamed
     *     output format
     */

    public Properties getOutputProperties() {
        if (outputProperties == null) {
            if (executable==null) {
                return new Properties();
            } else {
                outputProperties = executable.getDefaultOutputProperties();
            }
        }

        // Make a copy, so that modifications to the returned properties have no effect

        Properties newProps = new Properties();
        Enumeration keys = outputProperties.propertyNames();
        while(keys.hasMoreElements()) {
            String key = (String)keys.nextElement();
            newProps.put(key, outputProperties.getProperty(key));
        }
        return newProps;
    }

    /**
     * Set an output property for the transformation.
     *
     * @param name the name of the property
     * @param value the value of the property
     */

    public void setOutputProperty(String name, String value) {
        if (outputProperties == null) {
            outputProperties = getOutputProperties();
        }
        if (!SaxonOutputKeys.isValidOutputKey(name)) {
            throw new IllegalArgumentException(name);
        }
        outputProperties.put(name, value);
    }

    /**
     * Get the value of an output property.
     *
     * @param name the name of the requested property
     * @return the value of the requested property
     * @see net.sf.saxon.event.SaxonOutputKeys
     */

    public String getOutputProperty(String name) {
        if (!SaxonOutputKeys.isValidOutputKey(name)) {
            throw new IllegalArgumentException(name);
        }
        if (outputProperties == null) {
            if (executable==null) {
                return null;
            } else {
                outputProperties = executable.getDefaultOutputProperties();
            }
        }
        return outputProperties.getProperty(name);
    }

    /**
     * Get the URI of the principal result destination.
     *
     * @return the URI, as a String
     */

    public String getPrincipalResultURI() {
        return principalResultURI;
    }

    /**
     * Get the principal result destination
     */

    public Result getPrincipalResult() {
        return principalResult;
    }

    /**
     * Set a new output destination, supplying the output format details. <BR>
     * This affects all further output until resetOutputDestination() is called. Note that
     * it is the caller's responsibility to close the Writer after use.
     *
     * @exception TransformerException if any dynamic error occurs; and
     *     specifically, if an attempt is made to switch to a final output
     *     destination while writing a temporary tree or sequence
     * @param props properties defining the output format
     * @param result Details of the new output destination
     * @param isFinal true if the destination is a final result tree
     *     (either the principal output or a secondary result tree); false if
     *     it is a temporary tree, xsl:attribute, etc.
     */

    public void changeOutputDestination(Properties props,
                                        Result result,
                                        boolean isFinal,
                                        int validation,
                                        SchemaType schemaType)
    throws TransformerException {
        if (isFinal && (temporaryDestinationDepth>0)) {
            throw new TransformerException("Cannot switch to a final result destination while writing a temporary tree");
        }
        if (!isFinal) {
            temporaryDestinationDepth++;
        }
        ComplexContentOutputter out = new ComplexContentOutputter();
        out.setConfiguration(config);
        //out.setOutputURIResolver(outputURIResolver);
        //out.setOutputDestination(props, result, executable.getCharacterMapIndex());
        if (props == null) {
            props = new Properties();
        }
        setOutputProperties(props);

        Receiver receiver = ResultWrapper.getReceiver(
                                            result,
                                            config,
                                            props,
                                            executable.getCharacterMapIndex());

        // add a validator to the pipeline if required

        if (schemaType != null) {
            System.err.println("Type attribute for result document is currently ignored");
            // TODO: implement this
        }

        receiver = getConfiguration().getDocumentValidator(
                receiver, receiver.getSystemId(), getNamePool(), validation
        );

		// add a filter to remove duplicate namespaces

		NamespaceReducer ne = new NamespaceReducer();
		ne.setUnderlyingReceiver(receiver);
		ne.setConfiguration(config);
		out.setReceiver(ne);

        out.startDocument();
        currentOutputter = out;
    }

    /**
     * Set the output destination to write to a sequence. <BR>
     * This affects all further output until resetOutputDestination() is called.
     *
     * @exception TransformerException if any dynamic error occurs
     * @param out The SequenceOutputter to be used
     */

    public void changeToSequenceOutputDestination(SequenceReceiver out)
    throws TransformerException {
        temporaryDestinationDepth++;
        currentOutputter = out;
    }


    /**
     * Set a simple StringBuffer output destination. Used during calls to
     * xsl:attribute, xsl:comment, xsl:processing-instruction
     *
     * @param buffer the StringBuffer in which the string value of the node
     *     will be assembled
     */

    public void changeToTextOutputDestination(StringBuffer buffer) {
        temporaryDestinationDepth++;
        currentOutputter = new SimpleContentOutputter(buffer);
    }

    /**
     * Change the Receiver to which output is written
     */

    public void setReceiver(SequenceReceiver receiver) {
        currentOutputter = receiver;
    }

    /**
     * Get the Receiver to which output is currently being written.
     *
     * @return the current Receiver
     */
    public SequenceReceiver getReceiver() {
        return currentOutputter;
    }

    /**
     * Close the current receiver, and revert to the previous receiver.
     *
     * @exception TransformerException if any dynamic error occurs
     * @param receiver The receiver to revert to
     */

    public void resetOutputDestination(SequenceReceiver receiver) throws TransformerException {
        //System.err.println("resetOutputDestination");
        if (currentOutputter==null) {
            throw new IllegalStateException("No outputter has been allocated");
        }
        if (temporaryDestinationDepth > 0) {
            temporaryDestinationDepth--;
        }
        currentOutputter.endDocument();
        currentOutputter = receiver;
    }

    ///////////////////////////////////////////////////////////////////////////////

    /**
     * Set the initial named template to be used as the entry point
     * @param expandedName The expanded name of the template in {uri}local format
     * @throws TransformerException if there is no named template with this name
     */

    public void setInitialTemplate(String expandedName) throws TransformerException {
        int fingerprint = namePool.allocateClarkName(expandedName);
        HashMap templateTable = getExecutable().getNamedTemplateTable();
        Template t = (Template)templateTable.get(new Integer(fingerprint));
        if (t == null) {
            throw new TransformerException("There is no named template with expanded name "
                                           + expandedName);
        } else {
            initialTemplate = t;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////

    /**
     * Make an Emitter to be used for xsl:message output.
     *
     * @exception TransformerException if any dynamic error occurs; in
     *     particular, if the registered MessageEmitter class is not an
     *     Emitter
     * @return The newly constructed message Emitter
     */

    public Emitter makeMessageEmitter() throws TransformerException {
        String emitterClass = config.getMessageEmitterClass();

        Object emitter = Loader.getInstance(emitterClass);
        if (!(emitter instanceof Emitter)) {
            throw new TransformerException(emitterClass + " is not an Emitter");
        }
        messageEmitter = (Emitter)emitter;
        messageEmitter.setConfiguration(config);
        return messageEmitter;
    }

    /**
     * Get the Emitter used for xsl:message output.
     *
     * @return the Emitter being used for xsl:message output
     */

    public Emitter getMessageEmitter() {
       return messageEmitter;
    }

    /**
     * Get the policy for handling recoverable errors.
     *
     * @return the current policy, as set by setRecoveryPolicy
     */

    public int getRecoveryPolicy() {
        return recoveryPolicy;
    }

	/**
	 * Set the error listener.
	 *
	 * @param listener the ErrorListener to be used
	 */

	public void setErrorListener(ErrorListener listener) {
		errorListener = listener;
	}

	/**
	 * Get the error listener.
	 *
	 * @return the ErrorListener in use
	 */

	public ErrorListener getErrorListener() {
		return errorListener;
	}

    /**
     * Report a recoverable error.
     *
     * @param message the error message
     * @param location the stylesheet location at which the error
     *     occurred
     * @exception TransformerException if the error listener decides not to
     *     recover from the error
     */

    public void recoverableError(String message, SourceLocator location) throws TransformerException {
        if (location==null) {
            errorListener.warning(new TransformerException(message));
        } else {
            TransformerException err = new TransformerException(message, location);
            errorListener.warning(err);
        }
    }

    /**
     * Report a recoverable error.
     *
     * @param err An exception holding information about the error
     * @exception TransformerException if the error listener decides not to
     *     recover from the error
     */

    public void recoverableError(TransformerException err) throws TransformerException {
        errorListener.warning(err);
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // Methods for managing the various runtime control objects
    /////////////////////////////////////////////////////////////////////////////////////////


    /**
     * Get the Executable object.
     *
     * @return the Executable (which represents the compiled stylesheet)
     */

    public Executable getExecutable() {
        return executable;
    }

    /**
     * Get the document pool. This is used only for source documents, not for stylesheet modules
     *
     * @return the source document pool
     */

    public DocumentPool getDocumentPool() {
        return sourceDocumentPool;
    }

    /**
     * Clear the document pool.
     * This is sometimes useful when using the same Transformer
     * for a sequence of transformations, but it isn't done automatically, because when
     * the transformations use common look-up documents, the caching is beneficial.
     */

    public void clearDocumentPool() {
        sourceDocumentPool = new DocumentPool();
    }

    /**
     * Set line numbering (of the source document) on or off.
     *
     * @param onOrOff true to switch line numbering on; false to switch it off
     */

    public void setLineNumbering(boolean onOrOff) {
        lineNumbering = onOrOff;
    }

// --Recycle Bin START (30/06/03 19:49):
//    /**
//     * Determine whether line numbering is enabled.
//     *
//     * @return true if line numbering is enabled
//     */
//
//    public boolean isLineNumbering() {
//        return lineNumbering;
//    }
// --Recycle Bin STOP (30/06/03 19:49)

    /**
     * Create a new context with a given node as the current node and the only node in the current
     * node list.
     *
     * @param item the item that is to become the context item
     */

    public void makeContext(Item item) {
        setCurrentIterator(SingletonIterator.makeIterator(item));
    }

    /**
     * Set the principal source document (used for evaluating global variables)
     */

    public void setPrincipalSourceDocument(DocumentInfo doc) {
        principalSourceDocument = doc;
    }

    /**
     * Save the XSLT processing context. This function returns a value which can be subsequently
     * supplied to restoreContext() to restore the processing context.
     *
     * @return An array of objects containing the context information. This
     *     can be passed to restoreContext to reset the context.
     */

    public Object[] saveContext() {
        Object[] x = new Object[7];
        x[0] = currentIterator;
        x[1] = currentMode;
        x[2] = currentTemplate;
        x[3] = currentGroupIterator;
        x[4] = null; // was currentGroup
        x[5] = null; //was tailRecursion;
        x[6] = currentRegexIterator;
        return x;
    }

    /**
     * Restore the context. The supplied value must have been previously obtained using restoreContext().
     *
     * @param x An array of objects holding the saved context from a previous
     *     call of saveContext()
     */

    public void restoreContext(Object[] x) {
        currentIterator = (SequenceIterator)x[0];
        currentMode = (Mode)x[1];
        currentTemplate = (Template)x[2];
        currentGroupIterator = (GroupIterator)x[3];
        //currentGroup = (Item)x[4];
        //tailRecursion = (ParameterSet)x[5];
        currentRegexIterator = (RegexIterator)x[6];
    }

    /**
     * Set the context to point to the root of the principal source document as the singleton focus
     * Note: the caller is expected to save the previous context and reset it later.
     */

    public void setGlobalContext() {
        currentIterator = SingletonIterator.makeIterator(principalSourceDocument);
        currentMode = null;
        currentTemplate = null;
        currentGroupIterator = null;
        //currentGroup = null;
        //tailRecursion = null;
        currentRegexIterator = null;
    }

    /**
     * Get the current bindery.
     *
     * @return the Bindery (in which values of all variables are held)
     */

    public Bindery getBindery() {
        return bindery;
    }

    /**
     * Set an object that will be used to resolve URIs used in
     * document(), etc.
     *
     * @param resolver An object that implements the URIResolver interface, or
     *      null.
     */

    public void setURIResolver(URIResolver resolver) {
        // System.err.println("Setting uriresolver to " + resolver + " on " + this);
        userURIResolver = resolver;
    }

    /**
     * Get the primary URI resolver.
     *
     * @return the user-supplied URI resolver if there is one, or the
     *     system-defined one otherwise (Note, this isn't quite as JAXP
     *     specifies it).
     */

    public URIResolver getURIResolver() {
        return (userURIResolver==null ? standardURIResolver : userURIResolver);
    }

    /**
     * Get the fallback URI resolver.
     *
     * @return the the system-defined URIResolver
     */

    public URIResolver getStandardURIResolver() {
        return standardURIResolver;
    }

     /**
     * Set the URI resolver for secondary output documents.
     *
     * @param resolver An object that implements the OutputURIResolver
     *     interface, or null.
     */

    public void setOutputURIResolver(OutputURIResolver resolver) {
        if (resolver==null) {
            outputURIResolver = StandardOutputResolver.getInstance();
        } else {
            outputURIResolver = resolver;
        }
    }

    /**
     * Get the output URI resolver.
     *
     * @return the user-supplied URI resolver if there is one, or the
     *     system-defined one otherwise.
     */

    public OutputURIResolver getOutputURIResolver() {
        return outputURIResolver;
    }

    /**
     * Get the KeyManager.
     *
     * @return the KeyManager, which holds details of all key declarations
     */

    public KeyManager getKeyManager() {
        return executable.getKeyManager();
    }

// --Recycle Bin START (30/06/03 19:50):
//	/**
//	 * Set the name pool to be used.
//	 *
//	 * @param pool the name pool to be used
//	 */
//
//	public void setConfiguration(NamePool pool) {
//		namePool = pool;
//	}
// --Recycle Bin STOP (30/06/03 19:50)

	/**
	 * Get the name pool in use.
	 *
	 * @return the name pool in use
	 */

	public NamePool getNamePool() {
		return namePool;
	}

    /**
     * Set the tree data model to use.
     *
     * @param model the required tree model: Builder.STANDARD_TREE or
     *     Builder.TINY_TREE
     * @see net.sf.saxon.event.Builder
     */

    public void setTreeModel(int model) {
        treeModel = model;
    }

// --Recycle Bin START (30/06/03 19:50):
//    /**
//     * Get the tree model in use.
//     *
//     * @return the tree model in use
//     * @see net.sf.saxon.event.Builder
//     */
//
//    public int getTreeModel() {
//        return treeModel;
//    }
// --Recycle Bin STOP (30/06/03 19:50)

// --Recycle Bin START (30/06/03 19:48):
//    /**
//     * Disable whitespace stripping.
//     *
//     * @param disable true if whitespace stripping is to be disabled, false if
//     *      it is to be enabled
//     */
//
//    public void disableWhitespaceStripping(boolean disable) {
//        disableStripping = disable;
//    }
// --Recycle Bin STOP (30/06/03 19:48)

// --Recycle Bin START (30/06/03 19:48):
//    /**
//     * Determine if whitespace stripping is disabled.
//     *
//     * @return true if whitespace stripping is disabled
//     */
//
//    public boolean isWhitespaceStrippingDisabled() {
//        return disableStripping;
//    }
// --Recycle Bin STOP (30/06/03 19:48)

    /**
     * Make a builder for the selected tree model.
     *
     * @return an instance of the Builder for the chosen tree model
     */

    public Builder makeBuilder() {
        Builder b;
        if (treeModel==Builder.TINY_TREE)  {
            b = new TinyBuilder();
        } else {
            b = new TreeBuilder();
        }
        b.setTiming(config.isTiming());
        b.setConfiguration(config);
        b.setLineNumbering(lineNumbering);
        return b;
    }

    /**
     * Make a Stripper configured to implement the whitespace stripping rules.
     *
     * @param b the Builder to which the events filtered by this stripper are
     *     to be sent. May be null if the stripper is not being used for filtering
     *     into a Builder.
     * @return the required stripper
     */
    public Stripper makeStripper(Builder b) {
        if (config.isStripsAllWhiteSpace()) {
            return AllElementStripper.getInstance();
        }
        Stripper stripper;
        if (executable==null) {
            stripper = new Stripper(new Mode());
        } else {
            stripper = executable.newStripper();
        }
		stripper.setController(this);
        if (b != null) {
		    stripper.setUnderlyingReceiver(b);
        }
		return stripper;
    }

    /**
     * Add a document to the document pool.
     *
     * @param doc the root node of the document to be added
     * @param systemId thesystem ID of this document
     */
    public void registerDocument(DocumentInfo doc, String systemId) {
        sourceDocumentPool.add(doc, systemId);
        namePool.allocateDocumentNumber(doc);
    }

    //////////////////////////////////////////////////////////////////////
    // Methods for handling decimal-formats
    //////////////////////////////////////////////////////////////////////


    /**
     * Set the Decimal Format Manager.
     *
     * @param manager the Decimal Format Manager. This object is responsible
     *     for maintaining all named and unnamed decimal format declarations
     */
    public void setDecimalFormatManager(DecimalFormatManager manager) {
        decimalFormatManager = manager;
    }

    /**
     * Get the Decimal Format Manager.
     *
     * @return the Decimal Format Manager
     */
    public DecimalFormatManager getDecimalFormatManager() {
        return decimalFormatManager;
    }



    ////////////////////////////////////////////////////////////////////////////////
    // Methods for registering and retrieving handlers for template rules
    ////////////////////////////////////////////////////////////////////////////////

    /**
     * Set the RuleManager, used to manage template rules for each mode.
     *
     * @param r the Rule Manager
     */
    public void setRuleManager(RuleManager r) {
        ruleManager = r;
    }

    /**
     * Get the Rule Manager.
     *
     * @return the Rule Manager, used to hold details of template rules for
     *     all modes
     */
    public RuleManager getRuleManager() {
        return ruleManager;
    }

    /////////////////////////////////////////////////////////////////////////
    // Methods for tracing
    /////////////////////////////////////////////////////////////////////////

    /**
     * Get the TraceListener.
     *
     * @return the TraceListener used for XSLT instruction tracing
     */
    public TraceListener getTraceListener() { // e.g.
        return traceListener;
    }

    /**
     * Test whether instruction execution is being traced.
     *
     * @return true if tracing is active, false otherwise
     */
    public final boolean isTracing() { // e.g.
        return traceListener != null && !tracingPaused;
    }

    /**
     * Pause or resume tracing.
     *
     * @param pause true if tracing is to pause; false if it is to resume
     */
    public final void pauseTracing(boolean pause) {
        tracingPaused = pause;
    }

    /**
     * Adds the specified trace listener to receive trace events from
     * this instance.
     * Must be called before the invocation of the render method.
     *
     * @param trace the trace listener.
     */

    public void addTraceListener(TraceListener trace) { // e.g.
        traceListener = SaxonEventMulticaster.add(traceListener, trace);
    }

    /**
     * Removes the specified trace listener so that the next invocation
     * of the render method will not send trace events to the listener.
     *
     * @param trace the trace listener.
     */

    public void removeTraceListener(TraceListener trace) { // e.g.
        traceListener = SaxonEventMulticaster.remove(traceListener, trace);
    }

    /**
     * Associate this Controller with a compiled stylesheet.
     *
     * @param sheet the compiled stylesheet
     */

    public void setPreparedStyleSheet(PreparedStyleSheet sheet) {
        preparedStyleSheet = sheet;
        //styleSheetElement = (XSLStyleSheet)sheet.getStyleSheetDocument().getDocumentElement();
        executable = sheet.getExecutable();
        //setOutputProperties(sheet.getOutputProperties());
        // above line deleted for bug 490964 - may have side-effects
    }

    /**
     * Associate this Controller with an Executable. This method is used by the XQuery
     * processor. The Executable object is overkill in this case - the only thing it
     * currently holds are copies of the collation table.
     */

    public void setExecutable(Executable exec) {
        executable = exec;
    }

    /**
     * Internal method to create and initialize a controller.
     */

    private void initializeController() {
        setRuleManager(executable.getRuleManager());
        setDecimalFormatManager(executable.getDecimalFormatManager());

        if (traceListener!=null) {
            traceListener.open();
        }

        // get a new bindery, to clear out any variables from previous runs

        bindery = new Bindery();
        executable.initialiseBindery(bindery);

        // create an initial stack frame, used for evaluating standalone expressions,
        // e.g. expressions within the filter of a match pattern. This stack frame
        // never gets closed, but no one will notice.

        bindery.openStackFrame();

        // if parameters were supplied, set them up

        defineGlobalParameters(bindery);
    }

    public void defineGlobalParameters(Bindery bindery) {
        bindery.defineGlobalParameters(parameters);
    }



    /////////////////////////////////////////////////////////////////////////
    // Allow user data to be associated with nodes on a tree
    /////////////////////////////////////////////////////////////////////////

    /**
     * Get user data associated with a node.
     * @param node the node to which the data is attached
     * @param name the name of the required property
     * @return the value of the required property
     */
    public Object getUserData(Object node, String name) {
        String key = node.hashCode() + " " + name;
        // System.err.println("getUserData " + name + " on object returning " + userDataTable.get(key));
        return userDataTable.get(key);
    }

    /**
     * Set user data associated with a node (or any other object).
     * @param node
     * @param name
     * @param data
     */
    public void setUserData(Object node, String name, Object data)  {
        // System.err.println("setUserData " + name + " on object to " + data);
        String key = node.hashCode() + " " + name;
        if (data==null) {
            userDataTable.remove(key);
        } else {
            userDataTable.put(key, data);
        }
    }


    /////////////////////////////////////////////////////////////////////////
    // implement the javax.xml.transform.Transformer methods
    /////////////////////////////////////////////////////////////////////////

    /**
     * Perform a transformation from a Source document to a Result document.
     *
     * @exception TransformerException if the transformation fails. As a
     *     special case, the method throws a TerminationException (a subclass
     *     of TransformerException) if the transformation was terminated using
     *      xsl:message terminate="yes".
     * @param source The input for the source tree. May be null if and only if an
     * initial template has been supplied.
     * @param result The destination for the result tree.
     */

    public void transform(Source source, Result result) throws TransformerException {
        if (preparedStyleSheet==null) {
            throw new TransformerException("Stylesheet has not been prepared");
        }

        currentDateTime = null;     // reset at start of each transformation
        principalResultURI = result.getSystemId();

        try {
            NodeInfo startNode = null;
            boolean wrap = true;
            boolean validate = config.isSchemaValidation();
            Source underSource = source;
            if (source instanceof AugmentedSource) {
                Boolean localWrap = ((AugmentedSource)source).getWrapDocument();
                if (localWrap != null) {
                    wrap = localWrap.booleanValue();
                }
                Boolean localValidate = ((AugmentedSource)source).getSchemaValidation();
                if (localValidate != null) {
                    validate = localValidate.booleanValue();
                }
                if (validate) {
                    // If validation of a DOMSource or NodeInfo is requested, we must copy it, we can't wrap it
                    wrap = false;
                }
                underSource = ((AugmentedSource)source).getContainedSource();
            }
            if (wrap && (underSource instanceof NodeInfo || underSource instanceof DOMSource)) {
                startNode = prepareInputTree(source);
                registerDocument(startNode.getDocumentRoot(), source.getSystemId());

            } else if (source == null) {
                if (initialTemplate == null) {
                    throw new TransformerException("Either a source document or an initial template must be specified");
                }
            } else {
                // The input is a SAXSource or StreamSource, or
                // a DOMSource with wrap=no: build the document tree

                Builder sourceBuilder = makeBuilder();
                Sender sender = new Sender(config);
                sender.send(source, makeStripper(sourceBuilder));
                DocumentInfo doc = sourceBuilder.getCurrentDocument();
                registerDocument(doc, source.getSystemId());
                startNode = doc;
            }

            transformDocument(startNode, result);

        } catch (TerminationException err) {
            //System.err.println("Processing terminated using xsl:message");
            throw err;
        } catch (TransformerException err) {
            Throwable cause = err.getException();
            if (cause != null && cause instanceof SAXParseException) {
                // This generally means the error was already reported.
                // But if a RuntimeException occurs in Saxon during a callback from
                // the Crimson parser, Crimson wraps this in a SAXParseException without
                // reporting it further.
                SAXParseException spe = (SAXParseException)cause;
                cause = spe.getException();
                if (cause instanceof RuntimeException) {
                    errorListener.fatalError(err);
                }
            } else {
                errorListener.fatalError(err);
            }
            throw err;
        }
    }

    /**
     * Prepare an input tree for processing. This is used when either the initial
     * input, or a Source returned by the document() function, is a NodeInfo or a
     * DOMSource. The preparation consists of wrapping a DOM document inside a wrapper
     * that implements the NodeInfo interface, and/or adding a space-stripping wrapper
     * if the stylesheet strips whitespace nodes.
     * @param source the input tree. Must be either a DOMSource or a NodeInfo
     * @return the NodeInfo representing the input node, suitably wrapped.
     */

    public NodeInfo prepareInputTree(Source source) {
        NodeInfo start;
        if (source instanceof DOMSource) {
            Node dsnode = ((DOMSource)source).getNode();
            if (dsnode instanceof NodeInfo) {
                start = (NodeInfo)dsnode;
            } else {
                Document dom;
                if (dsnode instanceof Document) {
                    dom = (Document)dsnode;
                } else {
                    dom = dsnode.getOwnerDocument();
                }
                DocumentWrapper docWrapper = new DocumentWrapper(dom, source.getSystemId());
                start = docWrapper.wrap(dsnode);
            }
        } else {
            start = (NodeInfo)source;
        }
        if (executable.stripsWhitespace() && !disableStripping) {
            DocumentInfo docInfo = start.getDocumentRoot();
            StrippedDocument strippedDoc = new StrippedDocument(docInfo, makeStripper(null));
            start = strippedDoc.wrap(start);
        }
        return start;
    }

    /**
     * Get an XPath expression referencing a node in a DOM.
     *
     * @param startNode
     * @exception TransformerException
     * @return a string containing an XPath expression that will locate this node
     */

//    private String getPathToNode(Node startNode) throws TransformerException {
//        short nodeType = startNode.getNodeType();
//        String path;
//        if ( nodeType == Node.DOCUMENT_NODE ) {
//            path = "/";
//        } else if ( nodeType == Node.ELEMENT_NODE ) {
//            path = "";
//            Node curr = startNode;
//            while ( nodeType == Node.ELEMENT_NODE ) {
//                int count = 1;
//                Node prior = curr.getPreviousSibling();
//                while (prior != null) {
//                    short ptype = prior.getNodeType();
//                    if (ptype == Node.ELEMENT_NODE) {
//                        count++;
//                    } else if (ptype == Node.CDATA_SECTION_NODE ||
//                                 ptype == Node.ENTITY_REFERENCE_NODE) {
//                        throw new TransformerException(
//                            "Document contains CDATA or Entity nodes: can only transform starting at root");
//                    }
//                    prior = prior.getPreviousSibling();
//                }
//                if (!path.equals("")) {
//                    path = "/" + path;
//                }
//                path = "*[" + count + "]" + path;
//
//                curr = curr.getParentNode();
//                if (curr==null) {
//                    throw new TransformerException("Supplied element is not within a Document");
//                }
//                nodeType = curr.getNodeType();
//                if (nodeType == Node.DOCUMENT_NODE) {
//                    path = "/" + path;
//                } else if (nodeType == Node.CDATA_SECTION_NODE ||
//                            nodeType == Node.ENTITY_REFERENCE_NODE) {
//                    throw new TransformerException(
//                        "Document contains CDATA or Entity nodes: can only transform starting at root");
//                }
//            }
//        } else {
//            throw new TransformerException("Start node must be either the root or an element");
//        }
//        return path;
//    }

    /**
     * Render a source XML document supplied as a tree. <br>
     * A new output destination should be created for each source document,
     * by using setOutputDetails(). <br>
     *
     * @exception TransformerException if any dynamic error occurs
     * @param startNode A Node that identifies the source document to be
     *     transformed and the node where the transformation should start.
     *     May be null if the transformation is to start using an initial template.
     * @param result The output destination
     */

    public void transformDocument(NodeInfo startNode, Result result)
    throws TransformerException {

        if (executable==null) {
            throw new TransformerException("Stylesheet has not been compiled");
        }

        // Determine whether we need to close the output stream at the end. We
        // do this if the Result object is a StreamResult and is supplied as a
        // system ID, not as a Writer or OutputStream

        boolean mustClose = (result instanceof StreamResult &&
                ((StreamResult)result).getOutputStream() == null);

        principalResult = result;
        principalResultURI = result.getSystemId();

        if (startNode != null) {
            DocumentInfo sourceDoc;
            if (startNode instanceof DocumentInfo) {
                sourceDoc = (DocumentInfo)startNode;
            } else {
                sourceDoc = startNode.getDocumentRoot();
                if (sourceDoc == null) {
                    throw new TransformerException("Source tree must have a document node as its root");
                }
            }

            principalSourceDocument = sourceDoc;

            if (sourceDoc.getNamePool()==null) {
                // must be a non-standard document implementation
                sourceDoc.setNamePool(preparedStyleSheet.getTargetNamePool());
            }

            if (sourceDoc.getNamePool() != preparedStyleSheet.getTargetNamePool()) {
                throw new TransformerException("Source document and stylesheet must use the same name pool");
            }

            makeContext(sourceDoc);
        }

        initializeController();
        Properties xslOutputProps = executable.getDefaultOutputProperties();

        // overlay the output properties defined via the API
        if (outputProperties!=null) {
            Enumeration enum = outputProperties.propertyNames();
            while (enum.hasMoreElements()) {
                String p = (String)enum.nextElement();
                String v = outputProperties.getProperty(p);
                xslOutputProps.put(p, v);
            }
        }

        // deal with stylesheet chaining
        String nextInChain = xslOutputProps.getProperty(SaxonOutputKeys.NEXT_IN_CHAIN);
        if (nextInChain != null) {
            String baseURI = xslOutputProps.getProperty(SaxonOutputKeys.NEXT_IN_CHAIN_BASE_URI);
            result = prepareNextStylesheet(nextInChain, baseURI, result);
        }

        changeOutputDestination(xslOutputProps, result, true, Validation.PRESERVE, null);

        // Process the source document using the handlers that have been set up

        if (initialTemplate == null) {
            run(startNode);
        } else {
            initialTemplate.process(this);
        }

        if (traceListener!=null) {
            traceListener.close();
        }

        resetOutputDestination(null);

        if (mustClose && result instanceof StreamResult) {
            OutputStream os = ((StreamResult)result).getOutputStream();
            if (os != null) {
                try {
                    os.close();
                } catch (java.io.IOException err) {
                    throw new TransformerException(err);
                }
            }
        }

    }

    /**
     * Prepare another stylesheet to handle the output of this one.
     *
     * @exception TransformerException if any dynamic error occurs
     * @param href URI of the next stylesheet to be applied
     * @param baseURI base URI for resolving href if it's a relative
     *     URI
     * @param result the output destination of the current stylesheet
     * @return a replacement destination for the current stylesheet
     */

    public Result prepareNextStylesheet(String href, String baseURI, Result result)
    throws TransformerException {

        // TODO: should cache the results, we are recompiling the referenced
        // stylesheet each time it's used

        Source source = getURIResolver().resolve(href, baseURI);
        TransformerFactoryImpl factory = new TransformerFactoryImpl();
        factory.setConfiguration(config);
        Templates next = factory.newTemplates(source);
        TransformerReceiver nextTransformer =
                new TransformerReceiver((Controller) next.newTransformer());

        nextTransformer.setSystemId(principalResultURI);
        nextTransformer.setConfiguration(config);
        nextTransformer.setResult(result);

        return nextTransformer;
    }

    //////////////////////////////////////////////////////////////////////////
    // Handle parameters to the transformation
    //////////////////////////////////////////////////////////////////////////

    /**
     * Set a parameter for the transformation.
     *
     * @param expandedName The name of the parameter in {uri}local format
     * @param value The value object.  This can be any valid Java
     *     object  it follows the same conversion rules as a value returned
     *     from a Saxon extension function.
     */

    public void setParameter(String expandedName, Object value) {

        if (parameters == null) {
            parameters = new ParameterSet();
        }

        Value result;
        try {
            result = FunctionProxy.convertJavaObjectToXPath(value, this);
            if (result==null) {
                result = EmptySequence.getInstance();
            }
        } catch (TransformerException err) {
            result = new StringValue(value.toString());
        }
        int fingerprint = namePool.allocateClarkName(expandedName);
        parameters.put(fingerprint, result);

    }

    /**
     * Reset the parameters to a null list.
     */

    public void clearParameters() {
        parameters = null;
    }

    /**
     * Get a parameter to the transformation.
     *
     * @param expandedName the name of the required parameter, in
     *     "{uri}local-name" format
     * @return the value of the parameter, if it exists, or null otherwise
     */

    public Object getParameter(String expandedName) {
        if (parameters==null) return null;
        int f = namePool.allocateClarkName(expandedName);
        return parameters.get(f);
    }

    /**
     * Get the current date and time for this transformation.
     * All calls during one transformation return the same answer.
     *
     * @return Get the current date and time. This will deliver the same value
     *      for repeated calls within the same transformation
     */

    public GregorianCalendar getCurrentDateTime() {
        if (currentDateTime==null) {
            currentDateTime = new GregorianCalendar();
        }
        return currentDateTime;
    }

    /////////////////////////////////////////
    // Methods previously part of XSLTContext
    /////////////////////////////////////////

    /**
     * Set the current mode (for use by the built-in handlers). The caller
     * is responsible for saving the previous current mode and resetting
     * it after use.
     *
     * @param mode the new current mode
     */

    public void setCurrentMode(Mode mode) {
        currentMode = mode;
    }

    /**
     * Get the current mode. (For use by the built-in handlers, and when tracing)
     *
     * @return the current mode
     */

    public Mode getCurrentMode() {
        return currentMode;
    }

    /**
     * Set a new current item sequence iterator. The caller is responsible for
     * remembering the previous current iterator and resetting it after use.
     *
     * @param iterator The current sequence iterator. May be null, which
     *     causes the context item, position, and size to be unset.
     */

    public void setCurrentIterator(SequenceIterator iterator) {
        currentIterator = iterator;
    }

    /**
     * Get the current iterator.
     *
     * @return the current iterator. Note that this may be null if there is no
     *      context item, which will be the case on entry to a stylesheet
     *     function.
     */

    public SequenceIterator getCurrentIterator() {
        return currentIterator;
    }

    /**
     * Get the current item.
     *
     * @exception XPathException if any dynamic error occurs, for example, if
     *     there is no current item
     * @return the current item (identified by the current iterator)
     */

    public Item getCurrentItem() throws XPathException {
        if (currentIterator==null) {
            throw new XPathException.Dynamic("There is no current item");
        }
        return currentIterator.current();
    }

// --Recycle Bin START (30/06/03 19:49):
//    /**
//     * Get the current node (that is, the current item, provided it is a node).
//     *
//     * @exception XPathException if the current item is not a node
//     * @return the current item, if it is a node
//     */
//
//    public NodeInfo getCurrentNode() throws XPathException {
//        Item item = getCurrentItem();
//        if (item instanceof NodeInfo) {
//            return (NodeInfo)item;
//        } else {
//            throw new XPathException.Dynamic("The current item is not a node");
//        }
//    }
// --Recycle Bin STOP (30/06/03 19:49)


    /**
     * Set the current template. This is used to support xsl:apply-imports. The caller
     * is responsible for remembering the previous current template and resetting it
     * after use.
     *
     * @param template the current template
     */

    public void setCurrentTemplate(Template template) {
        currentTemplate = template;
    }

    /**
     * Get the current template. This is used to support xsl:apply-imports
     *
     * @return the current template
     */

    public Template getCurrentTemplate() {
        return currentTemplate;
    }

    /**
     * Set the current group collection. The caller is responsible for remembering and
     * resetting the previous current group.
     *
     * @param collection the new current GroupIterator
     */

    public void setCurrentGroupIterator(GroupIterator collection) {
        currentGroupIterator = collection;
    }

    /**
     * Get the current group collection.
     *
     * @return the current grouped collection
     */

    public GroupIterator getCurrentGroupIterator() {
        return currentGroupIterator;
    }

    /**
     * Set the current regex iterator
     * @param currentRegexIterator the current regex iterator
     */

    public void setCurrentRegexIterator(RegexIterator currentRegexIterator) {
        this.currentRegexIterator = currentRegexIterator;
    }

    /**
     * Get the current regex iterator.
     *
     * @return the current regular expresions iterator
     */

    public RegexIterator getCurrentRegexIterator() {
        return currentRegexIterator;
    }

    /**
     * Make an XPathContext object for expression evaluation.
     *
     * @return the new XPathContext
     */

    public XPathContext newXPathContext() {
        return new XPathContext(this);
    }

    /**
     * Set the last remembered node, for node numbering purposes.
     *
     * @param node the node in question
     * @param number the number of this node
     */

    public void setRememberedNumber(NodeInfo node, int number) {
        lastRememberedNode = node;
        lastRememberedNumber = number;
    }

    /**
     * Get the number of a node if it is the last remembered one.
     *
     * @param node the node for which remembered information is required
     * @return the number of this node if known, else -1.
     */

    public int getRememberedNumber(NodeInfo node) {
        if (lastRememberedNode == node) return lastRememberedNumber;
        return -1;
    }

    /**
    * Set tail recursion parameters
    */

    //public void setTailRecursion(ParameterSet p) {
    //    tailRecursion = p;
    //}

    /**
    * Get tail recursion parameters
    */

    //public ParameterSet getTailRecursion() {
    //    return tailRecursion;
    //}


}   // end of outer class Controller

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
