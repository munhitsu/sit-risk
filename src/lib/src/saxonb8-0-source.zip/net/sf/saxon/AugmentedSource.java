package net.sf.saxon;

import org.xml.sax.XMLReader;

import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;

/**
 * This class wraps a JAXP Source object to provide an extended Source object that
 * contains options indicating how the Source should be processed: for example,
 * whether or not it should be validated against a schema. Other options that can
 * be set include the SAX XMLReader to be used, and the choice of whether a source
 * in the form of an existing tree should be copied or wrapped.
 */

public class AugmentedSource implements Source {

    private Source source;
    private Boolean schemaValidation = null;
    private XMLReader parser = null;
    private Boolean wrapDocument = null;

    /**
     * Create an AugmentedSource that wraps a given Source object (which must not itself be an
     * AugmentedSource)
     * @param source the Source object to be wrapped
     * @throws IllegalArgumentException if the wrapped source is an AugmentedSource
     */

    private AugmentedSource(Source source) {
        if (source instanceof AugmentedSource) {
            throw new IllegalArgumentException("Contained source must not be an AugmentedSource");
        }
        this.source = source;
    }

    /**
     * Create an AugmentedSource that wraps a given Source object (which must not itself be an
     * AugmentedSource)
     * @param source the Source object to be wrapped
     * @throws IllegalArgumentException if the wrapped source is an AugmentedSource
     */

    public static AugmentedSource makeAugmentedSource(Source source) {
        if (source instanceof AugmentedSource) {
            return (AugmentedSource)source;
        }
        return new AugmentedSource(source);
    }

    /**
     * Get the Source object wrapped by this AugmentedSource
     * @return the contained Source object
     */

    public Source getContainedSource() {
        return source;
    }

    /**
     * Set whether or not schema validation of this source is required
     * @param option true indicates schema validation is required, false that validation
     * is not required, null indicates that the default value for the system configuration
     * should be used.
     */

    public void setSchemaValidation(Boolean option) {
        schemaValidation = option;
    }

    /**
     * Get whether or not schema validation of this source is required
     * @return true indicates schema validation is required, false that validation
     * is not required, null indicates that the default value for the system configuration
     * should be used.
     */

    public Boolean getSchemaValidation() {
        return schemaValidation;
    }

    public void setXMLReader(XMLReader parser) {
        this.parser = parser;
        if (source instanceof SAXSource) {
            ((SAXSource)source).setXMLReader(parser);
        }
    }

    public XMLReader getXMLReader() {
        if (parser != null) {
            return parser;
        } else if (source instanceof SAXSource) {
            return ((SAXSource)source).getXMLReader();
        } else {
            return null;
        }
    }

    /**
     * Assuming that the contained Source is a node in a tree, indicate whether a tree should be created
     * as a view of this supplied tree, or as a copy.
     * @param wrap if true, the node in the supplied Source is wrapped, to create a view. If false, the node
     * and its contained subtree is copied. If null, the system default is chosen.
     */

    public void setWrapDocument(Boolean wrap) {
        this.wrapDocument = wrap;
    }

    /**
       Assuming that the contained Source is a node in a tree, determine whether a tree will be created
     * as a view of this supplied tree, or as a copy.
     * @return if true, the node in the supplied Source is wrapped, to create a view. If false, the node
     * and its contained subtree is copied. If null, the system default is chosen.
     */

    public Boolean getWrapDocument() {
        return wrapDocument;
    }

    /**
     * Set the System ID. This sets the System Id on the underlying Source object.
     * @param id the System ID.
     */

    public void setSystemId(String id) {
        source.setSystemId(id);
    }

    /**
     * Get the System ID. This gets the System Id on the underlying Source object.
     * @return the System ID.
     */

    public String getSystemId() {
        return source.getSystemId();
    }
}
