package net.sf.saxon.expr;

import javax.xml.transform.SourceLocator;

/**
 * Class to hold details of the location of an expression.
 *
 * Currently only the linenumber is used.
 */

public class ExpressionLocation implements SourceLocator {

    private String systemId;
//    private String publicId;
    private int lineNumber;
//    private int columnNumber;

    public String getSystemId() {
        return systemId;
    }

    public String getPublicId() {
        return null;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public int getColumnNumber() {
        return -1;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public void setPublicId(String publicId) {
//        this.publicId = publicId;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public void setColumnNumber(int columnNumber) {
//        this.columnNumber = columnNumber;
    }
}
