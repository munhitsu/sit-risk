package net.sf.saxon.expr;
import net.sf.saxon.Controller;
import net.sf.saxon.type.AnyItemType;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.instruct.CallableFunction;
import net.sf.saxon.instruct.FunctionSignature;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.value.ObjectValue;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.Value;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;


/**
* This class represents a call to a function defined in the stylesheet or query.
 * It is used for all user-defined functions in XQuery, and for a limited class of
 * user-defined functions in XSLT: those that can be reduced to the evaluation
 * of a single expression.
*/

public class UserFunctionCall extends FunctionCall {

    private SequenceType staticType;
    private CallableFunction function;
    private int fingerprint;
    private boolean tailRecursive = false;

    /**
     * Set the fingerprint representing the name of the function
     */

    public void setFingerprint(int fingerprint) {
        this.fingerprint = fingerprint;
    }

    /**
     * Get the fingerprint representing the name of the function
     */

    public int getFingerprint() {
        return fingerprint;
    }

    /**
    * Set the static type
    */

    public void setStaticType(SequenceType type) {
        staticType = type;
    }

    /**
    * Create the reference to the function to be called, and validate for consistency
    */

    public void setFunction(FunctionSignature sourceFunction, CallableFunction compiledFunction) throws XPathException {
        function = compiledFunction;
        int n = sourceFunction.getNumberOfArguments();

        // the following check is probably redundant, since we are only binding this
        // function because it has the right name and arity
        checkArgumentCount(n, n);

        SequenceType[] requiredTypes = sourceFunction.getArgumentTypes();
        for (int i=0; i<n; i++) {
            RoleLocator role = new RoleLocator(RoleLocator.FUNCTION, getName(), i);
            argument[i] = TypeChecker.staticTypeCheck(
                                argument[i],
                                requiredTypes[i],
                                false,
                                role   );
        }
    }

    /**
    * Get the name of the function. Used for diagnostic purposes only.
    * @return the name of the function, as used in XSL expressions
    */

    public String getName() {
        if (function==null) {
            return "*** call to user function ***";
        } else {
            return function.getFunctionName();
        }
    }

    /**
    * Method called during the type checking phase
    */

    public void checkArguments(StaticContext env) throws XPathException {
        // these checks are now done in setFunction(), at the time when the function
        // call is bound to an actual function
    }

    /**
    * Pre-evaluate a function at compile time. This version of the method suppresses
    * early evaluation by doing nothing.
    */

    public Expression preEvaluate(StaticContext env) {
        return this;
    }

    /**
    * Determine the data type of the expression, if possible
    * @return Type.ITEM (meaning not known in advance)
    */

    public ItemType getItemType() {
        if (staticType == null) {
            // the actual type is not known yet, so we return an approximation
            return AnyItemType.getInstance();
        } else {
            return staticType.getPrimaryType();
        }
    }

    /**
    * Determine the cardinality of the result
    */

    public int computeCardinality() {
        if (staticType == null) {
            // the actual type is not known yet, so we return an approximation
            return StaticProperty.ALLOWS_ZERO_OR_MORE;
        } else {
            return staticType.getCardinality();
        }
    }

    /**
    * Simplify the function call
    */

     public Expression simplify() throws XPathException {
        for (int i=0; i<getNumberOfArguments(); i++) {
            argument[i] = argument[i].simplify();
        }
        return this;
    }

    /**
    * Mark tail-recursive calls on stylesheet functions. For most expressions, this does nothing.
    */

    public boolean markTailFunctionCalls() {
        tailRecursive = true;
        return true;
    }

    /**
    * Call the function, returning the value as an item. This method will be used
    * only when the cardinality is zero or one. If the function is tail recursive,
    * it returns an Object representing the arguments to the next (recursive) call,
    * which is specially handled by the code in FunctionInstr.
    */

    public Item evaluateItem(XPathContext c) throws XPathException {
        Value val = callFunction(c);
        if (val instanceof Item) {
            return (Item)val;
        } else {
            return val.iterate(c).next();
        }
    }

    /**
    * Call the function, returning an iterator over the results. (But if the function is
    * tail recursive, it returns an iterator over the arguments of the recursive call,
    * which is specially handled by the code in FunctionInstr)
    */

    public SequenceIterator iterate(XPathContext c) throws XPathException {
        return callFunction(c).iterate(c);
    }

    private Value callFunction(XPathContext c) throws XPathException {
        int numArgs = getNumberOfArguments();

        Value[] actualArgs = new Value[numArgs];
        for (int i=0; i<numArgs; i++) {
            actualArgs[i] = ExpressionTool.lazyEvaluate(argument[i], c);
        }

        if (tailRecursive) {
            return new ObjectValue(new FunctionCallPackage(function, actualArgs, c));
        }

        Controller controller = c.getController();
        Object[] savedContext = controller.saveContext();
        controller.setGlobalContext();
        controller.setCurrentIterator(null);

        try {
            Value result = function.call(actualArgs, controller, true);
            controller.restoreContext(savedContext);
            return result;
        } catch (TransformerException err) {
            if (err instanceof XPathException) {
                throw (XPathException)err;
            }
            Throwable cause = err.getException();
            if (cause instanceof XPathException) {
                throw (XPathException)cause;
            }
            throw new XPathException.Dynamic(err);
        }
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "function " + getName() +
                (tailRecursive ? " (tail call)" : ""));
        for (int a=0; a<getNumberOfArguments(); a++) {
            argument[a].display(level+1, pool);
        }
    }


    /**
    * Inner class used to wrap up the set of actual arguments to a tail-recursive call of
    * the containing function. This argument package is passed back to the calling FunctionInstr
    * in place of a function result; the FunctionInstr then loops to re-invoke the function
    * with these arguments, avoiding the creation of an additional stack frame.
    */

    public static class FunctionCallPackage {

        private CallableFunction function;
        private Value[] actualArgs;
        private XPathContext evaluationContext;

        public FunctionCallPackage(CallableFunction function, Value[] actualArgs, XPathContext c) {
            this.function = function;
            this.actualArgs = actualArgs;
            this.evaluationContext = c;
        }

        public Value call() throws XPathException {
            // System.err.println("Calling tail function call " + this);
            Controller controller = evaluationContext.getController();
            Object[] savedContext = controller.saveContext();
            controller.setGlobalContext();
            controller.setCurrentIterator(null);

            try {
                Value result = function.call(actualArgs, controller, false);
                controller.restoreContext(savedContext);
                return result;
            } catch (TransformerException err) {
                if (err instanceof XPathException) {
                    throw (XPathException)err;
                }
                Throwable cause = err.getException();
                if (cause instanceof XPathException) {
                    throw (XPathException)cause;
                }
                throw new XPathException.Dynamic(err);
            }
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
