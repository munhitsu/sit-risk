package net.sf.saxon.expr;
import net.sf.saxon.functions.Last;
import net.sf.saxon.functions.Position;
import net.sf.saxon.functions.StringLength;
import net.sf.saxon.functions.SystemFunction;
import net.sf.saxon.functions.NamePart;
import net.sf.saxon.om.Item;
import net.sf.saxon.sort.AtomicComparer;
import net.sf.saxon.sort.CodepointCollator;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.*;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AtomicType;

import java.util.Comparator;

/**
* ValueComparison: a boolean expression that compares two atomic values
* for equals, not-equals, greater-than or less-than. Implements the operators
* eq, ne, lt, le, gt, ge
*/

public final class ValueComparison extends BinaryExpression {

    private AtomicComparer comparer;

    /**
    * Create a relational expression identifying the two operands and the operator
    * @param p1 the left-hand operand
    * @param op the operator, as a token returned by the Tokenizer (e.g. Tokenizer.LT)
    * @param p2 the right-hand operand
    */

    public ValueComparison(Expression p1, int op, Expression p2) {
        super(p1, op, p2);
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {

        operands[0] = operands[0].analyze(env);
        if (operands[0] instanceof EmptySequence) {
            return operands[0];
        }
        operands[1] = operands[1].analyze(env);
        if (operands[1] instanceof EmptySequence) {
            return operands[1];
        }

        final SequenceType optionalAtomic = SequenceType.OPTIONAL_ATOMIC;

        RoleLocator role0 = new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 0);
        operands[0] = TypeChecker.staticTypeCheck(operands[0], optionalAtomic, false, role0);

        RoleLocator role1 = new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 1);
        operands[1] = TypeChecker.staticTypeCheck(operands[1], optionalAtomic, false, role1);

        AtomicType t1 = operands[0].getItemType().getAtomizedItemType();
        AtomicType t2 = operands[1].getItemType().getAtomizedItemType();

        int p1 = t1.getPrimitiveType();
        if (p1 == Type.UNTYPED_ATOMIC) {
            p1 = Type.STRING;
        }
        int p2 = t2.getPrimitiveType();
        if (p2 == Type.UNTYPED_ATOMIC) {
            p2 = Type.STRING;
        }

        if (!Type.isComparable(p1, p2)) {
            boolean opt0 = Cardinality.allowsZero(operands[0].getCardinality());
            boolean opt1 = Cardinality.allowsZero(operands[1].getCardinality());
            if (opt0 || opt1) {
                // This is a comparison such as (xs:integer? eq xs:date?). This is almost
                // certainly an error, but we need to let it through because it will work if
                // one of the operands is an empty sequence.
                try {
                    String which = null;
                    if (opt0) which = "the first operand is";
                    if (opt1) which = "the second operand is";
                    if (opt0 && opt1) which = "one or both operands are";
                    env.issueWarning(
                            "Comparison of " + t1.toString() + (opt0?"?":"") + " to " + t2.toString() +
                            (opt1?"?":"") + " will fail unless " + which + " empty");
                } catch (Exception err) {}
            } else {
                throw new XPathException.Type("Cannot compare " + t1.toString() +
                                              " to " + t2.toString());
            }
        }
        if (!(operator == Tokenizer.FEQ || operator == Tokenizer.FNE)) {
            if (!Type.isOrdered(p1)) {
                throw new XPathException.Type("Type " + t1.toString() + " is not an ordered type");
            }
            if (!Type.isOrdered(p2)) {
                throw new XPathException.Type("Type " + t2.toString() + " is not an ordered type");
            }
        }

        Comparator comp = env.getCollation(env.getDefaultCollationName());
        if (comp==null) comp = CodepointCollator.getInstance();
        comparer = new AtomicComparer(comp);

        // optimise count(x) eq 0 (or gt 0, ne 0, eq 0, etc)

        if ((operands[0] instanceof FunctionCall) &&
                ((FunctionCall)operands[0]).getName().equals("count") &&
                ((FunctionCall)operands[0]).getNumberOfArguments()==1 &&
                operands[1] instanceof AtomicValue) {
            if (isZero(operands[1])) {
                if (operator == Tokenizer.FEQ || operator == Tokenizer.FLE ) {
                    // rewrite count(x)=0 as empty(x)
                    FunctionCall fn = SystemFunction.makeSystemFunction("empty");
                    Expression[] args = new Expression[1];
                    args[0] = ((FunctionCall)operands[0]).argument[0];
                    fn.setArguments(args);
                    return fn;
                } else if (operator == Tokenizer.FNE || operator == Tokenizer.FGT) {
                    // rewrite count(x)!=0, count(x)>0 as exists(x)
                    FunctionCall fn = SystemFunction.makeSystemFunction("exists");
                    Expression[] args = new Expression[1];
                    args[0] = ((FunctionCall)operands[0]).argument[0];
                    fn.setArguments(args);
                    return fn;
                } else if (operator == Tokenizer.FGE) {
                    // rewrite count(x)>=0 as true()
                    return BooleanValue.TRUE;
                } else {  // singletonOperator == Tokenizer.FLT
                    // rewrite count(x)<0 as false()
                    return BooleanValue.FALSE;
                }
            } else if (operands[1] instanceof IntegerValue &&
                    (operator == Tokenizer.FGT || operator == Tokenizer.FGE) ) {
                // rewrite count(x) gt n as exists(x[n+1])
                //     and count(x) ge n as exists(x[n])
                long val = ((IntegerValue)operands[1]).getValue();
                if (operator == Tokenizer.FGT) {
                    val++;
                }
                FunctionCall fn = SystemFunction.makeSystemFunction("exists");
                Expression[] args = new Expression[1];
                FilterExpression filter =
                        new FilterExpression(((FunctionCall)operands[0]).argument[0],
                                new IntegerValue(val));
                args[0] = filter;
                fn.setArguments(args);
                return fn;
            }
        }

        // optimise (0 eq count(x)), etc

        if ((operands[1] instanceof FunctionCall) && ((FunctionCall)operands[1]).getName().equals("count") &&
        	(((FunctionCall)operands[1]).getNumberOfArguments()==1) && isZero(operands[0])) {
        	Expression s =
        	    new ValueComparison(operands[1], Value.inverse(operator), operands[0]).analyze(env);
			//((ValueComparison)s).defaultCollation = defaultCollation;
			return s;
        }

        // optimise string-length(x) = 0, >0, !=0 etc

        if ((operands[0] instanceof StringLength) &&
        	    (((StringLength)operands[0]).getNumberOfArguments()==1) && isZero(operands[1])) {
            ((StringLength)operands[0]).setShortcut();
        }

        // optimise (0 = string-length(x)), etc

        if ((operands[1] instanceof StringLength) &&
                (((StringLength)operands[1]).getNumberOfArguments()==1) && isZero(operands[0])) {
            ((StringLength)operands[1]).setShortcut();
        }

        // optimise [position() < n] etc

        if ((operands[0] instanceof Position) && (operands[1] instanceof IntegerValue)) {
            long pos = ((IntegerValue)operands[1]).getValue();
            if (pos < 0) {
                pos = 0;
            }
            if (pos < Integer.MAX_VALUE) {
                switch (operator) {
                    case Tokenizer.FEQ:
                        return new PositionRange((int)pos, (int)pos);
                    case Tokenizer.FGE:
                        return new PositionRange((int)pos, Integer.MAX_VALUE);
                    case Tokenizer.FNE:
                        if (pos==1) {
                            return new PositionRange(2, Integer.MAX_VALUE);
                        } else {
                            break;
                        }
                    case Tokenizer.FLT:
                        return new PositionRange(1, (int)pos-1 );
                    case Tokenizer.FGT:
                        return new PositionRange((int)pos+1, Integer.MAX_VALUE);
                    case Tokenizer.FLE:
                        return new PositionRange(1, ((int)pos));
                }
            }
        }

        if ((operands[0] instanceof IntegerValue) && (operands[1] instanceof Position)) {
            long pos = ((IntegerValue)operands[0]).getValue();
            if (pos < 0) {
                pos = 0;
            }
            if (pos < Integer.MAX_VALUE) {
                switch (operator) {
                    case Tokenizer.FEQ:
                        return new PositionRange((int)pos, (int)pos);
                    case Tokenizer.FLE:
                        return new PositionRange((int)pos, Integer.MAX_VALUE);
                    case Tokenizer.FNE:
                       if (pos==1) {
                            return new PositionRange(2, Integer.MAX_VALUE);
                        } else {
                            break;
                        }
                    case Tokenizer.FGT:
                        return new PositionRange(1, (int)pos - 1 );
                    case Tokenizer.FLT:
                        return new PositionRange((int)pos + 1, Integer.MAX_VALUE);
                    case Tokenizer.FGE:
                        return new PositionRange(1, (int)pos);
                }
            }
        }

        // optimise [position()=last()] etc

        if ((operands[0] instanceof Position) && (operands[1] instanceof Last)) {
            switch (operator) {
                case Tokenizer.FEQ:
                case Tokenizer.FGE:
                    return new IsLastExpression(true);
                case Tokenizer.FNE:
                case Tokenizer.FLT:
                    return new IsLastExpression(false);
                case Tokenizer.FGT:
                    return BooleanValue.FALSE;
                case Tokenizer.FLE:
                    return BooleanValue.TRUE;
            }
        }
        if ((operands[0] instanceof Last) && (operands[1] instanceof Position)) {
            switch (operator) {
                case Tokenizer.FEQ:
                case Tokenizer.FLE:
                    return new IsLastExpression(true);
                case Tokenizer.FNE:
                case Tokenizer.FGT:
                    return new IsLastExpression(false);
                case Tokenizer.FLT:
                    return BooleanValue.FALSE;
                case Tokenizer.FGE:
                    return BooleanValue.TRUE;
            }
        }

        // optimize generate-id(X) = generate-id(Y) as "X is Y"
        // This construct is often used in XSLT 1.0 stylesheets.
        // Only do this if we know the arguments are singletons, because "is" doesn't
        // do first-value extraction.

        if (operands[0] instanceof NamePart && operands[1] instanceof NamePart) {
            FunctionCall f0 = (FunctionCall)operands[0];
            FunctionCall f1 = (FunctionCall)operands[1];
            if (f0.getName().equals("generate-id") &&
                    f1.getName().equals("generate-id") &&
                    !Cardinality.allowsMany(f0.argument[0].getCardinality()) &&
                    !Cardinality.allowsMany(f1.argument[0].getCardinality()) &&
                    (operator == Tokenizer.FEQ) ) {
                IdentityComparison id =
                        new IdentityComparison (
                                f0.argument[0],
                                Tokenizer.IS,
                                f1.argument[0] );
                id.setGenerateIdEmulation(true);
                return id.simplify().analyze(env);
            }
        }

        // evaluate the expression now if both arguments are constant

        if ((operands[0] instanceof Value) && (operands[1] instanceof Value)) {
            return (AtomicValue)evaluateItem(null);
        }

        return this;
    }

    /**
    * Test whether an expression is constant zero
    */

    private static boolean isZero(Expression exp) {
        try {
            if (!(exp instanceof AtomicValue)) return false;
            if (exp instanceof IntegerValue) {
                return ((IntegerValue)exp).getValue()==0;
            }
            if (exp instanceof BigIntegerValue) {
                return ((BigIntegerValue)exp).compareTo(BigIntegerValue.ZERO) == 0;
            }

            Value val = ((AtomicValue)exp).convert(Type.INTEGER);
            return isZero(val);
        } catch (XPathException err) {
            return false;
        }
    }

    /**
    * Evaluate the expression in a boolean context
    * @param context the given context for evaluation
    * @return a boolean representing the result of the numeric comparison of the two operands
    */

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        try {
            AtomicValue v1 = (AtomicValue)operands[0].evaluateItem(context);
            if (v1==null) return false;
            if (v1 instanceof UntypedAtomicValue) {
                v1 = v1.convert(Type.STRING);
            }
            AtomicValue v2 = (AtomicValue)operands[1].evaluateItem(context);
            if (v2==null) return false;
            if (v2 instanceof UntypedAtomicValue) {
                v2 = v2.convert(Type.STRING);
            }
            return compare(v1, operator, v2, comparer);
        } catch (XPathException.Type err) {
            // re-throw the exception with location information added
            typeError(err.getMessage());
            return false;   // dummy return
        }
    }

    /**
    * Compare two atomic values, using a specified operator and collation
     * @param v1 the first operand
     * @param op the operator, as defined by constants such as {@link Tokenizer#FEQ} or
     * {@link Tokenizer#FLT}
     * @param v2 the second operand
     * @param collator the Collator to be used when comparing strings
    * @throws XPathException.Type if the values are not comparable
    */

    protected static boolean compare(AtomicValue v1, int op, AtomicValue v2,
                                     AtomicComparer collator)
            throws XPathException.Type {
        if (v1 instanceof NumericValue && ((NumericValue)v1).isNaN()) {
            return false;
        }
        if (v2 instanceof NumericValue && ((NumericValue)v2).isNaN()) {
            return false;
        }
        try {
            switch (op) {
                case Tokenizer.FEQ:
                    return collator.comparesEqual(v1, v2);
                case Tokenizer.FNE:
                    return !collator.comparesEqual(v1, v2);
                case Tokenizer.FGT:
                    return collator.compare(v1, v2) > 0;
                case Tokenizer.FLT:
                    return collator.compare(v1, v2) < 0;
                case Tokenizer.FGE:
                    return collator.compare(v1, v2) >= 0;
                case Tokenizer.FLE:
                    return collator.compare(v1, v2) <= 0;
                default:
                    throw new UnsupportedOperationException("Unknown operator " + op);
            }
        } catch (ClassCastException err) {
            throw new XPathException.Type(
                "Cannot compare " + v1.getItemType() + " to " + v2.getItemType());
        }
    }

    /**
    * Evaluate the expression in a given context
    * @param context the given context for evaluation
    * @return a BooleanValue representing the result of the numeric comparison of the two operands,
     * or null representing the empty sequence
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
       try {
            AtomicValue v1 = (AtomicValue)operands[0].evaluateItem(context);
            if (v1==null) return null;
            if (v1 instanceof UntypedAtomicValue) {
                v1 = v1.convert(Type.STRING);
            }
            AtomicValue v2 = (AtomicValue)operands[1].evaluateItem(context);
            if (v2==null) return null;
            if (v2 instanceof UntypedAtomicValue) {
                v2 = v2.convert(Type.STRING);
            }
            return BooleanValue.get(compare(v1, operator, v2, comparer));
        } catch (XPathException.Type err) {
            // re-throw the exception with location information added
            typeError(err.getMessage());
            return null;   // dummy return
        }
    }


    /**
    * Determine the data type of the expression
    * @return Type.BOOLEAN
    */

    public ItemType getItemType() {
        return Type.BOOLEAN_TYPE;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
