package net.sf.saxon.expr;
import net.sf.saxon.om.AtomizableIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.Type;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.Configuration;

/**
* An Atomizer is an expression corresponding essentially to the fn:data() function: it
* maps a sequence by replacing nodes with their typed values
*/

public final class Atomizer extends ComputedExpression implements MappingFunction {

    private Expression sequence;

    /**
    * Constructor
    */

    public Atomizer(Expression sequence) {
        this.sequence = sequence;
    }

    /**
    * Simplify an expression
    */

     public Expression simplify() throws XPathException {
        sequence = sequence.simplify();
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        sequence = sequence.analyze(env);
        if (Type.isSubType(sequence.getItemType(), Type.ANY_ATOMIC_TYPE)) {
            return sequence;
        }
        return this;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            sequence = sequence.promote(offer);
            return this;
        }
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[1];
        exp[0] = sequence;
        return exp;
    }

    /**
    * Iterate over the sequence of values
    */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        SequenceIterator base = sequence.iterate(context);
        if (base instanceof AtomizableIterator) {
            ((AtomizableIterator)base).setIsAtomizing(true);
        }
        return new MappingIterator(base, this, null, context.getController().getConfiguration());
    }

    /**
    * Evaluate as an Item. This should only be called if the Atomizer has cardinality zero-or-one,
    * which will only be the case if the underlying expression has cardinality zero-or-one.
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        Item i = sequence.evaluateItem(context);
        if (i==null) {
            return null;
        }
        if (i instanceof NodeInfo) {
            SequenceIterator it = i.getTypedValue(context.getController().getConfiguration());
            return it.next();
        } else {
            return i;
        }
    }

    /**
    * Implement the mapping function
    */

    public Object map(Item item, XPathContext context, Object info) throws XPathException {
        if (item instanceof NodeInfo) {
            return item.getTypedValue((Configuration)info);
        } else {
            return item;
        }
    }

    /**
    * Determine the data type of the items returned by the expression, if possible
    * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
    * or Type.ITEM (meaning not known in advance)
    */

	public ItemType getItemType() {
	    // note, we can't base this on SequenceType, because only untyped values are converted
	    return Type.ANY_ATOMIC_TYPE;
	}

	/**
	* Determine the static cardinality of the expression
	*/

	public int computeCardinality() {
        return StaticProperty.ALLOWS_ZERO_OR_MORE;
        // TODO: this is where we need schema information...
	}

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "atomize");
        sequence.display(level+1, pool);
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
