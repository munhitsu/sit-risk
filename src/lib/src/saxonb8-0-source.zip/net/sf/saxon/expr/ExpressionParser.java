package net.sf.saxon.expr;
import net.sf.saxon.Loader;
import net.sf.saxon.Err;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.NamespaceConstant;
import net.sf.saxon.om.QNameException;
import net.sf.saxon.om.XMLChar;
import net.sf.saxon.pattern.*;
import net.sf.saxon.sort.Reverser;
import net.sf.saxon.type.AnyItemType;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.ExternalObjectType;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.SchemaDeclaration;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.*;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.SourceLocator;
import javax.xml.transform.TransformerException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Parser for XPath expressions and XSLT patterns.
 *
 * This code was originally inspired by James Clark's xt but has been totally rewritten (several times)
 *
 * @author Michael Kay
 */


public class ExpressionParser {

    protected Tokenizer t;
    protected StaticContext env;
    protected int numberOfRangeVariables = 0;
    protected Stack rangeVariables = null;
        // The stack holds a list of range variables that are in scope.
        // Each entry on the stack is a VariableDeclaration object containing details
        // of the variable.

    protected boolean scanOnly = false;
        // scanOnly is set to true while attributes in direct element constructors
        // are being processed. We need to parse enclosed expressions in the attribute
        // in order to find the end of the attribute value, but we don't yet know the
        // full namespace context at this stage.

    public Tokenizer getTokenizer() {
        return t;
    }

    /**
     * Read the next token, catching any exception thrown by the tokenizer
     */

    protected void nextToken() throws XPathException.Static {
        try {
            t.next();
        } catch (XPathException.Static err) {
            grumble(err.getMessage());
        }
    }

    /**
     * Expect a given token, fail if the current token is different
     *
     * @param token the expected token
     * @throws XPathException.Static.Static if the current token is not the expected
     *     token
     */

    protected void expect(int token) throws XPathException.Static {
        if (t.currentToken != token)
            grumble("expected \"" + Tokenizer.tokens[token] +
                             "\", found " + currentTokenDisplay());
    }

    /**
     * Report a parsing error
     *
     * @param message the error message
     * @throws XPathException.Static.Static always thrown: an exception containing the
     *     supplied message
     */

    protected void grumble(String message) throws XPathException.Static {
        String s = t.recentText();
        int line = t.getLineNumber();
        String lineInfo = (line==1 ? "" : ("on line " + line + " "));
        String prefix = getLanguage() + " syntax error " + lineInfo +
                    (message.startsWith("...") ? "near" : "in") +
                     " " + Err.wrap(s) + ":\n    ";
        throw new XPathException.Static(prefix + message);
    }

    /**
     * Output a warning message
     */

    protected void warning(String message) throws XPathException.Static {
        String s = t.recentText();
        int line = t.getLineNumber();
        String lineInfo = (line==1 ? "" : ("on line " + line + " "));
        String prefix = "Warning " + lineInfo +
                    (message.startsWith("...") ? "near" : "in") +
                     " " + Err.wrap(s) + ":\n    ";
        env.issueWarning(prefix + message);
    }

    /**
     * Get the current language (XPath or XQuery)
     */

    protected String getLanguage() {
        return "XPath";
    }

    /**
     * Display the current token in an error message
     *
     * @return the display representation of the token
     */
    protected String currentTokenDisplay() {
        if (t.currentToken==Tokenizer.NAME) {
            return "name \"" + t.currentTokenValue + "\"";
        } else if (t.currentToken==Tokenizer.UNKNOWN) {
            return "(unknown token)";
        } else {
            return "\"" + Tokenizer.tokens[t.currentToken] + "\"";
        }
    }

	/**
	 * Parse a string representing an expression
	 *
	 * @throws XPathException.Static if the expression contains a syntax error
	 * @param expression the expression expressed as a String
	 * @param env the static context for the expression
	 * @return an Expression object representing the result of parsing
	 */

	public Expression parse(String expression, int start, int terminator, StaticContext env) throws XPathException.Static {
        // System.err.println("Parse expression: " + expression);
        numberOfRangeVariables = 0;
	    this.env = env;
        t = new Tokenizer();
	    t.tokenize(expression, start, -1);
        Expression exp = parseExpression();
        if (t.currentToken != terminator) {
            grumble("Unexpected token " + currentTokenDisplay() + " beyond end of expression");
        }
        //exp.setStaticContext(env);
        // System.err.println("After parsing:");
        // exp.display(0);
        // System.err.println("After rewrite:");
        // exp.simplify().display(0);
        return exp;
    }

    /**
     * Parse a string representing an XSLT pattern
     *
     * @throws XPathException.Static if the pattern contains a syntax error
     * @param pattern the pattern expressed as a String
     * @param env the static context for the pattern
     * @return a Pattern object representing the result of parsing
     */

    public Pattern parsePattern(String pattern, StaticContext env) throws XPathException.Static {
        //System.err.println("Parse pattern: " + pattern);
	    this.env = env;
        t = new Tokenizer();
	    t.tokenize(pattern, 0, -1);
        Pattern pat = parseUnionPattern();
        if (t.currentToken != Tokenizer.EOF)
            grumble("Unexpected token " + currentTokenDisplay() + " beyond end of pattern");
        //pat.setStaticContext(env);
        //System.err.println("Parsed [" + pattern + "] to " + pat.getClass() + " default prio = " + pat.getDefaultPriority());
        return pat;
    }

    /**
     * Parse a string representing a sequence type
     *
     * @param input the string, which should conform to the XPath SequenceType
     *      production
     * @param env the static context
     * @throws XPathException.Static if any error is encountered
     * @return a SequenceType object representing the type
     */

    public SequenceType parseSequenceType(String input, StaticContext env) throws XPathException.Static {
        this.env = env;
        t = new Tokenizer();
        t.tokenize(input, 0, -1);
        SequenceType req = parseSequenceType();
        if (t.currentToken != Tokenizer.EOF) {
            grumble("Unexpected token " + currentTokenDisplay() + " beyond end of SequenceType");
        }
        return req;
    }


    //////////////////////////////////////////////////////////////////////////////////
    //                     EXPRESSIONS                                              //
    //////////////////////////////////////////////////////////////////////////////////

    /**
     * Parse a top-level Expression:
     * ExprSingle ( ',' ExprSingle )*
     *
     * @throws XPathException.Static if the expression contains a syntax error
     * @return the Expression object that results from parsing
     */

    protected Expression parseExpression() throws XPathException.Static {
        Expression exp = parseExprSingle();
        while (t.currentToken == Tokenizer.COMMA) {
            nextToken();
            exp = new AppendExpression(exp, Tokenizer.COMMA, parseExpression());
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse an ExprSingle
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected Expression parseExprSingle() throws XPathException.Static {
        switch (t.currentToken) {
            case Tokenizer.FOR:
            case Tokenizer.LET:             // XQuery only
                return parseForExpression();
            case Tokenizer.SOME:
            case Tokenizer.EVERY:
                return parseQuantifiedExpression();
            case Tokenizer.IF:
                return parseIfExpression();
            case Tokenizer.TYPESWITCH:
                return parseTypeswitchExpression();
            case Tokenizer.VALIDATE:
            case Tokenizer.VALIDATE_STRICT:
            case Tokenizer.VALIDATE_LAX:
            case Tokenizer.VALIDATE_SKIP:
            case Tokenizer.VALIDATE_GLOBAL:
            case Tokenizer.VALIDATE_CONTEXT:
                return parseValidateExpression();

            default:
                return parseOrExpression();
        }
    }

    /**
     * Parse a Typeswitch Expression.
     * This construct is XQuery-only, so the XPath version of this
     * method throws an error unconditionally
     */

    protected Expression parseTypeswitchExpression() throws XPathException.Static {
        grumble("typeswitch is not allowed in XPath");
        return null;
    }

    /**
     * Parse a Validate Expression.
     * This construct is XQuery-only, so the XPath version of this
     * method throws an error unconditionally
     */

    protected Expression parseValidateExpression() throws XPathException.Static {
        grumble("validate{} expressions are not allowed in XPath");
        return null;
    }

    /**
     * Parse an OrExpression:
     * AndExpr ( 'or' AndExpr )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseOrExpression() throws XPathException.Static {
        Expression exp = parseAndExpression();
        while (t.currentToken == Tokenizer.OR) {
            nextToken();
            exp = new BooleanExpression(exp, Tokenizer.OR, parseAndExpression());
        }
        return exp;
    }

    /**
     * Parse an AndExpr:
     * EqualityExpr ( 'and' EqualityExpr )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseAndExpression() throws XPathException.Static {
        Expression exp = parseComparisonExpression();
        while (t.currentToken == Tokenizer.AND) {
            nextToken();
            exp = new BooleanExpression(exp, Tokenizer.AND, parseComparisonExpression());
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse a FOR expression:
     * for $x in expr (',' $y in expr)* 'return' expr
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected Expression parseForExpression() throws XPathException.Static {
        if (t.currentToken==Tokenizer.LET) {
            grumble("'let' is not supported in XPath");
        }
        return parseMappingExpression();
    }

    /**
     * Parse a quantified expression:
     * (some|every) $x in expr 'satisfies' expr
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseQuantifiedExpression() throws XPathException.Static {
        return parseMappingExpression();
    }

    /**
     * Parse a mapping expression. This is a common routine that handles
     * XPath for expressions and quantified expressions.
     *
     * <p>Syntax: <br/>
     * (for|some|every) $x in expr (',' $y in expr)* (return|satisfies) expr
     * </p>
     *
     * <p>On entry, the current token indicates whether a for, some, or every
     * expression is expected.</p>
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected Expression parseMappingExpression() throws XPathException.Static {
        int operator = t.currentToken;
        List clauseList = new ArrayList();
        do {
            ForClause clause = new ForClause();
            clause.lineNumber = t.getLineNumber();
            clauseList.add(clause);
            nextToken();
            expect(Tokenizer.DOLLAR);
            nextToken();
            expect(Tokenizer.NAME);
            String var = t.currentTokenValue;

            // declare the range variable
            RangeVariableDeclaration v = new RangeVariableDeclaration();
            v.setVariableFingerprint(makeNameCode(var, false) & 0xfffff);
            v.setRequiredType(SequenceType.SINGLE_ITEM);
            v.setVariableName(var);
            clause.rangeVariable = v;
            nextToken();

            // "as" and "at" clauses are not recognized in XPath
            clause.positionVariable = null;

            // process the "in" clause
            expect(Tokenizer.IN);
            nextToken();
            clause.sequence = parseExprSingle();
            declareRangeVariable(clause.rangeVariable);
            if (clause.positionVariable != null) {
                declareRangeVariable(clause.positionVariable);
            }
        } while (t.currentToken==Tokenizer.COMMA);

        // process the "return/satisfies" expression (called the "action")
        if (operator==Tokenizer.FOR) {
            expect(Tokenizer.RETURN);
        } else {
            expect(Tokenizer.SATISFIES);
        }
        nextToken();
        Expression action = parseExprSingle();

        // work back through the list of range variables, fixing up all references
        // to the variables in the inner expression

        for (int i = clauseList.size()-1; i>=0; i--) {
            ForClause fc = (ForClause)clauseList.get(i);
            Assignation exp;
            if (operator==Tokenizer.FOR) {
                exp = new ForExpression();
            } else {
                exp = new QuantifiedExpression();
                ((QuantifiedExpression)exp).setOperator(operator);
            }
            setLocation(exp);
            exp.setVariableDeclaration(fc.rangeVariable);
            exp.setSequence(fc.sequence);

            // Attempt to give the range variable a more precise type, base on analysis of the
            // "action" expression. This will often be approximate, because variables and function
            // calls in the action expression have not yet been resolved. We rely on the ability
            // of all expressions to return some kind of type information even if this is
            // imprecise.

            SequenceType type =
                    new SequenceType(fc.sequence.getItemType(), StaticProperty.EXACTLY_ONE);
            fc.rangeVariable.setRequiredType(type);
            exp.setAction(action);

            // for the next outermost "for" clause, the "action" is this ForExpression
            action = exp;
        }

        // undeclare all the range variables

        for (int i = clauseList.size()-1; i>=0; i--) {
            Object clause = clauseList.get(i);
            if ((clause instanceof ForClause) &&
                    ((ForClause)clause).positionVariable != null) {
                    // undeclare the "at" variable if it was declared
                undeclareRangeVariable();
            }
                // undeclare the primary variable
            undeclareRangeVariable();
        }

        return action;
    }


    /**
     * Parse an IF expression:
     * if '(' expr ')' 'then' expr 'else' expr
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseIfExpression() throws XPathException.Static {
        // left paren already read
        nextToken();
        Expression condition = parseExpression();
        expect(Tokenizer.RPAR);
        nextToken();
        expect(Tokenizer.THEN);
        nextToken();
        Expression thenExp = parseExpression();
        expect(Tokenizer.ELSE);
        nextToken();
        Expression elseExp = parseExprSingle();
        Expression ifExp = new IfExpression(condition, thenExp, elseExp);
        setLocation(ifExp);
        return ifExp;
    }

    /**
     * Parse an "instance of"  expression
     * Expr ("instance" "of") SequenceType
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseInstanceOfExpression() throws XPathException.Static {
        Expression exp = parseTreatExpression();
        if (t.currentToken == Tokenizer.INSTANCE_OF) {
            nextToken();
            exp = new InstanceOfExpression(exp, parseSequenceType());
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse a "treat as" expression
     * castable-expression ("treat" "as" SequenceType )?
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseTreatExpression() throws XPathException.Static {
        Expression exp = parseCastableExpression();
        if (t.currentToken == Tokenizer.TREAT_AS) {
            nextToken();
            SequenceType target = parseSequenceType();
            exp = TreatExpression.make(exp, target);
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse a "castable as" expression
     * Expr "castable as" AtomicType "?"?
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseCastableExpression() throws XPathException.Static {
        Expression exp = parseCastExpression();
        if (t.currentToken == Tokenizer.CASTABLE_AS) {
            nextToken();
            expect(Tokenizer.NAME);
            AtomicType at = getAtomicType(t.currentTokenValue);
            nextToken();
            boolean allowEmpty = (t.currentToken == Tokenizer.QMARK);
            if (allowEmpty) {
                nextToken();
            }
            exp = new CastableExpression(exp, at, allowEmpty);
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse a "cast as" expression
     * castable-expression ("cast" "as" AtomicType "?"?)
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseCastExpression() throws XPathException.Static {
        Expression exp = parseUnaryExpression();
        if (t.currentToken == Tokenizer.CAST_AS) {
            nextToken();
            expect(Tokenizer.NAME);
            AtomicType at = getAtomicType(t.currentTokenValue);
            nextToken();
            boolean allowEmpty = (t.currentToken == Tokenizer.QMARK);
            if (allowEmpty) {
                nextToken();
            }
            exp = new CastExpression(exp, at, allowEmpty);
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Analyze a token whose expected value is the name of an atomic type,
     * and return the object representing the atomic type.
     * @param qname The lexical QName of the atomic type
     * @return The atomic type
     * @throws XPathException.Static if the QName is invalid or if no atomic type of that
     * name exists as a built-in type or a type in an imported schema
     */
    private AtomicType getAtomicType(String qname) throws XPathException.Static {
        if (scanOnly) {
            return Type.ANY_ATOMIC_TYPE;
        }
        try {
            String[] parts = Name.getQNameParts(qname);
            String uri;
            if (parts[0].equals("")) {
                short uriCode = env.getDefaultElementNamespace();
                uri = env.getNamePool().getURIFromURICode(uriCode);
            } else {
                try {
                    uri = env.getURIForPrefix(parts[0]);
                } catch (XPathException err) {
                    grumble(err.getMessage());
                    uri = "";
                }
            }
            if (uri.equals(NamespaceConstant.SCHEMA) || uri.equals(NamespaceConstant.XDT)) {
                ItemType t = Type.getBuiltInItemType(uri, parts[1]);
                if (t == null) {
                    grumble("Unknown atomic type " + qname);
                }
                if (t instanceof AtomicType) {
                    return (AtomicType)t;
                } else {
                    grumble("The type " + qname + " is not atomic");
                }
            } else if (uri.equals(NamespaceConstant.JAVA_TYPE)) {
                Class theClass = null;
                try {
                    String className = parts[1].replace('-', '$');
                    theClass = Loader.getClass(className);
                } catch (TransformerException err) {
                    grumble("Unknown Java class " + parts[1]);
                }
                return new ExternalObjectType(theClass);
            } else {
                if (!env.isImportedSchema(uri) ) {
                    grumble("There is no imported schema for namespace " + uri);
                    return null;
                } else {
                    int fp = env.getNamePool().allocate(parts[0], uri, parts[1]);
                    SchemaType st = env.getConfiguration().getSchemaType(fp & 0xfffff);
                    if (st == null) {
                        grumble("Unknown atomic type " + qname);
                    } else if (st instanceof AtomicType) {
                        return (AtomicType)st;
                    } else if (st.isComplexType()) {
                        grumble("Cannot cast to a complex type (" + qname + ")");
                        return null;
                    } else {
                        grumble("Cannot cast to a list or union type (" + qname + ")");
                        return null;
                    }

                }
            }
            grumble("Unknown atomic type " + qname);
        } catch (QNameException err) {
            grumble(err.getMessage());
        }
        return null;
    }
    /**
     * Parse a ComparisonExpr:<br>
     * RangeExpr ( op RangeExpr )*
     * where op is one of =, <, >, !=, <=, >=,
     * eq, lt, gt, ne, le, ge,
     * is, isnot, <<, >>
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseComparisonExpression() throws XPathException.Static {
        Expression exp = parseRangeExpression();
        switch (t.currentToken) {
            case Tokenizer.IS:
            //case Tokenizer.ISNOT:
            case Tokenizer.PRECEDES:
            case Tokenizer.FOLLOWS:
                int op = t.currentToken;
                nextToken();
                exp = new IdentityComparison(exp, op, parseRangeExpression());
                setLocation(exp);
                return exp;

            case Tokenizer.EQUALS:
            case Tokenizer.NE:
            case Tokenizer.LT:
            case Tokenizer.GT:
            case Tokenizer.LE:
            case Tokenizer.GE:
                op = t.currentToken;
                nextToken();
                return new GeneralComparison(exp, op, parseRangeExpression());


            case Tokenizer.FEQ:
            case Tokenizer.FNE:
            case Tokenizer.FLT:
            case Tokenizer.FGT:
            case Tokenizer.FLE:
            case Tokenizer.FGE:
                op = t.currentToken;
                nextToken();
                exp = new ValueComparison(exp, op, parseRangeExpression());
                setLocation(exp);
                return exp;

            default:
                return exp;
        }
    }

    /**
     * Parse a RangeExpr:<br>
     * AdditiveExpr ('to' AdditiveExpr )?
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseRangeExpression() throws XPathException.Static {
        Expression exp = parseAdditiveExpression();
        if (t.currentToken == Tokenizer.TO ) {
            nextToken();
            exp = new RangeExpression(exp, Tokenizer.TO, parseAdditiveExpression());
            setLocation(exp);
        }
        return exp;
    }



    /**
     * Parse the sequence type production.
     * Provisionally, we use the syntax (QName | node-kind "()") ( "*" | "+" | "?" )?
     * We also allow "element of type QName" and "attribute of type QName"
     * The QName must be the name of a built-in schema-defined data type.
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected SequenceType parseSequenceType() throws XPathException.Static {
        ItemType primaryType;
        if (t.currentToken == Tokenizer.NAME) {
            primaryType = getAtomicType(t.currentTokenValue);
            nextToken();
        } else if (t.currentToken == Tokenizer.NODEKIND) {
            if (t.currentTokenValue == "item") {
                nextToken();
                expect(Tokenizer.RPAR);
                nextToken();
                primaryType = AnyItemType.getInstance();
            } else {
                primaryType = parseKindTest();
            }
        } else if (t.currentToken == Tokenizer.FUNCTION && t.currentTokenValue.equals("empty")) {
            // have to special-case this because "empty" is also used as a core function
            nextToken();
            expect(Tokenizer.RPAR);
            nextToken();
            return new SequenceType(NoNodeTest.getInstance(), StaticProperty.EMPTY);
            // Note, no occurrence indicator allowed
        } else {
            grumble("Expected type name in SequenceType, found " + Tokenizer.tokens[t.currentToken]);
            return null;
        }

        int occurrenceFlag;
        switch (t.currentToken) {
            case Tokenizer.STAR:
            case Tokenizer.MULT:
                // "*" will be tokenized different ways depending on what precedes it
                occurrenceFlag = StaticProperty.ALLOWS_ZERO_OR_MORE;
                //t.setState(Tokenizer.DEFAULT_STATE);
                nextToken();
                break;
            case Tokenizer.PLUS:
                occurrenceFlag = StaticProperty.ALLOWS_ONE_OR_MORE;
                //t.setState(Tokenizer.DEFAULT_STATE);
                nextToken();
                break;
            case Tokenizer.QMARK:
                occurrenceFlag = StaticProperty.ALLOWS_ZERO_OR_ONE;
                //t.setState(Tokenizer.DEFAULT_STATE);
                nextToken();
                break;
            default:
                occurrenceFlag = StaticProperty.EXACTLY_ONE;
        }
        return new SequenceType(primaryType, occurrenceFlag);
    }


    /**
     * Parse an AdditiveExpr:
     * MultiplicativeExpr ( (+|-) MultiplicativeExpr )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseAdditiveExpression() throws XPathException.Static {
        Expression exp = parseMultiplicativeExpression();
        while (t.currentToken == Tokenizer.PLUS ||
                t.currentToken == Tokenizer.MINUS ) {
            int op = t.currentToken;
            nextToken();
            exp = new ArithmeticExpression(exp, op, parseMultiplicativeExpression());
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse a MultiplicativeExpr:<br>
     * UnionExpr ( (*|div|idiv|mod) UnionExpr )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseMultiplicativeExpression() throws XPathException.Static {
        Expression exp = parseUnionExpression();
        while (t.currentToken == Tokenizer.MULT ||
                t.currentToken == Tokenizer.DIV ||
                t.currentToken == Tokenizer.IDIV ||
                t.currentToken == Tokenizer.MOD ) {
            int op = t.currentToken;
            nextToken();
            exp = new ArithmeticExpression(exp, op, parseUnionExpression());
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse a UnaryExpr:<br>
     * ('+'|'-')* ValueExpr
     * parsed as ('+'|'-')? UnaryExpr
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseUnaryExpression() throws XPathException.Static {
        Expression exp;
        switch (t.currentToken) {
        case Tokenizer.MINUS:
            nextToken();
            exp = new ArithmeticExpression(new IntegerValue(0),
                                          Tokenizer.NEGATE,
                                          parseUnaryExpression());
            break;
        case Tokenizer.PLUS:
            nextToken();
            // Unary plus: can't ignore it completely, it might be a type error, or it might
            // force conversion to a number which would affect operations such as "=".
            exp = new ArithmeticExpression(new IntegerValue(0),
                                          Tokenizer.PLUS,
                                          parseUnaryExpression());
            break;
        case Tokenizer.VALIDATE:
        case Tokenizer.VALIDATE_STRICT:
        case Tokenizer.VALIDATE_LAX:
        case Tokenizer.VALIDATE_SKIP:
        case Tokenizer.VALIDATE_GLOBAL:
        case Tokenizer.VALIDATE_CONTEXT:
            exp = parseValidateExpression();
            break;
        default:
            exp = parsePathExpression();
        }
        setLocation(exp);
        return exp;
    }

    /**
     * Parse a UnionExpr:<br>
     * IntersectExceptExpr ( "|" | "union" IntersectExceptExpr )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseUnionExpression() throws XPathException.Static {
        Expression exp = parseIntersectExpression();
        while (t.currentToken == Tokenizer.UNION ) {
            nextToken();
            exp = new VennExpression(exp, Tokenizer.UNION, parseIntersectExpression());
            setLocation(exp);
        }
        return exp;
    }

    /**
     * Parse an IntersectExceptExpr:<br>
     * PathExpr ( ( 'intersect' | 'except') PathExpr )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseIntersectExpression() throws XPathException.Static {
        Expression exp = parseInstanceOfExpression();
        while (t.currentToken == Tokenizer.INTERSECT ||
                t.currentToken == Tokenizer.EXCEPT ) {
            int op = t.currentToken;
            nextToken();
            exp = new VennExpression(exp, op, parseInstanceOfExpression());
            setLocation(exp);
        }
        return exp;
    }



    /**
     * Test whether the current token is one that can start a RelativePathExpression
     *
     * @return the resulting subexpression
     */

    private boolean atStartOfRelativePath() {
        switch(t.currentToken) {
            case Tokenizer.AXIS:
            case Tokenizer.AT:
            case Tokenizer.NAME:
            case Tokenizer.PREFIX:
            case Tokenizer.SUFFIX:
            case Tokenizer.STAR:
            case Tokenizer.NODEKIND:
            case Tokenizer.DOT:
            case Tokenizer.DOTDOT:
            case Tokenizer.FUNCTION:
            case Tokenizer.STRING_LITERAL:
            case Tokenizer.NUMBER:
            case Tokenizer.LPAR:
                return true;
            default:
                return false;
        }
    }

    /**
     * Parse a PathExpresssion. This includes "true" path expressions such as A/B/C, and also
     * constructs that may start a path expression such as a variable reference $name or a
     * parenthesed expression (A|B). Numeric and string literals also come under this heading.
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parsePathExpression() throws XPathException.Static {
        switch (t.currentToken) {
        case Tokenizer.SLASH:
            nextToken();
            Expression path;
            if (atStartOfRelativePath()) {
                path = new PathExpression(new RootExpression(), parseRelativePath());
            } else {
                path = new RootExpression();
            }
            setLocation(path);
            return path;

        case Tokenizer.SLSL:
            nextToken();
            // add in the implicit descendant-or-self::node() step
            Expression exp = new PathExpression(new RootExpression(),
                        new PathExpression(new AxisExpression(Axis.DESCENDANT_OR_SELF, null),
                            parseRelativePath()));
            setLocation(exp);
            return exp;
        default:
            return parseRelativePath();
        }

    }


    /**
     * Parse a relative path (a sequence of steps). Called when the current token immediately
     * follows a separator (/ or //), or an implicit separator (XYZ is equivalent to ./XYZ)
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected Expression parseRelativePath() throws XPathException.Static {
        Expression exp = parseStepExpression();
        while (t.currentToken == Tokenizer.SLASH ||
                t.currentToken == Tokenizer.SLSL ) {
            int op = t.currentToken;
            nextToken();
            Expression next = parseRelativePath();
            if (op == Tokenizer.SLASH) {
                exp = new PathExpression(exp, next);
            } else {
                // add implicit descendant-or-self::node() step
                exp = new PathExpression(exp,
                        new PathExpression(new AxisExpression(Axis.DESCENDANT_OR_SELF, null),
                            next));
            }
            setLocation(exp);

            //exp.setStaticContext(env);
        }
        return exp;
    }

    /**
     * Parse a step (including an optional sequence of predicates)
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    protected Expression parseStepExpression() throws XPathException.Static {
        Expression step = parseBasicStep();

        // When the filter is applied to an Axis step, the nodes are considered in
        // axis order. In all other cases they are considered in document order
        boolean reverse = (step instanceof AxisExpression) &&
                          Axis.isReverse[((AxisExpression)step).getAxis()];

        while (t.currentToken == Tokenizer.LSQB) {
            nextToken();
            Expression predicate = parseExprSingle();
            expect(Tokenizer.RSQB);
            nextToken();
            step = new FilterExpression(step, predicate);
            setLocation(step);
        }
        if (reverse) {
            return new Reverser(step);
        } else {
            return step;
        }
    }

    /**
     * Parse a basic step expression (without the predicates)
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseBasicStep() throws XPathException.Static {
        switch(t.currentToken) {
        case Tokenizer.DOLLAR:
            nextToken();
            expect(Tokenizer.NAME);
            String var = t.currentTokenValue;
            nextToken();

            if (scanOnly) {
                return new ContextItemExpression();
                // don't do any semantic checks during a prescan
            }

            int vtest = makeNameCode(var, false) & 0xfffff;

            // See if it's a range variable or a variable in the context
            VariableDeclaration b = findRangeVariable(vtest);
            VariableReference ref;
            if (b!=null) {
                ref = new VariableReference(b);
            } else {
                try {
                    ref = new VariableReference(env.bindVariable(vtest));
                } catch (XPathException err) {
                    grumble("Variable $" + var + " has not been declared");
                    ref = null;
                }
            }
            setLocation(ref);
            return ref;

        case Tokenizer.LPAR:
            nextToken();
            if (t.currentToken==Tokenizer.RPAR) {
                nextToken();
                return EmptySequence.getInstance();
            }
            Expression seq = parseExpression();
            expect(Tokenizer.RPAR);
            nextToken();
            return seq;

        case Tokenizer.STRING_LITERAL:
            StringValue literal = makeStringLiteral(t.currentTokenValue);
            nextToken();
            return literal;

        case Tokenizer.NUMBER:
            Value number = null;
            try {
                if (t.currentTokenValue.indexOf('e')>=0 || t.currentTokenValue.indexOf('E')>=0) {
                    double d = new Double(t.currentTokenValue).doubleValue();
                    number = new DoubleValue(d);
                } else if (t.currentTokenValue.indexOf('.')>=0 || t.currentTokenValue.length()>18) {
                    number = new DecimalValue(t.currentTokenValue);
                } else {
                    number = IntegerValue.stringToInteger(t.currentTokenValue);
                }
            } catch (NumberFormatException err) {
                grumble("Invalid numeric literal [" + t.currentTokenValue + "]");
            } catch (XPathException err) {
                grumble(err.getMessage());
            }
            nextToken();
            return number;

        case Tokenizer.FUNCTION:
            return parseFunctionCall();

        case Tokenizer.DOT:
            nextToken();
            Expression cie = new ContextItemExpression();
            setLocation(cie);
            return cie;

        case Tokenizer.DOTDOT:
            nextToken();
            Expression pne = new ParentNodeExpression();
            setLocation(pne);
            return pne;

        case Tokenizer.NAME:
        case Tokenizer.PREFIX:
        case Tokenizer.SUFFIX:
        case Tokenizer.STAR:
        case Tokenizer.NODEKIND:
            byte defaultAxis = Axis.CHILD;
            if (t.currentToken == Tokenizer.NODEKIND && t.currentTokenValue == "attribute") {
                defaultAxis = Axis.ATTRIBUTE;
            }
            return new AxisExpression(defaultAxis, parseNodeTest(Type.ELEMENT));

        case Tokenizer.AT:
            nextToken();
            switch(t.currentToken) {

            case Tokenizer.NAME:
            case Tokenizer.PREFIX:
            case Tokenizer.SUFFIX:
            case Tokenizer.STAR:
            case Tokenizer.NODEKIND:
                return new AxisExpression(Axis.ATTRIBUTE,
                                    parseNodeTest(Type.ATTRIBUTE));

            default:
                grumble("@ must be followed by a NodeTest");
            }
            break;

        case Tokenizer.AXIS:
            byte axis = Axis.getAxisNumber(t.currentTokenValue);
            short principalNodeType = Axis.principalNodeType[axis];
            nextToken();
            switch (t.currentToken) {

            case Tokenizer.NAME:
            case Tokenizer.PREFIX:
            case Tokenizer.SUFFIX:
            case Tokenizer.STAR:
            case Tokenizer.NODEKIND:
                Expression ax = new AxisExpression(axis, parseNodeTest(principalNodeType));
                setLocation(ax);
                return ax;

            default:
                grumble("Unexpected token " + currentTokenDisplay() + " after axis name");
            }
            break;

        case Tokenizer.KEYWORD_CURLY:
        case Tokenizer.ELEMENT_QNAME:
        case Tokenizer.ATTRIBUTE_QNAME:
        case Tokenizer.PI_QNAME:
        case Tokenizer.TAG:
            return parseConstructor();

        default:
            grumble("Unexpected token " + currentTokenDisplay() + " in path expression");
            //break;
        }
        return null;
    }

    /**
     * Method to make a string literal from a token identified as a string
     * literal. This is trivial in XPath, but in XQuery the method is overridden
     * to identify pseudo-XML character and entity references
     * @param currentTokenValue
     * @return The string value of the string literal
     */

    protected StringValue makeStringLiteral(String currentTokenValue) throws XPathException.Static {
        return new StringValue(currentTokenValue);
    }

    /**
     * Parse a node constructor. This is allowed only in XQuery, so the method throws
     * an error for XPath.
     */

    protected Expression parseConstructor() throws XPathException.Static {
        grumble("Node constructor expressions are allowed only in XQuery, not in XPath");
        return null;
    }

    /**
     * Parse a NodeTest.
     * One of QName, prefix:*, *:suffix, *, text(), node(), comment(), or
     * processing-instruction(literal?), or element(~,~), attribute(~,~), etc.
     *
     * @throws XPathException.Static if any error is encountered
     * @param nodeType the node type being sought if one is specified
     * @return the resulting NodeTest object
     */

    protected NodeTest parseNodeTest(short nodeType) throws XPathException.Static {
        int tok = t.currentToken;
        String tokv = t.currentTokenValue;
        switch (tok) {
        case Tokenizer.NAME:
            nextToken();
            return makeNameTest(nodeType, tokv, nodeType==Type.ELEMENT);

        case Tokenizer.PREFIX:
            nextToken();
        	return makeNamespaceTest(nodeType, tokv);

        case Tokenizer.SUFFIX:
            nextToken();
            tokv = t.currentTokenValue;
            expect(Tokenizer.NAME);
            nextToken();
        	return makeLocalNameTest(nodeType, tokv);

        case Tokenizer.STAR:
            nextToken();
            return NodeKindTest.makeNodeKindTest(nodeType);

        case Tokenizer.NODEKIND:
            return parseKindTest();

        default:
            grumble("Unrecognized node test");
            return null;
        }
    }

    /**
     * Parse a KindTest
     */

    private NodeTest parseKindTest() throws XPathException.Static {
        String typeName = t.currentTokenValue;
        boolean schemaDeclaration = (typeName.startsWith("schema-"));
        int primaryType = getSystemType(typeName);
        int nameCode = -1;
        int contentType = -1;
        boolean empty = false;
        nextToken();
        if (t.currentToken == Tokenizer.RPAR) {
            if (schemaDeclaration) {
                grumble("schema-element() and schema-attribute() require a name to be supplied");
                return null;
            }
            empty = true;
            nextToken();
        }
        switch (primaryType) {
            case Type.ITEM:
                grumble("item() is not allowed in a path expression");
                return null;
            case Type.NODE:
                if (empty) {
                    return AnyNodeTest.getInstance();
                } else {
                    grumble("No arguments are allowed in node()");
                    return null;
                }
            case Type.TEXT:
                if (empty) {
                    return NodeKindTest.TEXT;
                } else {
                    grumble("No arguments are allowed in text()");
                    return null;
                }
            case Type.COMMENT:
                if (empty) {
                    return NodeKindTest.COMMENT;
                } else {
                    grumble("No arguments are allowed in comment()");
                    return null;
                }
            case Type.NAMESPACE:
                grumble("No node test is defined for namespace nodes");
                return null;
            case Type.DOCUMENT:
                if (empty) {
                    return NodeKindTest.DOCUMENT;
                } else {
                    int innerType = Type.EMPTY;
                    try {
                        innerType = getSystemType(t.currentTokenValue);
                    } catch (XPathException err) {
                        innerType = Type.EMPTY;
                    }
                    if (innerType != Type.ELEMENT) {
                        grumble("Argument to document-node() must be an element type descriptor");
                        return null;
                    }
                    NodeTest inner = parseKindTest();
                    expect(Tokenizer.RPAR);
                    nextToken();
                    return new DocumentNodeTest(inner);
                }
            case Type.PROCESSING_INSTRUCTION:
                if (empty) {
                    return NodeKindTest.PROCESSING_INSTRUCTION;
                } else if (t.currentToken == Tokenizer.STRING_LITERAL) {
                    try {
                        String[] parts = Name.getQNameParts(t.currentTokenValue);
                        if (!parts[0].equals("")) {
                            warning("No processing instruction name will ever contain a colon");
                            nameCode = env.getNamePool().allocate("prefix", "http://saxon.sf.net/ nonexistent namespace", "___invalid-name");
                        } else {
                            nameCode = makeNameCode(parts[1], false);
                        }
                    } catch (QNameException e) {
                        warning("No processing instruction will ever be named '" +
                                t.currentTokenValue + "'. " + e.getMessage());
                        nameCode = env.getNamePool().allocate("prefix", "http://saxon.sf.net/ nonexistent namespace", "___invalid-name");
                    }
                } else if (t.currentToken == Tokenizer.NAME) {
                    try {
                        String[] parts = Name.getQNameParts(t.currentTokenValue);
                        if (!parts[0].equals("")) {
                            grumble("Processing instruction name must not contain a colon");
                        } else {
                            nameCode = makeNameCode(parts[1], false);
                        }
                    } catch (QNameException e) {
                        grumble("Invalid processing instruction name. " + e.getMessage());
                    }
                }
                nextToken();
                expect(Tokenizer.RPAR);
                nextToken();
                return new NameTest(Type.PROCESSING_INSTRUCTION, nameCode);

            case Type.ATTRIBUTE:
                // drop through

            case Type.ELEMENT:
                String nodeName = "";
                if (empty) {
                    return NodeKindTest.makeNodeKindTest(primaryType);
                } else if (t.currentToken == Tokenizer.STAR || t.currentToken == Tokenizer.MULT) {
                    // allow for both representations of "*" to be safe
                    if (schemaDeclaration) {
                        grumble("schema-element() and schema-attribute() must specify an actual name, not '*'");
                        return null;
                    }
                    nameCode = -1;
                } else if (t.currentToken == Tokenizer.NAME) {
                    nodeName = t.currentTokenValue;
                    nameCode = makeNameCode(t.currentTokenValue, true) & 0xfffff;
                } else {
                    grumble("Unexpected " + Tokenizer.tokens[t.currentToken] + " after '(' in SequenceType");
                }
                nextToken();
                if (t.currentToken == Tokenizer.SLASH) {
                    grumble("Schema context paths have been dropped from the language specification");
                } else if (t.currentToken == Tokenizer.RPAR) {
                    nextToken();
                    if (nameCode == -1) {
                        // element(*) or attribute(*)
                        return NodeKindTest.makeNodeKindTest(primaryType);
                    } else {
                        NodeTest nameTest = null;
                        SchemaType schemaType = null;
                        if (primaryType == Type.ATTRIBUTE) {
                            // attribute(N) or schema-attribute(N)
                            if (schemaDeclaration) {
                                SchemaDeclaration attributeDecl =
                                        env.getConfiguration().getAttributeDeclaration(nameCode);
                                if (attributeDecl == null) {
                                    grumble("There is no declaration for attribute @" + nodeName + " in an imported schema");
                                } else {
                                    schemaType = env.getConfiguration().getAttributeType(attributeDecl);
                                    nameTest = new NameTest(Type.ATTRIBUTE, nameCode);
                                }
                            } else {
                                nameTest = new NameTest(Type.ATTRIBUTE, nameCode);
                                return nameTest;
                            }
                        } else {
                            // element(N) or schema-element(N)
                            if (schemaDeclaration) {
                                SchemaDeclaration elementDecl =
                                        env.getConfiguration().getElementDeclaration(nameCode);
                                if (elementDecl == null) {
                                    grumble("There is no declaration for element <" + nodeName + "> in an imported schema");
                                } else {
                                    schemaType = env.getConfiguration().getElementType(elementDecl);
                                    nameTest = env.getConfiguration().makeSubstitutionGroupTest(elementDecl);

                                }
                            } else {
                                nameTest = new NameTest(Type.ELEMENT, nameCode);
                                return nameTest;
                            }
                        }
                        ContentTypeTest contentTest = null;
                        if (schemaType != null) {
                            contentTest = new ContentTypeTest(primaryType, schemaType, env.getConfiguration());
                        }

                        if (contentTest == null) {
                            return nameTest;
                        } else {
                            return new CombinedNodeTest(nameTest, Tokenizer.INTERSECT, contentTest);
                        }
                    }
                } else if (t.currentToken == Tokenizer.COMMA) {
                    if (schemaDeclaration) {
                        grumble("schema-element() and schema-attribute() must have one argument only");
                        return null;
                    }
                    nextToken();
                    NodeTest result;
                    if (t.currentToken == Tokenizer.STAR) {
                        grumble("'*' is no longer permitted as the second argument of element() and attribute()");
                        return null;
//                        if (nameCode == -1) {
//                            result = NodeKindTest.makeNodeKindTest(primaryType);
//                        } else {
//                            if (primaryType == Type.ATTRIBUTE) {
//                                result = new NameTest(Type.ATTRIBUTE, nameCode);
//                            } else {
//                                result = new NameTest(Type.ELEMENT, nameCode);
//                            }
//                        }
                    } else if (t.currentToken == Tokenizer.NAME) {
                        SchemaType schemaType;
                        contentType = makeNameCode(t.currentTokenValue, true) & 0xfffff;
                        String uri = env.getNamePool().getURI(contentType);
                        String lname = env.getNamePool().getLocalName(contentType);
                        if (uri.equals(NamespaceConstant.SCHEMA) ||
                                uri.equals(NamespaceConstant.XDT)) {
                            schemaType = env.getConfiguration().getSchemaType(contentType);
                        } else {
                            if (!env.isImportedSchema(uri)) {
                                grumble("No schema has been imported for namespace '" + uri + "'");
                            }
                            schemaType = env.getConfiguration().getSchemaType(contentType);
                        }
                        if (schemaType == null) {
                            grumble("Unknown type name " + lname);
                        }
                        if (primaryType == Type.ATTRIBUTE && schemaType.isComplexType()) {
                            grumble("An attribute cannot have a complex type");
                        }
                        NodeTest typeTest = new ContentTypeTest(primaryType, schemaType, env.getConfiguration());
                        if (nameCode == -1) {
                            // this represents element(*,T) or attribute(*,T)
                            result = typeTest;
                        } else {
                            if (primaryType == Type.ATTRIBUTE) {
                                SchemaDeclaration decl =
                                        env.getConfiguration().getAttributeDeclaration(nameCode & 0xfffff);
                                if (decl == null) {
                                    grumble("Attribute " + nodeName + " is not declared in an imported schema");
                                    return null;
                                } else {
                                    NodeTest nameTest = new NameTest(Type.ATTRIBUTE, nameCode);
                                    result = new CombinedNodeTest(nameTest, Tokenizer.INTERSECT, typeTest);
                                }
                            } else {
                                // assert (primaryType == Type.ELEMENT);
                                SchemaDeclaration decl =
                                        env.getConfiguration().getElementDeclaration(nameCode & 0xfffff);
                                if (decl == null) {
                                    grumble("Element " + nodeName + " is not declared in an imported schema");
                                    return null;
                                } else {
                                    NodeTest nameTest = new NameTest(Type.ELEMENT, nameCode);
                                    result = new CombinedNodeTest(nameTest, Tokenizer.INTERSECT, typeTest);
                                    // TODO: add support for substitution groups
                                }
                            }
                        }
                    } else {
                        grumble("Unexpected " + Tokenizer.tokens[t.currentToken] + " after ',' in SequenceType");
                        return null;
                    }
                    nextToken();
                    if (isKeyword("nillable")) {
                        grumble("'nillable' in a sequence type is not yet supported");
                        return null;
                        // TODO: support nillable (now replaced by "?")
                    }
                    nextToken();
                    return result;
                } else {
                    grumble("Expected ')' or ',' in SequenceType");
                }
                return null;
            default:
                // can't happen!
                grumble("Unknown node kind");
                return null;
        }
    }

    /**
     * Get a system type - that is, one whose name is a keyword rather than a QName. This includes the node
     * kinds such as element and attribute, the generic types node() and item(), and the pseudo-type empty()
     *
     * @param name
     * @exception XPathException.Static
     */
    private static int getSystemType(String name) throws XPathException.Static {
        if (name.equals("item"))                   return Type.ITEM;
        else if (name.equals("document-node"))     return Type.DOCUMENT;
        else if (name.equals("element"))           return Type.ELEMENT;
        else if (name.equals("schema-element"))    return Type.ELEMENT;
        else if (name.equals("attribute"))         return Type.ATTRIBUTE;
        else if (name.equals("schema-attribute"))  return Type.ATTRIBUTE;
        else if (name.equals("text"))              return Type.TEXT;
        else if (name.equals("comment"))           return Type.COMMENT;
        else if (name.equals("processing-instruction"))
                                                   return Type.PROCESSING_INSTRUCTION;
        else if (name.equals("namespace"))         return Type.NAMESPACE;
        else if (name.equals("node"))              return Type.NODE;
        else if (name.equals("empty"))             return Type.EMPTY;
        else throw new XPathException.Static("Unknown type " + name);
    }


    /**
     * Create a set containing all subtypes derived by restriction or extension
     * from a given type
     */

//    private static void addSubTypes(SchemaType base, HashSet subTypes) {
//        List list = base.getDerivedTypes();
//        for (int i = 0; i < list.size(); i++) {
//            SchemaType st = (SchemaType)list.get(i);
//            subTypes.add(new Integer(st.getFingerprint()));
//            addSubTypes(st, subTypes);
//        }
//    }

    /**
     * Parse a function call
     * function-name '(' ( Expression (',' Expression )* )? ')'
     *
     * @throws XPathException.Static if any error is encountered
     * @return the resulting subexpression
     */

    private Expression parseFunctionCall() throws XPathException.Static {

        String fname = t.currentTokenValue;
        ArrayList args = new ArrayList(10);

        // the "(" has already been read by the Tokenizer: now parse the arguments

        nextToken();
        if (t.currentToken!=Tokenizer.RPAR) {
            Expression arg = parseExprSingle();
            args.add(arg);
            while(t.currentToken==Tokenizer.COMMA) {
                nextToken();
                arg = parseExprSingle();
                args.add(arg);
            }
            expect(Tokenizer.RPAR);
        }
        nextToken();

        Expression[] arguments = new Expression[args.size()];
        args.toArray(arguments);

        try {
            Expression fcall = env.bindFunction(fname, arguments);
            setLocation(fcall);
            return fcall;
        } catch (XPathException err) {
            grumble(err.getMessage());
            return null;
        }
    }


    //////////////////////////////////////////////////////////////////////////////////
    // Routines for handling range variables
    //////////////////////////////////////////////////////////////////////////////////

    /**
     * Declare a range variable (record its existence within the parser).
     * A range variable is a variable declared within an expression, as distinct
     * from a variable declared in the context.
     *
     * @param declaration the VariableDeclaration to be added to the stack
     * @throws XPathException.Static if any error is encountered
     */

    protected void declareRangeVariable(VariableDeclaration declaration) throws XPathException.Static {
        if (rangeVariables == null) {
            rangeVariables = new Stack();
        }
        rangeVariables.push(declaration);
    }

    /**
     * Note when the most recently declared range variable has gone out of scope
     */

    protected void undeclareRangeVariable() {
        rangeVariables.pop();
    }

    /**
     * Locate a range variable with a given name. (By "range variable", we mean a
     * variable declared within the expression where it is used.)
     *
     * @param fingerprint identifies the name of the range variable within the
     *      name pool
     * @return null if not found (this means the variable is probably a
     *     context variable); otherwise the relevant VariableDeclaration
     */

    private VariableDeclaration findRangeVariable(int fingerprint) {
        if (rangeVariables==null) {
            return null;
        }
        for (int v=rangeVariables.size()-1; v>=0; v--) {
            VariableDeclaration b = (VariableDeclaration)rangeVariables.elementAt(v);
            if (b.getVariableFingerprint()==fingerprint) {
                return b;
            }
        }
        return null;  // not an in-scope range variable
    }

    /**
     * Get the range variable stack. Used when parsing a nested subexpression
     * inside an attribute constructor
     */

    public Stack getRangeVariableStack() {
        return rangeVariables;
    }

    /**
     * Set the range variable stack. Used when parsing a nested subexpression
     * inside an attribute constructor.
     */

    public void setRangeVariableStack(Stack stack) {
        rangeVariables = stack;
    }

    //////////////////////////////////////////////////////////////////////////////////
    //                     PATTERNS                                                 //
    //////////////////////////////////////////////////////////////////////////////////


    /**
     * Parse a Union Pattern:<br>
     * pathPattern ( | pathPattern )*
     *
     * @throws XPathException.Static if any error is encountered
     * @return the pattern that results from parsing
     */

    private Pattern parseUnionPattern() throws XPathException.Static {
        Pattern exp1 = parsePathPattern();

        while (t.currentToken == Tokenizer.UNION ) {
            if (t.currentTokenValue == "union") {
                grumble("Union operator in a pattern must be written as '|'");
            }
            nextToken();
            Pattern exp2 = parsePathPattern();
            exp1 = new UnionPattern(exp1, exp2);
        }

        return exp1;
    }

    /**
     * Parse a Location Path Pattern:
     *
     * @throws XPathException.Static if any error is encountered
     * @return the pattern that results from parsing
     */

    private Pattern parsePathPattern() throws XPathException.Static {

        Pattern prev = null;
        int connector = -1;
        boolean rootonly = false;

        // special handling of stuff before the first component

        switch(t.currentToken) {
            case Tokenizer.SLASH:
                connector = t.currentToken;
                nextToken();
                prev = NodeKindTest.makeNodeKindTest(Type.DOCUMENT);
                rootonly = true;
                break;
            case Tokenizer.SLSL:            // leading double slash can't be ignored
                                            // because it changes the default priority
                connector = t.currentToken;
                nextToken();
                prev = NodeKindTest.makeNodeKindTest(Type.DOCUMENT);
                rootonly = false;
                break;
            default:
                break;
        }

        while(true) {
            Pattern pat = null;
            switch(t.currentToken) {
                case Tokenizer.AXIS:
                    if (t.currentTokenValue.equals("child")) {
                        nextToken();
                        pat = parsePatternStep(Type.ELEMENT);
                    } else if (t.currentTokenValue.equals("attribute")) {
                        nextToken();
                        pat = parsePatternStep(Type.ATTRIBUTE);
                    } else {
                        grumble("Axis in pattern must be child or attribute");
                    }
                    break;

                case Tokenizer.STAR:
                case Tokenizer.NAME:
                case Tokenizer.PREFIX:
                case Tokenizer.SUFFIX:
                case Tokenizer.NODEKIND:
                    pat = parsePatternStep(Type.ELEMENT);
                    break;

                case Tokenizer.AT:
                    nextToken();
                    pat = parsePatternStep(Type.ATTRIBUTE);
                    break;

                case Tokenizer.FUNCTION:        // must be id(literal) or key(literal,literal)
                    if (prev!=null) {
                        grumble("Function call may appear only at the start of a pattern");
                    }
                    if (t.currentTokenValue.equals("id")) {
                        nextToken();
                        Expression idValue = null;
                        if (t.currentToken == Tokenizer.STRING_LITERAL) {
                            idValue = new StringValue(t.currentTokenValue);
                        } else if (t.currentToken == Tokenizer.DOLLAR) {
                            nextToken();
                            expect(Tokenizer.NAME);
                            int varNameCode = makeNameCode(t.currentTokenValue, false) & 0xfffff;
                            idValue = new VariableReference(env.bindVariable(varNameCode));
                        } else {
                            grumble("id value must be either a literal or a variable reference");
                        }
                        pat = new IDPattern(idValue);
                        nextToken();
                        expect(Tokenizer.RPAR);
                        nextToken();
                    } else if (t.currentTokenValue.equals("key")) {
                        nextToken();
                        expect(Tokenizer.STRING_LITERAL);
                        String keyname = t.currentTokenValue;
                        nextToken();
                        expect(Tokenizer.COMMA);
                        nextToken();
                        Expression idValue = null;
                        if (t.currentToken == Tokenizer.STRING_LITERAL) {
                            idValue = new StringValue(t.currentTokenValue);
                        } else if (t.currentToken == Tokenizer.DOLLAR) {
                            nextToken();
                            expect(Tokenizer.NAME);
                            int varNameCode = makeNameCode(t.currentTokenValue, false) & 0xfffff;
                            idValue = new VariableReference(env.bindVariable(varNameCode));
                        } else {
                            grumble("key value must be either a literal or a variable reference");
                        }
                        pat = new KeyPattern(makeNameCode(keyname, false),
                        						idValue);
                        nextToken();
                        expect(Tokenizer.RPAR);
                        nextToken();
                    } else {
                        grumble("The only functions allowed in a pattern are id() and key()");
                    }
                    break;

                default:
                    if (rootonly) {     // the pattern was plain '/'
                        return prev;
                    }
                    grumble("Unexpected token in pattern, found " + currentTokenDisplay());
            }

            if (prev != null) {
                if (connector==Tokenizer.SLASH) {
                     ((LocationPathPattern)pat).parentPattern = prev;
                } else {                        // connector == SLSL
                     ((LocationPathPattern)pat).ancestorPattern = prev;
                }
            }
            connector = t.currentToken;
            rootonly = false;
            if (connector == Tokenizer.SLASH || connector == Tokenizer.SLSL) {
                prev = pat;
                nextToken();
            } else {
                return pat;
            }
        }
    }

    /**
     * Parse a pattern step (after any axis name or @)
     *
     * @throws XPathException.Static if any error is encountered
     * @param principalNodeType is ELEMENT if we're on the child axis, ATTRIBUTE for
     *     the attribute axis
     * @return the pattern that results from parsing
     */

    private Pattern parsePatternStep(short principalNodeType) throws XPathException.Static {
        LocationPathPattern step = new LocationPathPattern();
        NodeTest test = parseNodeTest(principalNodeType);
        if (test instanceof AnyNodeTest) {
            // handle node() and @node() specially
            if (principalNodeType == Type.ELEMENT) {
                // this means we're on the CHILD axis
                test = new AnyChildNodePattern();
            } else {
                // we're on the attribute axis
                test = NodeKindTest.makeNodeKindTest(principalNodeType);
            }
        }

        // Deal with nonsense patterns such as @comment() or child::attribute(). These
        // are legal, but will never match anything.

        int kind = test.getNodeKind();
        if (principalNodeType == Type.ELEMENT &&
                (kind == Type.ATTRIBUTE || kind == Type.NAMESPACE)) {
            test = new NoNodeTest();
        } else if (principalNodeType == Type.ATTRIBUTE &&
                (kind == Type.COMMENT || kind == Type.TEXT ||
                kind == Type.PROCESSING_INSTRUCTION || kind == Type.ELEMENT ||
                kind == Type.DOCUMENT)) {
            test = new NoNodeTest();
        }

        step.nodeTest = test;
        parseFilters(step);
        return step;
    }

    /**
     * Test to see if there are filters for a Pattern, if so, parse them
     *
     * @param path the LocationPathPattern to which the filters are to be
     *     added
     * @throws XPathException.Static if any error is encountered
     */

    private void parseFilters(LocationPathPattern path) throws XPathException.Static {
        while (t.currentToken == Tokenizer.LSQB) {
            nextToken();
            Expression qual = parseExprSingle();
            expect(Tokenizer.RSQB);
            nextToken();
            path.addFilter(qual);
        }
    }

    // Helper methods to access the static context

    /**
     * Make a NameCode, using this Element as the context for namespace resolution
     *
     * @throws XPathException.Static if the name is invalid, or the prefix
     *     undeclared
     * @param qname The name as written, in the form "[prefix:]localname"
     * @param useDefault Defines the action when there is no prefix. If
     *      true, use the default namespace URI for element names. If false,
     *     use no namespace URI (as for attribute names).
     * @return the namecode, which can be used to identify this name in the
     *     name pool
     */

    public final int makeNameCode(String qname, boolean useDefault) throws XPathException.Static {
        if (scanOnly) {
            return -1;
        }
        try {
            String[] parts = Name.getQNameParts(qname);
            String prefix = parts[0];
            if (prefix.equals("")) {
                short uricode = 0;
                if (useDefault) {
                    uricode = env.getDefaultElementNamespace();
                }
                return env.getNamePool().allocate(prefix, uricode, qname);
            } else {
                try {
                    String uri = env.getURIForPrefix(prefix);
                    return env.getNamePool().allocate(prefix, uri, parts[1]);
                } catch (XPathException err) {
                    grumble(err.getMessage());
                    return -1;
                }
            }
        } catch (QNameException e) {
            //throw new XPathException.Static(e.getMessage());
            grumble(e.getMessage());
            return -1;
        }
    }

	/**
	 * Make a NameTest, using the static context for namespace resolution
	 *
	 * @param nodeType the type of node required (identified by a constant in
	 *     class Type)
	 * @param qname the lexical QName of the required node
	 * @param useDefault true if the default namespace should be used when
	 *     the QName is unprefixed
	 * @throws XPathException.Static if the QName is invalid
	 * @return a NameTest, representing a pattern that tests for a node of a
	 *     given node kind and a given name
	 */

	public NameTest makeNameTest(short nodeType, String qname, boolean useDefault)
		    throws XPathException.Static {
        int nameCode = makeNameCode(qname, useDefault);
		NameTest nt = new NameTest(nodeType, nameCode);
		nt.setOriginalText(qname);
		return nt;
	}

	/**
	 * Make a NamespaceTest (name:*)
	 *
	 * @param nodeType integer code identifying the type of node required
	 * @param prefix the namespace prefix
	 * @throws XPathException.Static if the namespace prefix is not declared
	 * @return the NamespaceTest, a pattern that matches all nodes in this
	 *     namespace
	 */

	public NamespaceTest makeNamespaceTest(short nodeType, String prefix)
			throws XPathException.Static {
        if (scanOnly) {
            // return an arbitrary namespace if we're only doing a syntax check
            return new NamespaceTest(env.getNamePool(), nodeType, NamespaceConstant.SAXON);
        }

        try {
            NamespaceTest nt = new NamespaceTest(env.getNamePool(), nodeType, env.getURIForPrefix(prefix));
            nt.setOriginalText(prefix + ":*");
            return nt;
        } catch (XPathException e) {
            // env.getURIForPrefix can return a dynamic error
            grumble(e.getMessage());
            return null;
        }
    }

	/**
	 * Make a LocalNameTest (*:name)
	 *
	 * @param nodeType the kind of node to be matched
	 * @param localName the requred local name
	 * @throws XPathException.Static if the local name is invalid
	 * @return a LocalNameTest, a pattern which matches all nodes of a given
	 *     local name, regardless of namespace
	 */

	public LocalNameTest makeLocalNameTest(short nodeType, String localName)
			throws XPathException.Static {
        if (!XMLChar.isValidNCName(localName)) {
            grumble("Local name [" + localName + "] contains invalid characters");
        }
		return new LocalNameTest(env.getNamePool(), nodeType, localName);
    }

    /**
     * Set location information on an expression. At present this consists of a simple
     * line number. Needed mainly for XQuery.
     */

    protected void setLocation(Expression exp) {
        if (exp instanceof ComputedExpression) {
            ((ComputedExpression)exp).setLineNumber((short)t.getLineNumber());
        }
        if (exp instanceof Instruction) {
            ((Instruction)exp).setSourceLocation(0, t.getLineNumber());
            ((Instruction)exp).setExecutable(getExecutable());
        }
    }

    /**
     * Set location information on an expression. At present this consists of a simple
     * line number. Needed mainly for XQuery. This version of the method supplies an
     * explicit line number.
     */

    protected void setLocation(Expression exp, int line, Executable executable) {
        if (exp instanceof ComputedExpression) {
            ((ComputedExpression)exp).setLineNumber((short)line);
        }
        if (exp instanceof Instruction) {
            ((Instruction)exp).setSourceLocation(0, line);
        }
    }

    /**
     * Get the executable containing this expression. Returns null for XPath: needed only for XQuery
     */

    public Executable getExecutable() {
        return null;
    }

    /**
     * Create a SourceLocator for use in an exception
     */

    protected SourceLocator makeLocator() {
        ExpressionLocation loc = new ExpressionLocation();
        loc.setLineNumber((short)t.getLineNumber());
        return loc;
    }

    /**
     * Test whether the current token is a given keyword.
     * @param s     The string to be compared with the current token
     * @return true if they are the same
     */

    protected boolean isKeyword(String s) {
        return (t.currentToken == Tokenizer.NAME && t.currentTokenValue.equals(s));
    }

    public void setScanOnly(boolean scanOnly) {
        this.scanOnly = scanOnly;
    }

    public static class ForClause {

        public RangeVariableDeclaration rangeVariable;
        public RangeVariableDeclaration positionVariable;
        public Expression sequence;
        public int lineNumber;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
