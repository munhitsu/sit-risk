package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.SequenceType;

/**
* TypeExpression: superclass for expressions involving a source expression and a type
*/

public abstract class TypeExpression extends ComputedExpression {

    protected Expression source;

    protected TypeExpression(){};

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        source = source.promote(offer);
        return this;
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[1];
        exp[0] = source;
        return exp;
    }

    /**
    * Determine the static cardinality
    */

    public int computeCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
