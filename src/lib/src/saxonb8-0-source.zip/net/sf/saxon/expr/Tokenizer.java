package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.functions.NormalizeSpace;

import java.util.HashMap;

/**
 * Tokenizer for expressions and inputs.
 *
 * This code was originally derived from James Clark's xt, though it has been greatly modified since.
 * See copyright notice at end of file.
 */


public final class Tokenizer {

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
        if (state==DEFAULT_STATE) {
            // force the followsOperator() test to return true
            precedingToken = UNKNOWN;
            currentToken = UNKNOWN;
        } else if (state==OPERATOR_STATE) {
            precedingToken = RPAR;
            currentToken = RPAR;
        }
    }

    private int state = DEFAULT_STATE;
        // we may need to make this a stack at some time

    /**
     * Initial default state of the Tokenizer
     */
    public static final int DEFAULT_STATE = 0;

    /**
     * State in which a name is NOT to be merged with what comes next, for example "("
     */
    public static final int BARE_NAME_STATE = 1;

    /**
     * State in which the next thing to be read is a SequenceType
     */
    public static final int SEQUENCE_TYPE_STATE = 2;
    /**
     * State in which the next thing to be read is an operator
     */

    public static final int OPERATOR_STATE = 3;

    /**
     * Token numbers. Those in the range 0 to 100 are tokens that can be followed
     * by a name or expression; those in the range 101 to 200 are tokens that can be
     * followed by an binary operator.
     */
    /**
     * Pseudo-token representing the start of the expression
     */
    public static final int UNKNOWN = -1;

    // Tokens that set "name" context, so an immediately following "div" is recognized
    // as an element name, not as an operator

    /**
     * Pseudo-token representing the end of the expression
     */
    public static final int EOF = 0;
    /**
     * "union" or "|" token
     */
    public static final int UNION = 1;
    /**
     * Forwards "/"
     */
    public static final int SLASH = 2;
    /**
     * At token, "@"
     */
    public static final int AT = 3;
    /**
     * Left square bracket
     */
    public static final int LSQB = 4;
    /**
     * Left parenthesis
     */
    public static final int LPAR = 5;
    /**
     * Equals token ("=")
     */
    public static final int EQUALS = 6;
    /**
     * Comma token
     */
    public static final int COMMA = 7;
    /**
     * Double forwards slash, "//"
     */
    public static final int SLSL = 8;
    /**
     * Operator "or"
     */
    public static final int OR = 9;
    /**
     * Operator "and"
     */
    public static final int AND = 10;
    /**
     * Operator ">"
     */
    public static final int GT = 11;
    /**
     * Operator "<"
     */
    public static final int LT = 12;
    /**
     * Operator ">="
     */
    public static final int GE = 13;
    /**
     * Operator "<="
     */
    public static final int LE = 14;
    /**
     * Operator "+"
     */
    public static final int PLUS = 15;
    /**
     * Binary minus operator
     */
    public static final int MINUS = 16;
    /**
     * Multiply operator, "*" when used in an operator context
     */
    public static final int MULT = 17;
    /**
     * Operator "div"
     */
    public static final int DIV = 18;
    /**
     * Operator "mod"
     */
    public static final int MOD = 19;
    /**
     * Operator "is"
     */
    public static final int IS = 20;
    /**
     * "$" symbol
     */
    public static final int DOLLAR = 21;
    /**
     * Operator "!="
     */
    public static final int NE = 22;
    /**
     * Operator "intersect"
     */
    public static final int INTERSECT = 23;
    /**
     * Operator "except"
     */
    public static final int EXCEPT = 24;
    /**
     * Keyword "return"
     */
    public static final int RETURN = 25;
    /**
     * Ketword "then"
     */
    public static final int THEN = 26;
    /**
     * Keyword "else"
     */
    public static final int ELSE = 27;
    /**
     * Keyword "where"
     */
    public static final int WHERE = 28;
    /**
     * Operator "to"
     */
    public static final int TO = 29;
    /**
     * Keyword "in"
     */
    public static final int IN = 30;
    /**
     * Keyword "some"
     */
    public static final int SOME = 31;
    /**
     * Keyword "every"
     */
    public static final int EVERY = 32;
    /**
     * Keyword "satisfies"
     */
    public static final int SATISFIES = 33;
    /**
     * Token representing the name of a function and the following "(" symbol
     */
    public static final int FUNCTION = 34;
    /**
     * Token representing the name of an axis and the following "::" symbol
     */
    public static final int AXIS = 35;
    /**
     * Keyword "if"
     */
    public static final int IF = 36;
    /**
     * Operator "<<"
     */
    public static final int PRECEDES = 37;
    /**
     * Operator ">>"
     */
    public static final int FOLLOWS = 38;
    /**
     * "::" symbol
     */
    public static final int COLONCOLON = 39;
    /**
     * ":*" symbol
     */
    public static final int COLONSTAR = 40;
    /**
     * operator "instance of"
     */
    public static final int INSTANCE_OF = 41;
    /**
     * operator "cast as"
     */
    public static final int CAST_AS = 42;
    /**
     * operator "treat as"
     */
    public static final int TREAT_AS = 43;
    /**
     * operator "eq"
     */
    public static final int FEQ = 44;       // "Fortran" style comparison operators eq, ne, etc
    /**
     * operator "ne"
     */
    public static final int FNE = 45;
    /**
     * operator "gt"
     */
    public static final int FGT = 46;
    /**
     * operator "lt"
     */
    public static final int FLT = 47;
    /**
     * operator "ge"
     */
    public static final int FGE = 48;
    /**
     * opeartor "le"
     */
    public static final int FLE = 49;
    /**
     * operator "idiv"
     */
    public static final int IDIV = 50;
    /**
     * operator "castable as"
     */
    public static final int CASTABLE_AS = 51;
    /**
      * ":=" symbol (XQuery only)
      */
    public static final int ASSIGN = 52;
    /**
     * "{" symbol (XQuery only)
     */
    public static final int LCURLY = 53;
    /**
     * composite token: <keyword "{"> (XQuery only)
     */
    public static final int KEYWORD_CURLY = 54;
    /**
     * composite token <'element' QNAME> (XQuery only)
     */
    public static final int ELEMENT_QNAME = 55;
    /**
     * composite token <'attribute' QNAME> (XQuery only)
     */
    public static final int ATTRIBUTE_QNAME = 56;
    /**
     * composite token <'pi' QNAME> (XQuery only)
     */
    public static final int PI_QNAME = 57;
    /**
     * Keyword "typeswitch"
     */
    public static final int TYPESWITCH = 58;
    /**
     * Keyword "case"
     */
    public static final int CASE = 59;
    /**
     * Keyword "default"
     */
    public static final int DEFAULT = 60;


    // The following tokens are used only in the query prolog. They are categorized
    // as operators on the basis that a following name is treated as a name rather than
    // an operator.


    /**
     * "xquery version"
     */
    public static final int XQUERY_VERSION = 70;
    /**
     * "declare namespace"
     */
    public static final int DECLARE_NAMESPACE = 71;
    /**
     * "declare default"
     */
    public static final int DECLARE_DEFAULT = 72;
    /**
     * "declare validation"
     */
    public static final int DECLARE_VALIDATION = 73;
    /**
     * "declare base-uri"
     */
    public static final int DECLARE_BASEURI = 74;
    /**
     * "declare xmlspace"
     */
    public static final int DECLARE_XMLSPACE = 75;
    /**
     * "import schema"
     */
    public static final int IMPORT_SCHEMA = 76;
    /**
     * "import module"
     */
    public static final int IMPORT_MODULE = 77;
    /**
     * "define variable"
     */
    public static final int DECLARE_VARIABLE = 78;
    /**
     * "define function"
     */
    public static final int DECLARE_FUNCTION = 79;
    /**
     * "module namespace"
     */
    public static final int MODULE_NAMESPACE = 80;
    /**
     * Various compound symbols supporting XQuery validation expression
     */
    public static final int VALIDATE = 81;
    public static final int VALIDATE_STRICT = 82;
    public static final int VALIDATE_LAX = 83;
    public static final int VALIDATE_SKIP = 84;
    public static final int VALIDATE_GLOBAL = 85;
    public static final int VALIDATE_CONTEXT = 86;

    /**
     * semicolon separator
     */
    public static final int SEMICOLON = 90;


    /**
     * Constant identifying the token number of the last token to be classified as an operator
     */
    static int LAST_OPERATOR = 100;

    // Tokens that set "operator" context, so an immediately following "div" is recognized
    // as an operator, not as an element name

    /**
     * Name token (a QName, in general)
     */
    public static final int NAME = 101;
    /**
     * String literal
     */
    public static final int STRING_LITERAL = 102;
    /**
     * Right square bracket
     */
    public static final int RSQB = 103;
    /**
     * Right parenthesis
     */
    public static final int RPAR = 104;
    /**
     * "." symbol
     */
    public static final int DOT = 105;
    /**
     * ".." symbol
     */
    public static final int DOTDOT = 106;
    /**
     * "*" symbol when used as a wildcard
     */
    public static final int STAR = 107;
    /**
     * "prefix:*" token
     */
    public static final int PREFIX = 108;    // e.g. prefix:*
    /**
     * Numeric literal
     */
    public static final int NUMBER = 109;
    /**
     * Node kind, e.g. "node()" or "comment()"
     */
    public static final int NODEKIND = 110;
    /**
     * "for" keyword
     */
    public static final int FOR = 111;
    /**
     * "*:local-name" token
     */
    public static final int SUFFIX = 112;    // e.g. *:suffix
    /**
     * "?" symbol
     */
    public static final int QMARK = 113;
    /**
     * "type("
     */
    public static final int TYPETEST = 114;
    /**
     * "}" symbol (XQuery only)
     */
    public static final int RCURLY = 115;
    /**
     * "let" keyword (XQuery only)
     */
    public static final int LET = 116;
    /**
     * "<" at the start of a tag (XQuery only). The pseudo-XML syntax that
     * follows is read character-by-character by the XQuery parser
     */
    public static final int TAG = 117;

    /**
     * Unary minus sign
     */
    public static final int NEGATE = 199;    // unary minus: not actually a token, but we
                                             // use token numbers to identify operators.


    /**
     * The following strings are used to represent tokens in error messages
     */

    public static String[] tokens = new String[200];
    static {
        tokens [ EOF ] = "<eof>";
        tokens [ UNION ] = "|";
        tokens [ SLASH ] = "/";
        tokens [ AT ] = "@";
        tokens [ LSQB ] = "[";
        tokens [ LPAR ] = "(";
        tokens [ EQUALS ] = "=";
        tokens [ COMMA ] = ",";
        tokens [ SLSL ] = "//";
        tokens [ OR ] = "or";
        tokens [ AND ] = "and";
        tokens [ GT ] = ">";
        tokens [ LT ] = "<";
        tokens [ GE ] = ">=";
        tokens [ LE ] = "<=";
        tokens [ PLUS ] = "+";
        tokens [ MINUS ] = "-";
        tokens [ MULT ] = "*";
        tokens [ DIV ] = "div";
        tokens [ MOD ] = "mod";
        tokens [ IS ] = "is";
        tokens [ DOLLAR ] = "$";
        tokens [ NE ] = "!=";
        tokens [ INTERSECT ] = "intersect";
        tokens [ EXCEPT ] = "except";
        tokens [ RETURN ] = "return";
        tokens [ THEN ] = "then";
        tokens [ ELSE ] = "else";
        //tokens [ ISNOT ] = "isnot";
        tokens [ TO ] = "to";
        tokens [ IN ] = "in";
        tokens [ SOME ] = "some";
        tokens [ EVERY ] = "every";
        tokens [ SATISFIES ] = "satisfies";
        tokens [ FUNCTION ] = "<function>(";
        tokens [ AXIS ] = "<axis>";
        tokens [ IF ] = "if(";
        tokens [ PRECEDES ] = "<<";
        tokens [ FOLLOWS ] = ">>";
        tokens [ COLONCOLON ] = "::";
        tokens [ COLONSTAR ] = ":*";
        tokens [ INSTANCE_OF ] = "instance of";
        tokens [ CAST_AS ] = "cast as";
        tokens [ TREAT_AS ] = "treat as";
        tokens [ FEQ ] = "eq";
        tokens [ FNE ] = "ne";
        tokens [ FGT ] = "gt";
        tokens [ FGE ] = "ge";
        tokens [ FLT ] = "lt";
        tokens [ FLE ] = "le";
        tokens [ IDIV ] = "idiv";
        tokens [ CASTABLE_AS ] = "castable as";
        tokens [ ASSIGN ] = ":=";
        tokens [ TYPESWITCH ] = "typeswitch";
        tokens [ CASE ] = "case";
        tokens [ DEFAULT ] = "default";


        tokens [ NAME ] = "<name>";
        tokens [ STRING_LITERAL ] = "<string-literal>";
        tokens [ RSQB ] = "]";
        tokens [ RPAR ] = ")";
        tokens [ DOT ] = ".";
        tokens [ DOTDOT ] = "..";
        tokens [ STAR ] = "*";
        tokens [ PREFIX ] = "<prefix:*>";
        tokens [ NUMBER ] = "<numeric-literal>";
        tokens [ NODEKIND ] = "<node-type>()";
        tokens [ FOR ] = "for";
        tokens [ SUFFIX ] = "<*:local-name>";
        tokens [ QMARK ] = "?";
        tokens [ TYPETEST ] = "type(";
        tokens [ LCURLY ] = "{";
        tokens [ KEYWORD_CURLY ] = "<keyword> {";
        tokens [ RCURLY ] = "}";
        tokens [ LET ] = "let";
        tokens [ VALIDATE ] = "validate {";

        tokens [ SEMICOLON ] = ";";
        tokens [ NEGATE ] = "-";
    }

    /**
     * Lookup table for composite (two-keyword) tokens
     */
    public static HashMap doubleKeywords = new HashMap(30);
    static {
        mapDouble("instance of", INSTANCE_OF);
        mapDouble("cast as", (CAST_AS));
        mapDouble("treat as", (TREAT_AS));
        mapDouble("castable as", (CASTABLE_AS));
        mapDouble("xquery version", (XQUERY_VERSION));
        mapDouble("declare namespace", (DECLARE_NAMESPACE));
        mapDouble("declare default", (DECLARE_DEFAULT));
        mapDouble("declare validation", (DECLARE_VALIDATION));
        mapDouble("declare base-uri", (DECLARE_BASEURI));
        mapDouble("declare xmlspace", (DECLARE_XMLSPACE));
        mapDouble("import schema", (IMPORT_SCHEMA));
        mapDouble("import module", (IMPORT_MODULE));
        mapDouble("declare variable", (DECLARE_VARIABLE));
        mapDouble("declare function", (DECLARE_FUNCTION));
        mapDouble("module namespace", (MODULE_NAMESPACE));
        mapDouble("validate strict", VALIDATE_STRICT);
        mapDouble("validate lax", VALIDATE_LAX);
        mapDouble("validate skip", VALIDATE_SKIP);
        mapDouble("validate global", VALIDATE_GLOBAL);
        mapDouble("validate context", VALIDATE_CONTEXT);

    }

    private static void mapDouble(String doubleKeyword, int token) {
        doubleKeywords.put(doubleKeyword, new Integer(token));
        tokens[token] = doubleKeyword;
    }
    /**
     * The number identifying the most recently read token
     */
    public int currentToken = EOF;
    /**
     * The string value of the most recently read token
     */
    public String currentTokenValue = null;
    /**
     * The position in the input expression where the current token starts
     */
    public int currentTokenStartIndex = 0;
    /**
     * The number of the next token to be returned
     */
    private int nextToken = EOF;
    /**
     * The string value of the next token to be returned
     */
    private String nextTokenValue = null;
    /**
     * The position in the expression of the start of the next token
     */
    private int nextTokenStartIndex = 0;
    /**
     * The string being parsed
     */
    public String input;
    /**
     * The current position within the input string
     */
    public int inputIndex = 0;
    /**
     * The length of the input string
     */
    private int inputLength;
    /**
     * The line number (within the expression) of the current token
     */
    private int lineNumber = 1;
    /**
     * The line number (within the expression) of the next token
     */
    private int nextLineNumber = 1;


    /**
     * The token number of the token that preceded the current token
     */
    private int precedingToken = UNKNOWN;


    public boolean recognizePragmas = false;
    public String lastPragma = null;

    //
    // Lexical analyser for expressions, queries, and XSLT patterns
    //

    /**
     * Prepare a string for tokenization.
     * The actual tokens are obtained by calls on next()
     *
     * @param input the string to be tokenized
     * @param start start point within the string
     * @param end end point within the string (last character not read):
     * -1 means end of string
     * @exception XPathException.Static if a lexical error occurs, e.g. unmatched
     *     string quotes
     */
    public void tokenize(String input, int start, int end) throws XPathException.Static {
        nextToken = EOF;
        nextTokenValue = null;
        nextTokenStartIndex = 0;
        inputIndex = start;
        this.input = input;
        if (end==-1) {
            this.inputLength = input.length();
        } else {
            this.inputLength = end;
        }

        // The tokenizer actually reads one token ahead. The raw lexical analysis performed by
        // the lookAhead() method does not (in general) distinguish names used as QNames from names
        // used for operators, axes, and functions. The next() routine further refines names into the
        // correct category, by looking at the following token. In addition, it combines compound tokens
        // such as "instance of" and "cast as".

        lookAhead();
        next();
    }

    //diagnostic version of next(): change real version to realnext()
    //
    //public void next() throws XPathException {
    //    realnext();
    //    System.err.println("Token: " + currentToken + "[" + tokens[currentToken] + "]");
    //}

    /**
     * Get the next token from the input expression. The type of token is returned in the
     * currentToken variable, the string value of the token in currentTokenValue.
     *
     * @exception XPathException.Static if a lexical error is detected
     */

    public void next() throws XPathException.Static {
        precedingToken = currentToken;
        currentToken = nextToken;
        currentTokenValue = nextTokenValue;
        if (currentTokenValue==null) {
            currentTokenValue="";
        }
        currentTokenStartIndex = nextTokenStartIndex;
        lineNumber = nextLineNumber;

        // disambiguate the current token based on the tokenizer state

        switch (currentToken) {
            case NAME:
                int optype = getBinaryOp(currentTokenValue);
                if (optype!=UNKNOWN && !followsOperator()) {
                    currentToken = optype;
                }
                break;
            case LT:
                if (followsOperator()) {
                    currentToken = TAG;
                }
                break;
            case STAR:
                if (!followsOperator()) {
                    currentToken = MULT;
                }
                break;
        }

        if (currentToken == TAG || currentToken == RCURLY) {
            // No lookahead after encountering "<" at the start of an XML-like tag.
            // After an RCURLY, the parser must do an explicit lookahead() to continue
            // tokenizing; otherwise it can continue with direct character reading
            return;
        }

        lookAhead();

        if (currentToken == NAME) {
            if (state == BARE_NAME_STATE) {
                return;
            }
            switch (nextToken) {
                case LPAR:
                    int op = getBinaryOp(currentTokenValue);
                    if (op != UNKNOWN) {
                        currentToken = op;
                    } else {
	                    currentToken = getFunctionType(currentTokenValue);
	                    lookAhead();    // swallow the "("
                    }
                    break;

                case LCURLY:
                    if (!(state == SEQUENCE_TYPE_STATE)) {
                        currentToken = KEYWORD_CURLY;
                        lookAhead();        // swallow the "{"
                    }
                    break;

                case COLONCOLON:
                    lookAhead();
                    currentToken = AXIS;
                    break;

                case COLONSTAR:
                    lookAhead();
                    currentToken = PREFIX;
                    break;

                case DOLLAR:
                    if (currentTokenValue=="for") {
                        currentToken = FOR;
                    } else if (currentTokenValue=="some") {
                        currentToken = SOME;
                    } else if (currentTokenValue=="every") {
                        currentToken = EVERY;
                    } else if (currentTokenValue=="let") {
                        currentToken = LET;
                    }
                    break;

                case NAME:
                    int candidate = -1;
                    if (currentTokenValue.equals("element")) {
                        candidate = ELEMENT_QNAME;
                    } else if (currentTokenValue.equals("attribute")) {
                        candidate = ATTRIBUTE_QNAME;
                    } else if (currentTokenValue.equals("processing-instruction")) {
                        candidate = PI_QNAME;
                    }
                    if (candidate != -1) {
                        // <'element' QName '{'> constructor
                        // <'attribute' QName '{'> constructor
                        // <'processing-instruction' QName '{'> constructor

                        String qname = nextTokenValue;
                        String saveTokenValue = currentTokenValue;
                        int savePosition = inputIndex;
                        lookAhead();
                        if (nextToken == LCURLY) {
                            currentToken = candidate;
                            currentTokenValue = qname;
                            lookAhead();
                            return;
                        } else {
                            // backtrack (we don't have 2-token lookahead; this is the
                            // only case where it's needed. So we backtrack instead.)
                            currentToken = NAME;
                            currentTokenValue = saveTokenValue;
                            inputIndex = savePosition;
                            nextToken = NAME;
                            nextTokenValue = qname;
                        }

                    }
                    String composite = currentTokenValue + " " + nextTokenValue;
                    Integer val = (Integer)doubleKeywords.get(composite);
                    if (val==null) {
                        break;
                    } else {
                        currentToken = val.intValue();
                        currentTokenValue = composite;
                        lookAhead();
                        return;
                    }
                default:
                    // no action needed
            }
        }
    }

    /**
     * Force the current token to be treated as an operator if possible
     */

    public void treatCurrentAsOperator() {
        switch (currentToken) {
            case NAME:
                int optype = getBinaryOp(currentTokenValue);
                if (optype!=UNKNOWN) {
                    currentToken = optype;
                }
                break;
            case STAR:
                currentToken = MULT;
                break;
        }
    }

    /**
     * Look ahead by one token. This method does the real tokenization work.
     * The method is normally called internally, but the XQuery parser also
     * calls it to resume normal tokenization after dealing with pseudo-XML
     * syntax.
     * @exception XPathException.Static if a lexical error occurs
     */
    public void lookAhead() throws XPathException.Static {
        precedingToken = nextToken;
        nextTokenValue = null;
        nextTokenStartIndex = inputIndex;
        for (;;) {
            if (inputIndex >= inputLength) {
	            nextToken = EOF;
	            return;
            }
            char c = input.charAt(inputIndex++);
            switch (c) {
            case '/':
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '/') {
	                inputIndex++;
	                nextToken = SLSL;
	                return;
	            }
	            nextToken = SLASH;
	            return;
            case ':':
	            if (inputIndex < inputLength) {
	                if (input.charAt(inputIndex) == ':') {
	                    inputIndex++;
	                    nextToken = COLONCOLON;
	                    return;
	                } else if (input.charAt(inputIndex) == '=') {
                        nextToken = ASSIGN;
                        inputIndex++;
                        return;
                    }
	            }
	            throw new XPathException.Static("Unexpected colon at start of token");
            case '@':
	            nextToken = AT;
	            return;
	        case '?':
	            nextToken = QMARK;
	            return;
            case '[':
	            nextToken = LSQB;
	            return;
            case ']':
	            nextToken = RSQB;
	            return;
            case '{':
	            nextToken = LCURLY;
	            return;
            case '}':
	            nextToken = RCURLY;
	            return;
            case ';':
                nextToken = SEMICOLON;
                state = DEFAULT_STATE;
                return;
            case '(':
	            if (inputIndex < inputLength && input.charAt(inputIndex) == ':') {
                    // XPath comment syntax is (: .... :)
                    // Comments may be nested
                    // Pragmas are recognized as anything starting with "(::", in which case the terminator
                    // must be "::)"
                    inputIndex++;
                    int pragmaStart = -1;
                    if (recognizePragmas && inputIndex < inputLength && input.charAt(inputIndex) == ':') {
                        inputIndex++;
                        pragmaStart = inputIndex;
                    }
                    int nestingDepth = 1;
                    while (nestingDepth > 0 && inputIndex < (inputLength-1)) {
                        if (input.charAt(inputIndex) == '\n') {
                            nextLineNumber++;
                        } else if (input.charAt(inputIndex) == ':' &&
                               input.charAt(inputIndex+1) == ')') {
                            if (pragmaStart >=0 && nestingDepth==1) {
                                if (input.charAt(inputIndex-1) == ':') {
                                    lastPragma = input.substring(pragmaStart, inputIndex-1).trim();
                                    if (lastPragma.startsWith("extension")) {
                                        inputIndex+=2;
                                        throw new XPathException.Static("Unrecognized must-understand extension");
                                    } else if (lastPragma.startsWith("pragma")) {
                                        lastPragma = lastPragma.substring(6).trim();
                                    } else {
                                        inputIndex+=2;
                                        throw new XPathException.Static("'(::' must be followed by 'pragma' or 'extension'");
                                    }
                                    nestingDepth--;
                                    inputIndex++;
                                }
                            } else {
                                nestingDepth--;
                                inputIndex++;
                            }
                        } else if (input.charAt(inputIndex) == '(' &&
                               input.charAt(inputIndex+1) == ':') {
                            nestingDepth++;
                            inputIndex++;
                        }
                        inputIndex++;
                    }
                    if (nestingDepth > 0) {
                        if (pragmaStart >= 0) {
                            throw new XPathException.Static("Unclosed XQuery pragma");
                        } else {
                            throw new XPathException.Static("Unclosed XPath comment");
                        }
                    }
                    lookAhead();
                } else {
	                nextToken = LPAR;
	            }
	            return;
            case ')':
	            nextToken = RPAR;
	            return;
            case '+':
	            nextToken = PLUS;
	            return;
            case '-':
	            nextToken = MINUS;   // not detected if part of a name
	            return;
            case '=':
	            nextToken = EQUALS;
	            return;
            case '!':
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '=') {
	                inputIndex++;
	                nextToken = NE;
	                return;
	            }
	            throw new XPathException.Static("'!' without '='");
            case '*':
                // disambiguation of MULT and STAR is now done later
                //if (followsOperator()) {
                    if (inputIndex < inputLength
	                        && input.charAt(inputIndex) == ':') {
    	                inputIndex++;
    	                nextToken = SUFFIX;
    	                // we leave the parser to get the following name as a separate
    	                // token, but first check there's no intervening white space
    	                if (inputIndex < inputLength) {
    	                    char ahead = input.charAt(inputIndex);
    	                    if (" \r\t\n".indexOf(ahead) >= 0) {
    	                        throw new XPathException.Static("Whitespace is not allowed after '*:'");
    	                    }
    	                }
    	                return;
	                }
	                nextToken = STAR;
                //} else {
                //    nextToken = MULT;
                //}
	            return;
            case ',':
	            nextToken = COMMA;
	            return;
            case '$':
	            nextToken = DOLLAR;
	            return;
            case '|':
	            nextToken = UNION;
	            return;
            case '<':
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '=') {
	                inputIndex++;
	                nextToken = LE;
	                return;
	            }
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '<') {
	                inputIndex++;
	                nextToken = PRECEDES;
	                return;
	            }
	            nextToken = LT;
	            return;
            case '>':
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '=') {
	                inputIndex++;
	                nextToken = GE;
	                return;
	            }
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '>') {
	                inputIndex++;
	                nextToken = FOLLOWS;
	                return;
	            }
	            nextToken = GT;
	            return;
            case '.':
	            if (inputIndex < inputLength
	                    && input.charAt(inputIndex) == '.') {
	                inputIndex++;
	                nextToken = DOTDOT;
	                return;
	            }
	            if (inputIndex == inputLength
	                    || input.charAt(inputIndex) < '0'
	                    || input.charAt(inputIndex) > '9') {
	                nextToken = DOT;
	                return;
	            }
                // otherwise drop through: we have a number starting with a decimal point
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                // The logic here can return some tokens that are not legitimate numbers,
                // for example "23e" or "1.0e+". However, this will only happen if the XPath
                // expression as a whole is syntactically incorrect.
                // These errors will be caught by the numeric constructor.
                boolean allowE = true;
                boolean allowSign = false;
                boolean allowDot = true;
                boolean endOfNum = false;
            numloop:
                while (!endOfNum) {
	                switch (c) {
                        case '0': case '1': case '2': case '3': case '4':
                        case '5': case '6': case '7': case '8': case '9':
                            allowSign = false;
                            break;
                        case '.':
                            if (allowDot) {
                                allowDot = false;
                                allowSign = false;
                            } else {
                                inputIndex--;
                                break numloop;
                            }
                            break;
                        case 'E': case 'e':
                            if (allowE) {
                                allowSign = true;
                                allowE = false;
                            } else {
                                inputIndex--;
                                break numloop;
                            }
                            break;
                        case '+': case '-':
                            if (allowSign) {
                                allowSign = false;
                            } else {
                                inputIndex--;
                                break numloop;
                            }
                            break;
                        default:
                            inputIndex--;
                            break numloop;
                    }
                    if (inputIndex >= inputLength) break;
                    c = input.charAt(inputIndex++);
	            }
	            nextTokenValue = input.substring(nextTokenStartIndex, inputIndex);
	            nextToken = NUMBER;
	            return;
            case '"':
            case '\'':
                nextTokenValue = "";
                while (true) {
    	            inputIndex = input.indexOf(c, inputIndex);
    	            if (inputIndex < 0) {
    	                inputIndex = nextTokenStartIndex + 1;
    	                throw new XPathException.Static("Unmatched quote in expression");
    	            }
    	            nextTokenValue += input.substring(nextTokenStartIndex + 1, inputIndex++);
    		        // look for doubled delimiters
    			    if (inputIndex < inputLength && input.charAt(inputIndex) == c) {
	                    nextTokenValue += c;
	                    nextTokenStartIndex = inputIndex;
	                    inputIndex++;
	                } else {
	                    break;
	                }
	            }

                // maintain line number if there are newlines in the string
                if (nextTokenValue.indexOf('\n') >= 0) {
                    for (int i = 0; i<nextTokenValue.length(); i++) {
                        if (nextTokenValue.charAt(i) == '\n') {
                            lineNumber++;
                        }
                    }
                }
	            nextTokenValue = nextTokenValue.intern();
	            nextToken = STRING_LITERAL;
	            return;
            case '\n':
                nextLineNumber++;
                // drop through
            case ' ':
            case '\t':
            case '\r':
	            nextTokenStartIndex = inputIndex;
	            break;
            default:
	            if (c < 0x80 && !Character.isLetter(c)) {
	                throw new XPathException.Static("Invalid character '" + c + "' in expression");
                }
                /* fall through */
            case '_':
            loop:
	            for (;inputIndex < inputLength; inputIndex++) {
	                c = input.charAt(inputIndex);
	                switch (c) {
                    case ':':
        	            if (inputIndex+1 < inputLength) {
    	                    char nc = input.charAt(inputIndex+1);
                            if (nc == ':') {
                                nextTokenValue = input.substring(nextTokenStartIndex,
                                                                inputIndex).intern();
                                nextToken = AXIS;
                                inputIndex+=2;
                                return;
        	                } else if (nc == '*') {
                                nextTokenValue = input.substring(nextTokenStartIndex,
                                                                inputIndex).intern();
                                nextToken = PREFIX;
                                inputIndex+=2;
                                return;
                            } else if (nc == '=') {
                                // as in "let $x:=2"
                                nextTokenValue = input.substring(nextTokenStartIndex,
                                                                inputIndex).intern();
                                nextToken = NAME;
                                return;
                            }
        	            }
                        break;
	                case '.':
	                case '-':
	                case '_':
	                    break;

	                default:
	                    if (c < 0x80 && !Character.isLetterOrDigit(c))
	                        break loop;
	                    break;
	                }
	            }
	            nextTokenValue = input.substring(nextTokenStartIndex,
					                                    inputIndex).intern();
                nextToken = NAME;
	            return;
            }
        }
    }

    /**
     * Identify a binary operator
     *
     * @param s String representation of the operator - must be interned
     * @return the token number of the operator, or UNKNOWN if it is not a
     *     known operator
     */

    static private int getBinaryOp(String s) {
        switch(s.length()) {
            case 2:
                if (s=="or") return OR;
                if (s=="is") return IS;
                if (s=="to") return TO;
                if (s=="in") return IN;
                if (s=="eq") return FEQ;
                if (s=="ne") return FNE;
                if (s=="gt") return FGT;
                if (s=="ge") return FGE;
                if (s=="lt") return FLT;
                if (s=="le") return FLE;
                break;
            case 3:
                if (s=="and") return AND;
                if (s=="div") return DIV;
                if (s=="mod") return MOD;
                break;
            case 4:
                if (s=="idiv") return IDIV;
                if (s=="then") return THEN;
                if (s=="else") return ELSE;
                if (s=="case") return CASE;
                break;
            case 5:
                if (s=="where") return WHERE;
                if (s=="union") return UNION;
                break;
            case 6:
                if (s=="except") return EXCEPT;
                if (s=="return") return RETURN;
                break;
            case 7:
                if (s=="default") return DEFAULT;
            case 9:
                if (s=="intersect") return INTERSECT;
                if (s=="satisfies") return SATISFIES;
                break;
        }
        return UNKNOWN;
    }

    /**
     * Distinguish nodekind names, "if", and function names, which are all
     * followed by a "("
     *
     * @param s the name - must be interned
     * @return the token number
     */

    static private int getFunctionType(String s) {
        switch(s.length()) {
            case 2:
                if (s=="if") return IF;
                break;
            case 4:
                if (s=="node") return NODEKIND;
                if (s=="item") return NODEKIND;
                if (s=="text") return NODEKIND;
                if (s=="type") return TYPETEST;
                break;
            case 7:
                if (s=="element") return NODEKIND;
                if (s=="comment") return NODEKIND;
                break;
            case 9:
                if (s=="attribute") return NODEKIND;
                if (s=="namespace") return NODEKIND;
                break;
            case 10:
                if (s=="typeswitch") return TYPESWITCH;
                break;
            default:
                if (s=="document-node") return NODEKIND;
                if (s=="schema-element") return NODEKIND;
                if (s=="schema-attribute") return NODEKIND;
                if (s=="processing-instruction") return NODEKIND;

                break;
        }
        return FUNCTION;
    }

    /**
     * Test whether the previous token is an operator
     *
     * @return true if the previous token is an operator token
     */

    private boolean followsOperator() {
        return precedingToken <= LAST_OPERATOR;
    }

    /**
     * Read next character directly. Used by the XQuery parser when parsing pseudo-XML
     * syntax
     * @return the next character from the input
     * @throws StringIndexOutOfBoundsException if an attempt is made to read beyond
     * the end of the string. This will only occur in the event of a syntax error in the
     * input.
     */

    public char nextChar() throws StringIndexOutOfBoundsException {
        char c = input.charAt(inputIndex++);
        if (c=='\n') {
            nextLineNumber++;
            lineNumber++;
        }
        return c;
    }

    /**
     * Step back one character
     */

    public void unreadChar() {
        if (input.charAt(--inputIndex) == '\n') {
            nextLineNumber--;
            lineNumber--;
        }
    }

    /**
     * Get the most recently read text (for use in an error message)
     */

    public String recentText() {
        if (inputIndex > inputLength) {
            inputIndex = inputLength;
        }
        if (inputIndex < 34) {
            return input.substring(0, inputIndex);
        } else {
            return NormalizeSpace.normalize(
                    "..." + input.substring(inputIndex-30, inputIndex));
        }
    }

    /**
     * Get the line number of the current token
     */

    public int getLineNumber() {
        return lineNumber;
    }

}

/*

The following copyright notice is copied from the licence for xt, from which the
original version of this module was derived:
--------------------------------------------------------------------------------
Copyright (c) 1998, 1999 James Clark

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED ``AS IS'', WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL JAMES CLARK BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of James Clark shall
not be used in advertising or otherwise to promote the sale, use or
other dealings in this Software without prior written authorization
from James Clark.
---------------------------------------------------------------------------
*/
