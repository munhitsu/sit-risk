package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.value.BooleanValue;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.DerivedAtomicValue;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.ItemType;

/**
* Castable Expression: implements "Expr castable as atomic-type?".
* The implementation simply wraps a cast expression with a try/catch.
*/

public final class CastableExpression extends ComputedExpression {

    Expression source;
    AtomicType targetType;
    boolean allowEmpty;

    public CastableExpression(Expression source, AtomicType target, boolean allowEmpty) {
        this.source = source;
        this.targetType = target;
        this.allowEmpty = allowEmpty;
    }

    /**
    * Simplify the expression
    * @return the simplified expression
    */

     public Expression simplify() throws XPathException {
        source = source.simplify();
        if (source instanceof Value) {
            try {
                return BooleanValue.get(effectiveBooleanValue(null));
            } catch (XPathException e) {
                throw new XPathException.Static(e);
                // Cannot happen
            }
        }
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        source = source.analyze(env);
        SequenceType atomicType =
                new SequenceType(Type.ANY_ATOMIC_TYPE,
                                 (allowEmpty ? StaticProperty.ALLOWS_ZERO_OR_ONE
                                             : StaticProperty.EXACTLY_ONE));

        RoleLocator role = new RoleLocator(RoleLocator.TYPE_OP, "castable as", 0);
        source = TypeChecker.staticTypeCheck(source, atomicType, false, role);

//        if (Type.isSubType(source.getItemType(), targetType.getBuiltInBaseType().get)) {
//            return source;
//        }
        if (source instanceof AtomicValue) {
            return BooleanValue.get(effectiveBooleanValue(null));
        }
        return this;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        source = source.promote(offer);
        return this;
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[1];
        exp[0] = source;
        return exp;
    }


    /**
    * Determine the data type of the result of the Castable expression
    */

    public ItemType getItemType() {
        return Type.BOOLEAN_TYPE;
    }

    public int computeCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    /**
    * Evaluate the expression
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        return BooleanValue.get(effectiveBooleanValue(context));
    }

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        try {
            AtomicValue value = (AtomicValue)source.evaluateItem(context);
            if (value == null) {
                return allowEmpty;
            }
            AtomicValue prim =
                    value.convert(targetType.getBuiltInBaseType().getFingerprint());
            DerivedAtomicValue val =
                    DerivedAtomicValue.makeValue(prim, prim.getStringValue(), targetType, false);
            return val != null;
        } catch (XPathException err) {
            return false;
        }
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "castable" );
        source.display(level+1, pool);
        System.err.println(ExpressionTool.indent(level+1) + "as " + targetType);
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
