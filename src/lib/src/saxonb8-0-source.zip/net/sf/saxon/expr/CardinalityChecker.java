package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.value.ObjectValue;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.type.ItemType;

/**
* A CardinalityChecker implements the cardinality checking of "treat as": that is,
* it returns the supplied sequence, checking that its cardinality is correct
*/

public final class CardinalityChecker extends ComputedExpression implements MappingFunction {

    private Expression sequence;
    private int requiredCardinality = -1;
    private RoleLocator role;

    /**
    * Constructor
    */

    public CardinalityChecker(Expression sequence, int cardinality, RoleLocator role) {
        this.sequence = sequence;
        this.requiredCardinality = cardinality;
        this.role = role;
        computeStaticProperties();
    }

    /**
    * Simplify an expression
    */

     public Expression simplify() throws XPathException {
        sequence = sequence.simplify();
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        sequence = sequence.analyze(env);
        if (requiredCardinality == StaticProperty.ALLOWS_ZERO_OR_MORE) {
            return sequence;
        }
        if (Cardinality.subsumes(requiredCardinality, sequence.getCardinality())) {
            return sequence;
        }
        return this;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        sequence = sequence.promote(offer);
        return this;
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[1];
        exp[0] = sequence;
        return exp;
    }

    /**
    * Iterate over the sequence of values
    */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        SequenceIterator base = sequence.iterate(context);

        ObjectValue stopper = null;
        if (!Cardinality.allowsZero(requiredCardinality)) {
            // To check for an empty sequence, we add a special item to the base
            // iteration, to ensure that the mapping function gets called at least
            // once. This item will cause an error if it is the first in the sequence,
            // and will be ignored otherwise.
            stopper = new ObjectValue(this);
            base = new AppendExpression.AppendIterator(base, stopper, context);
        }


//        if (!base.hasNext()) {
//            if (!Cardinality.allowsZero(requiredCardinality)) {
//                typeError("An empty sequence is not allowed as the " + role.getMessage());
//                return null;
//            }
//        }
//        if (!Cardinality.allowsMany(requiredCardinality)) {
            return new MappingIterator(base, this, null, base);
//        } else {
//            return base;
//        }
    }

    /**
    * Mapping function: this is used only if the expression does not allow a sequence of more than
    * one item.
    */

    public Object map(Item item, XPathContext context, Object info) throws XPathException {
        int pos = ((SequenceIterator)info).position();
        if (item instanceof ObjectValue && ((ObjectValue)item).getObject() == this) {
            // we've hit the stopper object
            if (pos==1) {
                 typeError("An empty sequence is not allowed as the " + role.getMessage());
            }
            // don't include the stopper in the result
            return null;
        }
        if (pos==2 && !Cardinality.allowsMany(requiredCardinality)) {
            typeError(
                    "A sequence of more than one item is not allowed as the " +
                    role.getMessage());
            return null;
        }
        return item;
    }

    /**
    * Evaluate as an Item.
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        SequenceIterator iter = sequence.iterate(context);
        Item item = null;
        while (true) {
            Item nextItem = iter.next();
            if (nextItem == null) break;
            if (item != null) {
                typeError("A sequence of more than one item is not allowed as the " +
                    role.getMessage());
                return null;
            }
            item = nextItem;
        }
        if (item == null && !Cardinality.allowsZero(requiredCardinality)) {
            typeError("An empty sequence is not allowed as the " +
                    role.getMessage());
            return null;
        }
        return item;
    }

    /**
    * Determine the data type of the items returned by the expression, if possible
    * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
    * or Type.ITEM (meaning not known in advance)
    */

	public ItemType getItemType() {
	    return sequence.getItemType();
	}

	/**
	* Determine the static cardinality of the expression
	*/

	public int computeCardinality() {
        return requiredCardinality;
	}

    /**
    * Get the static properties of this expression (other than its type). The result is
    * bit-signficant. These properties are used for optimizations. In general, if
    * property bit is set, it is true, but if it is unset, the value is unknown.
    */

    public int computeSpecialProperties() {
        return sequence.getSpecialProperties();
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "checkCardinality (" + Cardinality.toString(requiredCardinality) + ")");
        sequence.display(level+1, pool);
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
