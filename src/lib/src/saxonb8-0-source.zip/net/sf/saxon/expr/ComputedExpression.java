package net.sf.saxon.expr;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.SingletonIterator;
import net.sf.saxon.value.*;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.SourceLocator;
import java.io.Serializable;

/**
 * <p>This class is an abstract superclass for different kinds of XPath expression.</p>
 *
 * <p>There are two principal methods for evaluating an expression: iterate(), which
 * an iterator over the result of the expression as a sequence, and evaluateItem(), which returns an
 * object that is an instance of net.sf.saxon.om.Item. Both methods take an
 * XPathContext object to supply the evaluation context; for an expression that is
 * a Value, this argument is ignored and may be null. This root class provides an implementation
 * of iterate() in terms of evaluateItem() that works only for singleton expressions, and an implementation
 * of evaluateItem() in terms of iterate() that works only for non-singleton expressions. Subclasses
 * of expression must therefore provide either iterate() or evaluateItem(): they do not have to provide
 * both.</p>
 *
 * <p>Note that the methods that take an XPathContext argument are run-time methods.
 * The methods without such an argument are compile-time methods. Run-time methods must not
 * modify the state of the Expression object.</p>
 */

public abstract class ComputedExpression implements Serializable, Expression  {

    protected int staticProperties = -1;
    protected short lineNumber = -1;

    /**
     * A zero-length array of expressions, used for functions that have no arguments
     * or expressions that have no subexpressions
     */

    public final static Expression[] NO_ARGUMENTS = new Expression[0];


    /**
     * Set the line number on an expression.
     */

    public void setLineNumber(short line) {
        lineNumber = line;
    }

    /**
     * Get the line number on the expression
     */

    public short getLineNumber() {
        return lineNumber;
    }

    /**
     * Simplify an expression. This performs any static optimization (by rewriting the expression
     * as a different expression). The default implementation does nothing.
     *
     * @exception XPathException if an error is discovered during expression
     *     rewriting
     * @return the simplified expression
     */

     public Expression simplify() throws XPathException {
        return this;
    }

    /**
     * Offer promotion for this subexpression. The offer will be accepted if the subexpression
     * is not dependent on the factors (e.g. the context item) identified in the PromotionOffer.
     * By default the offer is not accepted - this is appropriate in the case of simple expressions
     * such as constant values and variable references where promotion would give no performance
     * advantage. This method is always called at compile time.
     *
     * @param offer details of the offer, for example the offer to move
     *     expressions that don't depend on the context to an outer level in
     *     the containing expression
     * @exception XPathException if any error is detected
     * @return if the offer is not accepted, return this expression unchanged.
     *      Otherwise return the result of rewriting the expression to promote
     *      this subexpression
     */

    public Expression promote(PromotionOffer offer) throws XPathException {
        // The following temporary code checks that this method is implemented for all expressions
        // that have subexpressions
//        if (getSubExpressions().length > 0) {
//            throw new UnsupportedOperationException("promote is not implemented for " + this.getClass());
//        }
        return this;
    }

    /**
     * Get the static properties of this expression (other than its type). The result is
     * bit-signficant. These properties are used for optimizations. In general, if
     * property bit is set, it is true, but if it is unset, the value is unknown.
     *
     * @return a set of flags indicating static properties of this expression
     */

    public final int getSpecialProperties() {
        if (staticProperties == -1) {
            computeStaticProperties();
        }
        return staticProperties & StaticProperty.SPECIAL_PROPERTY_MASK;
    }

    /**
     * Compute the static properties. This should only be done once for each
     * expression.
     */

    public final void computeStaticProperties() {
        staticProperties =
                computeDependencies() |
                computeCardinality() |
                computeSpecialProperties();
    }

    protected abstract int computeCardinality();

    protected int computeSpecialProperties() {
        return 0;
    }

    /**
     * Determine the static cardinality of the expression. This establishes how many items
     * there will be in the result of the expression, at compile time (i.e., without
     * actually evaluating the result.
     *
     * @return one of the values Cardinality.ONE_OR_MORE,
     *     Cardinality.ZERO_OR_MORE, Cardinality.EXACTLY_ONE,
     *     Cardinality.ZERO_OR_ONE, Cardinality.EMPTY. This default
     *     implementation returns ZERO_OR_MORE (which effectively gives no
     *     information).
     */

    public int getCardinality() {
        if (staticProperties==-1) {
            computeStaticProperties();
        }
        return staticProperties & StaticProperty.CARDINALITY_MASK;
        //return StaticProperty.CARDINALITY_ALLOWS_ZERO_OR_MORE;
    }


    /**
     * Determine which aspects of the context the expression depends on. The result is
     * a bitwise-or'ed value composed from constants such as XPathContext.VARIABLES and
     * XPathContext.CURRENT_NODE. The default implementation combines the intrinsic
     * dependencies of this expression with the dependencies of the subexpressions,
     * computed recursively. This is overridden for expressions such as FilterExpression
     * where a subexpression's dependencies are not necessarily inherited by the parent
     * expression.
     *
     * @return a set of bit-significant flags identifying the dependencies of
     *     the expression
     */

    public int getDependencies() {
        // Implemented as a memo function: we only compute the dependencies
        // for each expression once
        if (staticProperties==-1) {
            computeStaticProperties();
        }
        return staticProperties & StaticProperty.DEPENDENCY_MASK;
    }

    /**
     * Compute the dependencies of an expression, as the union of the
     * dependencies of its subexpressions. (This is overridden for path expressions
     * and filter expressions, where the dependencies of a subexpression are not all
     * propogated). This method should be called only once, to compute the dependencies;
     * after that, getDependencies should be used.
     * @return the depencies, as a bit-mask
     */

    public int computeDependencies() {
        int dependencies = (short)getIntrinsicDependencies();
        Expression[] children = getSubExpressions();
        for (int i=0; i<children.length; i++) {
            dependencies |= (short)children[i].getDependencies();
        }
        return dependencies;
    }

    /**
     * Determine the intrinsic dependencies of an expression, that is, those which are not derived
     * from the dependencies of its subexpressions. For example, position() has an intrinsic dependency
     * on the context position, while (position()+1) does not. The default implementation
     * of the method returns 0, indicating "no dependencies".
     *
     * @return a set of bit-significant flags identifying the "intrinsic"
     *     dependencies. The flags are documented in class net.sf.saxon.value.StaticProperty
     */

    public int getIntrinsicDependencies() {
        return 0;
    }


    /**
     * Get the immediate sub-expressions of this expression. Default implementation
     * returns a zero-length array, appropriate for an expression that has no
     * sub-expressions.
     * @return an array containing the sub-expressions of this expression
     */
    public Expression[] getSubExpressions() {
        return NO_ARGUMENTS;
    }

    /**
     * Mark tail-recursive calls on stylesheet functions. For most expressions, this does nothing.
     *
     * @return true if a tail recursive call was found and if this call
     *     accounts for the whole of the value.
     */

    public boolean markTailFunctionCalls() {
        return false;
    }

    /**
     * Test if this expression is the same as another expression.
     * (Note, returns false to indicate "don't know": our tests are rather limited)
     *
     * @param other the expression to be compared with this one
     * @return true if this expression is known to be equivalent to the other
     *     expression (that is, to deliver the same result in all
     *     circumstances, assuming the context is the same)
     */

//    public boolean equals(Object other) {
//        return this==other;
//    }

    /**
     * Evaluate an expression as a single item. This always returns either a single Item or
     * null (denoting the empty sequence). No conversion is done. This method should not be
     * used unless the static type of the expression is a subtype of "item" or "item?": that is,
     * it should not be called if the expression may return a sequence. There is no guarantee that
     * this condition will be detected.
     *
     * @param context The context in which the expression is to be evaluated
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @return the node or atomic value that results from evaluating the
     *     expression; or null to indicate that the result is an empty
     *     sequence
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        return iterate(context).next();
    }

    /**
     * Evaluate an expression as a String. This function must only be called in contexts
     * where it is known that the expression will return a single string (or where an empty sequence
     * is to be treated as a zero-length string). Implementations should not attempt to convert
     * the result to a string, other than converting () to "". This method is used mainly to
     * evaluate expressions produced by compiling an attribute value template.
     *
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @exception ClassCastException if the result type of the
     *     expression is not xs:string?
     * @param context The context in which the expression is to be evaluated
     * @return the value of the expression, evaluated in the current context.
     *     The expression must return a string or (); if the value of the
     *     expression is (), this method returns "".
     */

    public String evaluateAsString(XPathContext context) throws XPathException {
        Object o = evaluateItem(context);
        if (o instanceof DerivedAtomicValue) {
            o = ((DerivedAtomicValue)o).getPrimitiveValue();
        }
        StringValue value = (StringValue)o;
        if (value==null) return "";
        return value.getStringValue();
    }

    /**
     * Return an Iterator to iterate over the values of a sequence. The value of every
     * expression can be regarded as a sequence, so this method is supported for all
     * expressions. This default implementation handles iteration for expressions that
     * return singleton values: for non-singleton expressions, the subclass must
     * provide its own implementation.
     *
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @param context supplies the context for evaluation
     * @return a SequenceIterator that can be used to iterate over the result
     *     of the expression
     */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
       if ((!Cardinality.allowsMany(getCardinality()))) {
            // The above line is defensive coding. We should only be here if it's a singleton.
            Item value = evaluateItem(context);
            return SingletonIterator.makeIterator(value);
        } else {
            throw new UnsupportedOperationException("Non-singleton expression " + getClass() + " must supply iterate() method");
        }
    }

    /**
     * Return an Iterator to iterate over the values of a sequence. This version of the
     * iterate() method allows the caller to indicate that (a) there is no requirement
     * to return items in the correct sequence, or (b) that there is no requirement
     * to return each item exactly once. The default implementation of this method
     * ignores these options and returns a sequence in the correct order with no
     * unwanted duplicates.
     *
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @param context supplies the context for evaluation
     * @param inOrder indicates whether the items in this sequence must
     *      be delivered in sequence order. This will normally by true. In
     *     some situations, however (e.g. count() and sum()), the order of
     *     items is immaterial, and in this case some sequence implementations
     *      can optimize by delivering the items in a different order.
     * @param unique indicates that each item must be delivered exactly
     *      once. This will normally be true. However, in some circumstances
     *     (e.g. max() and min()) it does not matter if items are delivered
     *     more than once. If inOrder is true, unique should also be true.
     * @return A SequenceIterator that can be used to iterate over the results
     *      of the expression
     */

    //public SequenceIterator iterate(XPathContext context,
    //        boolean inOrder, boolean unique) throws XPathException {
    //    return iterate(context);
    //}

    /**
     * Get the effective boolean value of the expression. This returns false if the value
     * is the empty sequence, a zero-length string, a number equal to zero, or the boolean
     * false. Otherwise it returns true.
     *
     * @param context The context in which the expression is to be evaluated
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @return the effective boolean value
     */

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        return ExpressionTool.effectiveBooleanValue(iterate(context));
    }

    /**
     * Method used in subclasses to signal a dynamic error
     */

    protected void dynamicError(String message) throws XPathException.Dynamic {
        throw new XPathException.Dynamic(message, getSourceLocator());
    }

     /**
     * Method used in subclasses to signal a runtime type error
     */

    protected void typeError(String message) throws XPathException.Type {
        throw new XPathException.Type(message, getSourceLocator());
    }

    /**
     * Get a SourceLocator for this expression (needed to make the expression an Instr)
     */

    public SourceLocator getSourceLocator() {
        return ExpressionTool.getLocator(this);
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Contributor(s): Michael Kay
//
