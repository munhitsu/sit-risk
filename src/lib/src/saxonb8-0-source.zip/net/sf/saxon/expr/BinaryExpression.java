package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.om.NamePool;

/**
* Binary Expression: a numeric or boolean expression consisting of the
* two operands and an operator
*/

abstract class BinaryExpression extends ComputedExpression {

    // TODO: BinaryExpressions could be modelled as functions, allowing the same
    // table-driven logic to be used as for system function calls.

    protected Expression[] operands;
    protected int operator;       // represented by the token number from class Tokenizer

    /**
    * Default constructor
    */

    public BinaryExpression() {}

    /**
    * Create a binary expression identifying the two operands and the operator
    * @param p1 the left-hand operand
    * @param op the operator, as a token returned by the Tokenizer (e.g. Tokenizer.AND)
    * @param p2 the right-hand operand
    */

    public BinaryExpression(Expression p1, int op, Expression p2) {
        setDetails(p1, op, p2);
    }

    /**
    * Identify the two operands and the operator (for use when the default constructor was used)
    * @param p1 the left-hand operand
    * @param op the operator, as a token returned by the Tokenizer (e.g. Tokenizer.AND)
    * @param p2 the right-hand operand
    */

    public void setDetails(Expression p1, int op, Expression p2) {
        operands = new Expression[2];
        operands[0] = p1;
        operands[1] = p2;
        this.operator = op;
    }

    /**
    * Simplify an expression
    * @return the simplified expression
    */

     public Expression simplify() throws XPathException {
        operands[0] = operands[0].simplify();
        operands[1] = operands[1].simplify();
        return this;
    }

    /**
    * Type-check the expression. Default implementation for binary operators that accept
    * any kind of operand
    */

    public Expression analyze(StaticContext env) throws XPathException {
        operands[0] = operands[0].analyze(env);
        operands[1] = operands[1].analyze(env);
        // if both operands are known, pre-evaluate the expression
        try {
            if ((operands[0] instanceof Value) && (operands[1] instanceof Value)) {
                return ExpressionTool.eagerEvaluate(this, null);
            }
        } catch (XPathException.Dynamic err) {
            // if early evaluation fails, suppress the error: the value might
            // not be needed at run-time
        }
        return this;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            if (offer.action != PromotionOffer.UNORDERED) {
                operands[0] = operands[0].promote(offer);
                operands[1] = operands[1].promote(offer);
            }
            return this;
        }
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        return operands;
    }

    /**
    * Determine the static cardinality. Default implementation returns [0..1] if either operand
     * can be empty, or [1..1] otherwise.
    */

    public int computeCardinality() {
        if (Cardinality.allowsZero(operands[0].getCardinality()) &&
                Cardinality.allowsZero(operands[1].getCardinality())) {
            return StaticProperty.ALLOWS_ZERO_OR_ONE;
        } else {
            return StaticProperty.EXACTLY_ONE;
        }
    }

    protected static boolean isCommutative(int operator) {
        return (operator == Tokenizer.AND ||
                operator == Tokenizer.OR ||
                operator == Tokenizer.UNION ||
                operator == Tokenizer.INTERSECT ||
                operator == Tokenizer.PLUS ||
                operator == Tokenizer.MULT ||
                operator == Tokenizer.EQUALS ||
                operator == Tokenizer.FEQ ||
                operator == Tokenizer.NE ||
                operator == Tokenizer.FNE
                );
        // not + or * because the type promotion works non-associatively
    }

    /**
    * Is this expression the same as another expression?
    */

    public boolean equals(Object other) {
        if (other instanceof BinaryExpression) {
            BinaryExpression b = (BinaryExpression)other;
            if (operator == b.operator) {
                if (operands[0].equals(b.operands[0]) &&
                        operands[1].equals(b.operands[1])) {
                    return true;
                }
                if (isCommutative(operator) &&
                        operands[0].equals(b.operands[1]) &&
                        operands[1].equals(b.operands[0])) {
                    return true;
                }
            }
            // TODO: recognize associative operators (A|(B|C)) == ((A|B)|C)
            //    and inverse operators (A<B) == (B>A)
        }
        return false;
    }

    /**
    * get HashCode for comparing two expressions. Note that this hashcode gives the same
     * result for (A op B) and for (B op A), whether or not the operator is commutative.
    */

    public int hashCode() {
        return ("BinaryExpression " +
                operator).hashCode() ^ operands[0].hashCode() ^ operands[1].hashCode();
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "operator " + displayOperator());
        operands[0].display(level+1, pool);
        operands[1].display(level+1, pool);
    }

    protected String displayOperator() {
        return Tokenizer.tokens[operator];
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
