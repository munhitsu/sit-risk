package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.IntegerValue;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.instruct.Instr;
import net.sf.saxon.instruct.SequenceInstruction;
import net.sf.saxon.instruct.TailCall;
import net.sf.saxon.event.SequenceReceiver;

import javax.xml.transform.TransformerException;

/**
* A ForExpression maps an expression over a sequence.
* This version works with range variables, it doesn't change the context information
*/

public class ForExpression extends Assignation implements Instr {

    private transient RangeVariableDeclaration positionVariable = null;
    private PositionBinding positionBinding = null;

    /**
     * Set the reference to the position variable (XQuery only)
     */

    public void setPositionVariable (RangeVariableDeclaration decl) {
        positionVariable = decl;
        positionBinding = new PositionBinding();
    }

    public void setAction(Expression action) {
        super.setAction(action);
        if (positionVariable != null) {
            positionVariable.fixupReferences(positionBinding);
        }
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {

        if (declaration==null) {
            // we've already done the type checking, no need to do it again
            return this;
        }

        // The order of events is critical here. First we ensure that the type of the
        // sequence expression is established. This is used to establish the type of the variable,
        // which in turn is required when type-checking the action part.

        sequence = sequence.analyze(env);

        SequenceType decl = declaration.getRequiredType();
        SequenceType sequenceType =
            new SequenceType(decl.getPrimaryType(),
                             StaticProperty.ALLOWS_ZERO_OR_MORE);
        RoleLocator role = new RoleLocator(RoleLocator.VARIABLE, getVariableName(), 0);
        sequence = TypeChecker.staticTypeCheck(
                                sequence, sequenceType, false, role);
        ItemType actualItemType = sequence.getItemType();
        declaration.refineTypeInformation(actualItemType,
                StaticProperty.EXACTLY_ONE,
                null,
                sequence.getSpecialProperties());

        declaration = null;     // let the garbage collector take it

        action = action.analyze(env);

        // Extract subexpressions that don't depend on the range variable.
        // We don't do this if there is a position variable. Ideally we would
        // extract subexpressions so long as they don't depend on either variable,
        // but we don't have the machinery to do that yet.
        // TODO: add this optimisation

        if (positionVariable == null) {
            PromotionOffer offer = new PromotionOffer();
            offer.containingExpression = this;
            offer.action = PromotionOffer.RANGE_INDEPENDENT;
            offer.binding = this;
            action = action.promote(offer);
            if (offer.containingExpression instanceof LetExpression) {
                offer.containingExpression = offer.containingExpression.analyze(env);
            }
            return offer.containingExpression;
        }
        return this;
    }


    /**
    * Iterate over the sequence of values
    */

    public SequenceIterator iterate(XPathContext context) throws XPathException {

        // First create an iteration of the base sequence.

        // Then create a MappingIterator which applies a mapping function to each
        // item in the base sequence. The mapping function is essentially the "return"
        // expression, wrapped in a RangingAction object that is responsible also for
        // setting the range variable at each step.

        // System.err.println("ForExpr.iterate over sequence:");
        // sequence.display(20);
        // System.err.println("  applying action:");
        // action.display(20);

        SequenceIterator base = sequence.iterate(context);

        MappingFunction map = new MappingAction(context, slotNumber, positionBinding, action);
        return new MappingIterator(base, map, null, null);
    }

    /**
     * Process this expression as an instruction, writing results to the current
     * outputter
     */

    public void process(XPathContext context) throws TransformerException {
        if (action instanceof Instr) {
            SequenceIterator iter = sequence.iterate(context);
            int position = 1;
            while (true) {
                Item item = iter.next();
                if (item == null) break;
                context.setLocalVariable(slotNumber, Value.asValue(item));
                if (positionBinding != null) {
                    positionBinding.setPosition(position++);
                }
                ((Instr)action).process(context);
            }
        } else {
            SequenceIterator iter = sequence.iterate(context);
            SequenceReceiver out = context.getController().getReceiver();
            int position = 1;
            while (true) {  // for each item in the input sequence
                Item item = iter.next();
                if (item == null) break;
                context.setLocalVariable(slotNumber, Value.asValue(item));
                if (positionBinding != null) {
                    positionBinding.setPosition(position++);
                }
                SequenceIterator iter2 = action.iterate(context);
                while (true) { // output all the items in the return sequence
                    Item item2 = iter2.next();
                    if (item2==null) break;
                    SequenceInstruction.appendItem(item2, context, out);
                }
            }
        }
    }

    /**
    * Process the instruction, optionally returning an uncompleted tail call to
     * be invoked by the caller
    * @param context The dynamic context, giving access to the current node,
    * the current variables, etc.
    */

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        process(context);
        return null;
    }

    /**
    * Determine the data type of the items returned by the expression, if possible
    * @return one of the values Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
    * or Type.ITEM (meaning not known in advance)
    */

	public ItemType getItemType() {
	    return action.getItemType();
	}

	/**
	* Determine the static cardinality of the expression
	*/

	public int computeCardinality() {
        int c1 = sequence.getCardinality();
        int c2 = action.getCardinality();
        return Cardinality.multiply(c1, c2);
	}

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) +
                "for $" + getVariableName() +
                (positionVariable == null ? "" : " at $?") +
                " in");
        sequence.display(level+1, pool);
        System.err.println(ExpressionTool.indent(level) + "return");
        action.display(level+1, pool);
    }

    /**
     * The MappingAction represents the action to be taken for each item in the
     * source sequence. It acts as the MappingFunction for the mapping iterator, and
     * also as the Binding of the position variable (at $n) in XQuery, if used.
     */

    private static class MappingAction implements MappingFunction {

        private XPathContext context;
        private int slotNumber;
        private Expression action;
        private PositionBinding positionBinding;
        private int position = 1;

        public MappingAction(XPathContext context,
                                int slotNumber,
                                PositionBinding positionBinding,
                                Expression action) {
            this.context = context;
            this.slotNumber = slotNumber;
            this.positionBinding = positionBinding;
            this.action = action;
        }

        public Object map(Item item, XPathContext c, Object info) throws XPathException {
            context.setLocalVariable(slotNumber, Value.asValue(item));
            if (positionBinding != null) {
                positionBinding.setPosition(position++);
            }
            return action.iterate(context);
        }
    }

    private static class PositionBinding implements Binding {

        private int position;

        private void setPosition(int position) {
            this.position = position;
        }

        public SequenceType getRequiredType() {
            return SequenceType.SINGLE_INTEGER;
        }

        public Value evaluateVariable(XPathContext context) throws XPathException {
            return new IntegerValue(position);
        }

        public String getVariableName() {
            return "zz:at" + hashCode();
        }
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
