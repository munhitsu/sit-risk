package net.sf.saxon.expr;
import net.sf.saxon.Controller;
import net.sf.saxon.Configuration;
import net.sf.saxon.instruct.Bindery;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.SingletonIterator;
import net.sf.saxon.om.LookaheadIterator;
import net.sf.saxon.sort.CodepointCollator;
import net.sf.saxon.sort.CollationFactory;
import net.sf.saxon.value.Value;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.Comparator;

/**
* This class represents a context in which an XPath expression is evaluated.
*/

public class XPathContext {

    private Controller controller;
    private SequenceIterator currentIterator;
    private int last = -1;
    private Object[] localVariableFrame;

    /**
    * Protected constructor for use in subclasses
    */

    //protected XPathContext() {}

    /**
    * Constructor should only be called by the Controller,
    * which acts as a XPathContext factory.
    */

    public XPathContext(Controller c) {
        controller = c;
        currentIterator = c.getCurrentIterator();
        localVariableFrame = c.getBindery().getCurrentStackFrame();
    }

    /**
    * Constructor to create one XPathContext as a copy of another
    */

    public XPathContext(XPathContext c) {
        controller = c.controller;
        currentIterator = c.currentIterator;
        localVariableFrame = c.localVariableFrame;
        last = c.last;
    }

    /**
    * Constructor for use in free-standing Java applications.
    * Must be used with care, since functions dependent on a Controller
    * will not be available.
    */

    public XPathContext(Item item, Configuration config) {
        controller = new Controller(config);
        AxisIterator iter = SingletonIterator.makeIterator(item);
        iter.next();
        currentIterator = iter;
    }

    /**
    * Construct a new context as a copy of another
    */

    public XPathContext newContext() {
        XPathContext c = new XPathContext(this);
        return c;
    }

    /**
    * Get the Controller. Returns null when running outside XSLT
    */

    public Controller getController() {
        return controller;
    }

    /**
    * Set a new sequence iterator.
    */

    public void setCurrentIterator(SequenceIterator iter) {
        currentIterator = iter;
        last = 0;
    }

    /**
    * Get the current iterator
    */

    public SequenceIterator getCurrentIterator() {
        return currentIterator;
    }

    /**
    * Get the context position (the position of the context node in the context node list)
    * @return the context position (starting at one)
    */

    public int getContextPosition() throws XPathException {
        if (currentIterator==null) {
            throw new XPathException.Dynamic("The context item and context position are not set");
        }
        return currentIterator.position();
    }

    /**
    * Get the context item (XPath 2.0)
     * @return the context item, or null if the context item is not set
    */

    public Item getContextItem() {
        if (currentIterator==null) {
            return null;
        }
        return currentIterator.current();
    }

    /**
    * Get the context size (the position of the last item in the current node list)
    * @return the context size
    */

    public int getLast() throws XPathException {
        if (last>0) return last;
        if (currentIterator==null) {
            throw new XPathException.Dynamic("The context item, position, and size are not set");
        }
        if (currentIterator instanceof LastPositionFinder) {
            last = ((LastPositionFinder)currentIterator).getLastPosition();
            return last;
        } else {
            SequenceIterator another = currentIterator.getAnother();
            last = 0;
            while (another.next() != null) {
                last++;
            }
            return last;
        }
    }

    /**
    * Determine whether the context position is the same as the context size
    * that is, whether position()=last()
    */

    public boolean isAtLast() throws XPathException {
        if (currentIterator instanceof LookaheadIterator) {
            return !((LookaheadIterator)currentIterator).hasNext();
            // TODO: reinstate this optimization for more types of iterator!
        }
        return getContextPosition() == getLast();
    }

    /**
    * Get the current stylesheet item: supports the XSLT current() function
    */

    public Item getCurrentStylesheetItem() throws XPathException {
        return getController().getCurrentItem();
    }

    /**
    * Get a named collation
    */

    public Comparator getCollation(String name) throws XPathException {
        if (name.equals(CodepointCollator.URI)) {
            return CodepointCollator.getInstance();
        }
        Comparator collation = null;
        if (controller != null) {
            collation = controller.getExecutable().getNamedCollation(name);
        }
        if (collation == null) {
            try {
                collation = CollationFactory.makeCollationFromURI(name);
                if (collation==null) {
                    throw new XPathException.Dynamic("Unknown collation " + name);
                }
            } catch (TransformerException e) {
                throw new XPathException.Dynamic(e);
            }
        }
        return collation;
    }

    /**
    * Get the default collation
    */

    public Comparator getDefaultCollation() {
        if (controller != null) {
            return controller.getExecutable().getDefaultCollation();
        } else {
            return CodepointCollator.getInstance();
        }
    }

    /**
     * Get a reference to the local stack frame for variables. Note that it's
     * the caller's job to make a local copy of this. This is used for creating
     * a Closure containing a retained copy of the variables for delayed evaluation.
     * @return array of variables.
     */

    public Object[] getLocalVariableFrame() {
        return localVariableFrame;
    }


    /**
     * Set the local stack frame. This method is used when creating a Closure to support
     * delayed evaluation of expressions. The "stack frame" is actually on the heap, which
     * means it can survive function returns and the like.
     */

    public void setLocalVariableFrame(Object[] variables) {
        localVariableFrame = variables;
    }

    /**
     * Get the value of a local variable, identified by its slot number
     */

    public Value evaluateLocalVariable(int slotnumber) {
        return (Value)localVariableFrame[slotnumber+Bindery.FRAME_VARIABLES];
    }

    /**
     * Set the value of a local variable, identified by its slot number
     */

    public void setLocalVariable(int slotnumber, Value value) {
        localVariableFrame[slotnumber+Bindery.FRAME_VARIABLES] = value;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
