package net.sf.saxon.expr;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.type.AnyItemType;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.Type;
import net.sf.saxon.xpath.XPathException;

/**
* A ItemChecker implements the item type checking of "treat as": that is,
* it returns the supplied sequence, checking that all its items are of the correct type
*/

public final class ItemChecker extends ComputedExpression implements MappingFunction {

    private Expression sequence;
    private ItemType requiredItemType;
    private RoleLocator role;

    /**
    * Constructor
    */

    public ItemChecker(Expression sequence, ItemType itemType, RoleLocator role) {
        this.sequence = sequence;
        this.requiredItemType = itemType;
        this.role = role;
    }

    /**
    * Simplify an expression
    */

     public Expression simplify() throws XPathException {
        sequence = sequence.simplify();
        if (requiredItemType instanceof AnyItemType) {
            return sequence;
        }
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        sequence = sequence.analyze(env);
        if (Type.isSubType(sequence.getItemType(), requiredItemType)) {
            return sequence;
        }
        return this;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        sequence = sequence.promote(offer);
        return this;
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[1];
        exp[0] = sequence;
        return exp;
    }

    /**
    * Iterate over the sequence of values
    */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        SequenceIterator base = sequence.iterate(context);
        return new MappingIterator(base, this, null, null);
    }

    /**
    * Mapping function: this is used only if the expression does not allow a sequence of more than
    * one item.
    */

    public Object map(Item item, XPathContext context, Object info) throws XPathException {
        testConformance(item);
        return item;
    }

    /**
    * Evaluate as an Item.
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        Item item = sequence.evaluateItem(context);
        if (item==null) return null;
        testConformance(item);
        return item;
    }

    private void testConformance(Item item) throws XPathException {
        if (!requiredItemType.matchesItem(item)) {
            typeError("Required type of " + role.getMessage() +
                                             " is " + requiredItemType.toString() +
                                             "; supplied value is " + Type.displayTypeName(item));
        }
    }

    /**
    * Determine the data type of the items returned by the expression
    */

	public ItemType getItemType() {
	    return requiredItemType;
	}

	/**
	* Determine the static cardinality of the expression
	*/

	public int computeCardinality() {
        return sequence.getCardinality();
	}

    /**
    * Get the static properties of this expression (other than its type). The result is
    * bit-signficant. These properties are used for optimizations. In general, if
    * property bit is set, it is true, but if it is unset, the value is unknown.
    */

    public int computeSpecialProperties() {
        return sequence.getSpecialProperties();
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "treat as " +
                           requiredItemType.toString());
        sequence.display(level+1, pool);
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
