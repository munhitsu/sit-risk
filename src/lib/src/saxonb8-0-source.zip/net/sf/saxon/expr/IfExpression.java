package net.sf.saxon.expr;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.BooleanValue;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.instruct.Instr;
import net.sf.saxon.instruct.SequenceInstruction;
import net.sf.saxon.instruct.TailCall;
import net.sf.saxon.event.SequenceReceiver;

import javax.xml.transform.TransformerException;


/**
* An IfExpression returns the value of either the "then" part or the "else" part,
* depending on the value of the condition
*/

public class IfExpression extends ComputedExpression implements Instr {

    private Expression condition;
    private Expression thenExp;
    private Expression elseExp;

    /**
    * Constructor
    */

    public IfExpression(Expression condition, Expression thenExp, Expression elseExp) {
        this.condition = condition;
        this.thenExp = thenExp;
        this.elseExp = elseExp;
    }

    /**
    * Simplify an expression
    */

     public Expression simplify() throws XPathException {

        condition = condition.simplify();

        if (condition instanceof Value) {
            return (condition.effectiveBooleanValue(null) ? thenExp.simplify() : elseExp.simplify());
        } else {
            thenExp = thenExp.simplify();
            elseExp = elseExp.simplify();
        }

        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        condition = condition.analyze(env);
        // If the condition after typechecking is reduced to a constant,
        // cut it down to the appropriate branch. This is especially important
        // when handling typeswitch, as otherwise the unused branches will
        // generate a type error.
        if (condition instanceof BooleanValue) {
            if (((BooleanValue)condition).getValue()) {
                return thenExp.analyze(env);
            } else {
                return elseExp.analyze(env);
            }
        } else {
            thenExp = thenExp.analyze(env);
            elseExp = elseExp.analyze(env);
            return simplify();
        }
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            // Promote subexpressions in the condition, but not in the "then" and "else"
            // branches, because these are guaranteed not to be evaluated if the condition
            // is false (bzw true).
            condition = condition.promote(offer);

            // allow "unordered" to trickle down to the subexpressions
            if (offer.action == PromotionOffer.UNORDERED ||
                    offer.action == PromotionOffer.INLINE_VARIABLE_REFERENCES) {
                thenExp = thenExp.promote(offer);
                elseExp = elseExp.promote(offer);
            }
            return this;
        }
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[3];
        exp[0] = condition;
        exp[1] = thenExp;
        exp[2] = elseExp;
        return exp;
    }

    /**
    * Mark tail calls on used-defined functions. For most expressions, this does nothing.
    */

    public boolean markTailFunctionCalls() {
        boolean a = ExpressionTool.markTailFunctionCalls(thenExp);
        boolean b = ExpressionTool.markTailFunctionCalls(elseExp);
        return a || b;
    }

    /**
    * Evaluate the conditional expression in a given context
    * @param context the evaluation context
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        if (condition.effectiveBooleanValue(context)) {
            return thenExp.evaluateItem(context);
        } else {
            return elseExp.evaluateItem(context);
        }
    }

    /**
    * Iterate the path-expression in a given context
    * @param context the evaluation context
    */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        if (condition.effectiveBooleanValue(context)) {
            return thenExp.iterate(context);
        } else {
            return elseExp.iterate(context);
        }
    }

    /**
     * Process this expression as an instruction, writing results to the current
     * outputter
     */

    public void process(XPathContext context) throws TransformerException {
        if (condition.effectiveBooleanValue(context)) {
            if (thenExp instanceof Instr) {
                ((Instr)thenExp).process(context);
            } else {
                SequenceReceiver out = context.getController().getReceiver();
                SequenceIterator iter = thenExp.iterate(context);
                while (true) {
                    Item item = iter.next();
                    if (item==null) return;
                    SequenceInstruction.appendItem(item, context, out);
                }
            }
        } else {
            if (elseExp instanceof Instr) {
                ((Instr)elseExp).process(context);
            } else {
                SequenceReceiver out = context.getController().getReceiver();
                SequenceIterator iter = elseExp.iterate(context);
                while (true) {
                    Item item = iter.next();
                    if (item==null) return;
                    SequenceInstruction.appendItem(item, context, out);
                }
            }
        }
    }

    /**
    * Process the instruction, optionally returning an uncompleted tail call to
    * be invoked by the caller
    * @param context The dynamic context, giving access to the current node,
    * the current variables, etc.
    */

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        process(context);
        return null;
    }


    /**
    * Get data type of items in sequence returned by expression
    */

    public ItemType getItemType() {
        return Type.getCommonSuperType(thenExp.getItemType(), elseExp.getItemType());
    }

    /**
    * Determine the static cardinality of the result
    */

    public int computeCardinality() {
        return Cardinality.union(thenExp.getCardinality(), elseExp.getCardinality());
    }

    /**
    * Get the static properties of this expression (other than its type). The result is
    * bit-signficant. These properties are used for optimizations. In general, if
    * property bit is set, it is true, but if it is unset, the value is unknown.
    */

    public int computeSpecialProperties() {
        // return the properties that are shared by both subexpressions
        return thenExp.getSpecialProperties() & elseExp.getSpecialProperties();
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "if (");
        condition.display(level+1, pool);
        System.err.println(ExpressionTool.indent(level) + "then");
        thenExp.display(level+1, pool);
        System.err.println(ExpressionTool.indent(level) + "else");
        elseExp.display(level+1, pool);
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
