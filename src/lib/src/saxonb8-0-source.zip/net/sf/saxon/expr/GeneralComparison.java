package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.*;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.sort.CodepointCollator;
import net.sf.saxon.sort.AtomicComparer;
import net.sf.saxon.functions.Position;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.Type;
import net.sf.saxon.pattern.NodeTest;

import java.util.Comparator;



/**
* GeneralComparison: a boolean expression that compares two expressions
* for equals, not-equals, greater-than or less-than. This implements the operators
* =, !=, <, >, etc.
*/

public class GeneralComparison extends BinaryExpression {

    private int singletonOperator;
    private AtomicComparer comparer;
    private boolean backwardsCompatible = false;

    // TODO: collations don't survive compilation

    /**
    * Create a relational expression identifying the two operands and the operator
    * @param p0 the left-hand operand
    * @param op the operator, as a token returned by the Tokenizer (e.g. Tokenizer.LT)
    * @param p1 the right-hand operand
    */

    public GeneralComparison(Expression p0, int op, Expression p1) {
        super(p0, op, p1);
    }

    public void setDetails(Expression p0, int op, Expression p1) {
        super.setDetails(p0, op, p1);
        singletonOperator = getSingletonOperator(op);
    }

    /**
    * Determine the static cardinality. Returns [1..1]
    */

    public int computeCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    /**
    * Type-check the expression
    * @return the checked expression
    */

    public Expression analyze(StaticContext env) throws XPathException {

        backwardsCompatible = env.isInBackwardsCompatibleMode();

        operands[0] = operands[0].analyze(env);
        operands[1] = operands[1].analyze(env);

        // Neither operand needs to be sorted

        operands[0] = ExpressionTool.unsorted(operands[0], false);
        operands[1] = ExpressionTool.unsorted(operands[1], false);

        // Check for compatibility with XPath 1.0 rules

        if (backwardsCompatible) {
            issueWarnings(operands[0].getItemType(), operands[1].getItemType(), env);
        }

        SequenceType atomicType = SequenceType.ATOMIC_SEQUENCE;

        RoleLocator role0 = new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 0);
        operands[0] = TypeChecker.staticTypeCheck(operands[0], atomicType, false, role0);

        RoleLocator role1 = new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 1);
        operands[1] = TypeChecker.staticTypeCheck(operands[1], atomicType, false, role1);

        ItemType t0 = operands[0].getItemType();
        ItemType t1 = operands[1].getItemType();

        int c0 = operands[0].getCardinality();
        int c1 = operands[1].getCardinality();

        if (!backwardsCompatible) {
            if (t0 == Type.ANY_ATOMIC_TYPE || t0 == Type.UNTYPED_ATOMIC_TYPE ||
                    t1 == Type.ANY_ATOMIC_TYPE || t1 == Type.UNTYPED_ATOMIC_TYPE ) {
                // then no static type checking is possible
            } else {
                int pt0 = t0.getPrimitiveType();
                int pt1 = t1.getPrimitiveType();
                if (pt0 != pt1 &&
                    !(Type.isSubType(t0, Type.NUMBER_TYPE) &&
                        Type.isSubType(t1, Type.NUMBER_TYPE))) {
                    throw new XPathException.Type("Cannot compare " + t0.toString() + " to " + t1.toString());
                }
            }
        }

        if (c0 == StaticProperty.EXACTLY_ONE &&
            c1 == StaticProperty.EXACTLY_ONE &&
                (!backwardsCompatible || t0==t1)) {

            // Use a value comparison if both arguments are singletons

            Expression e0 = operands[0];
            Expression e1 = operands[1];

            if (t0==Type.UNTYPED_ATOMIC_TYPE) {
                if (t1==Type.UNTYPED_ATOMIC_TYPE) {
                    e0 = new CastExpression(operands[0], Type.STRING_TYPE, false);
                    e1 = new CastExpression(operands[1], Type.STRING_TYPE, false);
                } else if (Type.isSubType(t1, Type.NUMBER_TYPE)) {
                    e0 = new CastExpression(operands[0], Type.DOUBLE_TYPE, false);
                } else {
                    e0 = new CastExpression(operands[0],
                                            (AtomicType)t1,
                                            false);
                }
            } else if (t1==Type.UNTYPED_ATOMIC_TYPE) {
                if (Type.isSubType(t0, Type.NUMBER_TYPE)) {
                    e1 = new CastExpression(operands[1], Type.DOUBLE_TYPE, false);
                } else {
                    e1 = new CastExpression(operands[1],
                                            (AtomicType)t0,
                                            false);
                }
            }

            return new ValueComparison(e0, singletonOperator, e1).simplify().analyze(env);
        }

        Comparator comp = env.getCollation(env.getDefaultCollationName());
        if (comp==null) comp = CodepointCollator.getInstance();
        comparer = new AtomicComparer(comp);

        // Check if neither argument allows a sequence of >1

        if (!Cardinality.allowsMany(c0) && !Cardinality.allowsMany(c1)) {

            // Use a singleton comparison if both arguments are singletons

            SingletonComparison sc = new SingletonComparison(operands[0], singletonOperator, operands[1]);
            sc.setComparator(comparer);
            return sc.analyze(env);
        }

        // see if second argument is a singleton...

        if (!Cardinality.allowsMany(c0)) {

            // if first argument is a singleton, reverse the arguments
            //ManyToOneComparison mc = new ManyToOneComparison(operands[1], Value.inverse(singletonOperator), operands[0]);
            GeneralComparison mc = new GeneralComparison(operands[1], Value.inverse(operator), operands[0]);
            mc.comparer = comparer;
            return mc.analyze(env);
        }

        // look for (N to M = I)

        if (operands[0] instanceof RangeExpression &&
                Type.isSubType(operands[1].getItemType(), Type.INTEGER_TYPE) &&
                !Cardinality.allowsMany(operands[1].getCardinality())) {
            Expression min = ((RangeExpression)operands[0]).operands[0];
            Expression max = ((RangeExpression)operands[0]).operands[1];
            if (operands[1] instanceof Position &&
                    min instanceof IntegerValue &&
                    max instanceof IntegerValue) {
                return new PositionRange((int)((IntegerValue)min).getValue(),
                                        (int)((IntegerValue)max).getValue());
            } else {
                return new IntegerRangeTest(operands[1], min, max);
            }
        }

        // If the operator is gt, ge, lt, le then replace X < Y by min(X) < max(Y)

        // This optimization is done only in the case where at least one of the
        // sequences is known to be purely numeric. It isn't safe if both sequences
        // contain untyped atomic values, because in that case, the type of the
        // comparison isn't known in advance. For example [(1, U1) < ("fred", U2)]
        // involves both string and numeric comparisons.


        if (operator != Tokenizer.EQUALS && operator != Tokenizer.NE &&
                (Type.isSubType(t0, Type.NUMBER_TYPE) || Type.isSubType(t1, Type.NUMBER_TYPE))) {

            Expression e0 = operands[0];
            if (!Type.isSubType(t0, Type.NUMBER_TYPE)) {
                if (backwardsCompatible) {
                    e0 = new AtomicSequenceConverter(e0, Type.DOUBLE_TYPE);
                    // TODO: the Nov 2003 spec says the value is cast to a double
                    // which is what this does; but it should really convert using the
                    // number() function to be backwards compatible.
                } else {
                    e0 = TypeChecker.staticTypeCheck(e0, SequenceType.NUMERIC_SEQUENCE,
                            backwardsCompatible,
                            new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 0));
                }
            }
            Expression e1 = operands[1];
            if (!Type.isSubType(t1, Type.NUMBER_TYPE)) {
                if (backwardsCompatible) {
                    e1 = new AtomicSequenceConverter(e1, Type.DOUBLE_TYPE);
                } else {
                    e1 = TypeChecker.staticTypeCheck(e1, SequenceType.NUMERIC_SEQUENCE,
                            backwardsCompatible,
                            new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 1));
                }
            }
            MinimaxComparison mc = new MinimaxComparison(e0, operator, e1);
//            mc.setComparator(comparer);
            return mc.analyze(env);

        }


        // evaluate the expression now if both arguments are constant

        if ((operands[0] instanceof Value) && (operands[1] instanceof Value)) {
            return (AtomicValue)evaluateItem(null);
        }

        return this;
    }

    /**
    * Issue warnings about backwards compatibility
    */

    private void issueWarnings(ItemType t1, ItemType t2, StaticContext env) {

        // System.err.println("Check " + Type.getTypeName(t1) + " op " + Type.getTypeName(t2));

        if (t1 instanceof NodeTest && t2.getPrimitiveType() == Type.BOOLEAN) {
            env.issueWarning("Comparison of a node-set to a boolean has changed since XPath 1.0");
        }

        if (t1.getPrimitiveType() == Type.BOOLEAN && t2 instanceof NodeTest) {
            env.issueWarning("Comparison of a boolean to a node-set has changed since XPath 1.0");
        }

        if ((t1 instanceof NodeTest || t1.getPrimitiveType() == Type.STRING) &&
            (t2 instanceof NodeTest || t2.getPrimitiveType() == Type.STRING) &&
            (operator==Tokenizer.LT || operator==Tokenizer.LE || operator==Tokenizer.GT || operator==Tokenizer.GE )) {
            env.issueWarning("Less-than and greater-than comparisons between strings have changed since XPath 1.0");
        }
    }

    /**
    * Evaluate the expression in a given context
    * @param context the given context for evaluation
    * @return a BooleanValue representing the result of the numeric comparison of the two operands
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        return BooleanValue.get(effectiveBooleanValue(context));
    }

    /**
    * Evaluate the expression in a boolean context
    * @param context the given context for evaluation
    * @return a boolean representing the result of the numeric comparison of the two operands
    */

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {

        SequenceIterator iter1 = operands[0].iterate(context);
        SequenceIterator iter2 = operands[1].iterate(context);

        // TODO: We're resorting to a nested loop comparison here. This is
        // because the hash-join approach failed in the presence of untyped or
        // mixed-type data, e.g. (U, U, U) = (1, "paris"). Reinstate the hash-join
        // for cases where it's safe.

        SequenceExtent seq2 = new SequenceExtent(iter2);
                // we choose seq2 because it's more likely to be a singleton
        int count2 = seq2.getLength();

        if (count2 == 0) {
            return false;
        }

        if (count2 == 1) {
            AtomicValue s2 = (AtomicValue)seq2.itemAt(0);
            while (true) {
                AtomicValue s1 = (AtomicValue)iter1.next();
                if (s1 == null) break;
                try {
                    if (compare(s1, singletonOperator, s2, comparer, backwardsCompatible)) {
                        return true;
                    }
                } catch (XPathException.Type e) {
                    // re-throw the exception with location information added
                    typeError(e.getMessage());
                }
            }
            return false;
        }

        while (true) {
            AtomicValue s1 = (AtomicValue)iter1.next();
            if (s1 == null) break;
            SequenceIterator e2 = seq2.iterate(null);
            while (true) {
                AtomicValue s2 = (AtomicValue)e2.next();
                if (s2 == null) break;
                try {
                    if (compare(s1, singletonOperator, s2, comparer, backwardsCompatible)) {
                        return true;
                    }
                } catch (XPathException.Type e) {
                    // re-throw the exception with location information added
                    typeError(e.getMessage());
                }
            }
        }

        return false;

/*
            // first identify a primitive type that can be used as the basis for all comparisons.

            // TODO: reinstate hash-join logic for cases where it works

            int count1 = 0;
            int count2 = 0;

            int commonType = Type.ATOMIC;
            while(iter1.hasNext()) {
                AtomicValue val = (AtomicValue)iter1.next();
                count1++;
                int type = val.getItemType();
                if (type == Type.UNTYPED_ATOMIC) {
                    // do nothing
                } else if (Type.isSubType(type, commonType)) {
                    commonType = type;
                } else {
                    throw new XPathException.Dynamic("Types are not comparable: " + Type.getTypeName(commonType) +
                                                 " and " + Type.getTypeName(type));
                }
            }

            while(iter2.hasNext()) {
                AtomicValue val = (AtomicValue)iter2.next();
                count2++;
                int type = val.getItemType();
                if (type == Type.UNTYPED_ATOMIC) {
                    // do nothing
                } else if (Type.isSubType(type, commonType)) {
                    commonType = type;
                } else {
                    throw new XPathException.Dynamic("Types are not comparable: " + Type.getTypeName(commonType) +
                                                 " and " + Type.getTypeName(type));
                }
            }

            if (count1 < count2) {
                iter1 = iter1.getAnother();
                iter2 = iter2.getAnother();
            } else {
                SequenceIterator temp = iter2.getAnother();
                iter2 = iter1.getAnother();
                iter1 = temp;
            }

            // TO DO: if either count is 1, handle it specially

            AtomicComparer gc = (AtomicComparer)comparer;    // eh?

            // Use a hash join based on the collation keys

            HashSet table = new HashSet();
            while (iter1.hasNext()) {
                AtomicValue val = (AtomicValue)iter1.next();
                if (val instanceof UntypedAtomicValue) {
                    val = val.convert(commonType);
                }
                table.add(gc.getComparisonKey(val));
            }
            while (iter2.hasNext()) {
                AtomicValue val = (AtomicValue)iter2.next();
                if (val instanceof UntypedAtomicValue) {
                    val = val.convert(commonType);
                }
                if (table.contains(gc.getComparisonKey(val))) {
                    return true;
                }
            }
            return false;
*/



    }

    /**
    * Compare two atomic values
    */

    protected static boolean compare(AtomicValue a1, int operator, AtomicValue a2,
                                    AtomicComparer comparer, boolean backwardsCompatible) throws XPathException {

        AtomicValue v1 = a1;
        AtomicValue v2 = a2;
        if (a1 instanceof UntypedAtomicValue) {
            if (a2 instanceof NumericValue) {
                v1 = a1.convert(Type.DOUBLE);
            } else if (a2 instanceof UntypedAtomicValue) {
                // the spec says convert it to a string, but this doesn't affect the outcome
            } else {
                v1 = a1.convert(a2.getItemType().getPrimitiveType());
            }
        }
        if (a2 instanceof UntypedAtomicValue) {
            if (a1 instanceof NumericValue) {
                v2 = a2.convert(Type.DOUBLE);
            } else if (a1 instanceof UntypedAtomicValue) {
                // the spec says convert it to a string, but this doesn't affect the outcome
            } else {
                v2 = a2.convert(a1.getItemType().getPrimitiveType());
            }
        }
        if (backwardsCompatible) {
            if (v1 instanceof NumericValue || v2 instanceof NumericValue) {
                v1 = v1.convert(Type.DOUBLE);
                v2 = v2.convert(Type.DOUBLE);
            }
        }
        return ValueComparison.compare(v1, operator, v2, comparer);
    }

    /**
    * Determine the data type of the expression
    * @return Type.BOOLEAN
    */

    public ItemType getItemType() {
        return Type.BOOLEAN_TYPE;
    }

    /**
    * Return the singleton form of the comparison operator, e.g. FEQ for EQUALS, FGT for GT
    */

    private static int getSingletonOperator(int op) {
        switch (op) {
            case Tokenizer.EQUALS:
                return Tokenizer.FEQ;
            case Tokenizer.GE:
                return Tokenizer.FGE;
            case Tokenizer.NE:
                return Tokenizer.FNE;
            case Tokenizer.LT:
                return Tokenizer.FLT;
            case Tokenizer.GT:
                return Tokenizer.FGT;
            case Tokenizer.LE:
                return Tokenizer.FLE;
            default:
                return op;
        }
    }


    protected String displayOperator() {
        return "many-to-many " + super.displayOperator();
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
