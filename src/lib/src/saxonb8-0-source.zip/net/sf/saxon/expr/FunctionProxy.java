package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.*;
import net.sf.saxon.style.StandardNames;
import net.sf.saxon.pattern.AnyNodeTest;
import net.sf.saxon.pattern.NodeTest;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AnyItemType;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.BuiltInSchemaFactory;
import net.sf.saxon.type.ExternalObjectType;
import net.sf.saxon.value.*;
import net.sf.saxon.event.Builder;
import net.sf.saxon.om.NamespaceConstant;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.EmptyIterator;
import net.sf.saxon.event.Sender;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import java.lang.reflect.*;
import java.math.BigInteger;
import java.math.BigDecimal;

import org.w3c.dom.*;



/**
* This class acts as a proxy for an extension function defined as a method
* in a user-defined class
*/

public class FunctionProxy extends FunctionCall {

    private Class theClass;
    private transient ArrayList candidateMethods = new ArrayList();
    private XPathException theException = null;
    private String name;
    private Class resultClass = null;
    public Configuration config;
    private boolean debug = false;
    private boolean usesFocus = false;

    // TODO (performance): the candidateMethods array is transient, because the underlying Java objects
    // are not serializable. This means that in a compiled stylesheet that uses extension functions, all
    // the work of identifying the candidate methods has to be done again, at run-time. Moreover, the
    // relevant data is updated on first use of the executable, which is dubious practice from the
    // point of view of thread-safety, though probably OK because the result should be the same each
    // time.

    /**
    * Constructor: creates an uncommitted FunctionProxy
    */

    public FunctionProxy() {}

    /**
     * Set the configuration
     */

    public void setConfiguration(Configuration config) {
        this.config = config;
        debug = config.isTraceExternalFunctions();
    }

    /**
    * setFunctionName: locates the external class and the method (or candidate methods)
    * to which this function relates. At this
    * stage addArguments() will have normally been called, so the number of arguments is known. If no
    * method of the required name is located, an exception is saved, but it is not thrown until
    * an attempt is made to evaluate the function. All methods that match the required number of
    * arguments are saved in a list (candidateMethods), a decision among these methods is made
    * at run-time when the types of the actual arguments are known.<p>
    * The method is also used while calling
    * function-available(). In this case the number of arguments is not known (it will be
    * set to zero). We return true if a match was found, regardless of the number of arguments.
    * @param reqClass The Java class name
    * @param localName The local name used in the XPath function call
     * @param numArgs The number of arguments in the function call. -1 indicates unknown;
     * this is used during a call on function-available() with no second argument
	* @return true if the function is available (with some number of arguments).
    */

    public boolean setFunctionName(Class reqClass, String localName, int numArgs) {
    	boolean isAvailable = false;
    	if (debug) {
    	    System.err.println("Looking for method " + localName + " in Java class " + reqClass);
    	    System.err.println("Number of actual arguments = " + numArgs);
    	}

        name = localName;
        //int numArgs = getNumberOfArguments();
        int significantArgs = numArgs;

        theClass = reqClass;

        // if the method name is "new", look for a matching constructor

        if (name.equals("new")) {

        	if (debug) {
    	        System.err.println("Looking for a constructor");
    	    }

            int mod = theClass.getModifiers();
            if (Modifier.isAbstract(mod)) {
                theException = new XPathException.Static("Class " + theClass + " is abstract");
            } else if (Modifier.isInterface(mod)) {
                theException = new XPathException.Static(theClass + " is an interface");
            } else if (Modifier.isPrivate(mod)) {
                theException = new XPathException.Static("Class " + theClass + " is private");
            } else if (Modifier.isProtected(mod)) {
                theException = new XPathException.Static("Class " + theClass + " is protected");
            }

            if (theException != null) {
            	if (debug) {
        	        System.err.println("Cannot construct an instance: " + theException.getMessage());
        	    }
        	    return false;
        	}

            resultClass = theClass;
            Constructor[] constructors = theClass.getConstructors();
            for (int c=0; c<constructors.length; c++) {
                Constructor theConstructor = constructors[c];
            	isAvailable |= (numArgs==-1 || numArgs==theConstructor.getParameterTypes().length);
            	if (debug) {
        	        System.err.println("Found a constructor with " + theConstructor.getParameterTypes().length + " arguments");
        	    }
                if (theConstructor.getParameterTypes().length == numArgs) {
                    candidateMethods.add(theConstructor);
                }
            }
            if (isAvailable) {
                return true;
            } else {
                theException = new XPathException.Static("No constructor with " + numArgs +
                                 (numArgs==1 ? " parameter" : " parameters") +
                                  " found in class " + theClass.getName());
            	if (debug) {
        	        System.err.println(theException.getMessage());
        	    }
                return false;
            }
        } else {

            // convert any hyphens in the name, camelCasing the following character

            if (name.indexOf('-') >= 0) {
                StringBuffer buff = new StringBuffer();
                boolean afterHyphen = false;
                for (int n=0; n<name.length(); n++) {
                    char c = name.charAt(n);
                    if (c=='-') {
                        afterHyphen = true;
                    } else {
                        if (afterHyphen) {
                            buff.append(Character.toUpperCase(c));
                        } else {
                            buff.append(c);
                        }
                        afterHyphen = false;
                    }
                }
        	    name = buff.toString();
                if (debug) {
        	        System.err.println("Seeking a method with adjusted name " + name);
        	    }
            }

            // look through the methods of this class to find one that matches the local name

            Method[] methods = theClass.getMethods();
            boolean consistentReturnType = true;
            for (int m=0; m<methods.length; m++) {

                Method theMethod = methods[m];

                if (debug) {
                    if (theMethod.getName().equals(name)) {
        	            System.err.println("Trying method " + theMethod.getName() + ": name matches");
        	            if (!Modifier.isPublic(theMethod.getModifiers())) {
        	                System.err.println(" -- but the method is not public");
        	            }
        	        } else {
        	            System.err.println("Trying method " + theMethod.getName() + ": name does not match");
        	        }
        	    }

				if (theMethod.getName().equals(name) &&
				        Modifier.isPublic(theMethod.getModifiers())) {

                    if (numArgs == -1) {
                        isAvailable = true;
                    }
					if (consistentReturnType) {
					    if (resultClass==null) {
					        resultClass = theMethod.getReturnType();
					    } else {
					        consistentReturnType =
					            (theMethod.getReturnType()==resultClass);
					    }
					}
                    Class[] theParameterTypes = theMethod.getParameterTypes();
                    boolean isStatic = Modifier.isStatic(theMethod.getModifiers());

                    // if the method is not static, the first supplied argument is the instance, so
                    // discount it

                    if (debug) {
                        System.err.println("Method is " + (isStatic ? "" : "not ") + "static");
                    }

                    significantArgs = (isStatic ? numArgs : numArgs - 1);

                    if (significantArgs>=0) {

                        if (debug) {
                            System.err.println("Method has " + theParameterTypes.length + " argument" +
                                        (theParameterTypes.length==1?"":"s") +
                                        "; expecting " + significantArgs);
                        }

                        if (theParameterTypes.length == significantArgs &&
                                (significantArgs==0 || theParameterTypes[0]!=XPathContext.class))
                        {
                            if (debug) {
                                System.err.println("Found a candidate method:");
                                System.err.println("    " + theMethod);
                            }
                            isAvailable = true;
                            candidateMethods.add(theMethod);
                        }

                        // we allow the method to have an extra parameter if the first parameter is XPathContext

                        if (theParameterTypes.length == significantArgs+1 &&
                                theParameterTypes[0]==XPathContext.class ) {
                            if (debug) {
                                System.err.println("Method is a candidate because first argument is XPathContext");
                            }
                            isAvailable = true;
                            candidateMethods.add(theMethod);
                            usesFocus = true;
                                // we set usesFocus if any one of the candidate methods has an XPathContext argument
                        }
                    }
                }
            }

            // Code added by GS -- start

            // look through the fields of this class to find those that matches the local name

            Field[] fields = theClass.getFields();
            for (int m=0; m<fields.length; m++) {

                Field theField = fields[m];

                if (debug) {
                    if (theField.getName().equals(name)) {
                        System.err.println("Trying field " + theField.getName() + ": name matches");
                        if (!Modifier.isPublic(theField.getModifiers())) {
                            System.err.println(" -- but the field is not public");
                        }
                    } else {
                        System.err.println("Trying field " + theField.getName() + ": name does not match");
                    }
                }

                if (theField.getName().equals(name) &&
                        Modifier.isPublic(theField.getModifiers())) {
                    if (numArgs == -1) {
                        isAvailable = true;
                    }
                    if (consistentReturnType) {
                        if (resultClass==null) {
                            resultClass = theField.getType();
                        } else {
                            consistentReturnType =
                                (theField.getType()==resultClass);
                        }
                    }
                    boolean isStatic = Modifier.isStatic(theField.getModifiers());

                    // if the field is not static, the first supplied argument is the instance, so
                    // discount it

                    if (debug) {
                        System.err.println("Field is " + (isStatic ? "" : "not ") + "static");
                    }

                    significantArgs = (isStatic ? numArgs : numArgs - 1);

                    if (significantArgs==0) {
                        if (debug) {
                            System.err.println("Found a candidate field:");
                            System.err.println("    " + theField);
                        }
                        isAvailable = true;
                        candidateMethods.add(theField);
                    }
                }
            }

            // End of code added by GS

            if (!consistentReturnType) {
                resultClass = null;     // different return type from different methods
            }

            // No method found?

            if (isAvailable) {
                return true;
            } else {
                theException = new XPathException.Static("No method or field matching " + name +
                                     " with " + numArgs +
                                     (numArgs==1 ? " parameter" : " parameters") +
                                      " found in class " + theClass.getName());
                if (debug) {
                    System.err.println(theException.getMessage());
                }
                return false;
            }
        }

    }

    /**
    * preEvaluate: this method suppresses compile-time evaluation by doing nothing
    * (because the external function might have side-effects and might use the context)
    */

    public Expression preEvaluate(StaticContext env) {
        return this;
    }


    /**
    * Method called by the expression parser when all arguments have been supplied
    */

    public void checkArguments(StaticContext env) throws XPathException {
        // TODO: could use this for early resolution...
    }

    /**
    * Determine the data type of the expression, if possible
    * @return the return type of the function, if known in advance, or ITEM otherwise
    */

    public ItemType getItemType() {
        if (resultClass==null || resultClass==Value.class) {
            return AnyItemType.getInstance();
        } else if (resultClass.toString().equals("void")) {
            return AnyItemType.getInstance();
        } else if (resultClass==String.class || resultClass==StringValue.class) {
            return Type.STRING_TYPE;
        } else if (resultClass==Boolean.class || resultClass==boolean.class ||
                    resultClass==BooleanValue.class) {
            return Type.BOOLEAN_TYPE;
        } else if (resultClass==Double.class || resultClass==double.class || resultClass==DoubleValue.class) {
            return Type.DOUBLE_TYPE;
        } else if ( resultClass==Float.class || resultClass==float.class || resultClass==FloatValue.class) {
            return Type.FLOAT_TYPE;
        } else if ( resultClass==Long.class || resultClass==long.class ||
                    resultClass==IntegerValue.class || resultClass==BigIntegerValue.class ||
                    resultClass==Integer.class || resultClass==int.class ||
                    resultClass==Short.class || resultClass==short.class ||
                    resultClass==Byte.class || resultClass==byte.class ) {
            return Type.INTEGER_TYPE;
        } else if (SequenceValue.class.isAssignableFrom(resultClass) ||
                    SequenceIterator.class.isAssignableFrom(resultClass)) {
            return AnyItemType.getInstance();
        } else if ( NodeList.class.isAssignableFrom(resultClass) ||
                    NodeInfo.class.isAssignableFrom(resultClass) ||
                    Node.class.isAssignableFrom(resultClass) ||
                    Source.class.isAssignableFrom(resultClass)) {
            return AnyNodeTest.getInstance();
            // we could be more specific regarding the kind of node
        } else {
            return AnyItemType.getInstance();
        }
    }

    /**
    * Determine the cardinality of the result. Try to work it out from
    * the result class of the Java method.
    */

    public int computeCardinality() {
        if (resultClass==null) {
            // we don't know yet
            return StaticProperty.ALLOWS_ZERO_OR_MORE;
        }
        if (SequenceValue.class.isAssignableFrom(resultClass) ||
                    SequenceIterator.class.isAssignableFrom(resultClass) ||
                    NodeList.class.isAssignableFrom(resultClass) ||
                    List.class.isAssignableFrom(resultClass) ||
                    Closure.class.isAssignableFrom(resultClass)||
                    Source.class.isAssignableFrom(resultClass)) {
            return StaticProperty.ALLOWS_ZERO_OR_MORE;
        } else if (resultClass.isPrimitive()) {
            if (resultClass.equals(Void.TYPE)) {
                // this always returns an empty sequence, but we'll model it as
                // zero or one
                return StaticProperty.ALLOWS_ZERO_OR_ONE;
            } else {
                // return type = int, boolean, char etc
                return StaticProperty.EXACTLY_ONE;
            }
        } else {
            return StaticProperty.ALLOWS_ZERO_OR_ONE;
        }
    }

    /**
    * Get the name of the function
    */

    public String getName() {
        return name;
    }

    /**
    * Type-check the function call. This binds to the actual
    * Java method if possible.
    */

    public Expression analyze(StaticContext env) throws XPathException {
        super.analyze(env);

        if (debug) {
            System.err.println("Attempting to bind method for external function " + name);
        }

        // if the data type of all arguments is known at compile time,
        // we can choose the method now

        if (candidateMethods.size() > 1) {
            boolean allKnown = true;
            for (int i=0; i<getNumberOfArguments(); i++) {
                ItemType type = argument[i].getItemType();
                if (type==Type.ANY_ATOMIC_TYPE || type instanceof ExternalObjectType ||
                        type==Type.ITEM_TYPE || Type.isNodeType(type)) {
                    // TODO: also consider whether the values are singular or not
                    allKnown = false;
                    break;
                }
            }

            if (allKnown) {
                // set up some dummy arguments: only the data type matters
                Value[] argValues = new Value[getNumberOfArguments()];
                for (int k=0; k<getNumberOfArguments(); k++) {
                    // TODO: also consider whether the argument is a sequence
                    ItemType a = (argument[k].getItemType());
                    if (a == Type.BOOLEAN_TYPE) {
                        argValues[k] = BooleanValue.TRUE;
                    } else if (a == Type.DECIMAL_TYPE) {
                        argValues[k] = new DecimalValue("1.0");
                    } else if (a == Type.INTEGER_TYPE) {
                        argValues[k] = new IntegerValue(1);
                    } else if (a == Type.FLOAT_TYPE) {
                        argValues[k] = new FloatValue((float)1.0);
                    } else if (a == Type.DOUBLE_TYPE) {
                        argValues[k] = new DoubleValue(1.0);
                    } else if (a == Type.STRING_TYPE) {
                        argValues[k] = StringValue.EMPTY_STRING;
                    } else if (a instanceof NodeTest) {
                        argValues[k] = new SingletonNode(null);
                    }
                }
                try {
                    AccessibleObject method = getBestFit(argValues);
                    candidateMethods = new ArrayList();
                    candidateMethods.add(method);
                } catch (XPathException err) {
                    theException = err;
                }
            }
        }
        if (debug) {
            int n = candidateMethods.size();
            System.err.println("There " + (n==1?"is ":"are ") + n + " candidate method" + (n==1?"":"s"));
        }
        return this;
    }

     /**
    * Determine which aspects of the context the expression depends on. The result is
    * a bitwise-or'ed value composed from constants such as XPathContext.VARIABLES and
    * XPathContext.CURRENT_NODE
    */

    public int getIntrinsicDependencies() {
        if (usesFocus) {
            return StaticProperty.DEPENDS_ON_CONTEXT_ITEM | StaticProperty.DEPENDS_ON_POSITION | StaticProperty.DEPENDS_ON_LAST;
        } else {
            return 0;
        }
    }

    /**
    * Get the best fit amongst all the candidate methods, constructors, or fields
    * @return the result is either a Method or a Constructor or a Field.
    */

    public AccessibleObject getBestFit(Value[] argValues) throws XPathException {

        if (candidateMethods==null) {
            // This happens when loading a compiled stylesheet. Method references are not serializable,
            // so we have to recompute the list of candidate methods on reloading
            candidateMethods = new ArrayList();
            setFunctionName(theClass, name, argValues.length);
        }

        int candidates = candidateMethods.size();
        if (candidates == 0) {
            dynamicError("There is no suitable method matching the arguments of function " + name);
            return null;
        }

        if (candidates == 1) {
            // short cut: there is only one candidate method
            return (AccessibleObject)candidateMethods.get(0);

        } else {
            // choose the best fit method or constructor or field
            // for each pair of candidate methods, eliminate either or both of the pair
            // if one argument is less-preferred

            if (debug) {
                System.err.println("Finding best fit method for " + name + " with arguments:");
                for (int v=0; v<argValues.length; v++) {
                    argValues[v].display(10, null);
                }
            }

            boolean eliminated[] = new boolean[candidates];
            for (int i=0; i<candidates; i++) {
                eliminated[i] = false;
            }

            if (debug) {
                for (int i=0; i<candidates; i++) {
                    int[] pref_i = getConversionPreferences(
                                        argValues,
                                        candidateMethods.get(i));
                    System.err.println("Trying option " + i + ": " + candidateMethods.get(i).toString());
                    String prefs = "[";
                    for (int p=0; p<pref_i.length; p++) {
                        if (p!=0) prefs += ", ";
                        prefs += pref_i[p];
                    }
                    prefs += "]";
                    System.err.println("Conversion preferences are " + prefs);
                }
            }

            for (int i=0; i<candidates-1; i++) {
                int[] pref_i = getConversionPreferences(
                                    argValues,
                                    candidateMethods.get(i));

                if (!eliminated[i]) {
                    for (int j=i+1; j<candidates; j++) {
                        if (!eliminated[j]) {
                            int[] pref_j = getConversionPreferences(
                                            argValues,
                                            candidateMethods.get(j));
                            for (int k=0; k<pref_j.length; k++) {
                                if (pref_i[k] > pref_j[k] && !eliminated[i]) { // high number means less preferred
                                    eliminated[i] = true;
                                    if (debug) {
                                        System.err.println("Eliminating option " + i);
                                    }
                                }
                                if (pref_i[k] < pref_j[k] && !eliminated[j]) {
                                    eliminated[j] = true;
                                    if (debug) {
                                        System.err.println("Eliminating option " + j);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            int remaining = 0;
            AccessibleObject theMethod = null;
            for (int r=0; r<candidates; r++) {
                if (!eliminated[r]) {
                    theMethod = (AccessibleObject)candidateMethods.get(r);
                    remaining++;
                }
            }

            if (debug) {
                System.err.println("Number of candidate methods remaining: " + remaining);
            }

            if (remaining==0) {
                dynamicError("There are " + candidates + " candidate Java methods matching function " + name + ", but none is a unique best match");
                return null;
            }

            if (remaining>1) {
                dynamicError("There are several Java methods that match function " + name + " equally well");
                return null;
            }

            return theMethod;
        }
    }

    /**
    * Evaluate the function. <br>
    * @param context The context in which the function is to be evaluated
    * @return a Value representing the result of the function.
    * @throws XPathException if the function cannot be evaluated.
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        Object result = call(context);
        if (result==null) {
            return null;
        }
        Value actual = convertJavaObjectToXPath(result, context.getController());
        return Value.asItem(actual, context);
    }

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        if (resultClass==SequenceIterator.class) {
            return (SequenceIterator)call(context);
        } else {
            Object result = call(context);
            if (result==null) {
                return EmptyIterator.getInstance();
            }
            Value actual = convertJavaObjectToXPath(result, context.getController());
            return actual.iterate(context);
        }
    }

    /**
    * Call the external function and return its result as a Java object
    */

    private Object call(XPathContext context) throws XPathException {

        // Fail now if no method was found

        if (theException!=null) {
            throw theException;
        }

        Value[] argValues = new Value[getNumberOfArguments()];
        for (int a=0; a<getNumberOfArguments(); a++) {
            argValues[a] = ExpressionTool.lazyEvaluate(argument[a], context);
        }

        // find the best fit method

        AccessibleObject theMethod = getBestFit(argValues);

        if(debug) {
            System.err.println("Calling extension function " + theMethod);
        }

        // now call it

        Class[] theParameterTypes;

        if (theMethod instanceof Constructor) {
            Constructor constructor = (Constructor)theMethod;
            theParameterTypes = constructor.getParameterTypes();
            Object[] params = new Object[theParameterTypes.length];

            setupParams(argValues, params, theParameterTypes, 0, 0);

            try {
                Object obj = constructor.newInstance(params);
                return obj;
                //return new ObjectValue(obj);
            } catch (InstantiationException err0) {
                throw new XPathException.Dynamic ("Cannot instantiate class", err0);
            } catch (IllegalAccessException err1) {
                throw new XPathException.Dynamic ("Constructor access is illegal", err1);
            } catch (IllegalArgumentException err2) {
                throw new XPathException.Dynamic ("Argument is of wrong type", err2);
            } catch (NullPointerException err2) {
                throw new XPathException.Dynamic ("Object is null");
            } catch (InvocationTargetException err3) {
                Throwable ex = err3.getTargetException();
                if (ex instanceof XPathException) {
                    throw (XPathException)ex;
                } else {
                	if (debug || context.getController().isTracing()) {
                		err3.getTargetException().printStackTrace();
                	}
                    throw new XPathException.Dynamic ("Exception in extension function " + getName() + ": " +
                                            err3.getTargetException().toString(), ex);
                }
            }
        } else if (theMethod instanceof Method) {
            Method method = (Method)theMethod;
            boolean isStatic = Modifier.isStatic(method.getModifiers());
            Object theInstance;
            theParameterTypes = method.getParameterTypes();
            boolean usesContext = theParameterTypes.length > 0 &&
                                  (theParameterTypes[0] == XPathContext.class );
            if (isStatic) {
                theInstance = null;
            } else {
                int actualArgs = getNumberOfArguments();
                if (actualArgs==0) {
                    dynamicError("Must supply an argument for an instance-level extension function");
                    return null;
                }
                Value arg0 = argValues[0];
                theInstance = arg0.convertToJava(theClass, config);
                // this fails if the first argument is not of a suitable class
            }

            int requireArgs = theParameterTypes.length -
                                 (usesContext ? 1 : 0) +
                                 (isStatic ? 0 : 1);

            checkArgumentCount(requireArgs, requireArgs);
            Object[] params = new Object[theParameterTypes.length];

            if (usesContext) {
                params[0] = context;
            }

            setupParams(argValues, params, theParameterTypes,
                            (usesContext ? 1 : 0),
                            (isStatic ? 0 : 1)
                        );

            try {
                Object result = method.invoke(theInstance, params);
                //if (context.getException() != null) {
                //    throw context.getException();
                //}
                if (method.getReturnType().toString().equals("void")) {
                    // method returns void:
                    // tried (method.getReturnType()==Void.class) unsuccessfully
                    return EmptySequence.getInstance();
                }
                return result;

            } catch (IllegalAccessException err1) {
                throw new XPathException.Dynamic ("Method access is illegal", err1);
            } catch (IllegalArgumentException err2) {
                throw new XPathException.Dynamic ("Argument is of wrong type", err2);
            } catch (NullPointerException err2) {
                throw new XPathException.Dynamic ("Object is null", err2);
            } catch (InvocationTargetException err3) {
                Throwable ex = err3.getTargetException();
                if (ex instanceof XPathException) {
                    throw (XPathException)ex;
                } else {
                	if (debug || context.getController().isTracing()) {
                		err3.getTargetException().printStackTrace();
                	}
                    throw new XPathException.Dynamic ("Exception in extension function " +
                                            err3.getTargetException().toString(), ex);
                }
            }
        } else if (theMethod instanceof Field) {

            // Start of code added by GS

            Field field = (Field)theMethod;
            boolean isStatic = Modifier.isStatic(field.getModifiers());
            Object theInstance;
            if (isStatic) {
                theInstance = null;
            } else {
                int actualArgs = getNumberOfArguments();
                if (actualArgs==0) {
                    dynamicError("Must supply an argument for an instance-level extension function");
                    return null;
                }
                Value arg0 = argValues[0];
                theInstance = arg0.convertToJava(theClass, config);
                // this fails if the first argument is not of a suitable class
            }

            checkArgumentCount(0, 0);

            try {
                Object result = field.get(theInstance);
                return result;

            } catch (IllegalAccessException err1) {
                throw new XPathException.Dynamic ("Field access is illegal", err1);
            } catch (IllegalArgumentException err2) {
                throw new XPathException.Dynamic ("Argument is of wrong type", err2);
            }
	    } else {
	        throw new AssertionError("property " + theMethod + " was neither constructor, method, nor field");
  	    }

    }

    /**
    * Get a class corresponding to a known extension function URI
    */

    public static Class getVendorExtensionClass(String uri)  {
        // Try well-known namespaces (Saxon and EXSLT extensions)

        if (uri.equals(NamespaceConstant.SAXON)) {
            return net.sf.saxon.functions.Extensions.class;
        } else if (uri.equals(NamespaceConstant.EXSLT_COMMON)) {
            return net.sf.saxon.exslt.Common.class;
        } else if (uri.equals(NamespaceConstant.EXSLT_SETS)) {
            return net.sf.saxon.exslt.Sets.class;
        } else if (uri.equals(NamespaceConstant.EXSLT_MATH)) {
            return net.sf.saxon.exslt.Math.class;
        } else if (uri.equals(NamespaceConstant.EXSLT_DATES_AND_TIMES)) {
            return net.sf.saxon.exslt.Date.class;
        } else {
            return null;
        }
    }

    /**
    * Extract a class name from the URI
    */


    public static Class getImplicitJavaClass(String uri)  {
        try {

            // support the URN format java:full.class.Name

            if (uri.startsWith("java:")) {
                return Loader.getClass(uri.substring(5));
            }

            // extract the class name as anything in the URI after the last "/"
            // if there is one, or the whole class name otherwise

            int slash = uri.lastIndexOf('/');
            if (slash<0) {
                return Loader.getClass(uri);
            } else if (slash==uri.length()-1) {
                return null;
            } else {
                return Loader.getClass(uri.substring(slash+1));
            }
        } catch (TransformerException err) {
            return null;
        }
    }

    /**
    * Convert a Java object to an XPath value. This method is called to handle the result
    * of an external function call (but only if the required type is not known),
    * and also to process global parameters passed to the stylesheet.
    * @param result The Java object to be converted
    * @param controller The controller: may be null, in which case a Source object cannot be
    * supplied
     * @return the result of converting the value. If the value is null, returns null.
    */

    public static Value convertJavaObjectToXPath(Object result, Controller controller)
                                          throws XPathException {

        if (result==null) {
            return null;

        } else if (result instanceof String) {
            return new StringValue((String)result);

        } else if (result instanceof Character) {
            return new StringValue(result.toString());

        } else if (result instanceof Boolean) {
            return BooleanValue.get(((Boolean)result).booleanValue());

        } else if (result instanceof Double) {
            return new DoubleValue(((Double)result).doubleValue());

        } else if (result instanceof Float) {
            return new FloatValue(((Float)result).floatValue());

        } else if (result instanceof Short) {
            return new IntegerValue(((Short)result).shortValue(),
                                    (ItemType)BuiltInSchemaFactory.getSchemaType(StandardNames.XS_SHORT));
        } else if (result instanceof Integer) {
            return new IntegerValue(((Integer)result).intValue(),
                                    (ItemType)BuiltInSchemaFactory.getSchemaType(StandardNames.XS_INT));
        } else if (result instanceof Long) {
            return new IntegerValue(((Long)result).longValue(),
                                    (ItemType)BuiltInSchemaFactory.getSchemaType(StandardNames.XS_LONG));
        } else if (result instanceof Byte) {
            return new IntegerValue(((Byte)result).byteValue(),
                                    (ItemType)BuiltInSchemaFactory.getSchemaType(StandardNames.XS_BYTE));

        } else if (result instanceof BigInteger) {
            return BigIntegerValue.makeValue(((BigInteger)result));

        } else if (result instanceof BigDecimal) {
            return new DecimalValue(((BigDecimal)result));

        } else if (result instanceof Closure) {
            // Force eager evaluation, because of problems with side-effects.
            // (The value might depend on data that is mutable.)
            return ExpressionTool.eagerEvaluate((Closure)result, null);

        } else if (result instanceof Value) {
            return (Value)result;

        } else if (result instanceof NodeInfo) {
            return new SingletonNode((NodeInfo)result);

        } else if (result instanceof SequenceIterator) {
            return new SequenceIntent((SequenceIterator)result);

        } else if (result instanceof List) {
            Item[] array = new Item[((List)result).size()];
            int a = 0;
            for (Iterator i=((List)result).iterator(); i.hasNext(); ) {
                Object obj = i.next();
                if (obj instanceof NodeInfo) {
                    array[a++] = (NodeInfo)obj;
                } else {
                    Value v = convertJavaObjectToXPath(obj, controller);
                    if (v!=null) {
                        if (v instanceof Item) {
                            array[a++] = (Item)v;
                        } else if (v instanceof EmptySequence) {
                            // no action
                        } else if (v instanceof SingletonNode) {
                            NodeInfo node = ((SingletonNode)v).getNode();
                            if (node != null) {
                                array[a++] = node;
                            }
                        } else {
                            throw new XPathException.Dynamic(
                                    "Returned List contains an object that cannot be converted to an Item (" + obj.getClass() + ")");
                        }
                    }
                }
            }

            return new SequenceExtent(array);

        } else if (result instanceof Object[]) {
             Item[] array = new Item[((Object[])result).length];
             int a = 0;
             for (int i = 0; i < ((Object[])result).length; i++){
                 Object obj = ((Object[])result)[i];
                 if (obj instanceof NodeInfo) {
                     array[a++] = (NodeInfo)obj;
                 } else {
                     Value v = convertJavaObjectToXPath(obj, controller);
                     if (v!=null) {
                         if (v instanceof Item) {
                             array[a++] = (Item)v;
                         } else {
                             throw new XPathException.Dynamic(
                                     "Returned array contains an object that cannot be converted to an Item (" + obj.getClass() + ")");
                         }
                     }
                 }
             }
             return new SequenceExtent(array);

        } else if (result instanceof Source && controller != null) {
            try {
                Builder b = controller.makeBuilder();
                new Sender(controller.getConfiguration()).send(
                        (Source)result, b);
                return new SingletonNode(b.getCurrentDocument());
            } catch (TransformerException err) {
                throw new XPathException.Dynamic(err);
            }

        } else if (result instanceof org.w3c.dom.NodeList) {
            NodeList list = ((NodeList)result);
            NodeInfo[] nodes = new NodeInfo[list.getLength()];
            for (int i=0; i<list.getLength(); i++) {
                if (list.item(i) instanceof NodeInfo) {
                    nodes[i] = (NodeInfo)list.item(i);
                } else {
                    throw new XPathException.Dynamic("Supplied NodeList contains non-Saxon DOM Nodes");
                }

            }
            return new SequenceExtent(nodes);
            // Note, we accept the nodes in the order returned by the function; there
            // is no requirement that this should be document order.
        } else if (result instanceof org.w3c.dom.Node) {
            throw new XPathException.Dynamic("Supplied Java object is a non-Saxon DOM Node");
        } else {
            return new ObjectValue(result);
        }
    }

    private static final Class[] NO_PARAMS = new Class[0];

    /**
    * Get an array of integers representing the conversion distances of each "real" argument
    * to a given method
    * @param argValues: the actual argument values supplied
    * @param method: the method or constructor. (Could be an AccessibleObject in JDK 1.2)
    * @return an array of integers, one for each argument, indicating the conversion
    * distances. A high number indicates low preference.
    */

    private int[] getConversionPreferences(Value[] argValues, Object method) {

        Class[] params;
        int firstArg;

        if (method instanceof Constructor) {
            firstArg = 0;
            params = ((Constructor)method).getParameterTypes();
        } else if (method instanceof Method) {
            boolean isStatic = Modifier.isStatic(((Method)method).getModifiers());
            firstArg = (isStatic ? 0 : 1);
            params = ((Method)method).getParameterTypes();
        } else if (method instanceof Field) {
            boolean isStatic = Modifier.isStatic(((Field)method).getModifiers());
            firstArg = (isStatic ? 0 : 1);
            params = NO_PARAMS;
        } else {
            throw new AssertionError("property " + method + " was neither constructor, method, nor field");
        }

        int noOfArgs = getNumberOfArguments() - firstArg;
        int preferences[] = new int[noOfArgs];
        int firstParam = 0;

        if (params.length > 0 && params[0] == XPathContext.class) {
            firstParam = 1;
        }
        for (int i = 0; i<noOfArgs; i++) {
            preferences[i] = argValues[i+firstArg].conversionPreference(params[i+firstParam], config);
        }

        return preferences;
    }


    private void setupParams(Value[] argValues,
                             Object[] params,
                             Class[] paramTypes,
                             int firstParam,
                             int firstArg) throws XPathException {
        int j=firstParam;
        for (int i=firstArg; i<getNumberOfArguments(); i++) {
            // System.err.println("setupParams " + i + " " + argValues[i].getClass());
            params[j] = argValues[i].convertToJava(paramTypes[j], config);
            // System.err.println(" -- converted to " + params[j].getClass());
            j++;
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): Gunther Schadow (changes to allow access to public fields; also wrapping
// of extensions and mapping of null to empty sequence).
//
