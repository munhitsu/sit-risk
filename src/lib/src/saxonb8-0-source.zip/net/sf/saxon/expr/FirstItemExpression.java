package net.sf.saxon.expr;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.type.ItemType;

/**
* A FirstItemExpression returns the first item in the sequence returned by a given
* base expression
*/

public final class FirstItemExpression extends ComputedExpression {

    private Expression base;

    /**
    * Constructor
    * @param base A sequence expression denoting sequence whose first item is to be returned
    */

    public FirstItemExpression(Expression base) {
        this.base = base;
        computeStaticProperties();
    }

    /**
    * Get the data type of the items returned
    */

    public ItemType getItemType() {
        return base.getItemType();
    }

    /**
    * Simplify the expression
    */

     public Expression simplify() throws XPathException {
        base = base.simplify();
        if (!Cardinality.allowsMany(base.getCardinality())) {
            return base;
        }
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        base = base.analyze(env);
        if (!Cardinality.allowsMany(base.getCardinality())) {
            return base;
        }
        return this;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            if (offer.action != PromotionOffer.UNORDERED) {
                base = base.promote(offer);
            }
            return this;
        }
    }

    /**
    * Get the immediate subexpressions of this expression
    */

    public Expression[] getSubExpressions() {
        Expression[] exp = new Expression[1];
        exp[0] = base;
        return exp;
    }

    /**
    * Get the static cardinality
    */

    public int computeCardinality() {
        int x = base.getCardinality() & ~StaticProperty.ALLOWS_MANY;
        return x;
    }

    /**
    * Is this expression the same as another expression?
    */

    public boolean equals(Object other) {
        if (other instanceof FirstItemExpression) {
            FirstItemExpression f = (FirstItemExpression)other;
            return base.equals(f.base);
        }
        return false;
    }

    /**
    * get HashCode for comparing two expressions
    */

    public int hashCode() {
        return "FirstItemExpression".hashCode() + base.hashCode();
    }

    /**
    * Evaluate the expression
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        return base.iterate(context).next();
    }

    /**
    * Get the static properties of this expression (other than its type). The result is
    * bit-signficant. These properties are used for optimizations. In general, if
    * property bit is set, it is true, but if it is unset, the value is unknown.
    */

    public int computeSpecialProperties() {
        return base.getSpecialProperties();
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "first item of ");
        base.display(level+1, pool);
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
