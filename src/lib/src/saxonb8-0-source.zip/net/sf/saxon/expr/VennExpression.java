package net.sf.saxon.expr;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.pattern.CombinedNodeTest;
import net.sf.saxon.sort.DocumentOrderIterator;
import net.sf.saxon.sort.GlobalOrderComparer;
import net.sf.saxon.value.EmptySequence;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.type.Type;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.functions.SystemFunction;
import net.sf.saxon.type.ItemType;


/**
* An expression representing a nodeset that is a union, difference, or
* intersection of two other NodeSets
*/

public class VennExpression extends BinaryExpression {

    /**
    * Constructor
    * @param p1 the left-hand operand
    * @param op the operator (union, intersection, or difference)
    * @param p2 the right-hand operand
    */

    public VennExpression(Expression p1, int op, Expression p2) {
        super(p1, op, p2);
    }

    /**
    * Determine the data type of the items returned by this expression
    * @return the data type
    */

    public final ItemType getItemType() {
        ItemType t1 = operands[0].getItemType();
        ItemType t2 = operands[1].getItemType();
        return Type.getCommonSuperType(t1, t2);
    }

    /**
    * Determine the static cardinality of the expression
    */

    public final int computeCardinality() {
        int c1 = operands[0].getCardinality();
        int c2 = operands[1].getCardinality();
        switch (operator) {
            case Tokenizer.UNION:
                if (operands[0] instanceof EmptySequence) return c2;
                if (operands[1] instanceof EmptySequence) return c1;
                return c1 | c2 | StaticProperty.ALLOWS_ONE | StaticProperty.ALLOWS_MANY;
                    // allows ZERO only if one operand allows ZERO
            case Tokenizer.INTERSECT:
                if (operands[0] instanceof EmptySequence) return StaticProperty.EMPTY;
                if (operands[1] instanceof EmptySequence) return StaticProperty.EMPTY;
                return (c1 & c2) | StaticProperty.ALLOWS_ZERO | StaticProperty.ALLOWS_ONE;
                    // allows MANY only if both operands allow MANY
            case Tokenizer.EXCEPT:
                if (operands[0] instanceof EmptySequence) return StaticProperty.EMPTY;
                if (operands[1] instanceof EmptySequence) return c1;
                return c1 | StaticProperty.ALLOWS_ZERO | StaticProperty.ALLOWS_ONE;
                    // allows MANY only if first operand allows MANY
        }
        return StaticProperty.ALLOWS_ZERO_OR_MORE;
    }

    /**
    * Get the static properties of this expression (other than its type). The result is
    * bit-signficant. These properties are used for optimizations. In general, if
    * property bit is set, it is true, but if it is unset, the value is unknown.
    */

    public int computeSpecialProperties() {
        int prop0 = operands[0].getSpecialProperties();
        int prop1 = operands[1].getSpecialProperties();
        int props = StaticProperty.ORDERED_NODESET;
        if (testContextDocumentNodeSet(prop0, prop1)) {
            props |= StaticProperty.CONTEXT_DOCUMENT_NODESET;
        }
        if (testSubTree(prop0, prop1)) {
            props |= StaticProperty.SUBTREE_NODESET;
        }
        return props;
    }

    /**
     * Determine whether all the nodes in the node-set are guaranteed to
     * come from the same document as the context node. Used for optimization.
     */

    private boolean testContextDocumentNodeSet(int prop0, int prop1) {
        switch (operator) {
            case Tokenizer.UNION:
                return (prop0 & prop1 & StaticProperty.CONTEXT_DOCUMENT_NODESET) != 0;
            case Tokenizer.INTERSECT:
                return ((prop0 | prop1) & StaticProperty.CONTEXT_DOCUMENT_NODESET) != 0;
            case Tokenizer.EXCEPT:
                return (prop0 & StaticProperty.CONTEXT_DOCUMENT_NODESET) != 0;
        }
        return false;
    }

    /**
     * Determine whether all the nodes in the node-set are guaranteed to
     * come from a subtree rooted at the context node. Used for optimization.
     */

    private boolean testSubTree(int prop0, int prop1) {
        switch (operator) {
            case Tokenizer.UNION:
                return (prop0 & prop1 & StaticProperty.SUBTREE_NODESET) != 0;
            case Tokenizer.INTERSECT:
                return ((prop0 | prop1) & StaticProperty.SUBTREE_NODESET) != 0;
            case Tokenizer.EXCEPT:
                return (prop0 & StaticProperty.SUBTREE_NODESET) != 0;
        }
        return false;
    }


    /**
    * Simplify the expression
    */

     public Expression simplify() throws XPathException {
        operands[0] = operands[0].simplify();
        operands[1] = operands[1].simplify();

        // If either operand is an empty sequence, simplify the expression. This can happen
        // after reduction with constructs of the form //a[condition] | //b[not(condition)],
        // common in XPath 1.0 because there were no conditional expressions.

        switch (operator) {
            case Tokenizer.UNION:
                //return Type.isNodeType(getItemType()) && isSingleton();
                // this is a sufficient condition, but other expressions override this method
                if (operands[0] instanceof EmptySequence && (operands[1].getSpecialProperties() & StaticProperty.ORDERED_NODESET) != 0) return operands[1];
                //return Type.isNodeType(getItemType()) && isSingleton();
                // this is a sufficient condition, but other expressions override this method
                if (operands[1] instanceof EmptySequence && (operands[0].getSpecialProperties() & StaticProperty.ORDERED_NODESET) != 0) return operands[0];
                break;
            case Tokenizer.INTERSECT:
                if (operands[0] instanceof EmptySequence) return operands[0];
                if (operands[1] instanceof EmptySequence) return operands[1];
                break;
            case Tokenizer.EXCEPT:
                if (operands[0] instanceof EmptySequence) return operands[0];
                //return Type.isNodeType(getItemType()) && isSingleton();
                // this is a sufficient condition, but other expressions override this method
                if (operands[1] instanceof EmptySequence && (operands[0].getSpecialProperties() & StaticProperty.ORDERED_NODESET) != 0) return operands[0];
                break;
        }



        // If both are axis expressions on the same axis, merge them
        // ie. rewrite (axis::test1 | axis::test2) as axis::(test1 | test2)

        if (operands[0] instanceof AxisExpression && operands[1] instanceof AxisExpression) {
            AxisExpression a1 = (AxisExpression)operands[0];
            AxisExpression a2 = (AxisExpression)operands[1];
            if (a1.getAxis() == a2.getAxis()) {
                return new AxisExpression(a1.getAxis(),
                             new CombinedNodeTest(a1.getNodeTest(),
                                                  operator,
                                                  a2.getNodeTest()));
            }
        }

        // If both are path expressions starting the same way, merge them
        // i.e. rewrite (/X | /Y) as /(X|Y). This applies recursively, so that
        // /A/B/C | /A/B/D becomes /A/B/child::(C|D)

        if (operands[0] instanceof PathExpression && operands[1] instanceof PathExpression) {
            PathExpression path1 = (PathExpression)operands[0];
            PathExpression path2 = (PathExpression)operands[1];

            if (path1.getFirstStep().equals(path2.getFirstStep())) {
                Expression path = new PathExpression(
                        path1.getFirstStep(),
                        new VennExpression(
                            path1.getRemainingSteps(),
                            operator,
                            path2.getRemainingSteps())).simplify();
                ExpressionTool.copyLocationInfo(this, path);
                return path;
            }
        }

        // Try merging two non-positional filter expressions:
        // A[exp0] | A[exp1] becomes A[exp0 or exp1]

        if (operands[0] instanceof FilterExpression && operands[1] instanceof FilterExpression) {
            FilterExpression exp0 = (FilterExpression)operands[0];
            FilterExpression exp1 = (FilterExpression)operands[1];

            if (!exp0.isPositional() &&
                    !exp1.isPositional() &&
                    exp0.getBaseExpression().equals(exp1.getBaseExpression())) {
                Expression filter;
                switch (operator) {
                    case Tokenizer.UNION:
                        filter = new BooleanExpression(exp0.getFilter(),
                                                Tokenizer.OR,
                                                exp1.getFilter());
                        break;
                    case Tokenizer.INTERSECT:
                        filter = new BooleanExpression(exp0.getFilter(),
                                                Tokenizer.AND,
                                                exp1.getFilter());
                        break;
                    case Tokenizer.EXCEPT:
                        FunctionCall negate2 = SystemFunction.makeSystemFunction("not");
                        Expression[] args = new Expression[1];
                        args[0] = exp1.getFilter();
                        negate2.setArguments(args);
                        filter = new BooleanExpression(exp0.getFilter(),
                                                Tokenizer.AND,
                                                negate2);
                        break;
                    default:
                        throw new AssertionError("Unknown operator " + operator);
                }
                Expression f = new FilterExpression(
                        exp0.getBaseExpression(),
                        filter).simplify();
                ExpressionTool.copyLocationInfo(this, filter);
                ExpressionTool.copyLocationInfo(this, f);
                return f;
            }
        }
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {

        operands[0] = operands[0].analyze(env);
        operands[1] = operands[1].analyze(env);

        RoleLocator role0 = new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 0);
        operands[0] = TypeChecker.staticTypeCheck(operands[0], SequenceType.NODE_SEQUENCE, false, role0);

        RoleLocator role1 = new RoleLocator(RoleLocator.BINARY_EXPR, Tokenizer.tokens[operator], 1);
        operands[1] = TypeChecker.staticTypeCheck(operands[1], SequenceType.NODE_SEQUENCE, false, role1);
        return this;
    }

    /**
    * Is this expression the same as another expression?
    */

//    public boolean equals(Object other) {
//        if (other instanceof VennExpression) {
//            VennExpression b = (VennExpression)other;
//            if (operator != b.operator) {
//                return false;
//            }
//            if (operands[0].equals(b.operands[0]) && operands[1].equals(b.operands[1])) {
//               return true;
//            }
//            if (operator == Tokenizer.UNION || operator == Tokenizer.INTERSECT) {
//                // commutative operators: A|B == B|A
//                if (operands[0].equals(b.operands[1]) && operands[1].equals(b.operands[0])) {
//                    return true;
//                }
//            }
//        }
//        return false;
//    }

    public int hashCode() {
        return operands[0].hashCode() ^ operands[1].hashCode();
    }

    /**
    * Iterate over the value of the expression. The result will always be sorted in document order,
    * with duplicates eliminated
    * @param c The context for evaluation
    * @return a SequenceIterator representing the union of the two operands
    */

    public SequenceIterator iterate(XPathContext c) throws XPathException {
        SequenceIterator i1 = operands[0].iterate(c);
        //return Type.isNodeType(getItemType()) && isSingleton();
        // this is a sufficient condition, but other expressions override this method
        if (!((operands[0].getSpecialProperties() & StaticProperty.ORDERED_NODESET) != 0)) {
            i1 = new DocumentOrderIterator(i1, GlobalOrderComparer.getInstance());
        }
        SequenceIterator i2 = operands[1].iterate(c);
        //return Type.isNodeType(getItemType()) && isSingleton();
        // this is a sufficient condition, but other expressions override this method
        if (!((operands[1].getSpecialProperties() & StaticProperty.ORDERED_NODESET) != 0)) {
            i2 = new DocumentOrderIterator(i2, GlobalOrderComparer.getInstance());
        }
        switch (operator) {
            case Tokenizer.UNION:
                return new UnionEnumeration(i1, i2,
                                            GlobalOrderComparer.getInstance());
            case Tokenizer.INTERSECT:
                return new IntersectionEnumeration(i1, i2,
                                            GlobalOrderComparer.getInstance());
            case Tokenizer.EXCEPT:
                return new DifferenceEnumeration(i1, i2,
                                            GlobalOrderComparer.getInstance());
        }
        throw new UnsupportedOperationException("Unknown operator in Set Expression");
    }

    /**
    * Get the effective boolean value. In the case of a union expression, this
    * is reduced to an OR expression, for efficiency
    */

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        if (operator == Tokenizer.UNION) {
            return operands[0].effectiveBooleanValue(context) || operands[1].effectiveBooleanValue(context);
        } else {
            return super.effectiveBooleanValue(context);
        }
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
