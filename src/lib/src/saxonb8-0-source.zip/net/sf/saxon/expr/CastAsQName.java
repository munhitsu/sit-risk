package net.sf.saxon.expr;

import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.QNameException;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NamespaceResolver;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.value.QNameValue;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.style.ExpressionContext;
import net.sf.saxon.type.ItemType;

/**
 * This class supports casting a string to a QName
 */

public class CastAsQName extends ComputedExpression {

    private Expression input;
    private NamespaceResolver nsContext;
    private NamePool namePool;

    public CastAsQName(Expression s) {
        input = s;
    }

    public Expression analyze(StaticContext env) throws XPathException {
        if (!(env instanceof ExpressionContext)) {
            // TODO: allow cast as QName in XPath and XQuery; also allow
            // it to happen implicitly when passing untypedAtomic to a function
            // that expects a QName.
            throw new XPathException.Static("cast as xs:QName is currently implemented only in XSLT");
        }
        nsContext = ((ExpressionContext)env).getNamespaceContext();
        namePool = env.getNamePool();
        return this;
    }

    public Expression promote(PromotionOffer offer) throws XPathException {
        return super.promote(offer);
    }

    public int computeCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    public ItemType getItemType() {
        return Type.QNAME_TYPE;
    }

    public int getIntrinsicDependencies() {
        return 0;
    }

    public Expression[] getSubExpressions() {
        Expression[] e = new Expression[1];
        e[0] = input;
        return e;
    }

    public Item evaluateItem(XPathContext context) throws XPathException {
        AtomicValue av = (AtomicValue)input.evaluateItem(context);
        if (av==null) return null;
        StringValue sv = (StringValue)av.getPrimitiveValue();

        try {
            String parts[] = Name.getQNameParts(sv.getStringValue());
            String uri = nsContext.getURIForPrefix(parts[0], true);
            if (uri==null) {
                throw new XPathException.Dynamic("Prefix '" + parts[0] + "' has not been declared");
            }
            return new QNameValue(uri, parts[1]);
        } catch (QNameException e) {
            throw new XPathException.Dynamic(e);
        }
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "cast as QName");
        input.display(level+1, pool);
    }
}
