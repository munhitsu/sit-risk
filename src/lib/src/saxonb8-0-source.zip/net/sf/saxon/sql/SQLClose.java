package net.sf.saxon.sql;
import net.sf.saxon.Controller;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.InstructionDetails;
import net.sf.saxon.instruct.TailCall;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.style.StyleElement;
import net.sf.saxon.value.ObjectValue;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import java.sql.Connection;
import java.sql.SQLException;

/**
* An sql:close element in the stylesheet.
*/

public class SQLClose extends StyleElement {

    Expression connection = null;
    /**
    * Determine whether this node is an instruction.
    * @return true - it is an instruction
    */

    public boolean isInstruction() {
        return true;
    }

    /**
    * Determine whether this type of element is allowed to contain a template-body
    * @return true: yes, it may contain a fallback instruction
    */

    public boolean mayContainSequenceConstructor() {
        return true;
    }

    public void prepareAttributes() throws TransformerConfigurationException {
        String connectAtt = getAttribute("connection");
        if (connectAtt==null) {
            reportAbsence("connection");
        } else {
            connection = makeExpression(connectAtt);
        }
    }

    public void validate() throws TransformerConfigurationException {
        checkWithinTemplate();
        connection = typeCheck("connection", connection);
    }

    public Instruction compile(Executable exec) throws TransformerConfigurationException {
        CloseInstruction inst = new CloseInstruction(connection);
        return inst;
    }

    private static class CloseInstruction extends Instruction {

        private Expression connectExpression;

        public CloseInstruction(Expression connect) {
            connectExpression = connect;
        }

        public String getInstructionName() {
            return "close";
        }

        public String getInstructionNamespace() {
            return "java:/net.sf.saxon.sql.SQLElementFactory";
        }

        public TailCall processLeavingTail(XPathContext context) throws TransformerException {
            Controller controller = context.getController();
            Item conn = connectExpression.evaluateItem(context);
            if (!(conn instanceof ObjectValue && ((ObjectValue)conn).getObject() instanceof Connection) ) {
                throw new TransformerException("Value of connection expression is not a JDBC Connection");
            }
            Connection connection = (Connection)((ObjectValue)conn).getObject();
    		try {
                connection.close();
    	    } catch (SQLException ex) {
    			throw dynamicError("(SQL) Failed to close connection: " + ex.getMessage(), controller);
            }
            return null;
        }
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Additional Contributor(s): Rick Bonnett [rbonnett@acadia.net]
//
