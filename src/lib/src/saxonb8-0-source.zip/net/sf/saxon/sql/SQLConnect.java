package net.sf.saxon.sql;
import net.sf.saxon.Controller;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.instruct.Instruction;
import net.sf.saxon.instruct.InstructionDetails;
import net.sf.saxon.instruct.TailCall;
import net.sf.saxon.instruct.Executable;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.style.StyleElement;
import net.sf.saxon.value.ObjectValue;
import net.sf.saxon.value.StringValue;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import java.sql.Connection;
import java.sql.DriverManager;

/**
* An sql:connect element in the stylesheet.
*/

public class SQLConnect extends StyleElement {

    Expression database;
    Expression driver;
    Expression user;
    Expression password;

    /**
    * Determine whether this node is an instruction.
    * @return true - it is an instruction
    */

    public boolean isInstruction() {
        return true;
    }

    /**
    * Determine whether this type of element is allowed to contain a template-body
    * @return true: yes, it may contain a template-body (this is done only so that
    * it can contain xsl:fallback)
    */

    public boolean mayContainSequenceConstructor() {
        return true;
    }

    public void prepareAttributes() throws TransformerConfigurationException {

        // Get mandatory database attribute

        String dbAtt = attributeList.getValue("database");
        if (dbAtt==null) {
            reportAbsence("database");
            dbAtt = ""; // for error recovery
        }
        database = makeAttributeValueTemplate(dbAtt);

	    // Get driver attribute

        String dbDriver = attributeList.getValue("driver");
        if (dbDriver==null) {
            if (dbAtt.length()>9 && dbAtt.substring(0,9).equals("jdbc:odbc")) {
                dbDriver = "sun.jdbc.odbc.JdbcOdbcDriver";
            } else {
                reportAbsence("driver");
            }
        }
        driver = makeAttributeValueTemplate(dbDriver);


        // Get and expand user attribute, which defaults to empty string

        String userAtt = attributeList.getValue("user");
        if (userAtt==null) {
            user = StringValue.EMPTY_STRING;
        } else {
            user = makeAttributeValueTemplate(userAtt);
        }

        // Get and expand password attribute, which defaults to empty string

        String pwdAtt = attributeList.getValue("password");
        if (pwdAtt==null) {
            password = StringValue.EMPTY_STRING;
        } else {
            password = makeAttributeValueTemplate(pwdAtt);
        }
    }

    public void validate() throws TransformerConfigurationException {
        checkWithinTemplate();
        database = typeCheck("database", database);
        driver = typeCheck("driver", driver);
        user = typeCheck("user", user);
        password = typeCheck("password", password);
    }

    public Instruction compile(Executable exec) throws TransformerConfigurationException {
        Instruction inst = new ConnectInstruction(database, driver, user, password);
        // no need to compile the children, they can only be fallback instructions
        return inst;
    }

    private static class ConnectInstruction extends Instruction {

        Expression database;
        Expression driver;
        Expression user;
        Expression password;

        public ConnectInstruction(Expression database,
            Expression driver, Expression user, Expression password) {

            this.database = database;
            this.driver = driver;
            this.user = user;
            this.password = password;

        };

       public String getInstructionName() {
            return "connect";
        }

        public String getInstructionNamespace() {
            return "java:/net.sf.saxon.sql.SQLElementFactory";
        }

        public TailCall processLeavingTail(XPathContext context) throws TransformerException {

            // Establish the JDBC connection

            Connection connection = null;      // JDBC Database Connection
//            Statement sql = null;              // JDBC SQL Statement

            String dbString = database.evaluateAsString(context);
    	    String dbDriverString = driver.evaluateAsString(context);
            String userString = user.evaluateAsString(context);
            String pwdString = password.evaluateAsString(context);

            try {
                // the following hack is necessary to load JDBC drivers
    	        Class.forName(dbDriverString);

                connection = DriverManager.getConnection(dbString, userString, pwdString);
//                sql = connection.createStatement();
            } catch (Exception ex) {
                throw new TransformerException("JDBC Connection Failure: " + ex.getMessage());
            }

            Controller controller = context.getController();
            controller.getReceiver().append(new ObjectValue(connection));
//    		NodeInfo sourceDoc = controller.getCurrentDocument();
//            controller.setUserData(sourceDoc, "sql:connection", connection);
//            controller.setUserData(sourceDoc, "sql:statement", sql);

            return null;

        }
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Additional Contributor(s): Rick Bonnett [rbonnett@acadia.net]
//
