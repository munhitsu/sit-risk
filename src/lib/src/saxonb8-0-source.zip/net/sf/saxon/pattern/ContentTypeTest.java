package net.sf.saxon.pattern;
import net.sf.saxon.Configuration;
import net.sf.saxon.type.*;

/**
 * NodeTest is an interface that enables a test of whether a node matches particular
 * conditions. ContentTypeTest tests for an element or attribute node with a particular
 * type annotation.
  *
  * @author Michael H. Kay
  */

public class ContentTypeTest extends NodeTest {

	private int kind;          // element or attribute
    private int requiredType;
    private Configuration config;

    // TODO: need to consider "issue 309": what happens when the document contains
    // a type annotation that wasn't known at stylesheet compile time? It might be
    // a subtype of the required type.

    /**
     * Create a ContentTypeTest
     * @param nodeKind the kind of nodes to be matched: always elements or attributes
     * @param schemaType the required type annotation, as a simple or complex schema type
     * @param config the Configuration, supplied because this KindTest needs access to schema information
     */

	public ContentTypeTest(int nodeKind, SchemaType schemaType, Configuration config) {
		this.kind = nodeKind;
        this.requiredType = schemaType.getFingerprint();
        this.config = config;
        originalText = schemaType.getDescription();
	}

    public ItemType getSuperType() {
        return NodeKindTest.makeNodeKindTest(kind);
    }

    /**
    * Test whether this node test is satisfied by a given node
    * @param nodeKind The type of node to be matched
    * @param fingerprint identifies the expanded name of the node to be matched
    * @param annotation The actual content type of the node
    */

    public boolean matches(int nodeKind, int fingerprint, int annotation) {
        if (kind != nodeKind) {
            return false;
        }

        if (annotation == requiredType) {
            return true;
        }

        if (annotation == -1) {
            return false;
        }

        SchemaType type = config.getSchemaType(annotation).getBaseType();
        while (type != null) {
            if (type.getFingerprint() == requiredType) {
                return true;
            }
            type = type.getBaseType();
        }
        return false;
    }

    /**
    * Determine the default priority of this node test when used on its own as a Pattern
    */

    public final double getDefaultPriority() {
    	return 0;
    }

    /**
    * Determine the types of nodes to which this pattern applies. Used for optimisation.
    * @return the type of node matched by this pattern. e.g. Type.ELEMENT or Type.TEXT
    */

    public int getNodeKind() {
        return kind;
    }

    /**
     * Indicate whether this NodeTest is capable of matching text nodes
     */

    public boolean allowsTextNodes() {
        return false;
    }

    /**
     * Get the item type of the atomic values that will be produced when an item
     * of this type is atomized (assuming that atomization succeeds)
     */

    public AtomicType getAtomizedItemType() {
        SchemaType type = config.getSchemaType(requiredType);
        if (type instanceof AtomicType) {
            return (AtomicType)type;
        } else if (type instanceof ListType) {
            SimpleType mem = ((ListType)type).getItemType();
            if (mem instanceof AtomicType) {
                return (AtomicType)mem;
            }
        }
        return Type.ANY_ATOMIC_TYPE;
    }

    public String toString() {
        return originalText;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
