package net.sf.saxon.pattern;
import net.sf.saxon.Controller;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.Type;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.Item;

/**
  * A NodeTest is a simple kind of pattern that enables a context-free test of whether
  * a node has a particular
  * name. There are several kinds of node test: a full name test, a prefix test, and an
  * "any node of a given type" test, an "any node of any type" test, a "no nodes"
  * test (used, e.g. for "@comment()")
  *
  * @author Michael H. Kay
  */

public abstract class NodeTest extends Pattern implements ItemType {

    /**
     * Test whether a given item conforms to this type
     * @param item The item to be tested
     * @return true if the item is an instance of this type; false otherwise
    */

    public boolean matchesItem(Item item) {
        if (item instanceof NodeInfo) {
            NodeInfo node = (NodeInfo)item;
            return matches(node.getNodeKind(), node.getFingerprint(), node.getTypeAnnotation());
        } else {
            return false;
        }
    }

    public ItemType getSuperType() {
        return AnyNodeTest.getInstance();
        // overridden for AnyNodeTest itself
    }

    public int getPrimitiveType() {
        return getNodeKind();
    }

    /**
     * Get the item type of the atomic values that will be produced when an item
     * of this type is atomized (assuming that atomization succeeds)
     */

    public AtomicType getAtomizedItemType() {
        // This is overridden for a ContentTypeTest
        return Type.ANY_ATOMIC_TYPE;
    }

    /**
     * Test whether this node test is satisfied by a given node.
     * @param nodeKind The kind of node to be matched
     * @param fingerprint identifies the expanded name of the node to be matched.
     *  The value should be -1 for a node with no name.
     * @param annotation The actual content type of the node
     *
    */

    public abstract boolean matches(int nodeKind, int fingerprint, int annotation);

    /**
    * Determine whether this Pattern matches the given Node. This is the main external interface
    * for matching patterns: it sets current() to the node being tested
    * @param node The NodeInfo representing the Element or other node to be tested against the Pattern
    * @param controller The context in which the match is to take place. Only relevant if the pattern
    * uses variables, or contains calls on functions such as document() or key().
    * @return true if the node matches the Pattern, false otherwise
    */

    public boolean matches(NodeInfo node, Controller controller) {
    	return matches(node.getNodeKind(), node.getFingerprint(), node.getTypeAnnotation());
    }

    /**
    * Get a NodeTest that all the nodes matching this pattern must satisfy
    */

    public NodeTest getNodeTest() {
        return this;
    }

    /**
     * Indicate whether this NodeTest is capable of matching text nodes
     */

    public abstract boolean allowsTextNodes();

    /**
     * Test whether this NodeTest represents the same type as another NodeTest
     * @param other
     * @return true if the two NodeTests represent the same item type
     */

    public boolean isSameType(ItemType other) {
        return this.equals(other);
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
