package net.sf.saxon.sort;
import net.sf.saxon.expr.ComputedExpression;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.ItemType;

/**
* Expression equivalent to the imaginary syntax
 * expr sortby (sort-key)+
*/

public class SortExpression extends ComputedExpression {

    private Expression select = null;
    private SortKeyDefinition[] sortKeys = null;
    private FixedSortKeyDefinition[] fixedSortKeys = null;

    public SortExpression( Expression select,
                           SortKeyDefinition[] sortKeys ) {
        this.select = select;
        this.sortKeys = sortKeys;
        boolean fixed = true;
        for (int i = 0; i < sortKeys.length; i++) {
            if (!(sortKeys[i] instanceof FixedSortKeyDefinition)) {
                fixed = false;
                break;
            };
        }
        if (fixed) {
            fixedSortKeys = new FixedSortKeyDefinition[sortKeys.length];
            System.arraycopy(sortKeys, 0, fixedSortKeys, 0, sortKeys.length);
        }
    }

    /**
    * Simplify an expression
    */

     public Expression simplify() throws XPathException {
        select = select.simplify();
        return this;
    }

    /**
    * Type-check the expression
    */

    public Expression analyze(StaticContext env) throws XPathException {
        select = select.analyze(env);
        if (!Cardinality.allowsMany(select.getCardinality())) {
            return select;
        } else {
            return this;
        }
    }

    /**
    * Determine the static cardinality
    */

    public int computeCardinality() {
        return select.getCardinality();
    }

    /**
    * Determine the data type of the items returned by the expression, if possible
    * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
    * or Type.ITEM (meaning not known in advance)
    */

	public ItemType getItemType() {
	    return select.getItemType();
	}
    /**
    * Get the static properties of this expression (other than its type). The result is
    * bit-significant. These properties are used for optimizations. In general, if
    * property bit is set, it is true, but if it is unset, the value is unknown.
    */

    public int computeSpecialProperties() {
        int props = 0;
        if ((select.getSpecialProperties() & StaticProperty.CONTEXT_DOCUMENT_NODESET) != 0) {
            props |= StaticProperty.CONTEXT_DOCUMENT_NODESET;
        }
        return props;
    }

    /**
    * Enumerate the results of the expression
    */

    public SequenceIterator iterate(XPathContext context) throws XPathException {

        SequenceIterator iter = select.iterate(context);
        XPathContext xpc = context.newContext();

        FixedSortKeyDefinition[] reducedSortKeys;
        if (fixedSortKeys != null) {
            reducedSortKeys = fixedSortKeys;
        } else {
            reducedSortKeys = new FixedSortKeyDefinition[sortKeys.length];
            for (int s=0; s<sortKeys.length; s++) {
                reducedSortKeys[s] = sortKeys[s].reduce(xpc);
            }
        }
        iter = new SortedIterator(  xpc,
                                    iter,
                                    reducedSortKeys);
        return iter;
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "sort");
        select.display(level+1, pool);
    }
}





//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
