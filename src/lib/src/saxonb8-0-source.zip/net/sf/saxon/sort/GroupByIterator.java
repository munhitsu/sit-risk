package net.sf.saxon.sort;

import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.ListIterator;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.Controller;

import java.text.Collator;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * A GroupByIterator iterates over a sequence of groups defined by
 * xsl:for-each-group group-by="x". The groups are returned in
 * order of first appearance. Note that an item can appear in several groups;
 * indeed, an item may be the leading item of more than one group, which means
 * that knowing the leading item is not enough to know the current group.
 *
 * <p>The GroupByIterator acts as a SequenceIterator, where successive calls of
 * next() return the leading item of each group in turn. The current item of
 * the iterator is therefore the leading item of the current group. To get access
 * to all the members of the current group, the method iterateCurrentGroup() is used;
 * this underpins the current-group() function in XSLT. The grouping key for the
 * current group is available via the getCurrentGroupingKey() method.</p>
 */

public class GroupByIterator implements GroupIterator {

    // The implementation of group-by is not pipelined. All the items in the population
    // are read at the start, their grouping keys are calculated, and the groups are formed
    // in memory as a hash table indexed by the grouping key. This hash table is then
    // flattened into three parallel lists: a list of groups (each group being represented
    // as a list of items in population order), a list of grouping keys, and a list of
    // the initial items of the groups.

    private SequenceIterator population;
    private Expression keyExpression;
    private Collator collator;
    private XPathContext keyContext;
    private Controller controller;
    private int position = 0;

    // Main data structure holds one entry for each group. The entry is also an ArrayList,
    // which contains the Items that are members of the group, in population order.
    // The groups are arranged in order of first appearance within the population.
    private ArrayList groups = new ArrayList();

    // This parallel structure identifies the grouping key for each group. The list
    // corresponds one-to-one with the list of groups.
    private ArrayList groupKeys = new ArrayList();

    // For convenience (so that we can use a standard ArrayListIterator) we define
    // another parallel array holding the initial items of each group.
    private ArrayList initialItems = new ArrayList();

    // An AtomicSortComparer is used to do the comparisons
    private AtomicSortComparer comparer;



    public GroupByIterator(SequenceIterator population, Expression keyExpression,
                                 XPathContext keyContext, Collator collator)
    throws XPathException {
        this.population = population;
        this.keyExpression = keyExpression;
        this.keyContext = keyContext;
        this.controller = keyContext.getController();
        this.collator = collator;
        this.comparer = new AtomicSortComparer(collator);
        buildIndexedGroups();
    }

    /**
      * Build the grouping table forming groups of non-adjacent items with equal keys.
      * This form of grouping allows a member of the population to be present in zero
      * or more groups, one for each value of the grouping key.
     */

    private void buildIndexedGroups() throws XPathException {
        HashMap index = new HashMap();
        SequenceIterator savedIterator = controller.getCurrentIterator();
        controller.setCurrentIterator(population);
        XPathContext c = controller.newXPathContext();
        while (true) {
            Item item = population.next();
            if (item==null) {
                break;
            }
            SequenceIterator keys = keyExpression.iterate(c);
            boolean firstKey = true;
            while (true) {
                AtomicValue key = (AtomicValue) keys.next();
                if (key==null) {
                    break;
                }
                AtomicSortComparer.ComparisonKey comparisonKey = comparer.getComparisonKey(key);
                //Object comparisonKey = key;
                //if (key instanceof StringValue && collator != null) {
                //    comparisonKey = collator.getCollationKey(key.getStringValue());
                //}
                ArrayList g = (ArrayList) index.get(comparisonKey);
                if (g == null) {
                    ArrayList newGroup = new ArrayList();
                    newGroup.add(item);
                    groups.add(newGroup);
                    groupKeys.add(key);
                    initialItems.add(item);
                    index.put(comparisonKey, newGroup);
                } else {
                    if (firstKey) {
                        g.add(item);
                    } else {
                        // if this is not the first key value for this item, we
                        // check whether the item is already in this group before
                        // adding it again. If it is in this group, then we know
                        // it will be at the end.
                        if (g.get(g.size() - 1) != item) {
                            g.add(item);
                        }
                    }
                }
                firstKey = false;
            }
        }
        controller.setCurrentIterator(savedIterator);
    }

    /**
     * Get the value of the grouping key for the current group
     * @return the grouping key
     */

    public AtomicValue getCurrentGroupingKey() {
        return (AtomicValue)groupKeys.get(position-1);
    }

    /**
     * Get an iterator over the items in the current group
     * @return the iterator
     */

    public SequenceIterator iterateCurrentGroup() {
        return new ListIterator((ArrayList)groups.get(position-1));
    }

    public Item next() throws XPathException {
        if (position < groups.size()) {
            position++;
            return current();
        } else {
            return null;
        }
    }

    public Item current() {
        // return the initial item of the current group
        return (Item)((ArrayList)groups.get(position-1)).get(0);
    }

    public int position() {
        return position;
    }

    public SequenceIterator getAnother() throws XPathException {
        return new GroupByIterator(population, keyExpression,
                keyContext.newContext(), collator);
    }



}
