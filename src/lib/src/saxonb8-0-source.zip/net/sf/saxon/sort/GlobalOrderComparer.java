package net.sf.saxon.sort;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.type.Type;

import java.io.Serializable;

/**
 * A Comparer used for comparing nodes in document order. This
 * comparer is used when there is no guarantee that the nodes being compared
 * come from the same document
 *
 * @author Michael H. Kay
 *
 */

public final class GlobalOrderComparer implements NodeOrderComparer, Serializable {

    private static GlobalOrderComparer instance = new GlobalOrderComparer();

    /**
    * Get an instance of a GlobalOrderComparer. The class maintains no state
    * so this returns the same instance every time.
    */

    public static GlobalOrderComparer getInstance() {
        return instance;
    }

    public int compare(NodeInfo a, NodeInfo b) {
        NodeInfo r1 = a.getRoot();
        NodeInfo r2 = b.getRoot();
        if (r1.isSameNode(r2)) {
            return a.compareOrder(b);
        }
        int d1 = r1.getDocumentNumber();
        int d2 = r2.getDocumentNumber();
        return d1 - d2;
    }
}

