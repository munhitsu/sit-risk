package net.sf.saxon.sort;

import net.sf.saxon.Controller;
import net.sf.saxon.om.ListIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.xpath.XPathException;

import java.util.ArrayList;
import java.util.List;

/**
 * A GroupEndingIterator iterates over a sequence of groups defined by
 * xsl:for-each-group group-ending-with="x". The groups are returned in
 * order of first appearance.
 */

public class GroupEndingIterator implements GroupIterator {

    private SequenceIterator population;
    private Pattern endPattern;
    private Controller controller;
    private List currentMembers;
    private Item next;
    private Item current = null;
    private int position = 0;

    public GroupEndingIterator(SequenceIterator population, Pattern endPattern,
                                 Controller controller)
    throws XPathException {
        this.population = population;
        this.endPattern = endPattern;
        this.controller = controller;
        // the first item in the population always starts a new group
        next = population.next();
     }

     private void advance() throws XPathException {
         currentMembers = new ArrayList();
         currentMembers.add(current);

         next = current;
         while (next != null) {
             if (endPattern.matches((NodeInfo)next, controller)) {
                 next = population.next();
                 if (next != null) {
                     break;
                 }
             } else {
                 next = population.next();
                 if (next != null) {
                     currentMembers.add(next);
                 }
             }
         }
     }

     public AtomicValue getCurrentGroupingKey() {
         return null;
     }

     public SequenceIterator iterateCurrentGroup() {
         return new ListIterator(currentMembers);
     }

     public Item next() throws XPathException {
         if (next != null) {
             current = next;
             position++;
             advance();
             return current;
         } else {
             return null;
         }
     }

     public Item current() {
         return current;
     }

     public int position() {
         return position;
     }

    public SequenceIterator getAnother() throws XPathException {
        return new GroupEndingIterator(population, endPattern,
                controller);
    }



}
