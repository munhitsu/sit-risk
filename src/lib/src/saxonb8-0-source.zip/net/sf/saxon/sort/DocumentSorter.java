package net.sf.saxon.sort;

import net.sf.saxon.expr.ComputedExpression;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.PromotionOffer;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.ItemType;

/**
 * A DocumentSorter is an expression that sorts a sequence of nodes into
 * document order.
 */
public class DocumentSorter extends ComputedExpression {

    private Expression base;
    private NodeOrderComparer comparer;

    public DocumentSorter(Expression base) {
        this.base = base;
        if ((base.getSpecialProperties() & StaticProperty.CONTEXT_DOCUMENT_NODESET) != 0) {
            comparer = LocalOrderComparer.getInstance();
        } else {
            comparer = GlobalOrderComparer.getInstance();
        }
    }

    public Expression getBaseExpression() {
        return base;
    }

     public Expression simplify() throws XPathException {
        base = base.simplify();
        return this;
    }

    public Expression analyze(StaticContext env) throws XPathException {
        base = base.analyze(env);
        return this;
    }

    public ItemType getItemType() {
        return base.getItemType();
    }

    public int computeSpecialProperties() {
        return base.getSpecialProperties() | StaticProperty.ORDERED_NODESET;
    }

    public int computeCardinality() {
        return base.getCardinality();
    }

    public Expression[] getSubExpressions() {
        Expression[] sub = new Expression[1];
        sub[0] = base;
        return sub;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            base = base.promote(offer);
            return this;
        }
    }

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        return new DocumentOrderIterator(base.iterate(context), comparer);
    }

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        return base.effectiveBooleanValue(context);
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "Sort into Document Order");
        base.display(level+1, pool);
    }
}
