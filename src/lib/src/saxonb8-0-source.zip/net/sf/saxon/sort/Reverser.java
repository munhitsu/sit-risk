package net.sf.saxon.sort;

import net.sf.saxon.expr.*;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.value.SequenceExtent;
import net.sf.saxon.type.ItemType;

/**
 * A Reverser is an expression that reverses the order of a sequence of items.
 */

public class Reverser extends ComputedExpression {

    private Expression base;

    public Reverser(Expression base) {
        this.base = base;
    }

    public Expression getBaseExpression() {
        return base;
    }

     public Expression simplify() throws XPathException {
        base = base.simplify();
        return this;
    }

    public Expression analyze(StaticContext env) throws XPathException {
        base = base.analyze(env);
        return this;
    }

    public ItemType getItemType() {
        return base.getItemType();
    }

    public int computeSpecialProperties() {
        int baseProps = base.getSpecialProperties();
        if ((baseProps & StaticProperty.REVERSE_DOCUMENT_ORDER) != 0) {
            return (baseProps &
                (~StaticProperty.REVERSE_DOCUMENT_ORDER)) |
                StaticProperty.ORDERED_NODESET;
        } else if ((baseProps & StaticProperty.ORDERED_NODESET) != 0) {
            return (baseProps &
                (~StaticProperty.ORDERED_NODESET)) |
                StaticProperty.REVERSE_DOCUMENT_ORDER;
        } else {
            return baseProps;
        }
    }

    public int computeCardinality() {
        return base.getCardinality();
    }

    public Expression[] getSubExpressions() {
        Expression[] sub = new Expression[1];
        sub[0] = base;
        return sub;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            base = base.promote(offer);
            return this;
        }
    }

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        SequenceIterator forwards = base.iterate(context);
        if (forwards instanceof ReversibleIterator) {
            return ((ReversibleIterator)forwards).getReverseIterator();
        } else {
            SequenceExtent extent = new SequenceExtent(forwards);
            return extent.reverseIterate();
        }
    }

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        return base.effectiveBooleanValue(context);
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "reverse order");
        base.display(level+1, pool);
    }
}
