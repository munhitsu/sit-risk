package net.sf.saxon.sort;

import net.sf.saxon.Controller;
import net.sf.saxon.om.ListIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.xpath.XPathException;

import java.util.ArrayList;
import java.util.List;

/**
 * A GroupStartingIterator iterates over a sequence of groups defined by
 * xsl:for-each-group group-starting-with="x". The groups are returned in
 * order of first appearance.
 */

public class GroupStartingIterator implements GroupIterator {

    private SequenceIterator population;
    private Pattern startPattern;
    private Controller controller;
    private List currentMembers;
    private Item next;
    private Item current = null;
    private int position = 0;

    public GroupStartingIterator(SequenceIterator population, Pattern startPattern,
                                 Controller controller)
    throws XPathException {
        this.population = population;
        this.startPattern = startPattern;
        this.controller = controller;
        // the first item in the population always starts a new group
        next = population.next();
     }

     private void advance() throws XPathException {
         currentMembers = new ArrayList();
         currentMembers.add(current);
         while (true) {
             NodeInfo nextCandidate = (NodeInfo)population.next();
             if (nextCandidate == null) {
                 break;
             }
             if (startPattern.matches(nextCandidate, controller)) {
                 next = nextCandidate;
                 return;
             } else {
                 currentMembers.add(nextCandidate);
             }
         }
         next = null;
     }

     public AtomicValue getCurrentGroupingKey() {
         return null;
     }

     public SequenceIterator iterateCurrentGroup() {
         return new ListIterator(currentMembers);
     }

     public Item next() throws XPathException {
         if (next != null) {
             current = next;
             position++;
             advance();
             return current;
         } else {
             return null;
         }
     }

     public Item current() {
         return current;
     }

     public int position() {
         return position;
     }

    public SequenceIterator getAnother() throws XPathException {
        return new GroupStartingIterator(population, startPattern,
                controller);
    }



}
