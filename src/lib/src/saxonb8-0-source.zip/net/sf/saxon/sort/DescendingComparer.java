package net.sf.saxon.sort;
import java.util.Comparator;

/**
 * A Comparer used for comparing descending keys
 *
 *
 */

public class DescendingComparer implements Comparator, java.io.Serializable {

    private Comparator baseComparer;

    public DescendingComparer(Comparator base) {
        baseComparer = base;
    }

    /**
    * Compare two objects.
    * @return <0 if a<b, 0 if a=b, >0 if a>b
    * @throws ClassCastException if the objects are of the wrong type for this Comparer
    */

    public int compare(Object a, Object b) {
        return 0 - baseComparer.compare(a, b);
    }

}
