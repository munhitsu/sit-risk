package net.sf.saxon.sort;

import net.sf.saxon.expr.*;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.value.ObjectValue;
import net.sf.saxon.value.Value;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AnyItemType;

/**
 * A TupleSorter is an expression that sorts a stream of tuples. It is used
 * to implement XQuery FLWR expressions.
 */
public class TupleSorter extends ComputedExpression implements MappingFunction {

    private Expression base;
    private FixedSortKeyDefinition[] sortKeys;

    public TupleSorter(Expression base, FixedSortKeyDefinition[] keys) {
        this.base = base;
        this.sortKeys = keys;
    }

     public Expression simplify() throws XPathException {
        base = base.simplify();
        return this;
    }

    public Expression analyze(StaticContext env) throws XPathException {
        base = base.analyze(env);
        return this;
    }

    public ItemType getItemType() {
        return AnyItemType.getInstance();
            // TODO: we can do better than this, but we need more information
    }

    public int computeCardinality() {
        return StaticProperty.ALLOWS_ZERO_OR_MORE;
    }

    public Expression[] getSubExpressions() {
        Expression[] sub = new Expression[sortKeys.length + 1];
        sub[0] = base;
        for (int i=0; i<sortKeys.length; i++) {
            sub[i+1] = sortKeys[i].getSortKey();
        }
        return sub;
    }

    /**
    * Promote this expression if possible
    */

    public Expression promote(PromotionOffer offer) throws XPathException {
        Expression exp = offer.accept(this);
        if (exp != null) {
            return exp;
        } else {
            base = base.promote(offer);
            for (int i=0; i<sortKeys.length; i++) {
                sortKeys[i].setSortKey(sortKeys[i].getSortKey().promote(offer));
            }
            return this;
        }
    }

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        SequenceIterator iter = new SortedTupleIterator(context, base.iterate(context), sortKeys);
        MappingIterator mapper = new MappingIterator(iter, this, context, null);
        return mapper;
    }

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        return base.effectiveBooleanValue(context);
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "TupleSorter");
        base.display(level+1, pool);
    }

    /**
     * Mapping function to map the wrapped objects returned by the SortedTupleIterator
     * into real items. This is done because each tuple may actually represent a sequence
     * of underlying values that share the same sort key.
     */

    public Object map(Item item, XPathContext context, Object info) throws XPathException {
        ObjectValue tuple = (ObjectValue)item;
        Object o = tuple.getObject();
        if (o == null) {
            return o;
        }
        if (o instanceof Item) {
            return o;
        }
        Value value = (Value)tuple.getObject();
        return value.iterate(context);
    }

}
