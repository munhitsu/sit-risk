package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.pattern.NodeKindTest;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.PromotionOffer;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.Validation;
import net.sf.saxon.tinytree.TinyBuilder;
import net.sf.saxon.value.TextFragmentValue;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.List;


/**
* An instruction to create a document node. This doesn't correspond directly
 * to any XSLT instruction. It is used to support the document node constructor
 * expression in XQuery, and is used as a sub-instruction within an xsl:variable
 * that constructs a temporary tree.
 *
 * <p>Conceptually it represents an XSLT instruction xsl:document-node,
 * with no attributes, whose content is a complex content constructor for the
 * children of the document node.</p>
*/

public class DocumentInstr extends ExprInstruction {

    private static final int[] treeSizeParameters = {50, 10, 5, 200};
        // estimated size of a temporary tree: {nodes, attributes, namespaces, characters}

    boolean textOnly = false;
    String constantText = null;
    String baseURI = null;
    private int validationAction = Validation.PRESERVE;
    private SchemaType schemaType;

    public DocumentInstr(    boolean textOnly,
                        String constantText,
                        String baseURI) {
        this.textOnly = textOnly;
        this.constantText = constantText;
        this.baseURI = baseURI;
    }

    /**
     * Set the validation action
     */

    public void setValidationAction(int action) {
        validationAction = action;
    }

    /**
     * Set the SchemaType of the document element
     */

    public void setSchemaType(SchemaType type) {
        schemaType = type;
    }

    public ItemType getItemType() {
        return NodeKindTest.DOCUMENT;
    }

    public int getCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    public Expression analyze(StaticContext env) throws XPathException {
        for (int c=0; c<children.length; c++) {
            if (children[c] instanceof ExprInstruction) {
                children[c] = (ExprInstruction)((ExprInstruction)children[c]).analyze(env);
            } else {
                throw new IllegalStateException("Children of an ExprInstruction must themselves be ExprInstructions");
            }
        }
        return this;
    }


    public void getXPathExpressions(List list) {}

    /**
     * Offer promotion for subexpressions. The offer will be accepted if the subexpression
     * is not dependent on the factors (e.g. the context item) identified in the PromotionOffer.
     * By default the offer is not accepted - this is appropriate in the case of simple expressions
     * such as constant values and variable references where promotion would give no performance
     * advantage. This method is always called at compile time.
     *
     * @param offer details of the offer, for example the offer to move
     *     expressions that don't depend on the context to an outer level in
     *     the containing expression
     * @exception XPathException if any error is detected
     */

    public void promoteInst(PromotionOffer offer) throws XPathException {
        for (int c=0; c<children.length; c++) {
            if (children[c] instanceof ExprInstruction) {
                Expression p = ((ExprInstruction)children[c]).promote(offer);
                if (p instanceof Instruction) {
                    children[c] = (Instruction)p;
                } else {
                    children[c] = new SequenceInstruction(p, null);
                }
            } else {
                throw new IllegalStateException("Children of an ExprInstruction must themselves be ExprInstructions");
            }
        }
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        SequenceReceiver out = controller.getReceiver();
        Item item = evaluateItem(context);
        if (item != null) {
            out.append(item);
        }
        return null;
    }

   /**
     * Evaluate as an expression.
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        try {
            Controller controller = context.getController();
            DocumentInfo root = null;
            if (textOnly) {
                String textValue;
                if (constantText != null) {
                    textValue = constantText;
                } else {
                    SequenceReceiver old = controller.getReceiver();
                    StringBuffer buffer = new StringBuffer();
                    controller.changeToTextOutputDestination(buffer);
                    processChildren(context);
                    controller.resetOutputDestination(old);
                    textValue = buffer.toString();
                }
                root = new TextFragmentValue(textValue, baseURI);
                root.setNamePool(controller.getNamePool());
            } else {
                SequenceReceiver old = controller.getReceiver();

                // TODO: delayed evaluation of temporary trees, in the same way as
                // node-sets. This requires saving the controller, including values of local variables
                // and any assignable global variables (ouch).

                // TODO: use an Outputter that delayes the decision whether to build a
                // TextFragment or a TinyTree until the first element is encountered, to
                // avoid the overhead of using a TinyTree for text-only trees. This would
                // make the static analysis superfluous.

                TinyBuilder builder = new TinyBuilder();
                //System.err.println("Build doc " + builder);
                builder.setSizeParameters(treeSizeParameters);

                Receiver receiver = builder;
                receiver.setSystemId(baseURI);
                receiver.setConfiguration(controller.getConfiguration());
                receiver.startDocument();
                controller.changeOutputDestination(null,
                                                   receiver,
                                                   false,
                                                   validationAction,
                                                   schemaType);
                processChildren(context);
                controller.resetOutputDestination(old);
                receiver.endDocument();
                //System.err.println("End build doc " + builder);

                root = builder.getCurrentDocument();
                //((TinyDocumentImpl)root).condense();    // deleted because it's already done by endDocument
            }
            return root;
        } catch (XPathException err) {
            throw err;
        } catch (TransformerException err) {
            throw new XPathException.Dynamic(err);
        }
    }


    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    * (the string "document-constructor")
    */

    public String getInstructionName() {
        return "document";
    }

    /**
     * Display this instruction as an expression, for diagnostics
     */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "document-constructor");
        if (children.length==0) {
            System.err.println(ExpressionTool.indent(level+1) + "empty content");
        } else {
            Instruction.displayChildren(children, level+1, pool);
        }
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
