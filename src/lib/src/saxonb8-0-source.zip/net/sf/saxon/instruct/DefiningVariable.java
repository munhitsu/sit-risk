package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.expr.Binding;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.Value;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;

/**
* This class defines common behaviour across the compiled instructions for xsl:variable and xsl:param.
* In particular, this class contains the method used to evaluate the variable.
*/

public abstract class DefiningVariable extends GeneralVariable implements Binding  {

    private int slotNumber;
    private SequenceType requiredType;
    private String variableName;

    public DefiningVariable() {};

    public int getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(int s) {
        slotNumber = s;
    }

    public SequenceType getRequiredType() {
        return requiredType;
    }

    public void setRequiredType(SequenceType t) {
        requiredType = t;
    }

    public void setVariableName(String s) {
        variableName = s;
    }

    public String getVariableName() {
        return variableName;
    }

    /**
    * Evaluate the variable
    */

    public Value evaluateVariable(XPathContext c) throws XPathException {
        Controller controller = c.getController();
        Bindery b = controller.getBindery();

        if (isGlobal()) {
            Value v = b.evaluateGlobalVariable(this);

            if (v==null) {

                // This is the first reference to a global variable; try to evaluate it now.
                // But first set a flag to stop looping. This flag is set in the Bindery because
                // the VariableReference itself can be used by multiple threads simultaneously

                try {
                    b.setExecuting(this, true);

                    Object[] savedContext = controller.saveContext();
                    controller.setGlobalContext();
                    process(controller.newXPathContext());
                    controller.restoreContext(savedContext);

                    b.setExecuting(this, false);

                    v = b.evaluateGlobalVariable(this);
                    // System.err.println("After evaluation DefiningVar#eval v=" + v);
                    // v.display(10);
                } catch (TransformerException err) {
                    if (err instanceof XPathException.Circularity) {
                        throw new XPathException.Dynamic("Circular definition of variable " + getVariableName());
                    } else if (err instanceof XPathException) {
                        throw (XPathException)err;
                    } else {
                        throw new XPathException.Dynamic(err);
                    }
                }

                if (v==null) {
                    throw new XPathException.Dynamic("Variable " + getVariableName() + " is undefined");
                }
            }
            return v;

        } else {
            // local variable
            return c.evaluateLocalVariable(slotNumber);
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
