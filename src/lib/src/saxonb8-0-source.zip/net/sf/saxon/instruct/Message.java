package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.pattern.NoNodeTest;
import net.sf.saxon.event.Emitter;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.event.TreeReceiver;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.Validation;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.value.SequenceType;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerException;
import java.io.OutputStreamWriter;
import java.util.Properties;

/**
* An xsl:message element in the stylesheet.
*/

public class Message extends Instruction {

    private Expression terminate;
    private Expression select;

    public Message(Expression select, Expression terminate) {
        this.terminate = terminate;
        this.select = select;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "message";
    }

    public ItemType getItemType() {
        return NoNodeTest.getInstance();
    }

    public int getCardinality() {
        return StaticProperty.EMPTY;
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        Emitter emitter = controller.getMessageEmitter();
        if (emitter==null) {
            emitter = controller.makeMessageEmitter();
        }
        if (emitter.getWriter()==null) {
            emitter.setWriter(new OutputStreamWriter(System.err));
        }

        TreeReceiver rec = new TreeReceiver(emitter);
        SequenceReceiver old = controller.getReceiver();
        Properties props = new Properties();
        props.put(OutputKeys.OMIT_XML_DECLARATION, "yes");
        emitter.setOutputProperties(props);
        controller.changeOutputDestination(props, rec, false, Validation.PRESERVE, null);

        if (select != null) {
            SequenceIterator iter = select.iterate(context);
            while (true) {
                Item item = iter.next();
                if (item == null) {
                    break;
                }
                rec.append(item);
            }
        }
        processChildren(context);

        controller.resetOutputDestination(old);

        if (terminate != null) {
            String term = terminate.evaluateAsString(context);
            if (term.equals("no")) {
                // no action
            } else if (term.equals("yes")) {
                throw new TerminationException("Processing terminated by xsl:message at line " + getLineNumber());
            } else {
                throw new TransformerException("The terminate attribute of xsl:message must be 'yes' or 'no'");
            }
        }
        return null;
    }

}
//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
