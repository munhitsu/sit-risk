package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.Orphan;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.event.SequenceOutputter;
import net.sf.saxon.expr.*;

import javax.xml.transform.TransformerException;
import java.util.List;

/**
 * Common superclass for XSLT instructions whose content template produces a text
 * value: xsl:attribute, xsl:comment, xsl:processing-instruction, xsl:namespace,
 * and xsl:text
 */

public abstract class SimpleNodeConstructor extends ExprInstruction {

    protected Expression select = null;
    protected Expression separator = null;

    public final void setSelect(Expression select) {
        this.select = select;
    }

    public final void setSeparator(Expression separator) {
        this.separator = separator;
    }

    public abstract void typeCheck(StaticContext env) throws XPathException;

    /**
     * The analyze() method is called in XQuery, where node constructors
     * are implemented as Expressions. In this case the required type for the
     * select expression is a single string.
     * @param env The static context for the query
     * @return the rewritten expression
     * @throws XPathException if any static errors are found in this expression
     * or any of its children
     */

    public Expression analyze(StaticContext env) throws XPathException {
        typeCheck(env);
        if (separator != null) {
            separator = separator.analyze(env);
            RoleLocator role =
                new RoleLocator(RoleLocator.INSTRUCTION, "xsl:" + getInstructionName() + "/separator", 0);
            // TODO: identify the context in a way that's more meaningful in XQuery
            separator = TypeChecker.staticTypeCheck(separator, SequenceType.SINGLE_STRING, false, role);
        }
        if (select != null) {
            select = select.analyze(env);
            RoleLocator role =
                new RoleLocator(RoleLocator.INSTRUCTION, "xsl:" + getInstructionName() + "/select", 0);
            select = TypeChecker.staticTypeCheck(select, SequenceType.SINGLE_STRING, false, role);
        } else {
            if (children != null) {
                for (int c=0; c<children.length; c++) {
                    if (children[c] instanceof ExprInstruction) {
                        children[c] = (ExprInstruction)((ExprInstruction)children[c]).analyze(env);
                    } else {
                        throw new IllegalStateException("Children of an ExprInstruction must themselves be ExprInstructions");
                    }
                }
            }
        }
        return this;
    }


    public void getXPathExpressions(List list) {
        if (select != null) {
            list.add(select);
        }
        if (separator != null && !(separator instanceof StringValue)) {
            list.add(separator);
        }
    }

    /**
    * Expand the stylesheet elements subordinate to this one, returning the result
    * as a string. The expansion must not generate any element or attribute nodes.
    * @param context The dynamic context for the transformation
    */

    public CharSequence expandChildren(XPathContext context) throws TransformerException {

        String sep = " ";
        if (separator != null) {
            sep = separator.evaluateAsString(context);
        }

        if (select != null) {
            if (select instanceof StringValue) {
                return ((StringValue)select).getStringValue();
            } else {
                return flatten(select.iterate(context), sep);
            }

        } else {
            Controller controller = context.getController();
            SequenceReceiver old = controller.getReceiver();
            SequenceOutputter seq = new SequenceOutputter();
            seq.setConfiguration(controller.getConfiguration());
            controller.changeToSequenceOutputDestination(seq);
            // process the child elements in the stylesheet
            processChildren(context);
            controller.resetOutputDestination(old);
            return flatten(seq.getSequence().iterate(context), sep);

        }
    }

    /**
     * Flatten the value of the sequence to a character string
     */

    private StringBuffer flatten(SequenceIterator content, String separator)
    throws XPathException {
        StringBuffer buffer = new StringBuffer();
        boolean first = true;
        while(true) {
            Item item = content.next();
            if (item == null) {
                break;
            }
            if (first) {
                first = false;
            } else {
                buffer.append(separator);
            }
            buffer.append(item.getStringValue());
        }
        return buffer;
    }

    /**
     * Evaluate as an expression. We rely on the fact that when these instructions
     * are generated by XQuery, there will always be a valueExpression to evaluate
     * the content
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        String content = (select==null ?
                    "" :
                    select.evaluateAsString(context));
        Orphan o = new Orphan(context.getController().getNamePool());
        o.setNodeKind((short)getItemType().getPrimitiveType());
        o.setStringValue(content);
        try {
            o.setNameCode(evaluateNameCode(context));
        } catch (XPathException err) {
            throw err;
        } catch (TransformerException err) {
            throw new XPathException.Dynamic(err);
        }
        return o;
    }

    protected int evaluateNameCode(XPathContext context)
    throws XPathException, TransformerException {
        return -1;
    }

    /**
     * Display this instruction as an expression, for diagnostics
     */

    public void display(int level, NamePool pool) {
        if (select != null) {
            select.display(level, pool);
        } else if (children.length==0) {
            System.err.println(ExpressionTool.indent(level) + "empty content");
        } else {
            Instruction.displayChildren(children, level+1, pool);
        }
    }

    /**
      * Offer promotion for subexpressions. The offer will be accepted if the subexpression
      * is not dependent on the factors (e.g. the context item) identified in the PromotionOffer.
      * By default the offer is not accepted - this is appropriate in the case of simple expressions
      * such as constant values and variable references where promotion would give no performance
      * advantage. This method is always called at compile time.
      *
      * @param offer details of the offer, for example the offer to move
      *     expressions that don't depend on the context to an outer level in
      *     the containing expression
      * @exception XPathException if any error is detected
      */

     public void promoteInst(PromotionOffer offer) throws XPathException {
         // note, this is identical to the code in SimpleNodeConstructor
         if (select != null) {
             select = select.promote(offer);
         }
         if (children != null) {
             for (int c=0; c<children.length; c++) {
                 if (children[c] instanceof Expression) {
                     Expression p = ((Expression)children[c]).promote(offer);
                     if (p instanceof Instr) {
                         children[c] = (Instr)p;
                     } else {
                         children[c] = new SequenceInstruction(p, null);
                     }
                 } else {
                     throw new IllegalStateException("Children of an ExprInstruction must be expressions");
                 }
             }
         }
     }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
