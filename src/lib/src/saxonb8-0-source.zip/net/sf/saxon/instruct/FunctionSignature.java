package net.sf.saxon.instruct;

import net.sf.saxon.value.SequenceType;

/**
 * The class FunctionSignature represents information about the name, argument
 * types, and result type of a function.
 */

public interface FunctionSignature {

    /* TODO: this class is currently used only for user-defined functions. It
        could be used more generally, for system functions and external functions.
        The different kinds of function implementation could also be grouped under
        a common interface, and the same expression class could then be used for
        all kinds of function call...
    */

    /**
     * Get the name of the function, as a namepool fingerprint
     * @return the fingerprint of the function name
     */
    public int getFunctionFingerprint();
    /**
     * Get the type of value returned by this function
     * @return the declared result type, or the inferred result type
     * if this is more precise
     */
    public SequenceType getResultType();

    /**
     * Get the required types of the arguments to this function, as an array
     * @return an array of SequenceType objects, one for each formal argument,
     * indicating the required type of the argument
     */
    public SequenceType[] getArgumentTypes();

    /**
     * Get the number of arguments (the arity) of the function
     * @return  the function's arity
     */
    public int getNumberOfArguments();
}
