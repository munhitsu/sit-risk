package net.sf.saxon.instruct;
import net.sf.saxon.Configuration;
import net.sf.saxon.Controller;
import net.sf.saxon.ParameterSet;
import net.sf.saxon.expr.*;
import net.sf.saxon.om.NamespaceConstant;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.Type;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.SourceLocator;
import javax.xml.transform.TransformerException;
import java.io.Serializable;

/**
* Abstract superclass for all instructions in the compiled stylesheet.
* This represents a compiled instruction, and as such, the minimum information is
* retained from the original stylesheet. <br>
* Note: this class implements SourceLocator.
*/

public abstract class Instruction implements Serializable, SourceLocator, Instr {

    // The instructions that are children of this instruction
    protected Instr[] children;

    // The containing Executable
    private Executable executable;

    // The location of this instruction. The top 12 bits represent the systemId of the
    // source stylesheet module, as an index into the systemID map held by the Executable object.
    // The bottom 20 bits represent the line number within that module
    private int sourceLocation;

    /**
    * Constructor
    */

    public Instruction() {}


    /**
     * Set the containing executable
     */

    public void setExecutable(Executable exec) {
        this.executable = exec;
    }

    public Executable getExecutable() {
        return executable;
    }

    /**
    * Set the children of this instruction
    * @param children The instructions that are children of this instruction
    */

    public void setChildren(Instr[] children) {
        if (children==null || children.length==0) {
            this.children = null;
        } else {
            this.children = children;
        }
    }

    /**
    * Get the children of this instruction
    * @return the children of this instruction, as an array of Instruction objects. May return either
     * a zero-length array or null if there are no children
    */

    public Instr[] getChildren() {
        return children;
    }

    /**
    * Set the system ID and the line number of this instruction.
    * @param module integer identifying the module in which this instruction occurs,
    * This is an index into the module array owned by the Executable object
    * @param lineNumber the line number of this instruction within its module
    */

    public void setSourceLocation(int module, int lineNumber) {
        sourceLocation = (module<<20) | (lineNumber & 0x7ffff);
    }

    public String getSystemId() {
        int module = (sourceLocation>>20) & 0x3ff;
        if (executable==null) return "*unknown*";
        return executable.getSystemId(module);
    }

    public String getPublicId() {
        return null;
    }

    public int getColumnNumber() {
        return -1;
    }

    /**
    * Get the line number of the source stylesheet instruction within its module.
    * @return the line number of the instruction
    */

    public int getLineNumber() {
        return sourceLocation & 0x7ffff;
    }

    /**
    * Get the name of the instruction for use in diagnostics
    */

    public abstract String getInstructionName();

    /**
     * Get the namespace of the instruction name. Defaults to the XSLT namespace
     * @return the namespace of the instruction name
     */

    public String getInstructionNamespace() {
        return NamespaceConstant.XSLT;
    }
    /**
     * Get the item type of the items returned by evaluating this instruction
     * @return the static item type of the instruction
     */

    public ItemType getItemType() {
        // TODO: some kinds of instruction unnecessarily return ITEM_TYPE when they could be more specific
        return Type.ITEM_TYPE;
    }

    /**
     * Get the cardinality of the sequence returned by evaluating this instruction
     * @return the static cardinality
     */

    public int getCardinality() {
        return StaticProperty.ALLOWS_ZERO_OR_MORE;
    }

    /**
    * ProcessLeavingTail: called to do the real work of this instruction. This method
    * must be implemented in each subclass. The results of the instruction are written
    * to the current Receiver, which can be obtained via the Controller.
    * @param context The dynamic context of the transformation, giving access to the current node,
    * the current variables, etc.
    * @return null if the instruction has completed execution; or a TailCall indicating
    * a function call or template call that is delegated to the caller, to be made after the stack has
    * been unwound so as to save stack space.
    */

    public abstract TailCall processLeavingTail(XPathContext context) throws TransformerException;

    // TODO: provide an iterate() method that iterates over the results of the instruction.
    // This is needed to achieve lazy evaluation, especially of function calls.

    /**
    * Process the instruction, without returning any tail calls
    * @param context The dynamic context, giving access to the current node,
    * the current variables, etc.
    */

    public void process(XPathContext context) throws TransformerException {
        TailCall tc = processLeavingTail(context);
        while (tc != null) {
            tc = tc.processLeavingTail(context.getController());
        }
    }

    /**
    * Process the children of this instruction, including any tail calls
    * @param context The dynamic context for the transformation
     * @throws TransformerException if a dynamic error occurs
    */

    protected void processChildren(XPathContext context) throws TransformerException {
        if (children==null) {
            return;
        }
        Controller controller = context.getController();

        for (int i=0; i<children.length; i++) {
            try {
                children[i].process(context);
            } catch (TransformerException err) {
                if (err instanceof SkipInstructionException) {
                    // report the error and continue
                    recoverableError(children[i], err.getMessage(), controller);
                } else {
                    // terminate execution
                    throw dynamicError(children[i], err, controller);
                }
            }
        }
    }

    /**
    * Process the children of this instruction, returning any tail call made by
    * the last child instruction
    * @param context The dynamic context of the transformation, giving access to the current node,
    * the current variables, etc.
    * @return null if the instruction has completed execution; or a TailCall indicating
    * a function call or template call that is delegated to the caller, to be made after the stack has
    * been unwound so as to save stack space.
    */

    protected TailCall processChildrenLeavingTail(XPathContext context) throws TransformerException {

        if (children==null) return null;

        Controller controller = context.getController();
        TailCall tc = null;
        for (int i=0; i<children.length; i++) {
            try {
                tc = children[i].processLeavingTail(context);
            } catch (TransformerException err) {
                if (err instanceof SkipInstructionException) {
                    // report the error and continue
                    recoverableError(children[i], err.getMessage(), controller);
                } else {
                    // terminate execution
                    throw dynamicError(children[i], err, controller);
                }
            }
        }
    	return tc;
    }

    /**
     * Get a SourceLocator identifying the location of this instruction
     */

    public SourceLocator getSourceLocator() {
        return this;
    }

    /**
    * Construct an exception with diagnostic information. Note that this method
    * returns the exception, it does not throw it: that is up to the caller.
    * @param error The exception containing information about the error
    * @param controller The controller of the transformation
    * @return an exception based on the supplied exception, but with location information
    * added relating to this instruction
    */

    protected static TransformerException dynamicError(Instr instr, TransformerException error, Controller controller) {
        //if (error instanceof StyleException) return error;
        if (error instanceof TerminationException) return error;
        if (error.getException() instanceof TransformerException) {
            // This happens when the instruction executes an XPath expression and the XPath
            // expression invokes XSLT instructions via a variable reference or a function call.
            // We return the underlying exception in order to show the original line number.
            return dynamicError(instr, (TransformerException)error.getException(), controller);
        }
        if (error.getLocator()==null ||
                (error.getLocator() instanceof ExpressionLocation &&
                        controller.getConfiguration().getHostLanguage() != Configuration.XQUERY) ||
                error.getLocator().getLineNumber()==-1) {
            // If the exception has no location information, construct a new
            // exception containing the required information
            try {
                return new TransformerException(error.getMessage(),
                                                instr.getSourceLocator(),
                                                error.getException());
            } catch (Exception secondaryError) {
                // currently happens when running XQuery
                return error;
            }
        } else if (error instanceof XPathException) {
            // a locator within an XPathException is useful in XQuery, but less
            // useful in XSLT, so the action here depends on the host language
            if (controller.getConfiguration().getHostLanguage() == Configuration.XQUERY) {
                return error;
            } else if (error.getLocator() != null) {
                return error;
            } else {
                return new TransformerException(error.getMessage(),
                                                instr.getSourceLocator(),
                                                error.getException());
            }
        }
        return error;
    }

    /**
    * Raise a dynamic error
    * @param message An English text error message
    * @param controller The controller of the transformation
    * @return an exception containing details of the dynamic error
    */

    protected TransformerException dynamicError(String message, Controller controller) {
        return new TransformerException(message, getSourceLocator());
    }

    /**
    * Signal a recoverable error. The error may be reported if the error handling
    * policy indicates that recoverable errors should be reported
    * @param message an English-language error message
    * @param controller the controller for the transformation
    * @throws TransformerException - the method throws an exception if the selected
    * policy is not to recover from recoverable errors
    */

    protected static void recoverableError(Instr instr, String message, Controller controller)
    throws TransformerException {
        controller.recoverableError(message, instr.getSourceLocator());
    }

    /**
     * Display the children of an intstruction for diagostics
     */

    public static void displayChildren(Instr[] children, int level, NamePool pool) {
        for (int c=0; c<children.length; c++) {
            if (children[c] instanceof Expression) {
                ((Expression)children[c]).display(level+1, pool);
            } else if (children[c] instanceof Instruction) {
                System.err.println(ExpressionTool.indent(level+1) + ((Instruction)children[c]).getInstructionName());
            } else {
                System.err.println(children[c].toString());
            }
        }
    }

    /**
     * Assemble a ParameterSet. Method used by instructions that have xsl:with-param
     * children. This method is used for the non-tunnel parameters.
     */

    protected static ParameterSet assembleParams(XPathContext context,
                                          WithParam[] actualParams)
    throws TransformerException {
        if (actualParams == null || actualParams.length == 0) {
            return null;
        }
        ParameterSet params = new ParameterSet();
        for (int i=0; i<actualParams.length; i++) {
            params.put(actualParams[i].getVariableFingerprint(),
                       actualParams[i].getSelectValue(context));
        }
        return params;
    }

    /**
     * Assemble a ParameterSet. Method used by instructions that have xsl:with-param
     * children. This method is used for the tunnel parameters.
     */

    protected static ParameterSet assembleTunnelParams(XPathContext context,
                                          WithParam[] actualParams)
    throws TransformerException {
        ParameterSet existingParams = context.getController().getBindery().getTunnelParameters();
        if (existingParams == null) {
            return assembleParams(context, actualParams);
        }
        ParameterSet newParams = new ParameterSet(existingParams);
        if (actualParams == null || actualParams.length == 0) {
            return newParams;
        }
        for (int i=0; i<actualParams.length; i++) {
            newParams.put(actualParams[i].getVariableFingerprint(),
                          actualParams[i].getSelectValue(context));
        }
        return newParams;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
