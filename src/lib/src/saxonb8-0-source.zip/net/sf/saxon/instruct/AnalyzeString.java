package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.RegexTranslator;
import net.sf.saxon.trace.TraceListener;
import net.sf.saxon.trace.InstructionInfo;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.functions.Matches;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.Item;

import javax.xml.transform.TransformerException;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
* An xsl:analyze-string elements in the stylesheet. New at XSLT 2.0<BR>
*/

public class AnalyzeString extends Instruction {

    private Expression select;
    private Expression regex;
    private Expression flags;
    private Block matching;
    private Block nonMatching;
    private Pattern pattern;    // a regex pattern, not an XSLT pattern!

    /**
     * Construct an AnalyzeString instruction
     * @param select the expression containing the input string
     * @param regex the regular expression
     * @param flags the flags parameter
     * @param matching actions to be applied to a matching substring
     * @param nonMatching actions to be applied to a non-matching substring
     * @param pattern the compiled regular expression, if it was known statically
     */
    public AnalyzeString(   Expression select,
                            Expression regex,
                            Expression flags,
                            Block matching,
                            Block nonMatching,
                            Pattern pattern ) {
        this.select = select;
        this.regex = regex;
        this.flags = flags;
        this.matching = matching;
        this.nonMatching = nonMatching;
        this.pattern = pattern;
    }

    public String getInstructionName() {
        return "analyze-string";
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException
    {
        Controller controller = context.getController();
        SequenceIterator savedIterator = controller.getCurrentIterator();
        RegexIterator savedRegexIterator = controller.getCurrentRegexIterator();

	    boolean isTracing = controller.isTracing();

        String input = select.evaluateAsString(context);

        Pattern re = pattern;
        if (re == null) {
            int jflags = Matches.setFlags(flags.evaluateAsString(context));
            try {
                String javaRegex = RegexTranslator.translate(
                        regex.evaluateAsString(context), true);
                re = Pattern.compile(javaRegex, jflags);
            } catch (RegexTranslator.RegexSyntaxException err) {
                throw new XPathException.Dynamic(err);
            } catch (PatternSyntaxException err) {
                throw new XPathException.Dynamic(err);
            }
        }

        RegexIterator iter = new RegexIterator(input, re);
        controller.setCurrentIterator(iter);
        controller.setCurrentRegexIterator(iter);
        XPathContext innerContext = context.newContext();
        innerContext.setCurrentIterator(iter);


        while (true) {
            Item it = iter.next();
            if (it == null) {
                break;
            }
            if (iter.isMatching()) {
                if (matching != null) {
                    matching.process(innerContext);
                }
            } else {
                if (nonMatching != null) {
                    nonMatching.process(innerContext);
                }
            }
        }

        controller.setCurrentIterator(savedIterator);
        controller.setCurrentRegexIterator(savedRegexIterator);
        return null;

    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
