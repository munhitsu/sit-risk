package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.ParameterSet;
import net.sf.saxon.event.SequenceChecker;
import net.sf.saxon.event.SequenceOutputter;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.pattern.NoNodeTest;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.Value;

import javax.xml.transform.TransformerException;

/**
* This class defines common behaviour across xsl:variable, xsl:param, and xsl:with-param;
* also saxon:assign
*/

public abstract class GeneralVariable extends Instruction  {


    private static final int ASSIGNABLE = 1;
    private static final int GLOBAL = 2;
    private static final int REQUIRED = 4;
    private static final int TUNNEL = 8;
    private static final int CONTAINS_LOCALS = 16;

    private byte properties = 0;
    private Expression select = null;
    private SequenceType requiredType = null;
    protected int variableFingerprint = -1;

    public GeneralVariable() {};

    public void init(   Expression select,
                        SequenceType requiredType,
                        int variableFingerprint) {
        this.select = select;
        this.requiredType = requiredType;
        this.variableFingerprint = variableFingerprint;
    }

    public void setSelect(Expression select) {
        this.select = select;
    }

    public Expression getSelectExpression() {
        return select;
    }

    public void setVariableFingerprint(int variableFingerprint) {
        this.variableFingerprint = variableFingerprint;
    }

    public void setGlobal(boolean global) {
        if (global) {
            properties |= GLOBAL;
        } else {
            properties &= ~GLOBAL;
        }
    }

    public void setAssignable(boolean assignable) {
        if (assignable) {
            properties |= ASSIGNABLE;
        } else {
            properties &= ~ASSIGNABLE;
        }
    }

    public void setRequiredParam(boolean requiredParam) {
        if (requiredParam) {
            properties |= REQUIRED;
        } else {
            properties &= ~REQUIRED;
        }
    }

    public void setContainsLocals(boolean containsLocals) {
        if (containsLocals) {
            properties |= CONTAINS_LOCALS;
        } else {
            properties &= ~CONTAINS_LOCALS;
        }
    }

    public void setTunnel(boolean tunnel) {
        if (tunnel) {
            properties |= TUNNEL;
        } else {
            properties &= ~TUNNEL;
        }
    }

    /**
    * Test whether it is permitted to assign to the variable using the saxon:assign
    * extension element. This will only be true if the extra attribute saxon:assignable="yes"
    * is present.
    */

    public final boolean isAssignable() {
        return (properties & ASSIGNABLE) != 0;
    }

    public int getVariableFingerprint() {
        return variableFingerprint;
    }

    public ItemType getItemType() {
        return NoNodeTest.getInstance();
    }

    public int getCardinality() {
        return StaticProperty.EMPTY;
    }

    public final boolean isGlobal() {
        return (properties & GLOBAL) != 0;
    }

    public final boolean containsLocals() {
        return (properties & CONTAINS_LOCALS) != 0;
    }

    public final boolean isRequiredParam() {
        return (properties & REQUIRED) != 0;
    }

    public final boolean isTunnelParam() {
        return (properties & TUNNEL) != 0;
    }

    public String getInstructionName() {
        return "variable";
    }

    /**
     * Evaluate the variable. That is,
     * get the value of the select expression if present or the content
     * of the element otherwise, either as a tree or as a sequence
    */

    public Value getSelectValue(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        if (select==null) {
            // The value of the variable is a sequence of nodes and/or atomic values

            // Note that the "temporary tree" case has been dealt with by creating
            // a child DocumentInstr instruction to handle the tree construction

            // TODO: rather than evaluating child instructions and "pushing" the results
            // to an outputter, evaluation should be lazy. This means that an iterator should
            // be defined which causes instructions to be evaluated only when their output is needed
            // by an XPath expression. This would also allow type-checking and conversion code
            // to be re-used (i.e. ItemChecker and CardinalityChecker).

            SequenceReceiver old = controller.getReceiver();
            SequenceOutputter out = new SequenceOutputter();
            SequenceReceiver seq = out;
            seq.setConfiguration(controller.getConfiguration());
            controller.changeToSequenceOutputDestination(out);

            if (requiredType != null) {
                SequenceChecker checker = new SequenceChecker();
                checker.setUnderlyingReceiver(seq);
                checker.setRequiredType(requiredType);
                seq = checker;
                controller.setReceiver(checker);
            }
            //seq.setSystemId(baseURI);

            if (isGlobal() && containsLocals()) {
                Bindery bindery = controller.getBindery();
                bindery.openStackFrame(ParameterSet.EMPTY_PARAMETER_SET, null);
                processChildren(controller.newXPathContext());
                bindery.closeStackFrame();
            } else {
                processChildren(controller.newXPathContext());
            }
            controller.resetOutputDestination(old);
            if (requiredType != null) {
                ((SequenceChecker)seq).finalCheck();
            }
            return out.getSequence();

        } else {
            // There is a select attribute: do a lazy evaluation of the expression,
            // which will already contain any code to force conversion to the required type.

            // But with global variables, we have already delayed evaluating the expression
            // until the first reference to the variable is encountered, and there's not
            // much point delaying it any further.

            if (isAssignable() || isGlobal()) {
                if (containsLocals()) {
                    Bindery bindery = controller.getBindery();
                    bindery.openStackFrame(ParameterSet.EMPTY_PARAMETER_SET, null);
                    Value val = ExpressionTool.eagerEvaluate(select, controller.newXPathContext());
                    bindery.closeStackFrame();
                    return val;
                } else {
                    return ExpressionTool.eagerEvaluate(select, controller.newXPathContext());
                }
            } else {
                return ExpressionTool.lazyEvaluate(select, controller.newXPathContext());
            }
        }
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
