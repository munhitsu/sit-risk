package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.sort.*;
import net.sf.saxon.trace.TraceListener;

import javax.xml.transform.TransformerException;
import java.text.Collator;

/**
* Handler for xsl:for-each-group elements in stylesheet. This is a new instruction
* defined in XSLT 2.0
*/

public class ForEachGroup extends Instruction {

    public static final int GROUP_BY = 0;
    public static final int GROUP_ADJACENT = 1;
    public static final int GROUP_STARTING = 2;
    public static final int GROUP_ENDING = 3;


    private Expression select = null;
    private byte algorithm;
    private Object key;     // either an expression or pattern, depending on algorithm
    private Collator collator = null;
    private SortKeyDefinition[] sortKeys = null;

    public ForEachGroup(    Expression select,
                            byte algorithm,
                            Object key,
                            Collator collator,
                            SortKeyDefinition[] sortKeys ) {
        this.select = select;
        this.algorithm = algorithm;
        this.key = key;
        this.collator = collator;
        this.sortKeys = sortKeys;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "for-each-group";
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        GroupIterator savedGroupIterator = controller.getCurrentGroupIterator();
        SequenceIterator savedIterator = controller.getCurrentIterator();
        Template savedTemplate = controller.getCurrentTemplate();
        controller.setCurrentTemplate(null);

        SequenceIterator population = select.iterate(context);

        // get an iterator over the groups in "order of first appearance"

        GroupIterator groupIterator;
        switch (algorithm) {
            case GROUP_BY:
                XPathContext newContext = context.newContext();
                newContext.setCurrentIterator(population);
                groupIterator = new GroupByIterator(
                        population,
                        (Expression)key,
                        newContext,
                        collator
                );
                break;
            case GROUP_ADJACENT:
                XPathContext newContext2 = context.newContext();
                newContext2.setCurrentIterator(population);
                groupIterator = new GroupAdjacentIterator(
                        population,
                        (Expression)key,
                        newContext2,
                        collator
                );
                break;
            case GROUP_STARTING:
                groupIterator = new GroupStartingIterator(
                        population,
                        (Pattern)key,
                        context.getController()
                );
                break;
            case GROUP_ENDING:
                groupIterator = new GroupEndingIterator(
                        population,
                        (Pattern)key,
                        context.getController()
                );
                break;
            default:
                throw new AssertionError("Unknown grouping algorithm");
        }


        // now iterate over the leading nodes of the groups

        if (sortKeys!=null) {
            // TODO: avoid reducing the sort keys if they have no dependencies
            FixedSortKeyDefinition[] reducedSortKeys = new FixedSortKeyDefinition[sortKeys.length];
            XPathContext xpc = controller.newXPathContext();
            for (int s=0; s<sortKeys.length; s++) {
                reducedSortKeys[s] = sortKeys[s].reduce(xpc);
            }
            groupIterator = new SortedGroupIterator(  xpc,
                                           groupIterator,
                                           reducedSortKeys);
        }

        controller.setCurrentIterator(groupIterator);
        controller.setCurrentGroupIterator(groupIterator);
        XPathContext innerContext = context.newContext();
        innerContext.setCurrentIterator(groupIterator);

        if (controller.isTracing()) {
            TraceListener listener = controller.getTraceListener();
            while(true) {
                Item item = groupIterator.next();
                if (item == null) break;
                listener.startCurrentItem(item);
                processChildren(innerContext);
                listener.endCurrentItem(item);
            }
        } else {
            while(true) {
                Item item = groupIterator.next();
                if (item == null) break;
                processChildren(innerContext);
            }
        }

        controller.setCurrentGroupIterator(savedGroupIterator);
        controller.setCurrentIterator(savedIterator);
        controller.setCurrentTemplate(savedTemplate);
        return null;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
