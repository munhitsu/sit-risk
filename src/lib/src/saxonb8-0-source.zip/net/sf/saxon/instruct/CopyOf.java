package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.event.*;
import net.sf.saxon.expr.*;
import net.sf.saxon.om.*;
import net.sf.saxon.type.*;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.List;


/**
* An xsl:copy-of element in the stylesheet.
*/

public class CopyOf extends ExprInstruction {

    private Expression select;
    private boolean copyNamespaces;
    private int validation;
    private SchemaType schemaType;
    private ValidationContext validationContext = GlobalValidationContext.getInstance();
    private boolean requireDocumentOrElement = false;

    public CopyOf(  Expression select,
                    boolean copyNamespaces,
                    int validation,
                    SchemaType schemaType) {
        this.select = select;
        this.copyNamespaces = copyNamespaces;
        this.validation = validation;
        this.schemaType = schemaType;
    }

    /**
    * Get the name of this instruction, for diagnostics and tracing
    */

    public String getInstructionName() {
        return "copy-of";
    }

    /**
     * For XQuery, the operand (select) must be a single element or document node.
     * @param requireDocumentOrElement
     */
    public void setRequireDocumentOrElement(boolean requireDocumentOrElement) {
        this.requireDocumentOrElement = requireDocumentOrElement;
    }

    /**
     * Set the validation context
     * @param validationContext
     */

    public void setValidationContext(ValidationContext validationContext) {
        this.validationContext = validationContext;
    }

    /**
    * Process this xsl:copy-of instruction
    * @param context the dynamic context for the transformation
    * @return null - this implementation of the method never returns a TailCall
    */

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {

        Controller controller = context.getController();
    	SequenceReceiver out = controller.getReceiver();

        int whichNamespaces = (copyNamespaces ? NodeInfo.ALL_NAMESPACES : NodeInfo.NO_NAMESPACES);

    	SequenceIterator iter = select.iterate(context);
	    while (true) {

            try {
                Item item = iter.next();
                if (item == null) {
                    break;
                }
                if (item instanceof NodeInfo) {
                    NodeInfo source = (NodeInfo)item;
                    int kind = source.getNodeKind();
                    if (requireDocumentOrElement &&
                            !(kind == Type.ELEMENT || kind == Type.DOCUMENT)) {
                        throw new TransformerException(
                                "Operand of validate expression must be a document or element node"
                        );
                    }
                    switch (kind) {

                    case Type.ELEMENT:

                        Receiver eval = controller.getConfiguration().getElementValidator(
                                out, source.getNameCode(),
                                schemaType, validation, validationContext,
                                controller.getNamePool()
                        );
                        source.copy(eval, whichNamespaces, true);
                        break;

                    case Type.ATTRIBUTE:
                        try {
                            copyAttribute(source, schemaType, validation, controller);
                        } catch (NoOpenStartTagException err) {
                            recoverableError(this, "Cannot write an attribute node when no element start tag is open",
                                             controller);
                        }
                        break;
                    case Type.TEXT:
                        out.characters(source.getStringValue(), 0);
                        break;

                    case Type.PROCESSING_INSTRUCTION:
                        out.processingInstruction(source.getDisplayName(), source.getStringValue(), 0);
                        break;

                    case Type.COMMENT:
                        out.comment(source.getStringValue(), 0);
                        break;

                    case Type.NAMESPACE:
                        try {
                            source.copy(out, NodeInfo.NO_NAMESPACES, false);
                        } catch (NoOpenStartTagException err) {
                            recoverableError(this, "Cannot write a namespace node when no element start tag is open",
                                             controller);
                        }
                        break;

                    case Type.DOCUMENT:
                        // TODO: if we are building a sequence rather than a tree, we
                        // need to add a document node to the constructed sequence

                        Receiver val = controller.getConfiguration().
                                getDocumentValidator(out,
                                                     source.getBaseURI(),
                                                     controller.getNamePool(),
                                                     validation);
                        val.setConfiguration(controller.getConfiguration());
                        //val.startDocument();
                        source.copy(val, whichNamespaces, true);
                        //val.endDocument();
                        break;

                    default:
                        throw new IllegalArgumentException("Unknown node kind " + source.getNodeKind());

                    }

                } else {
                    out.append(item);
                    //out.characters(item.getStringValue(), 0);
                }
            } catch (SkipInstructionException err) {
                recoverableError(this, err.getMessage(), controller);
            }
        }
    	return null;
    }

    protected static void copyAttribute(NodeInfo source,
                                        SchemaType schemaType,
                                        int validation,
                                        Controller controller)
    throws TransformerException {
        int nameCode = source.getNameCode();
        int annotation = -1;
        int opt = 0;
        String value = source.getStringValue();
        if (schemaType != null) {
            if (schemaType instanceof SimpleType) {
                try {
                    ((SimpleType)schemaType).validateContent(value, DummyNamespaceResolver.getInstance());
                    if (((SimpleType)schemaType).isNamespaceSensitive()) {
                        opt |= ReceiverOptions.NEEDS_PREFIX_CHECK;
                    }
                    annotation = schemaType.getFingerprint();
                } catch (ValidationException err) {
                    throw new ValidationException("Attribute being copied does not match the required type. " +
                                                   err.getMessage());
                }
            } else {
                throw new TransformerException("Cannot validate an attribute against a complex type");
            }
        } else if (validation==Validation.STRICT ||
            validation==Validation.LAX) {
            long res = controller.getConfiguration().validateAttribute(nameCode,
                                                                     value,
                                                                     validation);
            annotation = (int)(res & 0xffffffff);
            opt |= (int)(res >> 32);
        }

        controller.getReceiver().attribute(nameCode, annotation, value, opt);
    }

     public Expression simplify() throws XPathException {
        return super.simplify();
    }

    public ItemType getItemType() {
        return select.getItemType();
        // TODO: could do better than this if the instruction is validating
    }

    public int getCardinality() {
        return select.getCardinality();
    }

    public int getDependencies() {
        return select.getDependencies();
    }

    public int getSpecialProperties() {
        return 0;
    }

    protected void promoteInst(PromotionOffer offer) throws XPathException {
        select = select.promote(offer);
    }

    protected void getXPathExpressions(List list) {
        list.add(select);
    }

    /**
     * Perform static analysis of an expression and its subexpressions.
     *
     * <p>This checks statically that the operands of the expression have
     * the correct type; if necessary it generates code to do run-time type checking or type
     * conversion. A static type error is reported only if execution cannot possibly succeed, that
     * is, if a run-time type error is inevitable. The call may return a modified form of the expression.</p>
     *
     * <p>This method is called after all references to functions and variables have been resolved
     * to the declaration of the function or variable. However, the types of such functions and
     * variables will only be accurately known if they have been explicitly declared.</p>
     *
     * @param env the static context of the expression
     * @exception XPathException if an error is discovered during this phase
     *     (typically a type error)
     * @return the original expression, rewritten to perform necessary
     *     run-time type checks, and to perform other type-related
     *     optimizations
     */

    public Expression analyze(StaticContext env) throws XPathException {
        select = select.analyze(env);
        return this;
    }

    /**
     * Diagnostic print of expression structure. The expression is written to the System.err
     * output stream
     *
     * @param level indentation level for this expression
     */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "copyOf " +
                           ("validation=" + Validation.toString(validation)));
        select.display(level+1, pool);
    }

    public Expression[] getSubExpressions() {
        Expression[] sub = {select};
        return sub;
    }

    /**
     * Return the first item if there is one, or null if not
     * @param context
     * @return the result of evaluating the instruction
     * @throws XPathException
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        return super.evaluateItem(context);
    }

    public boolean effectiveBooleanValue(XPathContext context) throws XPathException {
        return super.effectiveBooleanValue(context);
    }

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        Controller controller = context.getController();
        SequenceReceiver saved = controller.getReceiver();
        SequenceOutputter out = new SequenceOutputter();
        out.setConfiguration(controller.getConfiguration());
        controller.setReceiver(out);
        try {
            process(context);
            controller.resetOutputDestination(saved);
            return out.getSequence().iterate(context);
        } catch (TransformerException err) {
            if (err instanceof ValidationException) {
                ((ValidationException)err).setSourceLocator(this);
                ((ValidationException)err).setSystemId(getSystemId());
            }
            if (err.getLocator() == null) {
                err.setLocator(this);
            }
            if (err.getException() instanceof XPathException) {
                throw (XPathException)err.getException();
            } else {
                throw new XPathException.Dynamic(err);
            }
        }
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
