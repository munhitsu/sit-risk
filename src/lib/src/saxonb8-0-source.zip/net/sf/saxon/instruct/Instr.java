package net.sf.saxon.instruct;

import net.sf.saxon.expr.XPathContext;

import javax.xml.transform.TransformerException;

/**
 * This interface represents the key characteristic of an instruction, namely that
 * it can be processed in "push" mode, writing its results to the current outputter.
 * All XSLT instructions implement this interface, and a few XPath/XQuery expressions
 * implement it as well.
 */


public interface Instr extends Locatable {

    /**
    * Process the instruction, without returning any tail calls
    * @param context The dynamic context, giving access to the current node,
    * the current variables, etc.
    */

    public void process(XPathContext context) throws TransformerException;

    /**
    * Process the instruction, optionally returning an uncompleted tail call to
     * be invoked by the caller
    * @param context The dynamic context, giving access to the current node,
    * the current variables, etc.
    */

    public TailCall processLeavingTail(XPathContext context) throws TransformerException;
}
