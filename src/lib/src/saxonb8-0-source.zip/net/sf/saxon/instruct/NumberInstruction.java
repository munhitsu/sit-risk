package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.Loader;
import net.sf.saxon.functions.NumberFn;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.expr.Atomizer;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.number.NumberFormatter;
import net.sf.saxon.number.Numberer;
import net.sf.saxon.number.Numberer_en;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.Navigator;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.pattern.Pattern;
import net.sf.saxon.pattern.NodeKindTest;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.value.NumericValue;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.IntegerValue;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.ArrayList;
import java.util.List;

/**
* An xsl:number element in the stylesheet. <br>
*/

public class NumberInstruction extends Instruction {

    private final static int SINGLE = 0;
    private final static int MULTI = 1;
    private final static int ANY = 2;
    private final static int SIMPLE = 3;

    private int level;
    private Pattern count = null;
    private Pattern from = null;
    private Expression select = null;
    private Expression value = null;
    private Expression format = null;
    private Expression groupSize = null;
    private Expression groupSeparator = null;
    private Expression letterValue = null;
    private Expression ordinal = null;
    private Expression lang = null;
    private NumberFormatter formatter = null;
    private Numberer numberer = null;
    private boolean hasVariablesInPatterns;

    private static Numberer defaultNumberer = new Numberer_en();

    public NumberInstruction(  Expression select,
                    int level,
                    Pattern count,
                    Pattern from,
                    Expression value,
                    Expression format,
                    Expression groupSize,
                    Expression groupSeparator,
                    Expression letterValue,
                    Expression ordinal,
                    Expression lang,
                    NumberFormatter formatter,
                    Numberer numberer,
                    boolean hasVariablesInPatterns ) {
        this.select = select;
        this.level = level;
        this.count = count;
        this.from = from;
        this.value = value;
        this.format = format;
        this.groupSize = groupSize;
        this.groupSeparator = groupSeparator;
        this.letterValue = letterValue;
        this.ordinal = ordinal;
        this.lang = lang;
        this.formatter = formatter;
        this.numberer = numberer;
        this.hasVariablesInPatterns = hasVariablesInPatterns;

        if (this.value != null && !Type.isSubType(this.value.getItemType(), Type.ANY_ATOMIC_TYPE)) {
            this.value = new Atomizer(this.value);
        }
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "number";
    }

    public ItemType getItemType() {
        return NodeKindTest.TEXT;
    }

    public int getCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        Receiver out = controller.getReceiver();

        long value = -1;
        List vec = null;

        if (this.value!=null) {

            SequenceIterator iter = this.value.iterate(context);
            vec = new ArrayList();
            while (true) {
                AtomicValue val = (AtomicValue)iter.next();
                if (val == null) {
                    break;
                }
                try {
                    NumericValue num;
                    if (val instanceof NumericValue) {
                        num = (NumericValue)val;
                    } else {
                        num = NumberFn.convert(val);
                    }
                    num = num.round();
                    if (num.compareTo(IntegerValue.MAX_LONG) > 0) {
                        throw new XPathException.Dynamic("A number is too large to be formatted");
                    }
                    if (num.compareTo(IntegerValue.MIN_LONG) < 0) {
                        throw new XPathException.Dynamic("The numbers to be formatted must be positive");
                    }
                    long i = ((NumericValue)num.convert(Type.INTEGER)).asLong();
                    if (i < 1) {
                        throw new XPathException.Dynamic("The numbers to be formatted must be positive");
                    }
                    vec.add(new Long(i));
                } catch (XPathException err) {
                    vec.add(val.getStringValue());
                    recoverableError(this, err.getMessage(), controller);
                }
            }

        } else {
            NodeInfo source;
            if (select != null) {
                source = (NodeInfo)select.evaluateItem(context);
            } else {
                Item item = controller.getCurrentItem();
                if (!(item instanceof NodeInfo)) {
                    recoverableError(
                            this, "context item for xsl:number must be a node", controller);
                    return null;     // error recovery action is to output nothing
                }
                source = (NodeInfo)item;
            }

            if (level==SIMPLE) {
                value = Navigator.getNumberSimple(source, controller);
            } else if (level==SINGLE) {
                value = Navigator.getNumberSingle(source, count, from, controller);
                if (value==0) {
                	vec = new ArrayList(); 	// an empty list
                }
            } else if (level==ANY) {
                value = Navigator.getNumberAny(this, source, count, from, controller, hasVariablesInPatterns);
                if (value==0) {
                	vec = new ArrayList(); 	// an empty list
                }
            } else if (level==MULTI) {
                vec = Navigator.getNumberMulti(source, count, from, controller);
            }
        }

        int gpsize = 0;
        String gpseparator = "";
        String letterVal;
        String ordinalVal = null;

        if (groupSize!=null) {
            String g = groupSize.evaluateAsString(context);
            try {
                gpsize = Integer.parseInt(g);
            } catch (NumberFormatException err) {
                throw dynamicError("group-size must be numeric", controller);
            }
        }

        if (groupSeparator!=null) {
            gpseparator = groupSeparator.evaluateAsString(context);
        }

        if (ordinal != null) {
            ordinalVal = ordinal.evaluateAsString(context);
        }

        // fast path for the simple case

        if (vec==null && format==null && gpsize==0 && lang==null) {
            out.characters("" + value, 0);
            return null;
        }

        if (numberer==null) {
            numberer = makeNumberer(lang.evaluateAsString(context));
        }

        if (letterValue==null) {
            letterVal = "";
        } else {
            letterVal = letterValue.evaluateAsString(context);
            if (!(letterVal.equals("alphabetic") || letterVal.equals("traditional"))) {
                throw dynamicError("letter-value must be \"traditional\" or \"alphabetic\"", controller);
            }
        }

        if (vec==null) {
            vec = new ArrayList();
            vec.add(new Long(value));
        }

        NumberFormatter nf;
        if (formatter==null) {              // format not known until run-time
            nf = new NumberFormatter();
            nf.prepare(format.evaluateAsString(context));
        } else {
            nf = formatter;
        }

        String s = nf.format(vec, gpsize, gpseparator, letterVal, ordinalVal, numberer);
        out.characters(s, 0);
        return null;
    }

    /**
    * Load a Numberer class for a given language and check it is OK.
    * @param language the language for which a Numberer is required
    * @return a suitable numberer. If no specific numberer is available
    * for the language, the default (English) numberer is used.
    */

    public static Numberer makeNumberer (String language) {
        Numberer numberer;
        if (language.equals("en")) {
            numberer = defaultNumberer;
        } else {
            String langClassName = "net.sf.saxon.number.Numberer_";
            for (int i=0; i<language.length(); i++) {
                if (Character.isLetter(language.charAt(i))) {
                    langClassName += language.charAt(i);
                }
            }
            try {
                numberer = (Numberer)(Loader.getInstance(langClassName));
            } catch (Exception err) {
                numberer = defaultNumberer;
            }
        }

        return numberer;
     }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
