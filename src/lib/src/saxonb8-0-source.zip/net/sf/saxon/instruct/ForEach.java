package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.trace.TraceListener;

import javax.xml.transform.TransformerException;


/**
* Handler for xsl:for-each elements in a stylesheet.
*/

public class ForEach extends Instruction {

    private Expression select = null;

    public ForEach( Expression select ) {
        this.select = select;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "for-each";
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        SequenceIterator savedIterator = controller.getCurrentIterator();
        SequenceIterator iter = select.iterate(context);

        Template savedTemplate = controller.getCurrentTemplate();
        controller.setCurrentTemplate(null);
        controller.setCurrentIterator(iter);
        XPathContext innerContext = context.newContext();
        innerContext.setCurrentIterator(iter);

        if (controller.isTracing()) {
            TraceListener listener = controller.getTraceListener();
            while(true) {
                Item item = iter.next();
                if (item == null) {
                    break;
                }
                listener.startCurrentItem(item);
                processChildren(innerContext);
                listener.endCurrentItem(item);
            }
        } else {
            while(true) {
                Item item = iter.next();
                if (item == null) {
                    break;
                }
                processChildren(innerContext);
            }
        }
        controller.setCurrentIterator(savedIterator);
        controller.setCurrentTemplate(savedTemplate);
        return null;
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
