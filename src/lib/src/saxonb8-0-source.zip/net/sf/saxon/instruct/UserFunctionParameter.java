package net.sf.saxon.instruct;

import net.sf.saxon.expr.Binding;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.Value;
import net.sf.saxon.xpath.XPathException;

import java.io.Serializable;

/**
 * Run-time object representing a formal argument to a user-defined function
 */
public class UserFunctionParameter implements Binding, Serializable {

    private SequenceType requiredType;
    private String variableName;
    private int slotNumber;

    public void setRequiredType(SequenceType type) {
        requiredType = type;
    }

    public SequenceType getRequiredType() {
        return requiredType;
    }

    public void setSlotNumber(int slot) {
        slotNumber = slot;
    }

    public Value evaluateVariable(XPathContext context) throws XPathException {
        return context.evaluateLocalVariable(slotNumber);
        //return context.getController().getBindery().getLocalVariable(slotNumber);
    }

    public void setVariableName(String name) {
        variableName = name;
    }

    public String getVariableName() {
        return variableName;
    }
}
