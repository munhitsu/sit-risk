package net.sf.saxon.instruct;
import net.sf.saxon.event.SequenceChecker;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.expr.*;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.value.ObjectValue;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.Value;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.List;


/**
* An xsl:sequence element in the stylesheet; or a wrapper inserted around the sequence
 * constructor inside other instructions such as xsl:attribute.
*/

// TODO: could split this into three classes, handling (a) select="expr", (b) sequence constructor
// with type checking, (c) sequence constructor without type checking. [Note (b) has now been dropped,
// and (c) is also likely to go, as far as the xsl:sequence syntax is concerned. But we also use this class
// to do type-checking of xsl:template and xsl:function]

public class SequenceInstruction extends ExprInstruction {

    private Expression select;
    private SequenceType requiredType;
    private boolean closeTextNode = false;

    public SequenceInstruction(Expression select, SequenceType requiredType) {
        this.select = select;
        this.requiredType = requiredType;
    }

    public void setCloseTextNode(boolean b) {
        closeTextNode = b;
    }

    public Expression getSelectExpression() {
        return select;
    }

     public Expression simplify() throws XPathException {
        if (select!=null) {
            select = select.simplify();
        }
        return super.simplify();
    }

    public Expression analyze(StaticContext env) throws XPathException {
        if (select != null) {
            select = select.analyze(env);
            if (requiredType != null) {
                RoleLocator role =
                    new RoleLocator(RoleLocator.INSTRUCTION, "sequence/select", 0);
                select = TypeChecker.staticTypeCheck(select, requiredType, false, role);
            }
        }

        return super.analyze(env);

    }

    public void getXPathExpressions(List list) {
        if (select != null) {
            list.add(select);
            return;
        }
        if (children != null) {
            for (int c=0; c<children.length; c++) {
                if (children[c] instanceof Expression) {
                    list.add(children[c]);
                } else {
                    throw new IllegalStateException("Children of an ExprInstruction must be Expressions");
                }
            }
        }
    }

   /**
     * Offer promotion for subexpressions. The offer will be accepted if the subexpression
     * is not dependent on the factors (e.g. the context item) identified in the PromotionOffer.
     * By default the offer is not accepted - this is appropriate in the case of simple expressions
     * such as constant values and variable references where promotion would give no performance
     * advantage. This method is always called at compile time.
     *
     * @param offer details of the offer, for example the offer to move
     *     expressions that don't depend on the context to an outer level in
     *     the containing expression
     * @exception XPathException if any error is detected
     */

    public void promoteInst(PromotionOffer offer) throws XPathException {
        if (select != null) {
            select = select.promote(offer);
        }
        if (children != null) {
            for (int c=0; c<children.length; c++) {
                if (children[c] instanceof Expression) {
                    Expression p = ((Expression)children[c]).promote(offer);
                    if (p instanceof Instr) {
                        children[c] = (Instr)p;
                    } else {
                        children[c] = new SequenceInstruction(p, null);
                    }
                } else {
                    throw new IllegalStateException("Children of an ExprInstruction must be Expressions");
                }
            }
        }
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "sequence";
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {

        //Controller controller = context.getController();
    	SequenceReceiver out = context.getController().getReceiver();

        if (select != null) {
            SequenceIterator iter = select.iterate(context);
            while (true) {
                Item it = iter.next();
                if (it == null) break;
                appendItem(it, context, out);
            }
            if (closeTextNode) {
                out.characters("", 0);
            }
            return null;

        } else if (requiredType==null) {

    	    // No type-check necessary, so write the values directly to the current output destination

            TailCall tc = null;
            if (children != null) {
                tc = processChildrenLeavingTail(context);
            }
            return tc;

        } else {

            // Type check requested, so we need to create a type-checking filter

            SequenceChecker checker = new SequenceChecker();
            checker.setRequiredType(requiredType);
            checker.setUnderlyingReceiver(out);
            context.getController().setReceiver(checker);

            if (select != null) {
                SequenceIterator iter = select.iterate(context);
                while (true) {
                    Item it = iter.next();
                    if (it == null) break;
                    appendItem(it, context, checker);
                }
                if (closeTextNode) {
                    out.characters("", 0);
                }
            }

            if (children != null) {
                processChildren(context);
            }

            checker.finalCheck();

            //controller.resetOutputDestination(out);
            context.getController().setReceiver(out);

            return null;
        }

    }

    public static void appendItem(Item it, XPathContext context, SequenceReceiver out) throws TransformerException {
        // If this call to xsl:sequence is in a template (rather than a function) it may
        // be marked as a tail call; in this situation we need to evaluate the returned
        // function call package. Doing so may return further function call packages, which also need
        // to be processed. This has to be iterative rather than recursive to avoid consuming stack space.
        while (true) {
            if (it instanceof ObjectValue &&
                    ((ObjectValue)it).getObject() instanceof UserFunctionCall.FunctionCallPackage) {
                Value v = ((UserFunctionCall.FunctionCallPackage)((ObjectValue)it).getObject()).call();
                SequenceIterator fv = v.iterate(context);
                while (true) {
                    Item fvit = fv.next();
                    if (fvit == null) return;
                    if (fvit instanceof ObjectValue &&
                            ((ObjectValue)it).getObject() instanceof UserFunctionCall.FunctionCallPackage) {
                        it = fvit;
                        break;
                    } else {
                        out.append(fvit);
                    }
                }
            } else {
                out.append(it);
                return;
            }
        }
    }

    /**
     * Iterate the results, treating this instruction as an expression
     */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        if (children != null) {
            throw new IllegalStateException("Cannot process xsl:sequence with children as an expression");
        }
        return select.iterate(context);
    }

    /**
     * Display this instruction as an expression, for diagnostics
     */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "sequence");
        if (select != null) {
            select.display(level+1, pool);
        }
        if (children != null) {
            Instruction.displayChildren(children, level+1, pool);
        }
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
