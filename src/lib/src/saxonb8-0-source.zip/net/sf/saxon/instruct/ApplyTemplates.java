package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.ParameterSet;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.EmptyIterator;
import net.sf.saxon.trans.Mode;
import net.sf.saxon.value.Value;

import javax.xml.transform.TransformerException;

/**
* An instruction representing an xsl:apply-templates element in the stylesheet
*/

public class ApplyTemplates extends Instruction {

    private Expression select;
    private WithParam[] actualParams = null;
    private WithParam[] tunnelParams = null;
    private boolean useCurrentMode = false;
    private boolean useTailRecursion = false;
    private Mode mode;

    public ApplyTemplates(  Expression select,
                            WithParam[] actualParams,
                            WithParam[] tunnelParams,
                            boolean useCurrentMode,
                            boolean useTailRecursion,
                            Mode mode) {
        this.select = select;
        this.actualParams = actualParams;
        this.tunnelParams = tunnelParams;
        this.useCurrentMode = useCurrentMode;
        this.useTailRecursion = useTailRecursion;
        this.mode = mode;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "apply-templates";
    }

    public void process(XPathContext context) throws TransformerException {
        apply(context, false);
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        return apply(context, useTailRecursion);
    }

    private TailCall apply(XPathContext context, boolean returnTailCall) throws TransformerException {
        Mode thisMode = mode;
        Controller controller = context.getController();
        if (useCurrentMode) {
            thisMode = controller.getCurrentMode();
        }

        // handle parameters if any

        ParameterSet params = assembleParams(context, actualParams);
        ParameterSet tunnels = assembleTunnelParams(context, tunnelParams);

        if (returnTailCall) {
            return new ApplyTemplatesPackage(
                    ExpressionTool.lazyEvaluate(select, context),
                    thisMode, params, tunnels, controller.saveContext());
        }

        // Get an iterator to iterate through the selected nodes in original order

        SequenceIterator iter = select.iterate(context);

        // Quick exit if the iterator is empty

        if (iter instanceof EmptyIterator) {
            return null;
        }

        // process the selected nodes now
        TailCall tc = controller.applyTemplates(iter, thisMode, params, tunnels);
        while (tc != null) {
            tc = tc.processLeavingTail(controller);
        }
        return null;

    }

    /**
    * An ApplyTemplatesPackage is an object that encapsulates the sequence of nodes to be processed,
    * the mode, the parameters to be supplied, and the execution context. This object can be returned as a tail
    * call, so that the actual call is made from a lower point on the stack, allowing a tail-recursive
    * template to execute in a finite stack size
    */

    private static class ApplyTemplatesPackage implements TailCall {

        private Value selectedNodes;
        private Mode mode;
        private ParameterSet params;
        private ParameterSet tunnelParams;
        private Object[] executionContext;

        public ApplyTemplatesPackage(Value selectedNodes,
                                     Mode mode,
                                     ParameterSet params,
                                     ParameterSet tunnelParams,
                                     Object[] executionContext
                                     ) {
            this.selectedNodes = selectedNodes;
            this.mode = mode;
            this.params = params;
            this.tunnelParams = tunnelParams;
            this.executionContext = executionContext;
        }

        public TailCall processLeavingTail(Controller controller) throws TransformerException {
            Object[] save = controller.saveContext();
            controller.restoreContext(executionContext);
            TailCall tc = controller.applyTemplates(
                    selectedNodes.iterate(null), mode, params, tunnelParams);
            controller.restoreContext(save);
            return tc;
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
