package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.type.Type;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.UserFunctionCall;
import net.sf.saxon.event.SequenceOutputter;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.trace.InstructionInfo;
import net.sf.saxon.trace.TraceListener;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.ObjectValue;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.HashMap;
import java.io.Serializable;

/**
* Handler for xsl:function elements in stylesheet (XSLT 2.0). <BR>
* Attributes: <br>
* name gives the name of the function
* saxon:memo-function=yes|no indicates whether it acts as a memo function.
*/

public final class FunctionInstr implements CallableFunction, InstructionInfo, Serializable {

    private SequenceInstruction body;
    private String baseURI;
    private String displayName;
    private boolean memoFunction = false;
    private int lineNumber;

    /**
    * A FunctionInstr is constructed in two stages. The object is created as soon as the corresponding
    * xsl:function object is created, so that XPath expressions can be constructed containing a reference
    * to this FunctionInstr. The details of the FunctionInstr are supplied later, when the function is
    * compiled.
    */

    public FunctionInstr () {};

    public void initialize( SequenceInstruction body,
                            String baseURI,
                            String displayName,
                            boolean memoFunction ) {
        this.body = body;
        this.baseURI = baseURI;
        this.displayName = displayName;
        this.memoFunction = memoFunction;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public String getSystemId() {
        return null;
    }

    /**
     * Provide information to the TraceListener if required
     * @param propertyName: the name of the required property. For this instruction, the only
     * property recognized is "name", which returns the name of the function.
     * @return For the "name" property, return the name of the function (as a lexical QName). For
     * any other property, return null.
     */

    public Object getProperty(String propertyName) {
        if (propertyName.equals("name")) {
            return displayName;
        } else {
            return null;
        }
    }

    public HashMap getProperties() {
        HashMap map = new HashMap();
        map.put("name", displayName);
        return map;
    }

    /**
    * Set the name of this instruction for diagnostic and tracing purposes
    * to the string "function"
    */

    public void setInstructionDetails(Controller controller, NamePool namePool, InstructionDetails details) {
        details.setInstructionName("function");
    }

    public String getInstructionName() {
        return "xsl:function";
    }

    public String getFunctionName() {
        return displayName;
    }

    /**
    * Dummy processLeavingTail() method
    */

    public TailCall processLeavingTail(XPathContext context) {
        return null;
    }

    /**
     * Call this function.
     * @param actualArgs the arguments supplied to the function. These must have the correct
     * types required by the function signature (it is the caller's responsibility to check this).
     * It is acceptable to supply a {@link net.sf.saxon.value.Closure} to represent a value whose
     * evaluation will be delayed until it is needed. The array must be the correct size to match
     * the number of arguments: again, it is the caller's responsibility to check this.
     * @param controller This provides the run-time context for evaluating the function.
     * @param evaluateTailCalls if true, then any function calls contained in the body of the function
     * are evaluated in the normal way, whether or not they are marked as tail calls. If the argument
     * is false, then tail calls are not evaluated, and instead a FunctionCallPackage is returned containing
     * the information needed to evaluate the function. The caller must then be prepared to deal with this
     * returned value by evaluating the packaged function call (which may return further packaged function
     * calls, and so on).
     * @return a Value representing the result of the function.
     */

    public Value call(Value[] actualArgs, Controller controller, boolean evaluateTailCalls) throws TransformerException {

        // If this is a memo function, see if the result is already known
        if (memoFunction) {
            Value value = getCachedValue(controller, actualArgs);
            if (value!=null) return value;
        }

        // Otherwise evaluate the function

    	if (controller.isTracing()) {
    	    TraceListener listener = controller.getTraceListener();
        	listener.enter(this);
   	    }

        SequenceReceiver old = controller.getReceiver();
        SequenceOutputter seq = new SequenceOutputter();
        //seq.setRequiredType(requiredType);
        seq.setSystemId(baseURI);
        seq.setConfiguration(controller.getConfiguration());
        controller.changeToSequenceOutputDestination(seq);

        Bindery bindery = controller.getBindery();
        bindery.openStackFrame(actualArgs);
  	    body.process(controller.newXPathContext());
        bindery.closeStackFrame();

        controller.resetOutputDestination(old);
        Value result = seq.getSequence();

        if (evaluateTailCalls) {
            while (result instanceof ObjectValue &&
                    ((ObjectValue)result).getObject() instanceof UserFunctionCall.FunctionCallPackage) {
                result = ((UserFunctionCall.FunctionCallPackage)((ObjectValue)result).getObject()).call();
            }
        }

    	if (controller.isTracing()) {
    	    TraceListener listener = controller.getTraceListener();
      		listener.leave(this);
   	    }

        // If this is a memo function, save the result in the cache
        if (memoFunction) {
            putCachedValue(controller, actualArgs, result);
        }

        return result;
    }

    /**
    * For memo functions, get a saved value from the cache.
    * @return the cached value, or null if no value has been saved for these parameters
    */

    private Value getCachedValue(Controller controller, Value[] params) {

        try {
            HashMap map = (HashMap)controller.getUserData(this, "memo-function-cache");
            if (map==null) {
                return null;
            }
            String key = getCombinedKey(params);
            return (Value)map.get(key);
        } catch (XPathException err) {
            return null;
        }
    }

    /**
    * For memo functions, put the computed value in the cache.
    */

    private void putCachedValue(Controller controller, Value[] params, Value value) {
        try {
            HashMap map = (HashMap)controller.getUserData(this, "memo-function-cache");
            if (map==null) {
                map = new HashMap();
                controller.setUserData(this, "memo-function-cache", map);
            }
            String key = getCombinedKey(params);
            map.put(key, value);
        } catch (XPathException err) {
            // it doesn't matter if we fail to cache the result
        }
    }

    /**
    * Get a key value representing the values of all the supplied arguments
    */

    private static String getCombinedKey(Value[] params) throws XPathException {
        StringBuffer sb = new StringBuffer();

        for (int i=0; i<params.length; i++) {
            Value val = params[i];
            SequenceIterator iter = val.iterate(null);
            while (true) {
                Item item = iter.next();
                if (item == null) {
                    break;
                }
                if (item instanceof NodeInfo) {
                    NodeInfo node = (NodeInfo)item;
                    //sb.append(""+node.getDocumentRoot().getDocumentNumber());
                    //sb.append('/');
                    sb.append(node.generateId());
                } else {
                    sb.append(""+Type.displayTypeName(item));
                    sb.append('/');
                    sb.append(item.getStringValue());
                }
                sb.append('\u0001');
            }
            sb.append('\u0002');
        }
        return sb.toString();
    }



}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
