package net.sf.saxon.instruct;
import net.sf.saxon.ParameterSet;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.xpath.XPathException;


/**
* The Bindery class holds information about variables and their values.
*
* Variables are identified by a Binding object. Values can be any object, though values of XSL
* variables will always be of class Value.
*/

public final class Bindery  {

    public static final int FRAME_PARAMS = 0;
    public static final int FRAME_TUNNEL_PARAMS = 1;
    public static final int FRAME_VARIABLES = 2;

    private Object[] globals;    // global variables and parameters
    private boolean[] busy;
    private Object[][] stack = new Object[20][];    // stack for local variables and parameters
    private Object[] currentStackFrame;
    private ParameterSet globalParameters;          // supplied global parameters
    private int top = -1;
    private int allocated = 0;
    private int localSpace = 0;

    /**
    * Define how many slots are needed for global variables
    */

    public void allocateGlobals(int n) {
        globals = new Object[n];
        busy = new boolean[n];
        for (int i=0; i<n; i++) {
            globals[i] = null;
            busy[i] = false;
        }
    }

    /**
    * Define global parameters
    * @param params The ParameterSet passed in by the user, eg. from the command line
    */

    public void defineGlobalParameters(ParameterSet params) {
        globalParameters = params;
    }

    /**
    * Use global parameter. This is called when a global xsl:param element is processed.
    * If a parameter of the relevant name was supplied, it is bound to the xsl:param element.
    * Otherwise the method returns false, so the xsl:param default will be evaluated.
    * @param fingerprint The fingerprint of the parameter
    * @param binding The XSLParam element to bind its value to
    * @return true if a parameter of this name was supplied, false if not
    */

    public boolean useGlobalParameter(int fingerprint, DefiningVariable binding) throws XPathException {
        if (globalParameters==null) {
            return false;
        }
        Value val = globalParameters.get(fingerprint);
        if (val==null) {
            return false;
        }
        ItemType reqItemType = binding.getRequiredType().getPrimaryType();
        if (val instanceof AtomicValue && reqItemType instanceof AtomicType) {
            // If the parameter is an atomic value, typically a string supplied on
            // the command line, we attempt to convert it to the required type. This
            // will not always succeed.
            val = ((AtomicValue)val).convert((AtomicType)reqItemType);
        } else {
            // For any other parameter value, we verify that if conforms to the
            // required type. This must be precise conformance, we don't attempt to
            // do atomization or to convert untypedAtomic values

            if (!Type.isSubType(val.getItemType(), reqItemType)) {
                throw new XPathException.Type(
                        "Global parameter requires type " + reqItemType +
                        "; supplied value has type " + val.getItemType());
            }
            int reqCardinality = binding.getRequiredType().getCardinality();
            if (!Cardinality.subsumes(reqCardinality, val.getCardinality())) {
               throw new XPathException.Type(
                        "Supplied value of external parameter does not match the required cardinality");
            }
        }
        globals[binding.getSlotNumber()] = val;
        return true;
    }

    /**
    * Provide a value for a global variable
    * @param binding identifies the variable
    * @param value the value of the variable
    */

    public void defineGlobalVariable(DefiningVariable binding, Value value) {
        globals[binding.getSlotNumber()] = value;
    }

    /**
    * Set/Unset a flag to indicate that a particular global variable is currently being
    * evaluated.
    * @throws XPathException If an attempt is made to set the flag when it is already set, this means
    * the definition of the variable is circular.
    */

    public void setExecuting(DefiningVariable binding, boolean executing)
    throws XPathException {
        int slot = binding.getSlotNumber();
        if (executing) {
            if (busy[slot]) {
                throw new XPathException.Circularity("Circular definition");
            }
            // It would be better to detect circular references statically
            // at compile time. However, this is not always possible, because they
            // can arise via execution of templates or stylesheet functions.
            busy[slot]=true;
        } else {
            busy[slot]=false;
        }
    }

    /**
    * Test if global variable has already been evaluated
    */

    public boolean isEvaluated(DefiningVariable binding) {
        return globals[binding.getSlotNumber()]!=null;
    }

    /**
    * Define how many slots are needed for local variables. We work on the basis of
    * "one size fits all": all stackframes are allocated as large as the largest one needed
    */

    public void allocateLocals(int n) {
        if (n>localSpace) {
            localSpace = n;
        }
    }

    /**
    * Start a new stack frame supplying parameters by name
    */

    public void openStackFrame(ParameterSet localParameters, ParameterSet tunnelParameters) {
        allocateStackFrame();
        currentStackFrame[FRAME_PARAMS] = localParameters;
        currentStackFrame[FRAME_TUNNEL_PARAMS] = tunnelParameters;
    }

    /**
    * Start a new stack frame without parameters
    */

    public void openStackFrame() {
        allocateStackFrame();
    }

    /**
    * Start a new stack frame supplying parameters positionally
    */

    public void openStackFrame(Value[] arguments) {
        allocateStackFrame();
        System.arraycopy(arguments, 0, currentStackFrame, FRAME_VARIABLES, arguments.length);
    }

    /**
    * Allocate space for a new stack frame
    */

    private void allocateStackFrame() {
        if (++top >= allocated) {
            if (allocated==stack.length) {
                Object[][] stack2 = new Object[allocated*2][];
                System.arraycopy(stack, 0, stack2, 0, allocated);
                stack = stack2;
            }
            currentStackFrame = new Object[localSpace+FRAME_VARIABLES];
            stack[top]=currentStackFrame;
            allocated++;
        } else {
            currentStackFrame = stack[top];
        }

        for (int i=0; i<currentStackFrame.length; i++) {
            currentStackFrame[i] = null;
        }
    }

    /**
    * Close the current stack frame for local variables
    */

    public void closeStackFrame() {
        top--;
        currentStackFrame = (top<0 ? null : stack[top]);
    }

    /**
    * Use local parameter. This is called when a local xsl:param element is processed.
    * If a parameter of the relevant name was supplied, it is bound to the xsl:param element.
    * Otherwise the method returns false, so the xsl:param default will be evaluated
    * @param fingerprint    The fingerprint of the parameter name
    * @param binding        The XSLParam element to bind its value to
    * @param isTunnel      True if a tunnel parameter is required, else false
    * @return true if a parameter of this name was supplied, false if not
    */

    public boolean useLocalParameter(int fingerprint,
                                     DefiningVariable binding,
                                     boolean isTunnel) throws XPathException {

        int offset = (isTunnel ? FRAME_TUNNEL_PARAMS : FRAME_PARAMS);
    	ParameterSet params = (ParameterSet)currentStackFrame[offset];
    	if (params==null) return false;
    	Value val = params.get(fingerprint);


    	if (val==null) {
    	    currentStackFrame[binding.getSlotNumber()+FRAME_VARIABLES] = null;
    	    return false;
    	} else {
      	    currentStackFrame[binding.getSlotNumber()+FRAME_VARIABLES] = val;
    	    return true;
    	}
    }

    /**
     * Set the value of a local variable. Note, it is safe to call this when setting
     * XSLT variables, as these always run on the stack. When setting range variables
     * within XPath expressions, however, this method should not be used, because in
     * delayed evaluation mode the variables might be stored on the heap, within
     * the XPathContext object. Use the XPathContext#setLocalVariable method instead.
     * @param slotNumber  identifies the variable
     * @param value       the value of the variable
    */

    public void setLocalVariable(int slotNumber, Value value) {
        if (currentStackFrame==null) {
            throw new IllegalArgumentException("Can't define local variable: stack is empty");
        }

        currentStackFrame[slotNumber+FRAME_VARIABLES] = value;
    }

    /**
    * Get the value of a global variable
    * @param binding the Binding that establishes the unique instance of the variable
    * @return the Value of the variable if defined, null otherwise.
    */

    public Value evaluateGlobalVariable(DefiningVariable binding) {
        return (Value)globals[binding.getSlotNumber()];
    }

    /**
     * Get the value of a local variable, given its slot number
     * @param slotNumber   identifies the local variable
     * @return the value of the variable
     */

    public Value getLocalVariable(int slotNumber) {
        if (currentStackFrame != null) {
            return (Value)currentStackFrame[slotNumber+FRAME_VARIABLES];
        } else {
            return null;
        }
    }

    /**
    * Get a reference to the current stackframe containing local variables.
    * This is used when creating a Closure, which is used for lazy evaluation
    * of expressions. The Closure contains an expression and a copy of all the
    * local variables on which it depends.
    * @return the current stack frame. Position 0 contains a ParameterSet containing the
    * supplied values; this should not be needed. Remaining positions contain slots holding
    * Values of local variables.
    */

    public Object[] getCurrentStackFrame() {
        return currentStackFrame;
    }

    /**
     * Get the set of tunnel parameters from the local stackframe
     */

    public ParameterSet getTunnelParameters() {
        return (ParameterSet)currentStackFrame[FRAME_TUNNEL_PARAMS];
    }
    /**
    * Get the value of a variable in the given frame
    * @param binding the Binding that establishes the unique instance of the variable
    * @param frameId the id of the frame, see getFrameId
    * @return the Value of the variable if defined, null otherwise.
    */

    public Value getValue(DefiningVariable binding, int frameId ) { // e.g.
        if (binding.isGlobal()) {
            return (Value)globals[binding.getSlotNumber()];
        } else {
	        Object[] theStackFrame = stack[frameId];
            if (theStackFrame != null) {
                return (Value)theStackFrame[binding.getSlotNumber()+FRAME_VARIABLES];
            } else {
                return null;
            }
        }
    }

    /**
    * Get the id of the current frame.
    * @return an id, that may be given to getValue(Binding,int)
    */

    public int getFrameId() { // e.g.
      return top;
    }

    /**
    * Assign a new value to a variable
    * @param binding identifies the local or global variable or parameter
    */

    public void assignVariable(DefiningVariable binding, Value value) {
        if (binding.isGlobal()) {
            defineGlobalVariable(binding, value);
        } else {
            setLocalVariable(binding.getSlotNumber(), value);
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
//
