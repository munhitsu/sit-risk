package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.trace.TraceListener;

import javax.xml.transform.TransformerException;
import java.io.Serializable;

/**
* An xsl:template element in the style sheet.
*/

public class Template implements Serializable {

    // The body of the template is represented by a generated xsl:sequence element,
    // which is responsible for any type checking that's needed.

    private SequenceInstruction body;
    private int precedence;
    private int minImportPrecedence;
    private boolean needsStackFrame;
    private String systemId;
    private int lineNumber;
    private InstructionDetails details = null;

    public Template () { }

    public void init (  SequenceInstruction body,
                        boolean needsStackFrame,
                        int precedence,
                        int minImportPrecedence,
                        String systemId,
                        int lineNumber) {
        this.body = body;
        this.needsStackFrame = needsStackFrame;
        this.precedence = precedence;
        this.minImportPrecedence = minImportPrecedence;
        this.systemId = systemId;
        this.lineNumber = lineNumber;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public void setInstructionDetails(Controller controller, NamePool namePool, InstructionDetails details) {
        details.setInstructionName("template");
    }

    public int getPrecedence() {
        return precedence;
    }

    public int getMinImportPrecedence() {
        return minImportPrecedence;
    }

    public boolean needsStackFrame() {
        return this.needsStackFrame;
    }

    /**
    * Process the template, without returning any tail calls
    * @param controller The dynamic context, giving access to the current node,
    * the current variables, etc.
    */

    public void process(Controller controller) throws TransformerException {
        TailCall tc = processLeavingTail(controller);
        while (tc != null) {
            tc = tc.processLeavingTail(controller);
        }
    }

    /**
    * Process this template, with the possibility of returning a tail call package if the template
     * contains any tail calls that are to be performed by the caller.
    */

    public TailCall processLeavingTail(Controller controller) throws TransformerException {
        if (body==null) {
            // fast path for an empty template
            return null;
        }
        Template savedTemplate = controller.getCurrentTemplate();
        controller.setCurrentTemplate(this);

        TailCall tc;
    	if (controller.isTracing()) { // TODO: trace tail recursion
            tc = traceExpand(controller);
        } else {
            //tc = expand(controller);
            // above code inlined to save stack space
            tc = body.processLeavingTail(controller.newXPathContext());
        }

        controller.setCurrentTemplate(savedTemplate);
        return tc;
    }

    /**
    * Expand the template, with tracing. Called when the template is invoked either
    * by xsl:apply-templates or from xsl:call-template
    */

    protected TailCall traceExpand(Controller controller) throws TransformerException {
	    TraceListener listener = controller.getTraceListener();
        if (details == null) {
	        details = new InstructionDetails();
            details.setSystemId(systemId);
            details.setLineNumber(lineNumber);
            details.setInstructionName("template");
            details.setProperty("controller", controller);
        }
    	listener.enter(details);
        TailCall tc = expand(controller);
  		listener.leave(details);
  		return tc;
    }

    /**
    * Expand the template. Called when the template is invoked using xsl:call-template.
    * Invoking a template by this method does not change the current template.
    */

    protected TailCall expand(Controller controller) throws TransformerException {
        if (body==null) {
            // fast path for an empty template
            return null;
        }
        return body.processLeavingTail(controller.newXPathContext());
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
