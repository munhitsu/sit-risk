package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.event.NoOpenStartTagException;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.event.TreeReceiver;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.type.Type;

import javax.xml.transform.TransformerException;
import java.util.List;

/**
* Handler for xsl:copy elements in stylesheet.
*/

public class Copy extends ElementCreator {

    private boolean copyNamespaces;

    public Copy( AttributeSet[] useAttributeSets,
                 boolean copyNamespaces,
                 SchemaType schemaType,
                 int validation) {
        this.useAttributeSets = useAttributeSets;
        this.copyNamespaces = copyNamespaces;
        this.schemaType = schemaType;
        this.validation = validation;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "copy";
    }

    /**
     * Callback from ElementCreator when constructing an element
     * @param context
     * @return the namecode of the element to be constructed
     * @throws TransformerException
     */

    protected int getNameCode(XPathContext context)
            throws TransformerException {
        return ((NodeInfo)context.getContextItem()).getNameCode();
    }

    /**
     * Callback to output namespace nodes for the new element.
     * @param context The execution context
     * @param receiver the Receiver where the namespace nodes are to be written
     * @throws TransformerException
     */

    protected void outputNamespaceNodes(XPathContext context, Receiver receiver)
    throws TransformerException {
        if (copyNamespaces) {
            NodeInfo element = (NodeInfo)context.getContextItem();
            element.outputNamespaceNodes(receiver, true);
        }
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        SequenceReceiver out = controller.getReceiver();
        Item item = controller.getCurrentItem();
        if (!(item instanceof NodeInfo)) {
            out.append(item);
            return null;
        }
        NodeInfo source = (NodeInfo)item;

        // Processing depends on the node kind.

        switch(source.getNodeKind()) {

        case Type.ELEMENT:
            // use the generic code for creating new elements
            return super.processLeavingTail(context);

        case Type.ATTRIBUTE:
            try {
                CopyOf.copyAttribute(source, schemaType, validation, controller);
            } catch (NoOpenStartTagException err) {
                recoverableError(this, "Cannot write an attribute node when no element start tag is open",
                    controller);
            }
            break;

        case Type.TEXT:
            out.characters(source.getStringValue(), 0);
            break;

        case Type.PROCESSING_INSTRUCTION:
            out.processingInstruction(source.getDisplayName(), source.getStringValue(), 0);
            break;

        case Type.COMMENT:
            out.comment(source.getStringValue(), 0);
            break;

        case Type.NAMESPACE:
            try {
                source.copy(out, NodeInfo.NO_NAMESPACES, false);
            } catch (NoOpenStartTagException err) {
                recoverableError(this, "Cannot write a namespace node when no element start tag is open",
                    controller);
            }
            break;

        case Type.DOCUMENT:
            // TODO: add a document node to the result sequence (copying it only if
            // necessary?)
            SequenceReceiver savedReceiver = null;
            Receiver val = controller.getConfiguration().
                    getDocumentValidator(out,
                                         source.getBaseURI(),
                                         controller.getNamePool(),
                                         validation);
            if (val != out) {
                SequenceReceiver sr = new TreeReceiver(val);
                sr.setConfiguration(controller.getConfiguration());
                savedReceiver = out;
                controller.setReceiver(sr);
                val = sr;
            }
            val.setConfiguration(controller.getConfiguration());
            //val.startDocument();
            processChildren(context);
            //val.endDocument();
            if (savedReceiver != null) {
                controller.setReceiver(savedReceiver);
            }
            break;

        default:
            throw new IllegalArgumentException("Unknown node kind " + source.getNodeKind());

        }
        return null;
    }

    protected void getXPathExpressions(List list) {
        // not used
    }

    /**
     * Diagnostic print of expression structure. The expression is written to the System.err
     * output stream
     *
     * @param level indentation level for this expression
     */

    public void display(int level, NamePool pool) {
        // not used
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
