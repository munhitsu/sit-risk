package net.sf.saxon.instruct;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.Controller;
import net.sf.saxon.om.NamePool;

import javax.xml.transform.TransformerException;


/**
* Implements an imaginary xsl:block instruction which simply evaluates
* its contents. Used for top-level templates, xsl:otherwise, etc.
*/

public class Block extends Instruction {

    /**
    * General-purpose block
    */

    public static final byte BLOCK = 0;

    /**
    * Block representing an xsl:otherwise instruction
    */

    public static final byte OTHERWISE = 1;

    /**
    * Block representing an xsl:fallback instruction
    */

    public static final byte FALLBACK = 2;

    /**
    * Block representing an xsl:matching-substring instruction
    */

    public static final byte MATCHING_SUBSTRING = 3;

    /**
    * Block representing an xsl:non-matching-substring instruction
    */

    public static final byte NON_MATCHING_SUBSTRING = 4;

    /**
     * Block representing the body of an xsl:if
     */

    public static final byte IF = 5;

    /**
     * Block representing the body of an xsl:when
     */

    public static final byte WHEN = 6;

    private byte instructionName = BLOCK;

    public Block() {
    }

    public void setInstructionName(byte instructionNameCode) {
        instructionName = instructionNameCode;
    }

    public String getInstructionName() {
        switch (instructionName) {
            case BLOCK:
            default:
                return "[xsl:block]";
            case OTHERWISE:
                return "xsl:otherwise";
            case FALLBACK:
                return "xsl:fallback";
            case MATCHING_SUBSTRING:
                return "xsl:matching-substring";
            case NON_MATCHING_SUBSTRING:
                return "xsl:non-matching-substring";
            case IF:
                return "xsl:if";
            case WHEN:
                return "xsl:when";
        }
    }

     public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        return processChildrenLeavingTail(context);
    }

}
//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
