package net.sf.saxon.instruct;
import net.sf.saxon.trace.InstructionInfo;

import javax.xml.transform.SourceLocator;
import java.util.HashMap;

/**
* Details about an instruction, used when reporting errors and when tracing
*/

public final class InstructionDetails implements SourceLocator, InstructionInfo {

    private String systemId;
    private int lineNumber;
    private String instructionName;
    private HashMap properties = new HashMap();

    /**
    * Set the URI of the module containing the instruction
    * @param systemId the module's URI
    */

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    /**
    * Get the URI of the module containing the instruction
    * @return the module's URI
    */

    public String getSystemId() {
        return systemId;
    }

    /**
    * Set the line number of the instruction within the module
    * @param lineNumber the line number
    */

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
    * Get the line number of the instruction within its module
    * @return the line number
    */

    public int getLineNumber() {
        return lineNumber;
    }

    /**
    * Set the name of the instruction
    * @param instructionName the name of the instruction. This is a conventional name, it has the form
    * of a QName but the prefix chosen is arbitrary
    */

    public void setInstructionName(String instructionName) {
        this.instructionName = instructionName;
    }

    /**
    * Get the name of the instruction
    * @return the name of the instruction. This is a conventional name, it has the form
    * of a QName but the prefix chosen is arbitrary
    */

    public String getInstructionName() {
        return instructionName;
    }

    /**
     * Set a named property of the instruction
     */

    public void setProperty(String name, Object value) {
        properties.put(name, value);
    }

    /**
     * Get a named property of the instruction
     */

    public Object getProperty(String name) {
        return properties.get(name);
    }

    /**
    * Get the public ID of the module containing the instruction. This method
    * is provided to satisfy the SourceLocator interface. However, the public ID is
    * not maintained by Saxon, and the method always returns null
    * @return null
    */

    public String getPublicId() {
        return null;
    }

    /**
    * Get the column number identifying the position of the instruction. This method
    * is provided to satisfy the SourceLocator interface. However, the column number is
    * not maintained by Saxon, and the method always returns -1
    * @return -1
    */

    public int getColumnNumber() {
        return -1;
    }

    /**
     * Get all the properties of the instruction
     */

    public HashMap getProperties() {
        return properties;
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s):
// Portions marked "e.g." are from Edwin Glaser (edwin@pannenleiter.de)
//
