package net.sf.saxon.instruct;

import net.sf.saxon.value.Value;
import net.sf.saxon.Controller;

import javax.xml.transform.TransformerException;

/**
 * A callable (XSLT or XQuery) function
 */

public interface CallableFunction {

    // TODO: ideally, use the same implementation class (FunctionInstr/UserFunction) for
    // both XSLT and XQuery functions. Meanwhile this interface hides the differences
    // between them

    /**
     * Get the name of the function, for diagnostics
     * @return the function name, as a lexical QName
     */
    public String getFunctionName();

    /**
     * Call this function.
     * @param actualArgs the arguments supplied to the function. These must have the correct
     * types required by the function signature (it is the caller's responsibility to check this).
     * It is acceptable to supply a {@link net.sf.saxon.value.Closure} to represent a value whose
     * evaluation will be delayed until it is needed. The array must be the correct size to match
     * the number of arguments: again, it is the caller's responsibility to check this.
     * @param controller This provides the run-time context for evaluating the function.
     * @param evaluateTailCalls if true, then any function calls contained in the body of the function
     * are evaluated in the normal way, whether or not they are marked as tail calls. If the argument
     * is false, then tail calls are not evaluated, and instead a FunctionCallPackage is returned containing
     * the information needed to evaluate the function. The caller must then be prepared to deal with this
     * returned value by evaluating the packaged function call (which may return further packaged function
     * calls, and so on).
     * @return a Value representing the result of the function.
     */

    public Value call(Value[] actualArgs, Controller controller, boolean evaluateTailCalls)
            throws TransformerException;

}
