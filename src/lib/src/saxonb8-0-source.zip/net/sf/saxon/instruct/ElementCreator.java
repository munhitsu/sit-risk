package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.event.SequenceOutputter;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.event.TreeReceiver;
import net.sf.saxon.expr.*;
import net.sf.saxon.om.Item;
import net.sf.saxon.pattern.NodeKindTest;
import net.sf.saxon.type.*;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;


/**
 * An instruction that creates an element node. There are two subtypes, FixedElement
 * for use where the name is known statically, and Element where it is computed
 * dynamically. To allow use in both XSLT and XQuery, the class acts both as an
 * Instruction and as an Expression.
*/

public abstract class ElementCreator extends ExprInstruction {

    protected AttributeSet[] useAttributeSets;
    protected SchemaType schemaType;
    protected int validation;

    // The validation context is always "global" in XSLT, but may be set explicitly
    // in XQuery
    protected ValidationContext validationContext =
            GlobalValidationContext.getInstance();


    public ItemType getItemType() {
        return NodeKindTest.ELEMENT;
    }

    public int getCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    public Expression analyze(StaticContext env) throws XPathException {
        if (children != null) {
            for (int c=0; c<children.length; c++) {
                if (children[c] instanceof Expression) {
                    Expression exp = ((Expression)children[c]).analyze(env);
                    if (exp instanceof Instr) {
                        children[c] = (Instr)exp;
                    } else {
                        SequenceInstruction seq = new SequenceInstruction(exp, null);
                        children[c] = seq;
                    }
                }
            }
        }
        return this;
    }

    /**
     * Set the validation mode for the new element
     */

    public void setValidationMode(int mode) {
        validation = mode;
    }

    /**
     * Get the validation mode for the constructed element
     */

    public int getValidationMode() {
        return validation;
    }

   /**
     * Set the validation context for the new element
     */

    public void setValidationContext(ValidationContext context) {
        validationContext = context;
    }

    /**
     * Get the validation context for the constructed element
     */

    public ValidationContext getValidationContext() {
        return validationContext;
    }

    /**
     * Offer promotion for subexpressions. The offer will be accepted if the subexpression
     * is not dependent on the factors (e.g. the context item) identified in the PromotionOffer.
     * By default the offer is not accepted - this is appropriate in the case of simple expressions
     * such as constant values and variable references where promotion would give no performance
     * advantage. This method is always called at compile time.
     *
     * @param offer details of the offer, for example the offer to move
     *     expressions that don't depend on the context to an outer level in
     *     the containing expression
     * @exception XPathException if any error is detected
     */

    public void promoteInst(PromotionOffer offer) throws XPathException {
        for (int c=0; c<children.length; c++) {
            if (children[c] instanceof Expression) {
                Expression p = ((Expression)children[c]).promote(offer);
                if (p instanceof Instr) {
                    children[c] = (Instr)p;
                } else {
                    children[c] = new SequenceInstruction(p, null);
                }
            } else {
                throw new IllegalStateException("Children of an ExprInstruction must be Expressions");
            }
        }
    }

    protected abstract int getNameCode(XPathContext context)
    throws TransformerException;

    /**
     * Callback to output namespace nodes for the new element.
     * @param context The execution context
     * @param receiver the Receiver where the namespace nodes are to be written
     * @throws TransformerException
     */

    protected abstract void outputNamespaceNodes(XPathContext context, Receiver receiver)
    throws TransformerException;

    /**
     * Evaluate the instruction to produce a new element node
     * @param context
     * @return null (this instruction never returns a tail call)
     * @throws TransformerException
     */
    public TailCall processLeavingTail(XPathContext context)
    throws TransformerException {

        int nameCode = getNameCode(context);
        if (nameCode == -1) {
            // XSLT recovery action when the computed name is invalid
            skipElement(context);
            return null;
        }

        Controller controller = context.getController();
        SequenceReceiver out = controller.getReceiver();
        SequenceReceiver savedReceiver = null;

        Receiver validator = controller.getConfiguration().getElementValidator(
                out, nameCode,
                schemaType, validation, validationContext,
                controller.getNamePool()
        );

        if (validator != out) {
            savedReceiver = out;
            out = new TreeReceiver(validator);
            out.setConfiguration(controller.getConfiguration());
            controller.setReceiver(out);
        }
        out.startElement(nameCode, -1, 0);

        // output the required namespace nodes via a callback

        outputNamespaceNodes(context, out);


        // apply the content of any attribute sets mentioned in use-attribute-sets
        if (useAttributeSets != null) {
            AttributeSet.expand(useAttributeSets, controller);
        }

        // process subordinate instructions to generate attributes and content
        processChildren(context);

        // output the element end tag (which will fail if validation fails)
        out.endElement();
        if (savedReceiver != null) {
            controller.setReceiver(savedReceiver);
        }
        return null;
    }

    /**
    * Recovery action when the element name is invalid. We need to tell the outputter
    * about this, so that it can ignore attributes in the content
    */

    private void skipElement(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        controller.getReceiver().startElement(-1, 0, 0);
        // Sending a namecode of -1 to the Outputter is a special signal to ignore
        // this element and the attributes that follow it
        processChildren(context);
        // Note, we don't bother with an endElement call
    }


   /**
     * Evaluate as an expression. We rely on the fact that when these instructions
     * are generated by XQuery, there will always be a valueExpression to evaluate
     * the content
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        try {
            Controller controller = context.getController();
            SequenceReceiver old = controller.getReceiver();
            SequenceOutputter seq = new SequenceOutputter();
            seq.setConfiguration(controller.getConfiguration());

            int nameCode = getNameCode(context);

            Receiver validator = controller.getConfiguration().getElementValidator(
                    seq, nameCode,
                    schemaType, validation, validationContext,
                    controller.getNamePool()
            );

            SequenceReceiver ini = seq;
            if (validator == seq) {
                controller.changeToSequenceOutputDestination(seq);
            } else {
                TreeReceiver tr = new TreeReceiver(validator);
                tr.setConfiguration(controller.getConfiguration());
                controller.setReceiver(tr);
                ini = tr;
            }


            ini.startDocument();
            ini.startElement(nameCode, -1, 0);
            // ignore attribute sets for now

            // output the namespace nodes for the new element
            outputNamespaceNodes(context, ini);

            processChildren(context);

            ini.endElement();
            ini.endDocument();
            controller.resetOutputDestination(old);

            // the constructed element is the first and only item in the sequence
            return seq.getFirstItem();

        } catch (TransformerException err) {
            if (err instanceof ValidationException) {
                ((ValidationException)err).setSourceLocator(this);
                ((ValidationException)err).setSystemId(getSystemId());
            }
            if (err.getLocator() == null) {
                err.setLocator(this);
            }
            if (err instanceof XPathException) {
                throw (XPathException)err;
            } else {
                throw new XPathException.Dynamic(err);
            }
        }
    }
}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
