package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.ParameterSet;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.QNameException;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NamespaceResolver;

import javax.xml.transform.TransformerException;
import java.util.HashMap;

/**
* Instruction representing an xsl:call-template element in the stylesheet.
*/

public class CallTemplate extends Instruction {

    private Template template = null;
    private WithParam[] actualParams = null;
    private WithParam[] tunnelParams = null;
    private boolean useTailRecursion = false;
    private Expression calledTemplateExpression;    // allows name to be an AVT
    private NamespaceResolver nsContext;             // needed only for a dynamic call

    /**
    * Construct a CallTemplate instruction.
    * @param template the Template object identifying the template to be called, in the normal
    * case where this is known statically
    * @param actualParams array of WithParam instructions to calculate the actual parameters
    * to be supplied to the call
    * @param calledTemplateExpression expression to calculate the name of the template to be called
    * at run-time, this supports the saxon:allow-avt option
    * @param nsContext the static namespace context of the instruction, needed only in the case
    * where the name of the called template is to be calculated dynamically
    */

    public CallTemplate (   Template template,
                            WithParam[] actualParams,
                            WithParam[] tunnelParams,
                            boolean useTailRecursion,
                            Expression calledTemplateExpression,
                            NamespaceResolver nsContext ) {

        this.template = template;
        this.actualParams = actualParams;
        this.tunnelParams = tunnelParams;
        this.useTailRecursion = useTailRecursion;
        this.calledTemplateExpression = calledTemplateExpression;
        this.nsContext = nsContext;
    }

    /**
    * Return the name of this instruction.
    */

     public String getInstructionName() {
        return "call-template";
    }

    /**
     * Process this instruction, without leaving any tail calls.
     * @param context the dynamic context for this transformation
     * @throws TransformerException if a dynamic error occurs
     */

    public void process(XPathContext context) throws TransformerException {

        Controller controller = context.getController();
        controller.getBindery().openStackFrame(
                assembleParams(context, actualParams),
                assembleTunnelParams(context, tunnelParams));

        TailCall tc;
        if (controller.isTracing()) {
            tc = getTargetTemplate(context).traceExpand(controller);
        } else {
            tc = getTargetTemplate(context).expand(controller);
        }
        while (tc != null) {
            tc = tc.processLeavingTail(controller);
        }

        controller.getBindery().closeStackFrame();

    }

    /**
    * Process this instruction. If the called template contains a tail call (which may be
    * an xsl:call-template of xsl:apply-templates instruction) then the tail call will not
    * actually be evaluated, but will be returned in a TailCall object for the caller to execute.
    * @param context the dynamic context for this transformation
    * @return an object containing information about the tail call to be executed by the
    * caller. Returns null if there is no tail call.
    */

    public TailCall processLeavingTail(XPathContext context) throws TransformerException
    {
        if (!useTailRecursion) {
            process(context);
            return null;
        }

        // if name is determined dynamically, determine it now

        Template target = getTargetTemplate(context);

        // handle parameters if any

        ParameterSet params = assembleParams(context, actualParams);
        ParameterSet tunnels = assembleTunnelParams(context, tunnelParams);

        // Call the named template. Actually, don't call it; rather construct a call package
        // and return it to the caller, who will then process this package.

        //System.err.println("Call template using tail recursion");
        if (params==null) {                  // bug 490967
            params = new ParameterSet();
        }

        return new CallTemplatePackage(
                                target,
                                params,
                                tunnels,
                                context.getController().saveContext());
    }

    /**
     * Get the template, in the case where it is specified dynamically.
     * @param context        The dynamic context of the transformation
     * @return                  The template to be called
     * @throws TransformerException if a dynamic error occurs: specifically, if the
     * template name is computed at run-time (Saxon extension) and the name is invalid
     * or does not reference a known template
     */

    private Template getTargetTemplate(XPathContext context) throws TransformerException {
        if (calledTemplateExpression != null) {
            Controller controller = context.getController();
            String qname = calledTemplateExpression.evaluateAsString(context);

            String prefix;
            String localName;
            try {
                String[] parts = Name.getQNameParts(qname);
                prefix = parts[0];
                localName = parts[1];
            } catch (QNameException err) {
                throw dynamicError("Invalid template name. " + err.getMessage(), controller);
            }
            String uri = nsContext.getURIForPrefix(prefix, false);
            if (uri==null) {
  		        throw dynamicError("Namespace prefix " + prefix + " has not been declared", controller);
  		    }
            int fprint = controller.getNamePool().getFingerprint(uri, localName);
            HashMap templateTable = controller.getExecutable().getNamedTemplateTable();
            Template target = (Template)templateTable.get(new Integer(fprint));
            if (target==null) {
            	throw dynamicError("Template " + qname + " has not been defined", controller);
            }
            return target;
        } else {
            return template;
        }
    }

    /**
    * A CallTemplatePackage is an object that encapsulates the name of a template to be called,
    * the parameters to be supplied, and the execution context. This object can be returned as a tail
    * call, so that the actual call is made from a lower point on the stack, allowing a tail-recursive
    * template to execute in a finite stack size
    */

    private static class CallTemplatePackage implements TailCall {

        private Template target;
        private ParameterSet params;
        private ParameterSet tunnelParams;
        private Object[] executionContext;

        /**
        * Construct a CallTemplatePackage that contains information about a call.
        * @param template the Template to be called
        * @param params the parameters to be supplied to the called template
        * @param executionContext saved context information from the Controller (current mode, etc)
        * which must be reset to ensure that the template is called with all the context information
        * intact
        */

        public CallTemplatePackage(Template template,
                                   ParameterSet params,
                                   ParameterSet tunnelParams,
                                   Object[] executionContext) {
            this.target = template;
            this.params = params;
            this.tunnelParams = tunnelParams;
            this.executionContext = executionContext;
        }

        /**
        * Process the template call encapsulated by this package.
        * @param controller the controller for this transformation
        * @return another TailCall. This will never be the original call, but it may be the next
        * recursive call. For example, if A calls B which calls C which calls D, then B may return
        * a TailCall to A representing the call from B to C; when this is processed, the result may be
        * a TailCall representing the call from C to D.
         * @throws TransformerException if a dynamic error occurs
        */

        public TailCall processLeavingTail(Controller controller) throws TransformerException {
            Object[] save = controller.saveContext();
            controller.restoreContext(executionContext);
            Bindery bindery = controller.getBindery();
            bindery.openStackFrame(params, tunnelParams);

            // System.err.println("Tail call on template");

            TailCall tc;
        	if (controller.isTracing()) {
                tc = target.traceExpand(controller);
            } else {
                tc = target.expand(controller);
            }

            bindery.closeStackFrame();
            controller.restoreContext(save);
            return tc;
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
