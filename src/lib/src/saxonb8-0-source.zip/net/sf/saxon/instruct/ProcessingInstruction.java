package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.pattern.NodeKindTest;
import net.sf.saxon.expr.*;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.XMLChar;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.value.Cardinality;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.xpath.XPathException;

import javax.xml.transform.TransformerException;
import java.util.List;

/**
* An xsl:processing-instruction element in the stylesheet.
*/

public class ProcessingInstruction extends SimpleNodeConstructor {

    private Expression name;

    /**
    * Create an xsl:processing-instruction instruction
    * @param name the expression used to compute the name of the generated
    * processing-instruction
    */

    public ProcessingInstruction(Expression name) {
        this.name = name;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    * @return the string "xsl:processing-instruction"
    */

    public String getInstructionName() {
        return "processing-instruction";
    }

    public ItemType getItemType() {
        return NodeKindTest.PROCESSING_INSTRUCTION;
    }

    public int getCardinality() {
        return StaticProperty.EXACTLY_ONE;
    }

    public void typeCheck(StaticContext env) throws XPathException {
        name = name.analyze(env);

        RoleLocator role =
                new RoleLocator(RoleLocator.INSTRUCTION, "processing-instruction:name", 0);
        name = TypeChecker.staticTypeCheck(name, SequenceType.SINGLE_STRING, false, role);
    }

    public int getDependencies() {
        return name.getDependencies() | super.getDependencies();
    }

    public void getXPathExpressions(List list) {
        list.add(name);
        super.getXPathExpressions(list);
    }

    /**
       * Offer promotion for subexpressions. The offer will be accepted if the subexpression
       * is not dependent on the factors (e.g. the context item) identified in the PromotionOffer.
       * By default the offer is not accepted - this is appropriate in the case of simple expressions
       * such as constant values and variable references where promotion would give no performance
       * advantage. This method is always called at compile time.
       *
       * @param offer details of the offer, for example the offer to move
       *     expressions that don't depend on the context to an outer level in
       *     the containing expression
       * @exception XPathException if any error is detected
       */

    public void promoteInst(PromotionOffer offer) throws XPathException {
        name = name.promote(offer);
        super.promoteInst(offer);
    }


    /**
    * Process this instruction, that is, produce a processing-instruction node in the
    * result sequence.
    * @param context the dynamic context of this transformation
    * @throws TransformerException if any non-recoverable dynamic error occurs
    * @return always returns null in this implementation
    */

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        String expandedName = name.evaluateAsString(context);

        if (!(XMLChar.isValidNCName(expandedName)) || expandedName.equalsIgnoreCase("xml")) {
            recoverableError(
                    this, "Processing instruction name is invalid: " + expandedName, controller);
            return null;
        }

        String data = expandChildren(context).toString();

        int hh = data.indexOf("?>");
        if (hh >= 0) {
            recoverableError(
                    this, "Invalid characters (?>) in processing instruction", controller);
            data = data.substring(0, hh+1) + " " + data.substring(hh+1);
        }

        controller.getReceiver().processingInstruction(expandedName, data, 0);
        return null;
    }

    protected int evaluateNameCode(XPathContext context) throws XPathException {
        String expandedName = name.evaluateAsString(context);

        if (!(XMLChar.isValidNCName(expandedName)) || expandedName.equalsIgnoreCase("xml")) {
            throw new XPathException.Dynamic (
                "Processing instruction name is invalid: " + expandedName);
        }

        return context.getController().getNamePool().allocate("", "", expandedName);
    }

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "processing-instruction");
        name.display(level+1, pool);
        super.display(level+1, pool);
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
