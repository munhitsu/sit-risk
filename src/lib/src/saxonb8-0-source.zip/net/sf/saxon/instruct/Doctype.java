package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.event.ReceiverOptions;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.*;
import net.sf.saxon.tinytree.TinyBuilder;

import javax.xml.transform.TransformerException;

/**
* A saxon:doctype element in the stylesheet.
*/

public class Doctype extends Instruction {

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */


    public String getInstructionName() {
        return "doctype";
    }

    public String getInstructionNamespace() {
        return NamespaceConstant.SAXON;
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        SequenceReceiver out = controller.getReceiver();
        TinyBuilder builder = new TinyBuilder();
        Receiver receiver = builder;
        receiver.setConfiguration(controller.getConfiguration());
        receiver.startDocument();
        controller.changeOutputDestination(null, receiver, false, Validation.PRESERVE, null);
        processChildren(context);
        controller.resetOutputDestination(out);
        receiver.endDocument();
        DocumentInfo dtdRoot = builder.getCurrentDocument();

        SequenceIterator children = dtdRoot.iterateAxis(Axis.CHILD);
        NodeInfo docType = (NodeInfo)children.next();
        if (docType==null || !("doctype".equals(docType.getLocalPart()))) {
            throw new TransformerException("saxon:doctype instruction must contain dtd:doctype");
        }
        String name = Navigator.getAttributeValue(docType, "", "name");
        String system = Navigator.getAttributeValue(docType, "", "system");
        String publicid = Navigator.getAttributeValue(docType, "", "public");

        if (name==null) {
            throw new TransformerException("dtd:doctype must have a name attribute");
        }

        write(out, "<!DOCTYPE " + name + " ");
        if (system!=null) {
            if (publicid!=null) {
                write(out, "PUBLIC \"" + publicid + "\" \"" + system + "\"");
            } else {
                write(out, "SYSTEM \"" + system + "\"");
            }
        }

        boolean openSquare = false;
        children = docType.iterateAxis(Axis.CHILD);

        NodeInfo child = (NodeInfo)children.next();
        if (child != null) {
            write(out, " [");
            openSquare = true;
        }

        while (child != null) {
            String localname = child.getLocalPart();

            if ("element".equals(localname)) {
                String elname = Navigator.getAttributeValue(child, "","name");
                String content = Navigator.getAttributeValue(child, "", "content");
                if (elname==null) {
                    throw new TransformerException("dtd:element must have a name attribute");
                }
                if (content==null) {
                    throw new TransformerException("dtd:element must have a content attribute");
                }
                write(out, "\n  <!ELEMENT " + elname + " " + content + ">");

            } else if (localname.equals("attlist")) {
                String elname = Navigator.getAttributeValue(child, "","element");
                if (elname==null) {
                    throw new TransformerException("dtd:attlist must have an attribute named 'element'");
                }
                write(out, "\n  <!ATTLIST " + elname + " " );

                SequenceIterator attributes = child.iterateAxis(Axis.CHILD);
                while (true) {
                    NodeInfo attDef = (NodeInfo)attributes.next();
                    if (attDef == null) {
                        break;
                    }

                    if ("attribute".equals(attDef.getLocalPart())) {

                        String atname = Navigator.getAttributeValue(attDef, "","name");
                        String type = Navigator.getAttributeValue(attDef, "","type");
                        String value = Navigator.getAttributeValue(attDef, "","value");
                        if (atname==null) {
                            throw new TransformerException("dtd:attribute must have a name attribute");
                        }
                        if (type==null) {
                            throw new TransformerException("dtd:attribute must have a type attribute");
                        }
                        if (value==null) {
                            throw new TransformerException("dtd:attribute must have a value attribute");
                        }
                        write(out, "\n    " + atname + " " + type + " " + value);
                    } else {
                        throw new TransformerException("Unrecognized element within dtd:attlist");
                    }
                }
                write(out, ">");

            } else if (localname.equals("entity")) {

                String entname = Navigator.getAttributeValue(child, "","name");
                String parameter = Navigator.getAttributeValue(child, "","parameter");
                String esystem = Navigator.getAttributeValue(child, "","system");
                String epublicid = Navigator.getAttributeValue(child, "","public");
                String notation = Navigator.getAttributeValue(child, "","notation");

                if (entname==null) {
                    throw new TransformerException("dtd:entity must have a name attribute");
                }

                // we could do a lot more checking now...

                write(out, "\n  <!ENTITY ");
                if ("yes".equals(parameter)) {
                    write(out, "% ");
                }
                write(out, entname + " ");
                if (esystem!=null) {
                    if (epublicid!=null) {
                        write(out, "PUBLIC \"" + epublicid + "\" \"" + esystem + "\" ");
                    } else {
                        write(out, "SYSTEM \"" + esystem + "\" ");
                    }
                }
                if (notation!=null) {
                    write(out, "NDATA " + notation + " ");
                }

                SequenceIterator contents = child.iterateAxis(Axis.CHILD);
                while (true) {
                    NodeInfo content = (NodeInfo)contents.next();
                    if (content == null) {
                        break;
                    }
                    content.copy(out, NodeInfo.NO_NAMESPACES, false);
                }

            } else if (localname.equals("notation")) {
                String notname = Navigator.getAttributeValue(child, "","name");
                String nsystem = Navigator.getAttributeValue(child,"","system");
                String npublicid = Navigator.getAttributeValue(child, "","public");
                if (notname==null) {
                    throw new TransformerException("dtd:notation must have a name attribute");
                }
                if ((nsystem==null) && (npublicid==null)) {
                    throw new TransformerException("dtd:notation must have a system attribute or a public attribute");
                }
                write(out, "\n  <!NOTATION " + notname);
                if (npublicid!=null) {
                    write(out, " PUBLIC \"" + npublicid + "\" ");
                    if (nsystem!=null) {
                        write(out, "\"" + nsystem + "\" ");
                    }
                } else {
                    write(out, " SYSTEM \"" + nsystem + "\" ");
                }
            } else {
                throw new TransformerException("Unrecognized element " + localname + " in DTD output");
            }
            child = (NodeInfo)children.next();
        }

        if (openSquare) {
            write(out, "\n]");
            openSquare = false;
        }
        write(out, ">\n");

        return null;

    }

    private void write(Receiver out, String s) throws TransformerException {
        out.characters(s, ReceiverOptions.DISABLE_ESCAPING);
    }

}
//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
