package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.value.Value;

import javax.xml.transform.TransformerException;

/**
* The compiled form of an xsl:param element in the stylesheet or an
* external variable in a Query. <br>
* The xsl:param element in XSLT has mandatory attribute name and optional attribute select. It can also
* be specified as required="yes" or required="no". In standard XQuery external variables are always required,
* and no default value can be specified; but Saxon provides an extension pragma that allows a query
* to specify a default.
*/

public final class Param extends DefiningVariable {

    private Expression conversion = null;

    public void setConversion(Expression convertor) {
        conversion = convertor;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    */

    public String getInstructionName() {
        return "param";
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        Bindery bindery = controller.getBindery();
        boolean wasSupplied;

        if (isGlobal()) {
            wasSupplied = bindery.useGlobalParameter(variableFingerprint, this);
        } else {
            wasSupplied = bindery.useLocalParameter(variableFingerprint, this, isTunnelParam());
            if (wasSupplied && conversion != null) {
                bindery.setLocalVariable(getSlotNumber(),
                        ExpressionTool.eagerEvaluate(conversion, context));
                // We do an eager evaluation here for safety, because the result of the
                // type conversion overwrites the slot where the actual supplied parameter
                // is contained.
            }
        }

        // don't evaluate the default if a value has been supplied or if it has already been
        // evaluated by virtue of a forwards reference

        if (!wasSupplied) {
            if (isRequiredParam()) {
                throw new TransformerException("No value supplied for required parameter");
            }
            if (isGlobal()) {
                Value value = getSelectValue(context);
                bindery.defineGlobalVariable(this, value);
            } else {
                Value value = getSelectValue(context);
                bindery.setLocalVariable(getSlotNumber(), value);
            }
        }
        return null;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
