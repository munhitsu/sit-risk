package net.sf.saxon.instruct;

import javax.xml.transform.SourceLocator;

/**
 * This interface represents an instruction or expression whose location in a source module
 * is known.
 */


public interface Locatable {

    /**
     * Get a SourceLocator identifying the location of the instruction or expression
     */

    public SourceLocator getSourceLocator();
}
