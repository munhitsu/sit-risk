package net.sf.saxon.instruct;
import net.sf.saxon.Controller;
import net.sf.saxon.OutputURIResolver;
import net.sf.saxon.type.SchemaType;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.event.SaxonOutputKeys;
import net.sf.saxon.event.StandardOutputResolver;
import net.sf.saxon.event.SequenceReceiver;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;

import javax.xml.transform.TransformerException;
import javax.xml.transform.Result;
import java.util.Properties;

/**
* An xsl:result-document (formerly saxon:output) element in the stylesheet. <BR>
* The xsl:result-document element takes an attribute href="filename". The filename will
* often contain parameters, e.g. {position()} to ensure that a different file is produced
* for each element instance. <BR>
* There is a further attribute "name" which determines the format of the
* output file, it identifies the name of an xsl:output element containing the output
* format details.
*/

public class ResultDocument extends Instruction {

    private Expression href;
    private Properties outputProperties;
    private String baseURI;     // needed only for saxon:next-in-chain
    private int validationAction;
    private SchemaType schemaType;

    public ResultDocument(Properties outputProperties,
                          Expression href,
                          String baseURI,
                          int validationAction,
                          SchemaType schemaType) {
        this.outputProperties = outputProperties;
        this.href = href;
        this.baseURI = baseURI;
        this.validationAction = validationAction;
        this.schemaType = schemaType;
    }

    /**
    * Get the name of this instruction for diagnostic and tracing purposes
    *  (the string "xsl:result-document")
    */

    public String getInstructionName() {
        return "result-document";
    }

    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        SequenceReceiver oldReceiver = controller.getReceiver();

        Result result = null;
        OutputURIResolver resolver = null;

        if (href == null) {
            result = controller.getPrincipalResult();
        } else {
            resolver = controller.getOutputURIResolver();

            String hrefValue = href.evaluateAsString(context);
            result =
                resolver.resolve(hrefValue, controller.getPrincipalResultURI());
            if (result==null) {
                resolver = StandardOutputResolver.getInstance();
                result = resolver.resolve(hrefValue, controller.getPrincipalResultURI());
            }
        }

        boolean timing = controller.getConfiguration().isTiming();
        if (timing) {
            System.err.println("Writing to " + result.getSystemId());
        }

        String nextInChain = outputProperties.getProperty(SaxonOutputKeys.NEXT_IN_CHAIN);
        if (nextInChain != null) {
            result = controller.prepareNextStylesheet(nextInChain, baseURI, result);
        }

        controller.changeOutputDestination(outputProperties,
                                           result,
                                           true,
                                           validationAction,
                                           schemaType);
        processChildren(context);
        controller.resetOutputDestination(oldReceiver);
        if (resolver != null) {
            resolver.close(result);
        }
        return null;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Additional Contributor(s): Brett Knights [brett@knightsofthenet.com]
//
