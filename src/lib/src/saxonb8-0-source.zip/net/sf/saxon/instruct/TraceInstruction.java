package net.sf.saxon.instruct;

import net.sf.saxon.expr.*;
import net.sf.saxon.Controller;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.trace.TraceListener;

import javax.xml.transform.TransformerException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


/**
 * A run-time instruction which wraps a real instruction and traces its entry and exit to the
 * TraceListener
 */

public class TraceInstruction extends ExprInstruction {

    /**
     * A set of property name/value pairs to be added to the information
     * supplied to the TraceListener
     */

    private HashMap additionalProperties = new HashMap();

    /**
     * Create a Trace instruction
     * @param child the "real" instruction to be traced
     */

    public TraceInstruction(Instruction child) {
        Instruction[] children = {child};
        setChildren(children);
    }

    /**
     * Set a property to be supplied to the TraceListener when this instruction is executed
     * @param name the name of the property
     * @param value the value of the property
     */

    public void setProperty(String name, Object value) {
        additionalProperties.put(name, value);
    }

    /**
     * Get the system ID of the module in which this instruction is located
     * @return the system ID (URI) of the module
     */

    public String getSystemId() {
        return children[0].getSourceLocator().getSystemId();
    }

    /**
     * Get the line number of the instruction being traced
     * @return the line number (-1 if not known)
     */

    public int getLineNumber() {
        return children[0].getSourceLocator().getLineNumber();
    }

    /**
     * Get the name of the instruction being traced
     * @return the instruction name
     */

    public String getInstructionName() {
        if (children[0] instanceof Instruction) {
            return ((Instruction)children[0]).getInstructionName();
        } else {
            return "";
        }
    }

    /**
     * Get the namespace URI of the instruction being traced
     * @return the namespace URI of the instruction being traced
     */
    public String getInstructionNamespace() {
        if (children[0] instanceof Instruction) {
            return ((Instruction)children[0]).getInstructionNamespace();
        } else {
            return "";
        }
    }

    /**
     * Execute this instruction, with the possibility of returning tail calls if there are any.
     * This outputs the trace information via the registered TraceListener,
     * and invokes the instruction being traced.
     * @param context the dynamic execution context
     * @return either null, or a tail call that the caller must invoke on return
     * @throws TransformerException
     */
    public TailCall processLeavingTail(XPathContext context) throws TransformerException {
        Controller controller = context.getController();
        InstructionDetails details = null;
        TraceListener listener = controller.getTraceListener();
    	if (controller.isTracing()) {
            details = makeDetails(controller);
   	        listener.enter(details);
        }
     	TailCall tc = children[0].processLeavingTail(context);
    	if (controller.isTracing()) {
   	        listener.leave(details);
        }
        return tc;
    }

    private InstructionDetails makeDetails(Controller controller) {
        InstructionDetails details = new InstructionDetails();
        details.setSystemId(getSystemId());
        details.setLineNumber(getLineNumber());
        details.setInstructionName(getInstructionName());
        details.setProperty("instruction-namespace", getInstructionNamespace());
        Iterator iter = additionalProperties.keySet().iterator();
        while (iter.hasNext()) {
            String key = (String)iter.next();
            Object value = additionalProperties.get(key);
            details.setProperty(key, value);
        }
        details.setProperty("controller", controller);
        return details;
    }

    /**
     * Simplify an expression. This performs any static optimization (by rewriting the expression
     * as a different expression). The default implementation does nothing.
     *
     * @exception XPathException if an error is discovered during expression
     *     rewriting
     * @return the simplified expression
     */

     public Expression simplify() throws XPathException {
        if (children[0] instanceof ExprInstruction) {
            children[0] = (ExprInstruction)((Expression)children[0]).simplify();
        }
        return this;
    }

    /**
     * Perform static analysis of an expression and its subexpressions.
     *
     * <p>This checks statically that the operands of the expression have
     * the correct type; if necessary it generates code to do run-time type checking or type
     * conversion. A static type error is reported only if execution cannot possibly succeed, that
     * is, if a run-time type error is inevitable. The call may return a modified form of the expression.</p>
     *
     * <p>This method is called after all references to functions and variables have been resolved
     * to the declaration of the function or variable. However, the types of such functions and
     * variables will only be accurately known if they have been explicitly declared.</p>
     *
     * @param env the static context of the expression
     * @exception XPathException if an error is discovered during this phase
     *     (typically a type error)
     * @return the original expression, rewritten to perform necessary
     *     run-time type checks, and to perform other type-related
     *     optimizations
     */

    public Expression analyze(StaticContext env) throws XPathException {
        if (children[0] instanceof ExprInstruction) {
            children[0] = (ExprInstruction)((Expression)children[0]).analyze(env);
        }
        return this;
    }

    /**
     * Determine which aspects of the context the expression depends on. The result is
     * a bitwise-or'ed value composed from constants such as {@link StaticProperty#DEPENDS_ON_CONTEXT_ITEM} and
     * {@link StaticProperty#DEPENDS_ON_CURRENT_ITEM}. The default implementation combines the intrinsic
     * dependencies of this expression with the dependencies of the subexpressions,
     * computed recursively. This is overridden for expressions such as FilterExpression
     * where a subexpression's dependencies are not necessarily inherited by the parent
     * expression.
     *
     * @return a set of bit-significant flags identifying the dependencies of
     *     the expression
     */

    public int getDependencies() {
        if (children[0] instanceof ExprInstruction) {
            return ((ExprInstruction)children[0]).getDependencies();
        }
        return 0;
    }

    /**
     * Get the static properties of this expression (other than its type). The result is
     * bit-signficant. These properties are used for optimizations. In general, if
     * property bit is set, it is true, but if it is unset, the value is unknown.
     *
     * @return a set of flags indicating static properties of this expression
     */

    public int getSpecialProperties() {
        if (children[0] instanceof ExprInstruction) {
            return ((ExprInstruction)children[0]).getSpecialProperties();
        }
        return 0;
    }


    /**
     * Evaluate an expression as a single item. This always returns either a single Item or
     * null (denoting the empty sequence). No conversion is done. This method should not be
     * used unless the static type of the expression is a subtype of "item" or "item?": that is,
     * it should not be called if the expression may return a sequence. There is no guarantee that
     * this condition will be detected.
     *
     * @param context The context in which the expression is to be evaluated
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @return the node or atomic value that results from evaluating the
     *     expression; or null to indicate that the result is an empty
     *     sequence
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        InstructionDetails details = null;
        Controller controller = context.getController();
        if (controller.isTracing()) {
            details = makeDetails(controller);
            controller.getTraceListener().enter(details);
        }
        Item result = ((Expression)children[0]).evaluateItem(context);
        if (controller.isTracing()) {
            controller.getTraceListener().leave(details);
        }
        return result;
    }

    /**
     * Return an Iterator to iterate over the values of a sequence. The value of every
     * expression can be regarded as a sequence, so this method is supported for all
     * expressions. This default implementation handles iteration for expressions that
     * return singleton values: for non-singleton expressions, the subclass must
     * provide its own implementation.
     *
     * @exception XPathException if any dynamic error occurs evaluating the
     *     expression
     * @param context supplies the context for evaluation
     * @return a SequenceIterator that can be used to iterate over the result
     *     of the expression
     */

    public SequenceIterator iterate(XPathContext context) throws XPathException {
        InstructionDetails details = null;
        Controller controller = context.getController();
        if (controller.isTracing()) {
            details = makeDetails(controller);
            controller.getTraceListener().enter(details);
        }
        SequenceIterator result = ((Expression)children[0]).iterate(context);
        if (controller.isTracing()) {
            controller.getTraceListener().leave(details);
        }
        return result;
    }

    /**
     * Handle promotion offers, that is, non-local tree rewrites.
     * @param offer The type of rewrite being offered
     * @throws XPathException
     */

    protected void promoteInst(PromotionOffer offer) throws XPathException {
        if (children[0] instanceof ExprInstruction) {
            ((ExprInstruction)children[0]).promoteInst(offer);
        }
    }

    /**
     * Get all the XPath expressions associated with this instruction
     * (in XSLT terms, the expression present on attributes of the instruction,
     * as distinct from the child instructions in a sequence construction)
     * @param list A list to be populated with the list of XPath expressions
     */

    protected void getXPathExpressions(List list) {
        if (children[0] instanceof ExprInstruction) {
            ((ExprInstruction)children[0]).getXPathExpressions(list);
        }
    }

    /**
     * Diagnostic print of expression structure. The expression is written to the System.err
     * output stream
     *
     * @param level indentation level for this expression
     */

    public void display(int level, NamePool pool) {
        if (children[0] instanceof ExprInstruction) {
            ((ExprInstruction)children[0]).display(level, pool);
        }
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
