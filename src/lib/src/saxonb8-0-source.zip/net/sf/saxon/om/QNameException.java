package net.sf.saxon.om;

/**
 * A QNameException represents an error condition whereby a QName (for example a variable
 * name or template name) is malformed
 */

public class QNameException extends Exception {

    String message;

    public QNameException (String message) {
       this.message = message;
    }

    public String getMessage() {
        return message;
    }

}

