package net.sf.saxon.om;
import net.sf.saxon.Configuration;
import net.sf.saxon.tinytree.*;
import net.sf.saxon.event.Builder;
import net.sf.saxon.event.Sender;

import org.w3c.dom.Document;
import org.w3c.dom.DOMImplementation;
import org.xml.sax.InputSource;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.TransformerException;

/**
 * This class implements the JAXP DocumentBuilder interface, allowing a Saxon TinyTree to be
 * constructed using standard JAXP parsing interfaces. Note that although the TinyTree
 * implements the DOM interfaces, it is read-only, and all attempts to update it will throw
 * an exception. No schema or DTD validation is carried out on the document.
 */

public class DocumentBuilderImpl extends DocumentBuilder {

    private EntityResolver entityResolver;
    private ErrorHandler errorHandler;

    public boolean isNamespaceAware() {
        return true;
    }

    public boolean isValidating() {
        return false;
    }

    public Document newDocument() {
        // The returned document will be of little use, because it is immutable.
        // But it can be used in a DOMResult as the result of a transformation
        return new TinyDocumentImpl();
    }

    public Document parse(InputSource in) throws SAXException {
        try {
            Builder builder = new TinyBuilder();
            Configuration config = new Configuration();
            NamePool pool = config.getNamePool();
            builder.setConfiguration(config);
            SAXSource source = new SAXSource(in);
            if (entityResolver != null) {
                source.getXMLReader().setEntityResolver(entityResolver);
            }
            if (errorHandler != null) {
                source.getXMLReader().setErrorHandler(errorHandler);
            }
            source.setSystemId(in.getSystemId());
            new Sender(config).send(source, builder);
            TinyDocumentImpl doc = (TinyDocumentImpl)builder.getCurrentDocument();
            pool.allocateDocumentNumber(doc);
            return doc;
        } catch (TransformerException err) {
            throw new SAXException(err);
        }
    }

    public void setEntityResolver(EntityResolver er) {
        entityResolver = er;
    }

    public void setErrorHandler(ErrorHandler eh) {
        errorHandler = eh;
    }

    public DOMImplementation getDOMImplementation() {
        return new TinyDocumentImpl().getImplementation();
    }
}