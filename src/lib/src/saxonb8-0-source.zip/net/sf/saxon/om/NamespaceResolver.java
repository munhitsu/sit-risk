package net.sf.saxon.om;

import net.sf.saxon.xpath.XPathException;

/**
 * Interface that supports lookup of a lexical QName to get the expanded QName.
 */

public interface NamespaceResolver {

    /**
    * Get the namespace URI corresponding to a given prefix. Return null
    * if the prefix is not in scope.
    * @param prefix the namespace prefix
    * @param useDefault true if the default namespace is to be used when the
    * prefix is ""
    * @return the uri for the namespace, or null if the prefix is not in scope
    */

    public String getURIForPrefix(String prefix, boolean useDefault);

    /**
    * Use this NamespaceContext to resolve a lexical QName
    * @param qname the lexical QName; this must have already been lexically validated
    * @param useDefault true if the default namespace is to be used to resolve an unprefixed QName
    * @param pool the NamePool to be used
    * @return the integer fingerprint that uniquely identifies this name
     * @throws XPathException.Dynamic if the string is not a valid lexical QName or
     * if the namespace prefix has not been declared
    */

    public int getFingerprint(String qname, boolean useDefault, NamePool pool)
    throws XPathException;
}
