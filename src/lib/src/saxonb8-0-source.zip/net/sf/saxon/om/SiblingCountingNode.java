package net.sf.saxon.om;

/**
 * Interface that extends NodeInfo by providing a method to get the position
 * of a node relative to its siblings.
 */

public interface SiblingCountingNode extends NodeInfo {

    /**
     * Get the index position of this node among its siblings (starting from 0)
     * @return 0 for the first child, 1 for the second child, etc.
     */
    public int getSiblingPosition();
}
