package net.sf.saxon.om;

/**
 * This interface is implemented by NodeInfo implementations that act as wrappers
 * on some underlying tree. It provides a method to access the real node underlying
 * the virtual node, for use by applications that need to drill down to the
 * underlying data.
 */

public interface VirtualNode {

    /**
     * Get the real node undelying this virtual node.
     * @return The underlying node. Note that this may itself be
     * a VirtualNode; you may have to drill down through several layers of
     * wrapping.
     */

    public Object getUnderlyingNode();

}
