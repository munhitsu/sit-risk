package net.sf.saxon.dom;

import net.sf.saxon.Transform;
import net.sf.saxon.dom.DocumentWrapper;

import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.TransformerException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

import org.xml.sax.SAXException;


/**
 * Variant of command line net.sf.saxon.Transform do build the source document
 * in DOM and then proceed with the transformation. This class is provided largely for
 * testing purposes.
 */

public class DOMTransform extends Transform {

    public List preprocess(List sources) throws TransformerException {
        try {
            ArrayList domSources = new ArrayList(sources.size());
            for (int i=0; i<sources.size(); i++) {
                SAXSource ss = (SAXSource)sources.get(i);

                // The following statement, if uncommented, forces use of the Xerces DOM.
                // This system property can also be set from the command line using the -D option

                System.setProperty("javax.xml.parser.DocumentBuilderFactory",
                                   "org.apache.xerces.jaxp.DocumentBuilderFactoryImpl");

                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                factory.setNamespaceAware(true);
                DocumentBuilder builder = factory.newDocumentBuilder();
                org.w3c.dom.Document doc = builder.parse(ss.getInputSource());
                DocumentWrapper jdom = new DocumentWrapper(doc, ss.getSystemId());
                domSources.add(jdom);
            }
            return domSources;
        } catch (ParserConfigurationException e) {
            throw new TransformerException(e);
        } catch (SAXException e) {
            throw new TransformerException(e);
        } catch (IOException e) {
            throw new TransformerException(e);
    }
    }

    public static void main(String[] args) {
        new DOMTransform().doMain(args, "DOMTransform");
    }
}
