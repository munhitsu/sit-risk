package net.sf.saxon;

import net.sf.saxon.event.Builder;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.event.StandardOutputResolver;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.pattern.NodeTest;
import net.sf.saxon.query.StaticQueryContext;
import net.sf.saxon.trace.TraceListener;
import net.sf.saxon.type.*;
import net.sf.saxon.xpath.XPathException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.*;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Locale;

/**
 * This class holds details of user-selected configuration options for a transformation
 * or query
 */


public class Configuration implements Serializable {

    private transient URIResolver resolver;
    private transient ErrorListener listener;
    private int treeModel = Builder.TINY_TREE;
    private boolean lineNumbering = false;
    private TraceListener traceListener = null;
    private int recoveryPolicy = RECOVER_WITH_WARNINGS;
    private String messageEmitterClass = "net.sf.saxon.event.MessageEmitter";
    private String sourceParserClass;
    private String styleParserClass;
    private transient OutputURIResolver outputURIResolver;
    private boolean timing = false;
    private boolean allowExternalFunctions = true;
    private boolean traceExternalFunctions = false;
    private boolean validation = false;
    private NamePool targetNamePool = null;
    private boolean stripsAllWhiteSpace = false;
    private int hostLanguage = XSLT;
    private HashMap queryLibraryModules = null;
    private boolean schemaValidation = false;

    /**
     * Constant indicating that the processor should take the recovery action
     * when a recoverable error occurs, with no warning message.
     */
    public final static int RECOVER_SILENTLY = 0;
    /**
     * Constant indicating that the processor should produce a warning
     * when a recoverable error occurs, and should then take the recovery
     * action and continue.
     */
    public final static int RECOVER_WITH_WARNINGS = 1;
    /**
     * Constant indicating that when a recoverable error occurs, the
     * processor should not attempt to take the defined recovery action,
     * but should terminate with an error.
     */
    public final static int DO_NOT_RECOVER = 2;

    /**
     * Constant indicating that the host language is XSLT
     */
    public static final int XSLT = 10;

    /**
     * Constant indicating that the host language is XQuery
     */
    public static final int XQUERY = 11;

    /**
     * Create a configuration object with default settings for all options
     */

    public Configuration() {
        targetNamePool = NamePool.getDefaultNamePool();
    }

   /**
     * Get a message used to identify this product when a transformation is run using the -t option
     * @return A string containing both the product name and the product
     *     version
     */

    public String getProductTitle() {
        return "Saxon " + Version.getProductVersion() + " from Saxonica";
    }

    /**
     * Determine if the configuration is schema-aware
     */

    public boolean isSchemaAware() {
        return false;
        // changing this to true will do no good!
    }

    /**
     * Display a message about the license status
     */

    public void displayLicenseMessage() {}

    /**
     * Get the host language used in this configuration. The possible values
     * are XSLT and XQUERY.
     * @return Configuration.XSLT or Configuration.XQUERY
     */

    public int getHostLanguage() {
        return hostLanguage;
    }

    /**
     * Set the host language used in this configuration. The possible values
     * are XSLT and XQUERY.
     * @param hostLanguage Configuration.XSLT or Configuration.XQUERY
     */

    public void setHostLanguage(int hostLanguage) {
        this.hostLanguage = hostLanguage;
    }

    /**
     * Get the URIResolver used in this configuration
     * @return the URIResolver. If no URIResolver has been set explicitly, the
     * default URIResolver is used.
     */

    public URIResolver getURIResolver() {
        if (resolver==null) {
            resolver = new StandardURIResolver(this);
        }
        return resolver;
    }

    /**
     * Set the URIResolver to be used in this configuration. This will be used to
     * resolve the URIs used statically (e.g. by xsl:include) and also the URIs used
     * dynamically by functions such as document() and doc(). Note that the URIResolver
     * does not resolve the URI in the sense of RFC 2396 (which is also the sense in which
     * the resolve-uri() function uses the term): rather it dereferences an absolute URI
     * to obtain an actual resource, which is returned as a Source object.
     * @param resolver The URIResolver to be used.
     */

    public void setURIResolver(URIResolver resolver) {
        this.resolver = resolver;
    }

    /**
     * Get the ErrorListener used in this configuration. If no ErrorListener
     * has been supplied explicitly, the default ErrorListener is used.
     * @return the ErrorListener.
     */

    public ErrorListener getErrorListener() {
        if (listener == null) {
            listener = new StandardErrorListener();
        }
        return listener;
    }

    /**
     * Set the ErrorListener to be used in this configuration. The ErrorListener
     * is informed of all static and dynamic errors detected, and can decide whether
     * run-time warnings are to be treated as fatal.
     * @param listener the ErrorListener to be used
     */

    public void setErrorListener(ErrorListener listener) {
        this.listener = listener;
    }

    /**
     * Get the Tree Model used by this Configuration. This is either
     * Builder.STANDARD_TREE or Builder.TINY_TREE. The default (confusingly)
     * is Builder.TINY_TREE.
     * @return the selected Tree Model
     */

    public int getTreeModel() {
        return treeModel;
    }

    /**
     * Set the Tree Model used by this Configuration. This is either
     * Builder.STANDARD_TREE or Builder.TINY_TREE. The default (confusingly)
     * is Builder.TINY_TREE.
     * @param treeModel the selected Tree Model
     */

    public void setTreeModel(int treeModel) {
        this.treeModel = treeModel;
    }

    /**
     * Determine whether source documents will maintain line numbers, for the
     * benefit of the saxon:line-number() extension function as well as run-time
     * tracing.
     * @return true if line numbers are maintained in source documents
     */

    public boolean isLineNumbering() {
        return lineNumbering;
    }

    /**
     * Determine whether source documents will maintain line numbers, for the
     * benefit of the saxon:line-number() extension function as well as run-time
     * tracing.
     * @param lineNumbering true if line numbers are maintained in source documents
     */

    public void setLineNumbering(boolean lineNumbering) {
        this.lineNumbering = lineNumbering;
    }

    /**
     * Get the TraceListener used for run-time tracing of instruction execution.
     * @return the TraceListener, or null if none is in use.
     */

    public TraceListener getTraceListener() {
        return traceListener;
    }

    /**
     * Set the TraceListener to be used for run-time tracing of instruction execution.
     * @param traceListener The TraceListener to be used.
     */

    public void setTraceListener(TraceListener traceListener) {
        this.traceListener = traceListener;
    }

    /**
     * Determine how recoverable run-time errors are to be handled. This applies
     * only if the standard ErrorListener is used. The options are RECOVER_SILENTLY,
     * RECOVER_WITH_WARNINGS, or DO_NOT_RECOVER.
     * @return the current recovery policy
     */

    public int getRecoveryPolicy() {
        return recoveryPolicy;
    }

    /**
     * Determine how recoverable run-time errors are to be handled. This applies
     * only if the standard ErrorListener is used. The options are RECOVER_SILENTLY,
     * RECOVER_WITH_WARNINGS, or DO_NOT_RECOVER.
     * @param recoveryPolicy the recovery policy to be used.
     */

    public void setRecoveryPolicy(int recoveryPolicy) {
        this.recoveryPolicy = recoveryPolicy;
    }

    /**
     * Get the name of the class that will be instantiated to create a MessageEmitter,
     * to process the output of xsl:message instructions.
     * @return the full class name of the message emitter class.
     */

    public String getMessageEmitterClass() {
        return messageEmitterClass;
    }

    /**
     * Set the name of the class that will be instantiated to create a MessageEmitter,
     * to process the output of xsl:message instructions.
     * @param messageEmitterClass the full class name of the message emitter class. This
     * must implement net.sf.saxon.event.Emitter.
     */

    public void setMessageEmitterClass(String messageEmitterClass) {
        this.messageEmitterClass = messageEmitterClass;
    }

    /**
     * Get the name of the class that will be instantiated to create an XML parser
     * for parsing source documents (for example, documents loaded using the document()
     * or doc() functions).
     * @return the fully qualified name of the XML parser class
     */

    public String getSourceParserClass() {
        return sourceParserClass;
    }

    /**
     * Set the name of the class that will be instantiated to create an XML parser
     * for parsing source documents (for example, documents loaded using the document()
     * or doc() functions).
     * @param sourceParserClass the fully qualified name of the XML parser class. This must implement
     * the SAX2 XMLReader interface.
     */

    public void setSourceParserClass(String sourceParserClass) {
        this.sourceParserClass = sourceParserClass;
    }

    /**
     * Get the name of the class that will be instantiated to create an XML parser
     * for parsing stylesheet modules.
     * @return the fully qualified name of the XML parser class
     */

    public String getStyleParserClass() {
        return styleParserClass;
    }

   /**
     * Set the name of the class that will be instantiated to create an XML parser
     * for parsing stylesheet modules.
     * @param styleParserClass the fully qualified name of the XML parser class
     */

    public void setStyleParserClass(String styleParserClass) {
        this.styleParserClass = styleParserClass;
    }

    /**
     * Get the OutputURIResolver that will be used to resolve URIs used in the
     * href attribute of the xsl:result-document instruction.
     * @return the OutputURIResolver. If none has been supplied explicitly, the
     * default OutputURIResolver is returned.
     */

    public OutputURIResolver getOutputURIResolver() {
        if (outputURIResolver==null) {
            outputURIResolver = StandardOutputResolver.getInstance();
        }
        return outputURIResolver;
    }

    /**
     * Set the OutputURIResolver that will be used to resolve URIs used in the
     * href attribute of the xsl:result-document instruction.
     * @param outputURIResolver the OutputURIResolver to be used.
     */

    public void setOutputURIResolver(OutputURIResolver outputURIResolver) {
        this.outputURIResolver = outputURIResolver;
    }

    /**
     * Determine whether brief progress messages and timing information will be output
     * to System.err
     * @return true if these messages are to be output.
     */

    public boolean isTiming() {
        return timing;
    }

    /**
     * Determine whether brief progress messages and timing information will be output
     * to System.err
     * @param timing true if these messages are to be output.
     */

    public void setTiming(boolean timing) {
        this.timing = timing;
    }

    /**
     * Determine whether calls to external Java functions are permitted.
     * @return true if such calls are permitted.
     */

    public boolean isAllowExternalFunctions() {
        return allowExternalFunctions;
    }

    /**
     * Determine whether calls to external Java functions are permitted. Allowing
     * external function calls is potentially a security risk if the stylesheet or
     * Query is untrusted, as it allows arbitrary Java methods to be invoked, which can
     * examine or modify the contents of filestore and other resources on the machine
     * where the query/stylesheet is executed
     * @param allowExternalFunctions true if external function calls are to be
     * permitted.
     */

    public void setAllowExternalFunctions(boolean allowExternalFunctions) {
        this.allowExternalFunctions = allowExternalFunctions;
    }

    /**
     * Determine whether calls on external functions are to be traced for diagnostic
     * purposes.
     * @return true if tracing is enabled for calls to external Java functions
     */

    public boolean isTraceExternalFunctions() {
        return traceExternalFunctions;
    }

    /**
     * Determine whether calls on external functions are to be traced for diagnostic
     * purposes.
     * @param traceExternalFunctions true if tracing is to be enabled
     * for calls to external Java functions
     */

    public void setTraceExternalFunctions(boolean traceExternalFunctions) {
        this.traceExternalFunctions = traceExternalFunctions;
    }

    /**
     * Determine whether the XML parser for source documents will be asked to perform
     * DTD validation of source documents
     * @return true if DTD validation is requested.
     */

    public boolean isValidation() {
        return validation;
    }

    /**
     * Determine whether the XML parser for source documents will be asked to perform
     * DTD validation of source documents
     * @param validation true if DTD validation is to be requested.
     */

    public void setValidation(boolean validation) {
        this.validation = validation;
    }

    /**
     * Determine whether source documents (supplied as a StreamSource or SAXSource)
     * should be subjected to schema validation
     * @return true if source documents should be validated
     */

    public boolean isSchemaValidation() {
        return schemaValidation;
    }

    /**
     * Indicate whether source documents (supplied as a StreamSource or SAXSource)
     * should be subjected to schema validation
     * @param validate true if source documents should be validated
     */

    public void setSchemaValidation(boolean validate) {
        if (validate && !isSchemaAware()) {
            needSchemaAwareVersion();
        }
        schemaValidation = validate;
    }

    /**
     * Get the target namepool to be used for stylesheets/queries and for source documents.
     * @return the target name pool. If no NamePool has been specified explicitly, the
     * default NamePool is returned.
     */

    public NamePool getNamePool() {
        return targetNamePool;
    }

    /**
     * Set the NamePool to be used for stylesheets/queries and for source documents.
     * @param targetNamePool The NamePool to be used.
     */

    public void setNamePool(NamePool targetNamePool) {
        this.targetNamePool = targetNamePool;
    }

    /**
     * Determine whether whitespace-only text nodes are to be stripped unconditionally
     * from source documents.
     * @return true if all whitespace-only text nodes are stripped.
     */

    public boolean isStripsAllWhiteSpace() {
        return stripsAllWhiteSpace;
    }

      /**
     * Determine whether whitespace-only text nodes are to be stripped unconditionally
     * from source documents.
     * @param stripsAllWhiteSpace if all whitespace-only text nodes are to be stripped.
     */

    public void setStripsAllWhiteSpace(boolean stripsAllWhiteSpace) {
        this.stripsAllWhiteSpace = stripsAllWhiteSpace;
    }

    /**
    * Get the parser for source documents
    */

    public XMLReader getSourceParser() throws TransformerFactoryConfigurationError {
        XMLReader parser;
        if (getSourceParserClass()!=null) {
            return parser = makeParser(getSourceParserClass());
        } else {
            try {
                parser = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
            } catch (Exception err) {
                throw new TransformerFactoryConfigurationError(err);
            }
        }
        if (isValidation()) {
            try {
                parser.setFeature("http://xml.org/sax/features/validation", true);
            } catch (SAXException err) {
                throw new TransformerFactoryConfigurationError("The XML parser does not support validation");
            }
        }

        return parser;
    }

    /**
    * Get the parser for stylesheet documents
    */

    public XMLReader getStyleParser() throws TransformerFactoryConfigurationError {
        XMLReader parser;
        if (getStyleParserClass()!=null) {
            parser = makeParser(getStyleParserClass());
        } else {
            try {
                parser = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
            } catch (Exception err) {
                throw new TransformerFactoryConfigurationError(err);
            }
        }
        try {
            parser.setFeature("http://xml.org/sax/features/namespaces", true);
            parser.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
        } catch (SAXNotRecognizedException e) {
            throw new TransformerFactoryConfigurationError(e);
        } catch (SAXNotSupportedException e) {
            throw new TransformerFactoryConfigurationError(e);
        }
        return parser;
    }

    /**
     * Read a schema from a given schema location
     * @return the target namespace of the schema
     */

    public String readSchema(String baseURI, String schemaLocation, String expected)
    throws TransformerConfigurationException {
        needSchemaAwareVersion();
        return null;
    }

    private void needSchemaAwareVersion() {
        throw new UnsupportedOperationException(
                "You need the schema-aware version of Saxon for this operation");
    }

    /**
     * Load a schema, which will be available for use by all subsequent operations using
     * this Configuration.
     * @param schemaSource the JAXP Source object identifying the schema document to be loaded
     * @throws TransformerException if the schema cannot be read or parsed or if it is invalid
     */

    public void addSchema(Source schemaSource) throws TransformerException {
        needSchemaAwareVersion();
    }

    /**
     * Add a schema to the cache
     */

    public void addSchema(SchemaMarker schema)
    throws TransformerConfigurationException {
        needSchemaAwareVersion();
    }

    /**
     * Get a schema from the cache. Return null if not found.
     */

    public SchemaMarker getSchema(String namespace) {
        return null;
    }

    /**
     * Get a global element declaration
     * @return the element declaration whose name matches the given
     * fingerprint, or null if no element declaration with this name has
     * been registered.
     */

    public SchemaDeclaration getElementDeclaration(int fingerprint) {
        return null;
    }

    /**
     * Get a global attribute declaration
     * @return the attribute declaration whose name matches the given
     * fingerprint, or null if no element declaration with this name has
     * been registered.
     */

    public SchemaDeclaration getAttributeDeclaration(int fingerprint) {
        return null;
    }

    /**
      * Get the top-level schema type with a given fingerprint.
      * @param fingerprint the fingerprint of the schema type
      * @return the schema type , or null if there is none
      * with this name.
      */

     public SchemaType getSchemaType(int fingerprint) {
        if (fingerprint < 1023) {
            return BuiltInSchemaFactory.getSchemaType(fingerprint);
        }
        return null;
     }

    /**
     * Get a document-level validator to add to a Receiver pipeline
     * @param receiver The receiver to which events should be sent after validation
     * @param systemId the base URI of the document being validated
     * @param namePool the namePool to be used by the validator
     * @param validationMode for example Validation.STRICT or Validation.STRIP
     * @return A Receiver to which events can be sent for validation
     */

    public Receiver getDocumentValidator(Receiver receiver,
                                         String systemId,
                                         NamePool namePool,
                                         int validationMode) {
        // non-schema-aware version
        return receiver;
    }

    /**
     * Get a Receiver that can be used to validate an element, and that passes the validated
     * element on to a target receiver. If validation is not supported, the returned receiver
     * will be the target receiver.
     * @param receiver the target receiver tp receive the validated element
     * @param nameCode the nameCode of the element to be validated. This must correspond to the
     * name of an element declaration in a loaded schema
     * @param schemaType the schema type (typically a complex type) against which the element is to
     * be validated
     * @param validation The validation mode, for example Validation.STRICT or Validation.LAX
     * @param pool The name pool
     * @return The target receiver, indicating that with this configuration, no validation
     * is performed.
     */
    public Receiver getElementValidator(Receiver receiver,
                                        int nameCode,
                                        SchemaType schemaType,
                                        int validation,
                                        ValidationContext context,
                                        NamePool pool)
            throws TransformerException {
        return receiver;
    }

    /**
     * Get a validation context nested within an existing validation context
     * (XQuery only)
     */

    public ValidationContext getContainedValidationContext(
                                        ValidationContext outer,
                                        int fingerprint,
                                        boolean isType)
    throws XPathException {
        needSchemaAwareVersion();
        return null;
    }

    /**
     * Validate an attribute value
     * @param nameCode the name of the attribute
     * @param value the value of the attribute as a string
     * @param validation STRICT or LAX
     * @return the type annotation to apply to the attribute node
     * @throws ValidationException if the value is invalid
     */

    public long validateAttribute(int nameCode, CharSequence value, int validation)
    throws ValidationException {
        return -1;
    }

    /**
     * Get the schema type corresponding to an attribute declaration
     */

    public SchemaType getAttributeType(SchemaDeclaration attributeDecl) {
        needSchemaAwareVersion();
        return null;
    }

    /**
     * Get the schema type corresponding to an element declaration
     */

    public SchemaType getElementType(SchemaDeclaration attributeDecl) {
        needSchemaAwareVersion();
        return null;
    }

    /**
     * Make a test for elements corresponding to a give element declaration
     */

    public NodeTest makeSubstitutionGroupTest(SchemaDeclaration elementDecl) {
        needSchemaAwareVersion();
        return null;
    }

    /**
     * Add an XQuery library module to the configuration
     */

    public void addQueryLibraryModule(StaticQueryContext module) {
        if (queryLibraryModules==null) {
            queryLibraryModules = new HashMap();
        }
        queryLibraryModules.put(module.getModuleNamespace(), module);
    }

    /**
     * Locate an XQuery library module in the configuration.
     * @param namespace the module namespace URI
     * @return the StaticQueryContext representing the module, or
     * null if the module namespace is unknown
     */

    public StaticQueryContext getQueryLibraryModule(String namespace) {
        if (queryLibraryModules == null) {
            return null;
        }
        return (StaticQueryContext)queryLibraryModules.get(namespace);
    }

    /**
    * Create a new SAX XMLReader object using the class name provided. <br>
    *
    * The named class must exist and must implement the
    * org.xml.sax.XMLReader or Parser interface. <br>
    *
    * This method returns an instance of the parser named.
    *
    * @param className A string containing the name of the
    *   SAX parser class, for example "com.microstar.sax.LarkDriver"
    * @return an instance of the Parser class named, or null if it is not
    * loadable or is not a Parser.
    *
    */
    public static XMLReader makeParser (String className)
    throws TransformerFactoryConfigurationError
    {
        Object obj;
        try {
            obj = Loader.getInstance(className);
        } catch (TransformerException err) {
            throw new TransformerFactoryConfigurationError(err);
        }
        if (obj instanceof XMLReader) {
            return (XMLReader)obj;
        }
        throw new TransformerFactoryConfigurationError("Class " + className +
                                 " is not a SAX2 XMLReader");
    }

    /**
    * Get a locale given a language code in XML format
    */

    public static Locale getLocale(String lang) {
        int hyphen = lang.indexOf("-");
        String language, country;
        if (hyphen < 1) {
            language = lang;
            country = "";
        } else {
            language = lang.substring(1, hyphen);
            country = lang.substring(hyphen+1);
        }
        return new Locale(language, country);
    }

}
