package net.sf.saxon.functions;
import net.sf.saxon.expr.Tokenizer;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.LastPositionFinder;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.value.IntegerValue;
import net.sf.saxon.value.NumericValue;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.xpath.XPathException;

/**
* This class implements the sum(), avg(), count() functions,
*/

public class Aggregate extends SystemFunction {

    public final static int SUM = 0;
    public final static int AVG = 1;
    public final static int COUNT = 4;

    // TODO: implement sum() and avg() over a sequence of durations

    // TODO: implement 2-argument form of sum() function

    /**
     * Static analysis: prevent sorting of the argument
     */

    public void checkArguments(StaticContext env) throws XPathException {
        super.checkArguments(env);
        argument[0] = ExpressionTool.unsorted(argument[0], true);
    }

    /**
    * Evaluate the function
    */

    public Item evaluateItem(XPathContext context) throws XPathException {
        // Note: these functions do not need to sort the underlying sequence,
        // but they do need to de-duplicate it
        switch (operation) {
            case COUNT:
                SequenceIterator iter = argument[0].iterate(context);
                return new IntegerValue(count(iter));
            case SUM:
                return total(argument[0].iterate(context));
            case AVG:
                return average(argument[0].iterate(context));
            default:
                throw new UnsupportedOperationException("Unknown aggregate function");
        }
    }

    /**
    * Calculate total
    */

    private NumericValue total(SequenceIterator iter) throws XPathException {
        NumericValue sum = new IntegerValue(0);
        while (true) {
            AtomicValue nextVal = (AtomicValue)iter.next();
            if (nextVal == null) {
                return sum;
            }
            NumericValue next = (NumericValue)nextVal.getPrimitiveValue();
            sum = sum.arithmetic(Tokenizer.PLUS, next);
            if (sum.isNaN()) {
                // take an early bath, once we've got a NaN it's not going to change
                return sum;
            }
        }
    }

    /**
    * Calculate average
    */

    private NumericValue average(SequenceIterator iter) throws XPathException {
        NumericValue sum = new IntegerValue(0);
        int count = 0;
        while (true) {
            AtomicValue nextVal = (AtomicValue)iter.next();
            if (nextVal == null) {
                break;
            }
            NumericValue next = (NumericValue)nextVal.getPrimitiveValue();
            sum = sum.arithmetic(Tokenizer.PLUS, next);
            count++;
        }

        if (count == 0) {
            return null;
        }

        // divide sum by count, following the exact rules in the spec. (These rules have the
        // effect that the average of a set of integers is a double, but the average of a set of
        // decimals is a decimal)

        return sum.arithmetic(Tokenizer.DIV, new IntegerValue(count));

    }

    /**
     * Get the number of items in a sequence identified by a SequenceIterator
     * @param enum The SequenceIterator. This method moves the current position
     * of the supplied iterator; if this isn't safe, make a copy of the iterator
     * first by calling getAnother().
     * @return the number of items in the underlying sequence
     * @throws XPathException
     */

    public static int count(SequenceIterator enum) throws XPathException {
        if (enum instanceof LastPositionFinder) {
            return ((LastPositionFinder)enum).getLastPosition();
        } else {
            int n = 0;
            while (enum.next() != null) {
                n++;
            }
            return n;
        }
    }

}


//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
