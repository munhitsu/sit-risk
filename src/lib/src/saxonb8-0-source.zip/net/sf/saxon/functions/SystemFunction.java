package net.sf.saxon.functions;
import net.sf.saxon.expr.*;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AnyItemType;


/**
* Abstract superclass for system-defined and user-defined functions
*/

public abstract class SystemFunction extends FunctionCall {

    /**
    * Make a system function (one in the standard function namespace).
    * @param name The local name of the function
    * @return a FunctionCall that implements this function, if it
    * exists, or null if the function is unknown.
    */

    public static FunctionCall makeSystemFunction(String name) {
        StandardFunction.Entry entry = StandardFunction.getFunction(name);
        if (entry==null) {
            return null;
        }
        Class functionClass = entry.implementationClass;
        try {
            SystemFunction f = (SystemFunction)functionClass.newInstance();
            f.setDetails(entry);
            return f;
        } catch (Exception err) {
            return null;
        }
    }

    /**
     *
     */

    private StandardFunction.Entry details;
    protected int operation;

    /**
    * Set the details of this type of function
    */

    private void setDetails(StandardFunction.Entry entry) {
        details = entry;
        operation = details.opcode;
    }

    /**
    * Get the details
    */

    protected StandardFunction.Entry getDetails() {
        return details;
    }

    /**
    * Method called during static type checking
    */

    public void checkArguments(StaticContext env) throws XPathException {
        checkArgumentCount(details.minArguments, details.maxArguments);
        for (int i=0; i<getNumberOfArguments(); i++) {
            checkArgument(i, env);
        }
    }

    /**
    * Perform static type checking on an argument to a function call, and add
    * type conversion logic where necessary.
    */

    private void checkArgument(int arg, StaticContext env) throws XPathException {
        //try {
                    // System.err.println("before type-check:"); argument[arg].display(10);
            RoleLocator role = new RoleLocator(RoleLocator.FUNCTION, getName(), arg);
            argument[arg] = TypeChecker.staticTypeCheck(
                                    argument[arg],
                                    getRequiredType(arg),
                                    env.isInBackwardsCompatibleMode(),
                                    role);
                    // System.err.println("after type-check:"); argument[arg].display(10);
//        } catch (XPathException.Type err) {
//            String s = "Type error in " + ordinal(arg) + " argument of call to " + getName() + "():\n  "
//                       + err.getMessage();
//            throw new XPathException.Type(s);
//        }
        argument[arg] = argument[arg].simplify();
    }

//    private String ordinal(int n) {
//        switch (n+1) {
//            case 1: return "first";
//            case 2: return "second";
//            case 3: return "third";
//            default: return n+"th";
//        }
//    }


    /**
    * Get the required type of the nth argument
    */

    protected SequenceType getRequiredType(int arg) {
        return details.argumentTypes[arg];
        // this is overridden for concat()
    }

    /**
    * Get the name of the function.
    * @return the name of the function, as used in XPath expressions, but excluding
    * its namespace prefix
    */

    public String getName() {
        return details.name;
    }


    /**
    * Determine the item type of the value returned by the function
    */

    public ItemType getItemType() {
        ItemType type = details.itemType;
        if (type == StandardFunction.SAME_AS_FIRST_ARGUMENT) {
            if (argument.length > 0) {
                return argument[0].getItemType();
            } else {
                return AnyItemType.getInstance();
                // if there is no first argument, an error will be reported
            }
        } else {
            return type;
        }
    }

    /**
    * Determine the cardinality of the function.
    */

    public int computeCardinality() {
        if (details==null) {
            System.err.println("**** No details for " + getClass() + " at " + this);
            return StaticProperty.ALLOWS_ZERO_OR_MORE;
        }
        return details.cardinality;
    }

    /**
    * Set "." as the default value for the first and only argument. Called from subclasses.
    */

    protected final void useContextItemAsDefault() {
        if (getNumberOfArguments()==0) {
            argument = new Expression[1];
            argument[0] = new ContextItemExpression();
            ExpressionTool.copyLocationInfo(this, argument[0]);
        }
        // Note that the extra argument is added before type-checking takes place. The
        // type-checking will add any necessary checks to ensure that the context item
        // is a node, in cases where this is required.
    }

    /**
    * Add an implicit argument referring to the context document. Called by functions such as
    * id() and key() that take the context document as an implicit argument
    */

    protected final void addContextDocumentArgument(int pos, String augmentedName)
    throws XPathException.Static {
        if (getNumberOfArguments() > pos) {
            return;
            // this happens during expression reduction, when the extra argument is already present
        }
        if (getNumberOfArguments() != pos) {
            throw new XPathException.Static("Too few arguments in call to " + getName() + "() function");
        }
        Expression[] newArgs = new Expression[pos+1];
        for (int i=0; i<getNumberOfArguments(); i++) {
            newArgs[i] = argument[i];
        }
        newArgs[pos] = new RootExpression();
        argument = newArgs;
        setDetails(StandardFunction.getFunction(augmentedName));
    }

    /**
    * Diagnostic print of expression structure
    */

    public void display(int level, NamePool pool) {
        System.err.println(ExpressionTool.indent(level) + "function " + getName());
        for (int a=0; a<getNumberOfArguments(); a++) {
            argument[a].display(level+1, pool);
        }
    }

    /**
     * The main() method of this class is not intended to be called, it merely
     * tells the code inspection tools in IDEA that the constructors of each
     * function class are actual entry points
     */

    public static void main(String[] args) throws Exception {
        SystemFunction f;
        f = new Aggregate();
        f = new Available();
        f = new BaseURI();
        f = new BooleanFn();
        f = new Compare();
        f = new Component();
        f = new Concat();
        f = new Contains();
        //f = new ContextItem();
        f = new Current();
        f = new CurrentDateTime();
        f = new CurrentGroup();
        f = new Data();
        f = new DeepEqual();
        f = new DefaultCollation();
        //f = new DistinctNodes();
        f = new DistinctValues();
        f = new Doc();
        f = new Document();
        f = new Error();
        f = new EscapeURI();
        f = new Evaluate();
        f = new Existence();
        f = new ForceCase();
        f = new FormatDate();
        f = new FormatNumber2();
        f = new Id();
        f = new IndexOf();
        f = new InScopeNamespaces();
        f = new Insert();
        f = new Key();
        f = new Lang();
        f = new Last();
        f = new Matches();
        f = new Minimax();
        f = new NamePart();
        f = new NamespaceForPrefix();
        f = new NormalizeSpace();
        f = new NumberFn();
        f = new Parse();
        f = new Position();
        f = new QNameFn();
        f = new RegexGroup();
        f = new Remove();
        f = new Replace();
        f = new ResolveQName();
        f = new ResolveURI();
        f = new Root();
        f = new Rounding();
        //f = new SequenceCompare();
        f = new Serialize();
        //f = new Sort();
        f = new StringFn();
        f = new StringJoin();
        f = new StringLength();
        //f = new StringPad();
        f = new Subsequence();
        f = new Substring();
        f = new SystemProperty();
        f = new Tokenize();
        f = new Trace();
        f = new Translate();
        f = new TreatFn();
        f = new Unicode();
        f = new Unordered();
        f = new UnparsedEntity();
        f = new UnparsedText();
        System.err.println(f);
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
