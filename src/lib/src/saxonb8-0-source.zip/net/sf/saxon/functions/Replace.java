package net.sf.saxon.functions;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.value.Value;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.RegexTranslator;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;


/**
* This class implements the replace() function for replacing
* substrings that match a regular expression
*/

public class Replace extends SystemFunction {

    private Pattern regexp;

    /**
    * Simplify and validate.
    * This is a pure function so it can be simplified in advance if the arguments are known
    */

     public Expression simplify() throws XPathException {
        Expression e = simplifyArguments();

        // compile the regular expression once if possible
        if (!(e instanceof Value)) {
            regexp = Matches.tryToCompile(argument, 1, 3);

            // check that it's not a pattern that matches ""
            if (regexp != null && regexp.matcher("").matches()) {
                throw new XPathException.Static(
                        "The regular expression must not be one that matches a zero-length string");
            }
        }

        return e;
    }


    /**
    * Evaluate the function in a string context
    */

    public Item evaluateItem(XPathContext c) throws XPathException {

        AtomicValue arg0 = (AtomicValue)argument[0].evaluateItem(c);
        if (arg0==null) {
            return StringValue.EMPTY_STRING;
        }

        AtomicValue arg2 = (AtomicValue)argument[2].evaluateItem(c);
        String replacement = arg2.getStringValue();
        checkReplacement(replacement);

        Pattern re = regexp;
        if (re == null) {

            AtomicValue arg1 = (AtomicValue)argument[1].evaluateItem(c);

            String flags;

            if (getNumberOfArguments() == 3) {
                flags = "";
            } else {
                AtomicValue arg3 = (AtomicValue)argument[3].evaluateItem(c);
                flags = arg3.getStringValue();
            }

            try {
                String javaRegex = RegexTranslator.translate(
                        arg1.getStringValue(), true);
                re = Pattern.compile(javaRegex, Matches.setFlags(flags));
            } catch (RegexTranslator.RegexSyntaxException err) {
                throw new XPathException.Dynamic(err);
            } catch (PatternSyntaxException err) {
                throw new XPathException.Dynamic(err);
            }

            // check that it's not a pattern that matches ""
            if (re.matcher("").matches()) {
                throw new XPathException.Dynamic(
                        "The regular expression must not be one that matches a zero-length string");
            }
        }
        String res = re.matcher(arg0.getStringValue()).replaceAll(arg2.getStringValue());
        return new StringValue(res);
    }

    /**
    * Check the contents of the replacement string
    */

    private void checkReplacement(String rep) throws XPathException {
        for (int i=0; i<rep.length(); i++) {
            char c = rep.charAt(i);
            if (c == '$') {
                if (i+1 < rep.length()) {
                    char next = rep.charAt(++i);
                    if (next < '0' || next > '9') {
                        dynamicError("Invalid replacement string in replace(): $ sign must be followed by digit 0-9");
                    }
                } else {
                    dynamicError("Invalid replacement string in replace(): $ sign at end of string");
                }
            } else if (c == '\\') {
                if (i+1 < rep.length()) {
                    char next = rep.charAt(++i);
                    if (next != '\\' && next != '$') {
                        dynamicError("Invalid replacement string in replace(): \\ character must be followed by \\ or $");
                    }
                } else {
                    dynamicError("Invalid replacement string in replace(): \\ character at end of string");
                }
            }
        }
    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
