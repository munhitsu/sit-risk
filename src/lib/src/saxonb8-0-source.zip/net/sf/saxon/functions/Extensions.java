package net.sf.saxon.functions;
import net.sf.saxon.expr.*;
import net.sf.saxon.om.*;
import net.sf.saxon.sort.GlobalOrderComparer;
import net.sf.saxon.value.*;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.type.Type;
import net.sf.saxon.type.SchemaType;

import java.util.HashSet;
import java.math.BigDecimal;
//import java.text.*;

/**
* This class implements functions that are supplied as standard with SAXON,
* but which are not defined in the XSLT or XPath specifications. <p>
*
* To invoke these functions, use a function call of the form prefix:name() where
* name is the method name, and prefix maps to a URI such as
* http://saxon.sf.net/net.sf.saxon.functions.Extensions (only the part
* of the URI after the last slash is important).
*/



public class Extensions  {

    /**
    * Switch tracing off. Only works if tracing is enabled.
    */

    public static void pauseTracing(XPathContext c) {
        c.getController().pauseTracing(true);
    }

    /**
    * Resume tracing. Only works if tracing was originally enabled
    * but is currently paused.
    */


    public static void resumeTracing(XPathContext c) {
        c.getController().pauseTracing(false);
    }

    /**
    * Return the system identifier of the context node
    */

    public static String systemId(XPathContext c) throws XPathException {
        Item item = c.getContextItem();
        if (item==null) {
            throw new XPathException.Dynamic("The context item for saxon:systemId() is not set");
        }
        if (item instanceof NodeInfo) {
            return ((NodeInfo)item).getSystemId();
        } else {
            return "";
        }
    }

    /**
    * Return the line number of the context node.
    */

    public static int lineNumber(XPathContext c) {
        Item item = c.getCurrentIterator().current();
        if (item instanceof NodeInfo) {
            return ((NodeInfo)item).getLineNumber();
        } else {
            return -1;
        }
    }

    /**
     * Remove a document from the document pool. The effect is that the document becomes eligible for
     * garbage collection, allowing memory to be released when processing of the document has finished.
     * The downside is that a subsequent call on document() with the same URI causes the document to be
     * reloaded and reparsed, and the new nodes will have different node identity from the old.
     * @param context the evaluation context (supplied implicitly by the call mechanism)
     * @param doc the document to be released from the document pool
     * @return the document that was released. This allows a call such as
     * select="saxon:discard-document(document('a.xml'))"
     */

    public static DocumentInfo discardDocument(XPathContext context, DocumentInfo doc) {
        return context.getController().getDocumentPool().discard(doc);
    }

    /**
    * Determine whether two node-sets contain the same nodes
    * @param p1 The first node-set. The iterator must be correctly ordered.
    * @param p2 The second node-set. The iterator must be correctly ordered.
    * @return true if p1 and p2 contain the same set of nodes
    */

    public static boolean hasSameNodes(SequenceIterator p1, SequenceIterator p2) throws XPathException {
        SequenceIterator e1 = p1;
        SequenceIterator e2 = p2;

        while (true) {
            NodeInfo n1 = (NodeInfo)e1.next();
            NodeInfo n2 = (NodeInfo)e2.next();
            if (n1==null || n2==null) {
                return n1==n2;
            }
            if (!n1.isSameNode(n2)) {
                return false;
            }
        }
    }


    /**
    * Evaluate the stored expression supplied in the first argument
    */

    //public static Value eval (XPathContext c, Expression expr) throws XPathException {
    //    return expr.lazyEvaluate(c, false);
    //}
    /**
    * Total a stored expression over a set of nodes
    */

    public static double sum (XPathContext context,
                              SequenceIterator nsv,
                              Evaluate.PreparedExpression pexpression) throws XPathException {

        double total = 0.0;
        XPathContext c = context.newContext();
        c.setCurrentIterator(nsv);
        while (true) {
            Item next = nsv.next();
            if (next == null) break;
            Item val = pexpression.expression.evaluateItem(c);
            if (val instanceof NumericValue) {
                DoubleValue v = (DoubleValue)((NumericValue)val).convert(Type.DOUBLE);
                total += v.getValue();
            } else {
                throw new XPathException.Dynamic("expression in saxon:sum() must return numeric values");
            }
        }
        return total;
    }

    /**
    * Get the maximum numeric value of the string-value of each of a set of nodes
    */

    public static double max (SequenceIterator nsv) throws XPathException {
        return net.sf.saxon.exslt.Math.max(nsv);
    }


    /**
    * Get the maximum numeric value of a stored expression over a set of nodes
    */

    public static double max (XPathContext context,
                              SequenceIterator nsv,
                              Evaluate.PreparedExpression pexpression) throws XPathException {
        double max = Double.NEGATIVE_INFINITY;
        XPathContext c = context.newContext();
        c.setCurrentIterator(nsv);
        while (true) {
            Item next = nsv.next();
            if (next==null) break;
            Item val = pexpression.expression.evaluateItem(c);
            if (val instanceof NumericValue) {
                DoubleValue v = (DoubleValue)((NumericValue)val).convert(Type.DOUBLE);
                if (v.getValue()>max) max = v.getValue();
            } else {
                throw new XPathException.Dynamic("expression in saxon:max() must return numeric values");
            }
        }
        return max;
    }

    /**
    * Get the minimum numeric value of the string-value of each of a set of nodes
    */

    public static double min (SequenceIterator nsv) throws XPathException {
        return net.sf.saxon.exslt.Math.min(nsv);
    }

    /**
    * Get the minimum numeric value of a stored expression over a set of nodes
    */

    public static double min (XPathContext context,
                              SequenceIterator nsv,
                              Evaluate.PreparedExpression pexpression) throws XPathException {
        double min = Double.POSITIVE_INFINITY;
        XPathContext c = context.newContext();
        c.setCurrentIterator(nsv);
        while (true) {
            Item next = nsv.next();
            if (next==null) break;
            Item val = pexpression.expression.evaluateItem(c);
            if (val instanceof NumericValue) {
                DoubleValue v = (DoubleValue)((NumericValue)val).convert(Type.DOUBLE);
                if (v.getValue()<min) min = v.getValue();
            } else {
                throw new XPathException.Dynamic("expression in saxon:min() must return numeric values");
            }
        }
        return min;
    }

    /**
    * Get the node with maximum numeric value of the string-value of each of a set of nodes
    */

    public static SequenceValue highest (XPathContext c, SequenceIterator nsv) throws XPathException {
        return net.sf.saxon.exslt.Math.highest(c, nsv);
    }


    /**
    * Get the maximum numeric value of a stored expression over a set of nodes
    */

    public static SequenceIterator highest (XPathContext context,
                                        SequenceIterator nsv,
                                        Evaluate.PreparedExpression pexpression) throws XPathException {
        double max = Double.NEGATIVE_INFINITY;
        XPathContext c = context.newContext();
        Item highest = null;
        c.setCurrentIterator(nsv);
        while (true) {
            Item next = nsv.next();
            if (next==null) break;
            Item val = pexpression.expression.evaluateItem(c);
            if (val instanceof NumericValue) {
                DoubleValue v = (DoubleValue)((NumericValue)val).convert(Type.DOUBLE);
                if (v.getValue()>max) {
                    max = v.getValue();
                    highest = nsv.current();
                }
            } else {
                throw new XPathException.Dynamic("expression in saxon:highest() must return numeric values");
            }
        }
        return SingletonIterator.makeIterator(highest);
    }

    /**
    * Get the node with minimum numeric value of the string-value of each of a set of nodes
    */

    public static SequenceValue lowest (XPathContext c, SequenceIterator nsv) throws XPathException {
        return net.sf.saxon.exslt.Math.lowest(c, nsv);
    }

    /**
    * Get the node with minimum numeric value of a stored expression over a set of nodes
    */

    public static SequenceIterator lowest (XPathContext context,
                                       SequenceIterator nsv,
                                       Evaluate.PreparedExpression pexpression) throws XPathException {
        double min = Double.POSITIVE_INFINITY;
        XPathContext c = context.newContext();
        Item lowest = null;
        c.setCurrentIterator(nsv);
        //int pos = 1;
        while (true) {
            Item next = nsv.next();
            if (next==null) break;
            Item val = pexpression.expression.evaluateItem(c);
            if (val instanceof NumericValue) {
                DoubleValue v = (DoubleValue)((NumericValue)val).convert(Type.DOUBLE);
                if (v.getValue()<min) {
                    min = v.getValue();
                    lowest = nsv.current();
                }
            } else {
                throw new XPathException.Dynamic("expression in saxon:lowest() must return numeric values");
            }
        }
        return SingletonIterator.makeIterator(lowest);
    }

    /**
    * Given a node-set, return a subset that includes only nodes with distinct string-values
    * for the supplied expression
    */

    public static SequenceIterator distinct(XPathContext context,
                                        SequenceIterator in,
                                        Evaluate.PreparedExpression pexp) throws XPathException {
        DistinctExpressionFunction dkf = new DistinctExpressionFunction(pexp.expression);
        XPathContext context2 = context.newContext();
    	context2.setCurrentIterator(in);

        return new MappingIterator(in, dkf, context2, new HashSet());
    }

    private static class DistinctExpressionFunction implements MappingFunction {

        public Expression exp;

        public DistinctExpressionFunction(Expression exp) {
            this.exp = exp;
        }

        public Object map(Item item, XPathContext context, Object lookup) throws XPathException {
            Item val = exp.evaluateItem(context);
            if (val==null) return val;  // treat all () values as distinct
            String key = val.getStringValue();
            if (((HashSet)lookup).contains(key)) {
                return null;
            } else {
                ((HashSet)lookup).add(key);
                return item;
            }
        }
    }

    /**
    * Get the nodes that satisfy the given expression, up to and excluding the first one
    * (in document order) that doesn't
    */

    public static SequenceIterator leading (XPathContext context,
                         SequenceIterator in, Evaluate.PreparedExpression pexp) throws XPathException {
        return new FilterIterator.Leading(in, pexp.expression, context.newContext());
    }

    /**
    * Find all the nodes in ns1 that are after the first node in ns2.
    * Return ns1 if ns2 is empty,
    */

    // This function is no longer documented as a user-visible extension function.
    // But exslt:trailing depends on it.

    public static SequenceIterator after (
                     XPathContext context,
                     SequenceIterator ns1,
                     SequenceIterator ns2) throws XPathException {

        NodeInfo first = null;

        // Find the first node in ns2 (in document order)

        GlobalOrderComparer comparer = GlobalOrderComparer.getInstance();
        while (true) {
            Item item = ns2.next();
            if (item == null) {
                if (first == null) {
                    return ns1;
                } else {
                    break;
                }
            }
            if (item instanceof NodeInfo) {
                NodeInfo node = (NodeInfo)item;
                if (first==null) {
                    first = node;
                } else {
                    if (comparer.compare(node, first) < 0) {
                        first = node;
                    }
                }
            } else {
                throw new XPathException.Dynamic("Operand of after() contains an item that is not a node");
            }
        }

        // Filter ns1 to select nodes that come after this one

        Expression filter = new IdentityComparison(
                                    new ContextItemExpression(),
                                    Tokenizer.FOLLOWS,
                                    new SingletonNode(first));

        return new FilterIterator(ns1, filter, context);

    }


    /**
    * Return a node-set by tokenizing a supplied string. Tokens are delimited by any sequence of
    * whitespace characters.
    */

    public static SequenceIterator tokenize(String s) {
        if (s == null) {
            // empty sequence supplied: treat as empty string
            return EmptyIterator.getInstance();
        }
        return new StringTokenIterator(s);
    }

    /**
    * Return a sequence by tokenizing a supplied string. The argument delim is a String, any character
    * in this string is considered to be a delimiter character, and any sequence of delimiter characters
    * acts as a separator between tokens.
    */

    public static SequenceIterator tokenize(String s, String delim) {
        if (s == null) {
            // empty sequence supplied: treat as empty string
            return EmptyIterator.getInstance();
        }
        return new StringTokenIterator(s, delim);
    }



    /**
    * Return an XPath expression that identifies the current node
    */

    public static String path(XPathContext c) throws XPathException {
        Item item = c.getContextItem();
        if (item==null) {
            throw new XPathException.Dynamic("The context item for saxon:path() is not set");
        }
        if (item instanceof NodeInfo) {
            return Navigator.getPath((NodeInfo)item);
        } else {
            return "";
        }
    }

    /**
     * Display the value of the type annotation of a node
     */

    public static String typeAnnotation(XPathContext context, NodeInfo node) {
        int code = node.getTypeAnnotation();
        if (code==-1) {
            return "untyped";
        }
        SchemaType type = context.getController().getConfiguration().getSchemaType(code & 0xfffff);
        if (type==null) {
            // Anonymous types are not accessible by the namecode
            return context.getController().getNamePool().getDisplayName(code);
        }
        return type.getDescription();
    }

    /**
    * Save a value associated with the context item
    */

//    public static void setUserData(XPathContext c, String name, Value value) throws XPathException {
//            // System.err.println("Set user data " + name + " = " + value); value.display(10);
//        Item item = c.getContextItem();
//        if (item==null) {
//            throw new XPathException.Dynamic("The context item for saxon:setUserData() is not set");
//        }
//        if (item instanceof NodeInfo) {
//            c.getController().setUserData((NodeInfo)item, name, value);
//        }
//    }

    /**
    * Retrieve a value associated with the context item
    */

//    public static Value getUserData(XPathContext c, String name) throws XPathException {
//        Item item = c.getContextItem();
//        if (item==null) {
//            throw new XPathException.Dynamic("The context item for saxon:getUserData() is not set");
//        }
//        if (item instanceof NodeInfo) {
//            Object o = c.getController().getUserData(
//                            (NodeInfo)item, name);
//                // System.err.println("Get user data " + name + " = " + o);
//            if (o==null) {
//                return EmptySequence.getInstance();
//            }
//            if (o instanceof Value) {
//                // System.err.println("Found:");((Value)o).display(10);
//                return (Value)o;
//            }
//            return new ObjectValue(o);
//        } else {
//            return EmptySequence.getInstance();
//        }
//    }

	/**
	* Return the XPathContext object
	*/

	public static XPathContext getContext(XPathContext c) {
		return c;
	}

	/**
	* Get a pseudo-attribute of a processing instruction. Return an empty string
	* if the pseudo-attribute is not present.
	* Character references and built-in entity references are expanded
	*/

	public static String getPseudoAttribute(XPathContext c, String name)
	throws XPathException {
	    Item pi = c.getContextItem();
        if (pi==null) {
            throw new XPathException.Dynamic("The context item for saxon:getPseudoAttribute() is not set");
        }
	    // we'll assume it's a PI, it doesn't matter if it isn't...
	    String val = ProcInstParser.getPseudoAttribute(pi.getStringValue(), name);
	    if (val==null) return "";
	    return val;
	}

    /**
    * Get a dayTimeDuration value corresponding to a given number of seconds
    */

    public static SecondsDurationValue dayTimeDurationFromSeconds(double arg) throws XPathException {
        return SecondsDurationValue.fromSeconds(arg);
    }

    /**
    * Get a yearMonthDuration value corresponding to a given number of months
    */

    public static MonthDurationValue yearMonthDurationFromMonths(double arg) {
        return MonthDurationValue.fromMonths((int)arg);
    }

    /**
     * Perform decimal division to a user-specified precision
     */

    public static BigDecimal decimalDivide(BigDecimal arg1, BigDecimal arg2, int scale) {
        return arg1.divide(arg2, scale, BigDecimal.ROUND_DOWN);
    }

}





//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
