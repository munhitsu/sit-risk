package net.sf.saxon.functions;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.instruct.NumberInstruction;
import net.sf.saxon.number.Numberer;
import net.sf.saxon.om.Item;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.value.DateTimeValue;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.type.Type;
import net.sf.saxon.xpath.XPathException;

import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Implement the format-date() function in XPath 2.0
 */

public class FormatDate extends SystemFunction implements XSLTFunction {

    public void checkArguments(StaticContext env) throws XPathException {
        int numArgs = getNumberOfArguments();
        if (numArgs != 2 && numArgs != 5) {
            throw new XPathException.Static("Function " + getName() + " must have " +
                    "either two or five arguments",
                    ExpressionTool.getLocator(this));
        }
        super.checkArguments(env);
    }

    /**
     * Evaluate in a general context
     */

    public Item evaluateItem(XPathContext context) throws XPathException {
        AtomicValue item = (AtomicValue)argument[0].evaluateItem(context);
        if (item==null) {
            return null;
        }
        DateTimeValue value = (DateTimeValue)item.convert(Type.DATE_TIME);
        String format = argument[1].evaluateItem(context).getStringValue();

        String language;

        if (getNumberOfArguments() > 2) {
            AtomicValue languageVal = (AtomicValue)argument[2].evaluateItem(context);
            //StringValue calendarVal = (StringValue)argument[3].evaluateItem(context);
            //StringValue countryVal = (StringValue)argument[4].evaluateItem(context);
            if (languageVal==null) {
                language = Locale.getDefault().getLanguage();
            } else {
                language = languageVal.getStringValue();
                if (language.length() >= 2) {
                    language = language.substring(0, 2);
                } else {
                    language = Locale.getDefault().getLanguage();
                }
            }
        } else {
            language = Locale.getDefault().getLanguage();
        }

        return new StringValue(formatDate(value, format, language));
    }

    /**
     * This method analyzes the formatting picture and delegates the work of formatting
     * individual parts of the date.
     */

    private static String formatDate(DateTimeValue value, String format, String language)
    throws XPathException {

        Numberer numberer = NumberInstruction.makeNumberer(language);
        StringBuffer sb = new StringBuffer();
        int i = 0;
        while (true) {
            while (i < format.length() && format.charAt(i) != '[') {
                sb.append(format.charAt(i));
                if (format.charAt(i) == ']') {
                    i++;
                    if (i == format.length() || format.charAt(i) != ']') {
                        throw new XPathException.Dynamic("Closing ']' in date picture must be written as ']]'");
                    }
                }
                i++;
            }
            if (i == format.length()) {
                break;
            }
            // look for '[['
            i++;
            if (format.charAt(i) == '[') {
                sb.append('[');
                i++;
            } else {
                int close = format.indexOf("]", i);
                if (close == -1) {
                    throw new XPathException.Dynamic("Date format contains a '[' with no matching ']'");
                }
                String componentFormat = format.substring(i, close);
                sb.append(formatComponent(value, componentFormat.trim(), numberer));
                i = close+1;
            }
        }
        return sb.toString();
    }

    private static Pattern componentPattern =
            Pattern.compile("([YMDdWwFHhmsfZzPCE])\\s*(.*)");

    private static String formatComponent(DateTimeValue value, String specifier, Numberer numberer)
    throws XPathException {
        Calendar cal = value.getCalendar();
        Matcher matcher = componentPattern.matcher(specifier);
        if (!matcher.matches()) {
            System.err.println("Unrecognized date/time component [" + specifier + "] (ignored)");
            return "";
        }
        String component = matcher.group(1);
        String format = matcher.group(2);
        if (format==null || format.equals("")) {
            switch (component.charAt(0)) {
                case 'F':
                    format = "Nn";
                    break;
                case 'P':
                    format = "n";
                    break;
                case 'C':
                case 'E':
                    format = "N";
                    break;
                default:
                    format = "1";
            }
        }

        switch (component.charAt(0)) {
            case 'Y':       // year
                return formatNumber(component, cal.get(Calendar.YEAR), format, numberer);
            case 'M':       // month
                return formatNumber(component, cal.get(Calendar.MONTH)+1, format, numberer);
            case 'D':       // day in month
                return formatNumber(component, cal.get(Calendar.DAY_OF_MONTH), format, numberer);
            case 'd':       // day in year
                return formatNumber(component, cal.get(Calendar.DAY_OF_YEAR), format, numberer);
            case 'W':       // week of year
                return formatNumber(component, cal.get(Calendar.WEEK_OF_YEAR), format, numberer);
            case 'w':       // week in month
                return formatNumber(component, cal.get(Calendar.WEEK_OF_MONTH), format, numberer);
            case 'H':       // hour in day
                return formatNumber(component, cal.get(Calendar.HOUR_OF_DAY), format, numberer);
            case 'h':       // hour in half-day (12 hour clock)
                return formatNumber(component, cal.get(Calendar.HOUR), format, numberer);
            case 'm':       // minutes
                return formatNumber(component, cal.get(Calendar.MINUTE), format, numberer);
            case 's':       // seconds
                return formatNumber(component, cal.get(Calendar.SECOND), format, numberer);
            case 'f':       // fractional seconds
                // ignore the format
                int millis = cal.get(Calendar.MILLISECOND) % 1000;
                return ((1000 + millis)+"").substring(1);
            case 'Z':       // timezone
            case 'z':       // timezone
                StringBuffer sbz = new StringBuffer();
                value.appendTimezone(cal, sbz);
                return sbz.toString();
                // TODO: this isn't the correct format for timezone

            case 'F':       // day of week
                return formatNumber(component, cal.get(Calendar.DAY_OF_WEEK), format, numberer);
            case 'P':       // am/pm marker
                int hour = cal.get(Calendar.HOUR_OF_DAY);
                int minutes = cal.get(Calendar.MINUTE);
                return formatNumber(component, hour*60 + minutes, format, numberer);
            case 'C':       // calendar
                return "Gregorian";
            case 'E':       // era
                return "*AD*";
                //return formatEra(cal.get(Calendar.ERA), format);
            default:
                throw new XPathException.Dynamic("Unknown formatDate/time component specifier '" + format.charAt(0) + "'");
        }
    }

    private static Pattern formatPattern =
            Pattern.compile("([^ot]+?)([ot]?)(,.*)?");

    private static Pattern widthPattern =
            Pattern.compile(",(\\*|[0-9]+)(\\-(\\*|[0-9]+))?");

    private static String formatNumber(String component, int value,
                                       String format, Numberer numberer)
    throws XPathException {
        Matcher matcher = formatPattern.matcher(format);
        if (!matcher.matches()) {
            System.err.println("Unrecognized formatDate/time presentation modifier " + format);
            matcher = formatPattern.matcher("1");
            matcher.matches();
        }
        String primary = matcher.group(1);
        String modifier = matcher.group(2);
        String letterValue = (modifier.equals("t") ? "traditional" : null);
        String ordinal = (modifier.equals("o") ? "yes" : null);
            // TODO: decide gender of the ordinal for non-English languages
        String widths = matcher.group(3);
        int min, max;

        if (widths==null || widths.equals("")) {
            min = 1;
            max = Integer.MAX_VALUE;
        } else {
            int[] range = getWidths(widths);
            min = range[0];
            max = range[1];
        }

        if (primary.equals("N") || primary.equals("n") || primary.equals("Nn")) {
            String s = "";
            if (component.equals("M")) {
                s = numberer.monthName(value, min, max);
            } else if (component.equals("F")) {
                s = numberer.dayName(value, min, max);
            } else if (component.equals("P")) {
                s = numberer.halfDayName(value, min, max);
            } else {
                primary = "1";
            }
            if (primary.equals("N")) {
                return s.toUpperCase();
            } else if (primary.equals("n")) {
                return s.toLowerCase();
            } else {
                return s;
            }
        }

        String s = numberer.format(value, primary, 0, ",", letterValue, ordinal);

        while (s.length() < min) {
            s = ("00000000"+s).substring(s.length()+8-min);
        }
        if (s.length() > max) {
            // the year is the only field we allow to be truncated
            if (format.charAt(0) == 'Y') {
                s = s.substring(s.length() - max);
            }
        }
        return s;
    }

    private static int[] getWidths(String widths) throws XPathException {
        try {
            int min = -1;
            int max = -1;

            if (!widths.equals("")) {
                Matcher widthMatcher = widthPattern.matcher(widths);
                if (!widthMatcher.matches()) {
                    System.err.println("Invalid width specifier '" +
                            widths +
                            "' in formatDate/Time picture (ignored)");
                    min = 1;
                    max = 50;
                } else {
                    String smin = widthMatcher.group(1);
                    if (smin==null || smin.equals("") || smin.equals("*")) {
                        min = 1;
                    } else {
                        min = Integer.parseInt(smin);
                    }
                    String smax = widthMatcher.group(3);
                    if (smax==null || smax.equals("") || smax.equals("*")) {
                        max = Integer.MAX_VALUE;
                    } else {
                        max = Integer.parseInt(smax);
                    }
                }
            }

            if (min>max && max!=-1) {
                throw new XPathException.Dynamic("Minimum width in date picture exceeds maximum width");
            }
            int[] result = new int[2];
            result[0] = min;
            result[1] = max;
            return result;
        } catch (NumberFormatException err) {
            throw new XPathException.Dynamic("Invalid integer as width in date picture");
        }
    }

//    private static String formatMonth(Date date, Calendar cal, String format)
//    throws XPathException {
//        boolean n = format.indexOf('n') >= 0;
//        boolean N = format.indexOf('N') >= 0;
//        int[] widths = getWidths(format);
//        if (n || N) {
//            StringBuffer sb = new StringBuffer();
//            new SimpleDateFormat("MMMMM").format(date, sb, new FieldPosition(DateFormat.MONTH_FIELD));
//            if (sb.length() > widths[1] && widths[1] > 0) {
//                sb.setLength(widths[1]);
//            }
//            if (n) {
//                return sb.toString();
//            } else {
//                return sb.toString().toUpperCase();
//            }
//        } else {
//            return formatNumber(cal.get(Calendar.MONTH) + 1, format, 1);
//        }
//    }

//    private static String formatDayOfWeek(Date date, Calendar cal, String format)
//    throws XPathException {
//        if (format.indexOf('n') >= 0) {
//            StringBuffer sb = new StringBuffer();
//            new SimpleDateFormat("EEEEE").format(date, sb, new FieldPosition(DateFormat.DAY_OF_WEEK_FIELD));
//            return sb.toString();
//        } else {
//            return formatNumber(null, cal.get(Calendar.DAY_OF_WEEK), format);
//        }
//    }

//    private static String formatAmPm(Date date, Calendar cal, String format) {
//        int hour = Calendar.HOUR_OF_DAY;
//        int min = Calendar.MINUTE;
//
//        StringBuffer sb = new StringBuffer();
//        new SimpleDateFormat("a").format(date, sb, new FieldPosition(DateFormat.AM_PM_FIELD));
//        return sb.toString();
//    }

}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//

