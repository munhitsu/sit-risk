package net.sf.saxon.functions;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionTool;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.Tokenizer;
import net.sf.saxon.instruct.NamespaceContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.SingletonIterator;
import net.sf.saxon.style.ExpressionContext;
import net.sf.saxon.value.*;
import net.sf.saxon.xpath.StandaloneContext;
import net.sf.saxon.xpath.Variable;
import net.sf.saxon.xpath.XPathException;
import net.sf.saxon.Controller;


/**
* This class implements the saxon:evaluate(), saxon:expression(), and saxon:eval() extension functions,
* which are specially-recognized by the system because they needs access
* to parts of the static context
*/

public class Evaluate extends SystemFunction implements XSLTFunction {

    StandaloneContext staticContext;
    public final static int EVALUATE = 0;
    public final static int EXPRESSION = 1;
    public final static int EVAL = 2;

    /**
    * Get the required type of the nth argument
    */

    protected SequenceType getRequiredType(int arg) {
        if (arg==0) {
            return super.getRequiredType(arg);
        } else {
            return SequenceType.ANY_SEQUENCE;
        }
    }

    /**
    * Method supplied by each class of function to check arguments during parsing, when all
    * the argument expressions have been read
    */

    public void checkArguments(StaticContext env) throws XPathException {
        super.checkArguments(env);
        if (!(env instanceof ExpressionContext)) {
            throw new XPathException.Static(getName() + " is available only within XSLT");
        }
        if (operation != EVAL) {
            NamespaceContext nsContext = ((ExpressionContext)env).getNamespaceContext();
            NamePool pool = env.getNamePool();
            staticContext = new StandaloneContext(env.getConfiguration());
            staticContext.setBaseURI(env.getBaseURI());
            int[] nscodes = nsContext.getNamespaceCodes();
            for (int i=0; i<nscodes.length; i++) {
                String prefix = pool.getPrefixFromNamespaceCode(nscodes[i]);
                String uri = pool.getURIFromNamespaceCode(nscodes[i]);
                staticContext.declareNamespace(prefix, uri);
            }
        }

        // TODO: provide an option to take the namespace context for the expression from the
        // source document, rather than from the stylesheet. Perhaps as part of an XPointer
        // implementation?
    }

    /**
    * preEvaluate: this method suppresses compile-time evaluation by doing nothing
    * (because the value of the expression depends on the runtime context)
    */

    public Expression preEvaluate(StaticContext env) {
        return this;
    }

    private PreparedExpression prepareExpression(XPathContext c) throws XPathException {
        if (operation == EVAL) {
            Item item = argument[0].evaluateItem(c);
            if (!(item instanceof ObjectValue)) {
                dynamicError(
                    "First argument to saxon:eval must be an expression prepared using saxon:expression");
                return null;
            }
            ObjectValue obj = (ObjectValue)item;
            Object v = obj.getObject();
            if (!(v instanceof PreparedExpression)) {
                dynamicError(
                    "First argument to saxon:eval must be an expression prepared using saxon:expression");
                return null;
            }
            return (PreparedExpression)v;

        } else {

            AtomicValue exprSource = (AtomicValue)argument[0].evaluateItem(c);

            PreparedExpression pexpr = new PreparedExpression();

            pexpr.variables = new Variable[10];
            for (int i=1; i<10; i++) {
                pexpr.variables[i-1] = staticContext.declareVariable("p"+i, EmptySequence.getInstance());
            }
            Expression expr = ExpressionTool.make(exprSource.getStringValue(),
                                                  staticContext,
                                                  0, Tokenizer.EOF);
            expr = expr.analyze(staticContext);
            ExpressionTool.allocateSlots(expr, 1);
            pexpr.expression = expr;

            return pexpr;
        }
    }

    /**
    * Evaluate in a general context
    */

    public Item evaluateItem(XPathContext c) throws XPathException {
        PreparedExpression pexpr = prepareExpression(c);

        if (operation == EXPRESSION) {
            return new ObjectValue(pexpr);
        } else {
            for (int i=1; i<getNumberOfArguments(); i++) {
                pexpr.variables[i-1].setXPathValue(ExpressionTool.eagerEvaluate(argument[i],c));
            }
            Controller controller = c.getController();
            controller.getBindery().openStackFrame();
            XPathContext c2 = controller.newXPathContext();
            c2.setCurrentIterator(c.getCurrentIterator());
            Item result = pexpr.expression.evaluateItem(c2);
            controller.getBindery().closeStackFrame();
            return result;
        }
    }

    /**
    * Iterate over the results of the function
    */

    public SequenceIterator iterate(XPathContext c) throws XPathException {
        PreparedExpression pexpr = prepareExpression(c);

        if (operation == EXPRESSION) {
            return SingletonIterator.makeIterator(new ObjectValue(pexpr));
        } else {
            for (int i=1; i<getNumberOfArguments(); i++) {
                pexpr.variables[i-1].setXPathValue(ExpressionTool.eagerEvaluate(argument[i],c));
            }
            Controller controller = c.getController();
            controller.getBindery().openStackFrame();
            XPathContext c2 = controller.newXPathContext();
            c2.setCurrentIterator(c.getCurrentIterator());
            //SequenceIterator result = pexpr.expression.iterate(c2);
            SequenceIterator result = ExpressionTool.lazyEvaluate(pexpr.expression,  c2).iterate(c2);
            controller.getBindery().closeStackFrame();
            return result;
        }
    }

    /**
    * Determine the dependencies
    */

    public int getIntrinsicDependencies() {
       return StaticProperty.DEPENDS_ON_FOCUS;
    }

    /**
    * Inner class PreparedExpression represents a compiled XPath expression together
    * with the standard variables $p1 .. $p9 available for use when the expression is
    * evaluated
    */

    protected static class PreparedExpression {
        public Expression expression;
        public Variable[] variables;
    }

}




//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
