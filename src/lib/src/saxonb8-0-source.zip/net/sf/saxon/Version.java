package net.sf.saxon;

/**
 * The Version class holds the SAXON version information.
 */

public final class Version
{
    /**
     * Return the name of this product. Supports the XSLT 2.0 system property xsl:product-name
     * @return the string "SAXON"
     */

    public final static String getProductName() {
        return "SAXON";
    }

   /**
     * Get the version number of the schema-aware version of the product
     * @return the version number of this version of Saxon, as a string
     */

    public final static String getSchemaAwareProductVersion() {
        return "SA " + getProductVersion();
    }

    /**
     * Get the version number of this version of the product
     * @return the version number of this version of Saxon, as a string
     */

    public final static String getProductVersion() {
        return "8.0";
    }

    /**
     * Get the issue date of this version of the product
     * @return the release date, as an ISO 8601 string
     */

    public final static String getReleaseDate() {
        return "2004-06-10";
    }

    /**
     * Get the version of the XSLT specification that this product supports
     * @return the string 2.0
     */

    public final static String getXSLVersionString() {
        return "2.0";
    }

    /**
     * Get a message used to identify this product when a transformation is run using the -t option
     * @return A string containing both the product name and the product
     *     version
     */

    public final static String getProductTitle() {
        return getProductName() + " " + getProductVersion() + " from Saxonica";
    }

    /**
     * Return a web site address containing information about the product. Supports the XSLT system property xsl:vendor-url
     * @return the string "http://saxon.sf.net/"
     */

    public final static String getWebSiteAddress() {
        return "http://www.saxonica.com/";
    }
}



//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
