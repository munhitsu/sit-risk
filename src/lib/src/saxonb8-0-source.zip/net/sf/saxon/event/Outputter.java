package net.sf.saxon.event;
import net.sf.saxon.Configuration;
import org.xml.sax.Locator;

import javax.xml.transform.TransformerException;

/**
  * This class allows output to be generated. It channels output requests to an
  * Emitter which does the actual writing. This is an abstract class, there are
  * concrete implementions for XML output and text output.
  *
  * @author Michael H. Kay
  */

public abstract class Outputter implements SequenceReceiver {

    protected boolean previousAtomic = false;

    public abstract void setConfiguration(Configuration config);

    public abstract Configuration getConfiguration();

    public void setSystemId(String systemId) {}

    public String getSystemId() {
        return null;
    }

    public void setDocumentLocator(Locator locator) {}

    public void setUnparsedEntity(String name, String systemId, String publicId) {}


    //public abstract Properties getOutputProperties();

    /**
    * Start the output process
    */

    public void startDocument() throws TransformerException {
        //System.err.println("Open " + this + " using emitter " + emitter.getClass());
        //receiver.startDocument();
        previousAtomic = false;
    }



}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
