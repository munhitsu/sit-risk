package net.sf.saxon.event;
import javax.xml.transform.OutputKeys;

/**
 * Provides string constants that can be used to set
 * output properties for a Transformer, or to retrieve
 * output properties from a Transformer or Templates object.
 *
 * These keys are private Saxon keys that supplement the standard keys
 * defined in javax.xml.transform.OutputKeys. As well as Saxon extension
 * attributes, the list includes new attributes defined in XSLT 2.0 which
 * are not yet supported in JAXP
 */

public class SaxonOutputKeys {

    /**
     * indentSpaces = integer.
     *
     * <p>Defines the number of spaces used for indentation of output</p>
     */

    public static final String INDENT_SPACES = "{http://saxon.sf.net/}indent-spaces";

    /**
     * use-character-map = list-of-qnames.
     *
     * <p>Defines the character maps used in this output definition. The QNames
     * are represented in Clark notation as {uri}local-name.</p>
     */

    public static final String USE_CHARACTER_MAPS = "{http://saxon.sf.net/}use-character-maps";


    /**
     * include-content-type = "yes" | "no". This attribute is defined in XSLT 2.0
     *
     * <p>Indicates whether the META tag is to be added to HTML output</p>
     */

    public static final String INCLUDE_CONTENT_TYPE = "{http://saxon.sf.net/}include-content-type";

   /**
     * include-content-type = "yes" | "no". This attribute is defined in XSLT 2.0
     *
     * <p>Indicates XML 1.1 namespace declarations are to be output</p>
     */

    public static final String UNDECLARE_NAMESPACES = "{http://saxon.sf.net/}undeclare-namespaces";

    /**
     * escape-uri-attributes = "yes" | "no". This attribute is defined in XSLT 2.0
     *
     * <p>Indicates whether HTML attributes of type URI are to be URI-escaped</p>
     */

    public static final String ESCAPE_URI_ATTRIBUTES = "{http://saxon.sf.net/}escape-uri-attibutes";

    /**
     * representation = rep1[;rep2].
     *
     * <p>Indicates the preferred way of representing non-ASCII characters in HTML
     * and XML output. rep1 is for characters in the range 128-256, rep2 for those
     * above 256.</p>
     */
    public static final String CHARACTER_REPRESENTATION = "{http://saxon.sf.net/}character-representation";

    /**
     * saxon:next-in-chain = URI.
     *
     * <p>Indicates that the output is to be piped into another XSLT stylesheet
     * to perform another transformation. The auxiliary property NEXT_IN_CHAIN_BASE_URI
     * records the base URI of the stylesheet element where this attribute was found.</p>
     */
    public static final String NEXT_IN_CHAIN = "{http://saxon.sf.net/}next-in-chain";
    public static final String NEXT_IN_CHAIN_BASE_URI = "{http://saxon.sf.net/}next-in-chain-base-uri";

    /**
    * saxon:type-information = none|preserve|strict|lax.
    *
    * <p>Indicates the value of the type-information attribute: "none", "preserve", "strict", "lax"
    */

    public static final String TYPE_INFORMATION = "{http://saxon.sf.net/}type-information";

    /**
    * saxon:byte-order-mark = yes|no.
    *
    * <p>Indicates whether UTF-8/UTF-16 output is to start with a byte order mark. Values are "yes" or "no",
    * default is "no"
    */

    public static final String BYTE_ORDER_MARK = "{http://saxon.sf.net/}byte-order-mark";

    /**
    * saxon:require-well-formed = yes|no.
    *
    * <p>Indicates whether a user-supplied ContentHandler requires the stream of SAX events to be
    * well-formed (that is, to have a single element node and no text nodes as children of the root).
    * The default is "no".</p>
    */

    public static final String REQUIRE_WELL_FORMED = "{http://saxon.sf.net/}require-well-formed";

    /**
    * Check that a supplied output key is valid
    */

    public static final boolean isValidOutputKey(String key) {
        if (key.startsWith("{")) {
            if (key.startsWith("{http://saxon.sf.net/}")) {
                return
                    key.equals(INDENT_SPACES) ||
                    key.equals(INCLUDE_CONTENT_TYPE) ||
                    key.equals(ESCAPE_URI_ATTRIBUTES) ||
                    key.equals(CHARACTER_REPRESENTATION) ||
                    key.equals(NEXT_IN_CHAIN) ||
                    key.equals(NEXT_IN_CHAIN_BASE_URI) ||
                    key.equals(TYPE_INFORMATION) ||
                    key.equals(UNDECLARE_NAMESPACES) ||
                    key.equals(USE_CHARACTER_MAPS) ||
                    key.equals(REQUIRE_WELL_FORMED) ||
                    key.equals(BYTE_ORDER_MARK);
            } else {
                return true;
            }
        } else {
            return
                key.equals(OutputKeys.CDATA_SECTION_ELEMENTS) ||
                key.equals(OutputKeys.DOCTYPE_PUBLIC) ||
                key.equals(OutputKeys.DOCTYPE_SYSTEM) ||
                key.equals(OutputKeys.ENCODING) ||
                key.equals(OutputKeys.INDENT) ||
                key.equals(OutputKeys.MEDIA_TYPE) ||
                key.equals(OutputKeys.METHOD) ||
                key.equals(OutputKeys.OMIT_XML_DECLARATION) ||
                key.equals(OutputKeys.STANDALONE) ||
                key.equals(OutputKeys.VERSION);
        }
    }

}
