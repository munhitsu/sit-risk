package net.sf.saxon.event;
import net.sf.saxon.instruct.SkipInstructionException;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.Configuration;

import javax.xml.transform.TransformerException;


/**
 * This class allows output to be generated. It channels output requests to an
 * Emitter which does the actual writing. This implementation handles the rules
 * for constructing simple content, which is used when processing the instructions
 * xsl:attribute, xsl:comment, and xsl:processing-instruction.
 *
 * @author Michael H. Kay
 */

public final class SimpleContentOutputter extends Outputter {

    // TODO: this class is hardly used any more, and could be replaced with SequenceOutputter

    private StringBuffer buffer;
    private int ignoreElements = 0;
    private Configuration config;

	public SimpleContentOutputter(StringBuffer buffer) {
	    this.buffer = buffer;
	}

    public void setConfiguration(Configuration config) {
        this.config = config;
    }

    public Configuration getConfiguration() {
        return config;
    }

    /**
    * Produce text content output. <BR>
    * Special characters are escaped using XML/HTML conventions if the output format
    * requires it.
    * @param s The String to be output
    * @exception TransformerException for any failure
    */

    public void characters(CharSequence s, int properties) throws TransformerException {
        if (s==null) return;
        if (ignoreElements==0) {
            buffer.append(s.toString());
        }
        previousAtomic = false;
    }

    /**
    * Output an element start tag. With this outputter, this is a recoverable error.<br>
    * @param nameCode The element name code
    */

    public void startElement(int nameCode, int typeCode, int properties) throws TransformerException {
        recoverableError();
        ignoreElements++;
        previousAtomic = false;
    }

    /**
    * Output a namespace declaration. <br>
    * This is added to a list of pending namespaces for the current start tag.
    * If there is already another declaration of the same prefix, this one is
    * ignored.
    * Note that unlike SAX2 startPrefixMapping(), this call is made AFTER writing the start tag.
    * @param nscode The namespace code
    * @throws TransformerException if there is no start tag to write to (created using writeStartTag),
    * or if character content has been written since the start tag was written.
    */

    public void namespace(int nscode, int properties)
    throws TransformerException {
        // no-op
    }

    /**
     * Output an attribute value. <br>
     * No-op in this implementation.
     * @param nameCode The name of the attribute
     * @param typeCode The type annotation of the attribute
     * @param value The value of the attribute
     * @param properties Bits identifying properties of the attribute
     * @throws TransformerException if recoverable errors are to be treated as fatal.
     * (Writing an attribute to this kind of destination is always an error)
     */

    public void attribute(int nameCode, int typeCode, CharSequence value, int properties)
    throws TransformerException {
        recoverableError();
        previousAtomic = false;
    }

    public void startContent() {}

    /**
    * Output an element end tag.
    */

    public void endElement() throws TransformerException {
        ignoreElements--;
        previousAtomic = false;
    }

    /**
    * Write a comment.
    * No-op in this implementation
    */

    public void comment(CharSequence comment, int properties) throws TransformerException {
        recoverableError();
        previousAtomic = false;
    }

    /**
    * Write a processing instruction
    * No-op in this implementation
    */

    public void processingInstruction(String target, CharSequence data, int properties) throws TransformerException {
        recoverableError();
        previousAtomic = false;
    }

    /**
    * Append an arbitrary item (node or atomic value) to the output
    */

    public void append(Item item) throws TransformerException {
        if (item instanceof AtomicValue) {
            if (previousAtomic) {
                characters(" ", 0);
            }
            characters(item.getStringValue(), 0);
            previousAtomic = true;
        } else if (item instanceof DocumentInfo) {
            SequenceIterator iter = ((DocumentInfo)item).iterateAxis(Axis.CHILD);
            while (true) {
                Item it = iter.next();
                if (it == null) break;
                append(it);
            }
        } else {
            SequenceIterator iter = item.getTypedValue(config);
            while (true) {
                Item it = iter.next();
                if (it == null) break;
                characters(it.getStringValue(), 0);
            }
            previousAtomic = false;
        }
    }

    /**
    * Close the output
    */

    public void endDocument() throws TransformerException {
        previousAtomic = false;
    }

    private void recoverableError() throws TransformerException {
        // TODO: the rules have changed, the nodes should now be atomized
        throw new SkipInstructionException("Non-text output nodes are ignored when writing a text node, attribute, comment, or PI");
    }


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License.
//
// The Original Code is: all this file.
//
// The Initial Developer of the Original Code is Michael H. Kay.
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved.
//
// Contributor(s): none.
//
