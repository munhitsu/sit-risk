package net.sf.saxon.event;

import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.type.Type;
import org.xml.sax.Locator;

import javax.xml.transform.TransformerException;

/**
 * Sends an entire document to a Receiver.
 *
 * @author Ruud Diterwich, integrated by Michael Kay
 */

public class DocumentSender implements Locator {

	private NodeInfo top;

    /**
    * Create a DocumentSender, which takes an input document tree and generates
    * a stream of events for a Receiver
    * @param top the document or element node to be turned into a stream of events
    */

	public DocumentSender(NodeInfo top) {
		this.top = top;
        int kind = top.getNodeKind();
        if (kind != Type.DOCUMENT && kind != Type.ELEMENT) {
            throw new IllegalArgumentException("DocumentSender can only handle document or element nodes");
        }
	}

    /**
    * Send the entire document to the receiver
    */

	public void send(Receiver receiver) throws TransformerException {

        if (top.getNamePool() != receiver.getConfiguration().getNamePool()) {
            throw new IllegalArgumentException("DocumentSender source and target must use the same NamePool");
        }

		// set system id
		receiver.setSystemId(top.getSystemId());
		receiver.setDocumentLocator(this);

		// start document event
		receiver.startDocument();

		// copy the contents of the document
		top.copy(receiver, NodeInfo.ALL_NAMESPACES, true);

		// end document event
		receiver.endDocument();
	}

    // Implement the SAX Locator interface. This is needed to pass the base URI of nodes
    // to the receiver. We don't attempt to preserve the original base URI of each individual
    // node as it is copied, only the base URI of the document as a whole.

    // TODO: this is OK for some applications, but not ideal for others. To pass through the base
    // URI of individual nodes would make it difficult to re-use the same code as xsl:copy-of, which
    // does not do this.

	public int getColumnNumber() {
		return -1;
	}

	public int getLineNumber() {
		return -1;
	}

	public String getPublicId() {
		return null;
	}

	public String getSystemId() {
		return top.getSystemId();
	}
}
