package net.sf.saxon.event;

import javax.xml.transform.TransformerException;

/**
* Exception indicating that an attribute or namespace node has been written when
* there is no open element to write it to
*/

public class NoOpenStartTagException extends TransformerException {
    
    public NoOpenStartTagException(String msg) {
        super(msg);
    }

}