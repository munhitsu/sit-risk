package net.sf.saxon.event;

import net.sf.saxon.value.Cardinality;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.UntypedAtomicValue;
import net.sf.saxon.value.StringValue;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.expr.StaticProperty;
import net.sf.saxon.type.ItemType;
import net.sf.saxon.type.AtomicType;
import net.sf.saxon.type.AnyItemType;
import net.sf.saxon.pattern.AnyNodeTest;
import net.sf.saxon.pattern.NodeTest;

import javax.xml.transform.TransformerException;

/**
 * This is a receiver that can be inserted into a pipeline to do type checking of the
 * nodes and/or atomic values produced by a content constructor, as they are written.
 * It is used, for example, when xsl:sequence has an "as" attribute to indicate the required
 * type, or to enforce the "as" attribute on xsl:template.
 *
 * <p>This filter also atomizes any nodes in the sequence if the required item type
 * is atomic.</p>
 */
public class SequenceChecker extends ProxyReceiver implements SequenceReceiver {

    private ItemType itemType;
    private int cardinality;
    private int count = 0;
    private int level = 0;
    private boolean atomize;
    private boolean allowAnyNode;

    private StringBuffer buffer = null;

    public void setRequiredType(SequenceType type) {
        itemType = type.getPrimaryType();
        cardinality = type.getCardinality();
        atomize = itemType instanceof AtomicType;
        allowAnyNode = itemType instanceof AnyItemType || itemType instanceof AnyNodeTest;
    }

    public void startElement(int nameCode, int typeCode, int properties) throws TransformerException {
        if (level++ == 0) {
            if (atomize) {
                buffer = new StringBuffer();
                return;
            } else {
                if (count++==1 && !Cardinality.allowsMany(cardinality)) {
                    throw new TransformerException("The output sequence contains more than one item, only one is allowed");
                }
                if (allowAnyNode) {
                    // OK, let it pass
                } else if (((NodeTest)itemType).matches(Type.ELEMENT, typeCode & 0xfffff, typeCode)) {
                    // OK, let it pass
                } else {
                    throw new TransformerException("This element node does not conform to the required type");
                }
            }
        }
        super.startElement(nameCode, typeCode, properties);
    }

    public void namespace(int namespaceCode, int properties) throws TransformerException {
        if (level==0) {
            if (atomize) {
                return;
                // discard the namespace node when atomizing
            } else {
                if ( count++==1 && !Cardinality.allowsMany(cardinality)) {
                    throw new TransformerException("The output sequence contains more than one item, only one is allowed");
                }
                if (!(allowAnyNode || ((NodeTest)itemType).matches(Type.NAMESPACE, -1, -1))) {
                    throw new TransformerException("The output sequence is not allowed to contain namespace nodes");
                }
            }
        } else if (buffer!=null) {
            return;
            // discard the namespace node
        }
        super.namespace(namespaceCode, properties);
    }

    public void attribute(int nameCode, int typeCode, CharSequence value, int properties)
            throws TransformerException {
        if (level==0) {
            if (atomize) {
                //if (typeCode == -1) {
                //    append(new UntypedAtomicValue(value));
                //} else {
                    append(new StringValue(value).convert((AtomicType)itemType));
                //}
                return;
            } else {
                if (count++==1 && !Cardinality.allowsMany(cardinality)) {
                    throw new TransformerException("The output sequence contains more than one item, only one is allowed");
                }
                if (allowAnyNode) {
                    // OK, let it past
                } else if (((NodeTest)itemType).matches(Type.ATTRIBUTE, nameCode & 0xfffff, typeCode)) {
                    // OK, let it past
                } else {
                    throw new TransformerException("This attribute node does not conform to the required type");
                }
            }
        } else if (buffer!=null) {
            // discard the attribute
            return;
        }
        super.attribute(nameCode, typeCode, value, properties);
    }

    public void endElement() throws TransformerException {
        level--;
        if (buffer != null) {
            if (level==0) {
                append(new UntypedAtomicValue(buffer));
                buffer = null;
                return;
            } else {
                return;
            }
        }
        super.endElement();
    }

    public void characters(CharSequence chars, int properties) throws TransformerException {
        if (level==0) {
            if (atomize) {
                append(new UntypedAtomicValue(chars));
                return;
            } else {
                if (count++==1 && !Cardinality.allowsMany(cardinality)) {
                    throw new TransformerException("The output sequence contains more than one item, only one is allowed");
                }
                if (allowAnyNode) {
                    // let it past
                } else if (((NodeTest)itemType).allowsTextNodes()) {
                    // let it past
                } else {
                    throw new TransformerException("The output sequence is not allowed to contain text nodes");
                }
            }
        } else if (buffer != null) {
            buffer.append(chars);
            return;
        }
        super.characters(chars, properties);
    }

    public void processingInstruction(String target, CharSequence data, int properties) throws TransformerException {
        if (level==0) {
            if (atomize) {
                append(new UntypedAtomicValue(data));
                return;
            } else {
                if (count++==1 && !Cardinality.allowsMany(cardinality)) {
                    throw new TransformerException("The output sequence contains more than one item, only one is allowed");
                }
                if (allowAnyNode) {
                    // OK, let it past
                } else if (((NodeTest)itemType).matches(Type.PROCESSING_INSTRUCTION, -1, -1)) {
                    // TODO: check the PI name?
                    // OK, let it past
                } else {
                    throw new TransformerException("The result sequence does not allow processing instructions");
                }
            }
        } else if (buffer!=null) {
            // discard the PI
            return;
        }
        super.processingInstruction(target, data, properties);
    }

    public void comment(CharSequence chars, int properties) throws TransformerException {
        if (level == 0) {
            if (atomize) {
                append(new UntypedAtomicValue(chars));
                return;
            } else {
                if (count++==1 && !Cardinality.allowsMany(cardinality)) {
                    throw new TransformerException("The output sequence contains more than one item, only one is allowed");
                }
                if (allowAnyNode) {
                    // OK, let it past
                } else if (((NodeTest)itemType).matches(Type.COMMENT, -1, -1)) {
                    // OK, let it past
                } else {
                    throw new TransformerException("The result sequence does not allow comment nodes");
                }
            }
        } else if (buffer!=null) {
            // discard the comment
            return;
        }
        super.comment(chars, properties);
    }

    public void append(Item item) throws TransformerException {
        if (level == 0) {
            if (atomize && item instanceof NodeInfo) {
                SequenceIterator iter = item.getTypedValue(config);
                while (true) {
                    Item it = iter.next();
                    if (it == null) break;
                    append(it);
                }
                return;
            }
            if (count==1 && !Cardinality.allowsMany(cardinality)) {
                throw new TransformerException("The output sequence contains more than one item, only one is allowed");
            }
            if (itemType.matchesItem(item)) {
                // all is well
            } else {
                if (item instanceof UntypedAtomicValue) {
                    item = ((UntypedAtomicValue)item).convert((AtomicType)itemType);
                    // TODO: attempt numeric promotion also?
                } else {
                    throw new TransformerException("The output sequence is not allowed to contain items of type " +
                        Type.displayTypeName(item));
                }
            }
        }
        ((SequenceReceiver)baseReceiver).append(item);
        count++;
    }

    public void finalCheck() throws TransformerException {
        if (count==0 && (cardinality & StaticProperty.ALLOWS_ZERO)==0) {
            throw new TransformerException("The output sequence is not allowed to be empty");
        }
        //super.endDocument();
    }
}
