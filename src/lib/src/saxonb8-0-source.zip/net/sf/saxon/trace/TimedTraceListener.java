package net.sf.saxon.trace;
import net.sf.saxon.om.Item;

/**
* A Simple trace listener that writes messages to System.err
*/

public class TimedTraceListener implements TraceListener {

    private int indent = 0;

    /**
    * Called at start
    */

    public void open() {
        System.err.println("<trace time=\"" + System.currentTimeMillis() + "\">");
    }

    /**
    * Called at end
    */

    public void close() {
        System.err.println("<end time=\"" + System.currentTimeMillis()
    	       + "\"/></trace>");
    }

    /**
    * Called when an instruction in the stylesheet gets processed
    */

    public void enter(InstructionInfo instruction) {
        String file = instruction.getSystemId();
        if (file==null) file="";
        if (file.length()>15) file="*" + file.substring(file.length()-14);
        String name = instruction.getInstructionName();
        System.err.println(spaces(indent) + "<Instruction element=\"" + name +
                        "\" line=\"" + instruction.getLineNumber() +
                        "\" file=\"" + file +
			            "\" time=\"" + System.currentTimeMillis() +
                        (name.equals("xsl:apply-templates") ? ("\" mode=\"" + instruction.getProperty("mode")) : "") +
                        "\">");
        indent++;
    }

    /**
    * Called after an instruction of the stylesheet got processed
    */

  	public void leave(InstructionInfo instruction) {
    	indent--;
	    System.err.println(spaces(indent) +
			   "<end time=\"" + System.currentTimeMillis()
			   + "\"/></Instruction>");
  	}

    /**
    * Called when an item becomes current
    */

    public void startCurrentItem(Item item) {}

    /**
    * Called after a node of the source tree got processed
    */

    public void endCurrentItem(Item item) {}

    /**
    * Get n spaces
    */

    private static String spaces(int n) {
        if (spaceBuffer.length() < n) {
            spaceBuffer.append(spaceBuffer);
        }
        return spaceBuffer.substring(0, n);
    }

    private static StringBuffer spaceBuffer = new StringBuffer("                ");

}
