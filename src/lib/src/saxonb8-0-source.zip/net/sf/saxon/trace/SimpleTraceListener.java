package net.sf.saxon.trace;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.Navigator;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.NamespaceConstant;

/**
* A Simple trace listener that writes messages to System.err
*/

public class SimpleTraceListener implements TraceListener {

  private int indent = 0;

  /**
  * Called at start
  */

  public void open() {
    System.err.println("<trace>");
  }

  /**
  * Called at end
  */

  public void close() {
    System.err.println("</trace>");
  }

/**
* Called when an instruction in the stylesheet gets processed
*/

public void enter(InstructionInfo instruction) {
    String file = instruction.getSystemId();
    if (file==null) file="";
    while (true) {
        int i = file.indexOf('/');
        if (i >= 0 && i < file.length()-6) {
             file = file.substring(i+1);
        } else {
            break;
        }
    }
//    if (file.length()>15) {
//        file="*" + file.substring(file.length()-14);
//    }
    String name = instruction.getInstructionName();
    String instNamespace = (String)instruction.getProperty("instruction-namespace");
    String mode = (String)instruction.getProperty("mode");
    String value = (String)instruction.getProperty("value");
    String displayName = (String)instruction.getProperty("name");



    System.err.println(spaces(indent) + "<Instruction element=\"" + name +
                (displayName!=null ? ("\" name=\"" + displayName) : "") +
                (value!=null ? ("\" value=\"" + value) : "") +
                (instNamespace!=null && !instNamespace.equals(NamespaceConstant.XSLT)
                    ? "\" inst-namespace=\"" + instNamespace : "") +
                "\" line=\"" + instruction.getLineNumber() +
                "\" file=\"" + file +
                (mode!=null ? ("\" mode=\"" + mode) : "") +
                "\">");
    indent++;
}

  /**
   * Called after an instruction of the stylesheet got processed
   */
  	public void leave(InstructionInfo instruction) {
    	indent--;
    	System.err.println(spaces(indent) + "</Instruction> <!-- " +
    						 instruction.getInstructionName() + " -->");
  	}

  /**
   * Called when an item becomes current
   */

    public void startCurrentItem(Item item) {
        if (item instanceof NodeInfo) {
            NodeInfo curr = (NodeInfo)item;
            System.err.println(spaces(indent) + "<Source node=\""  + Navigator.getPath(curr)
                            + "\" line=\"" + curr.getLineNumber() + "\">");
        }
        indent++;
    }

    /**
    * Called after a node of the source tree got processed
    */

    public void endCurrentItem(Item item)
    {
        indent--;
        if (item instanceof NodeInfo) {
            NodeInfo curr = (NodeInfo)item;
            System.err.println(spaces(indent) + "</Source><!-- "  +
                            Navigator.getPath(curr) + " -->");
        }
    }

    /**
    * Get n spaces
    */

    private static String spaces(int n) {
        if (spaceBuffer.length() < n) {
            spaceBuffer.append(spaceBuffer);
        }
        return spaceBuffer.substring(0, n);
    }

    private static StringBuffer spaceBuffer = new StringBuffer("                ");
}
