/*
 * Created on Jul 24, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package net.sourceforge.cilib.Functions;

/**
 * @author espeer
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class BinaryAdapter {

	/* (non-Javadoc)
	 * @see net.sourceforge.cilib.Functions.Function#evaluate(double[])
	 */
	public double evaluate(double[] x) {
		// TODO Auto-generated method stub
		return 0;
	}

}
