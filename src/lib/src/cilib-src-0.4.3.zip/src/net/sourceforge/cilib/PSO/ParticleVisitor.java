/*
 * Created on Apr 11, 2004
 */
package net.sourceforge.cilib.PSO;

/**
 * @author espeer
 */
public interface ParticleVisitor {
    public void visit(Particle particle);
}
