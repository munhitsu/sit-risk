package org.joonegap.samples.noughtsandcrosses;

import org.joonegap.samples.noughtsandcrosses.NoughtOrCross;

public class NoughtsAndCrossesGame
{
    //
    //
    // Private members
    //
    //

    private String[]            m_strHistory = new String[3];

    /**
     * The noughts and crosses board. The first dimension is
     * the row, the second the column, like so:<P>
     *
     * <CODE>
     * [0,0]|[1,0]|[2,0]<BR>
     * -----------------<BR>
     * [1,0]|[1,1]|[2,1]<BR>
     * -----------------<BR>
     * [2,0]|[2,1]|[2,2]<BR>
     * </CODE>
     */

    private NoughtOrCross[][]   m_board = new NoughtOrCross[3][3];

    private NoughtOrCross       m_turn = null;

    //
    //
    // Constructor
    //
    //

    public NoughtsAndCrossesGame()
    {
        clear();
    }

    //
    //
    // Public methods
    //
    //

    public void clear()
    {
        // Clear the history

        for( int iLoop = 0; iLoop < m_strHistory.length; iLoop++ )
        {
            m_strHistory[iLoop] = null;
        }

        // Clear the board

        m_board[0][0] = null;
        m_board[0][1] = null;
        m_board[0][2] = null;
        m_board[1][0] = null;
        m_board[1][1] = null;
        m_board[1][2] = null;
        m_board[2][0] = null;
        m_board[2][1] = null;
        m_board[2][2] = null;

        // Nobody's turn

        m_turn = null;
    }

    /**
     * Play the given type (nought or cross) at the given column and row.
     *
     * @return true if the cross was play, false if the square was not empty
     */

    public boolean play( NoughtOrCross p_type, int p_iColumn, int p_iRow )
    {
        // Sanity check

        if ( m_board[p_iRow][p_iColumn] != null )
            return false;

        if ( p_type == null )
            return false;

        if ( m_turn != null && !m_turn.equals( p_type ))
            return false;

        try
        {
            getWinner();
            return false;
        }
        catch( Exception e )
        {
        }

        // Add the current state to the history

        for( int iRow = 0; iRow < m_strHistory.length; iRow++ )
        {
            m_strHistory[iRow] = getHistoryAndCurrentState( iRow );
        }

        // Play the go

        m_board[p_iRow][p_iColumn] = p_type;

        // Swap turns

        if ( m_turn == null )
            m_turn = p_type;

        if ( m_turn.equals( NoughtOrCross.CROSS ))
            m_turn = NoughtOrCross.NOUGHT;
        else
            m_turn = NoughtOrCross.CROSS;

        return true;
    }

    public String toString()
    {
        StringBuffer strToReturn = new StringBuffer();

        for( int iRow = 0; iRow < m_strHistory.length; iRow++ )
        {
            strToReturn.append( getHistoryAndCurrentState( iRow ) );
            strToReturn.append( '\n' );
        }

        return strToReturn.toString();
    }

    /**
     * See if 'noughts' or 'crosses' have won the match
     *
     * @return noughts or crosses, or null if a draw
     */

    public NoughtOrCross getWinner()
        throws Exception
    {
        boolean bGameNotFinishedYet = false;

        // See if either noughts or crosses have won

        NoughtOrCross[] lookFor = new NoughtOrCross[]{ NoughtOrCross.NOUGHT, NoughtOrCross.CROSS };

        for( int iLookFor = 0; iLookFor < lookFor.length; iLookFor++ )
        {
            // Check horizontal rows

            for( int iRow = 0; iRow < m_board.length; iRow++ )
            {
                // Check each square

                for ( int iColumn = 0; iColumn < m_board[0].length; iColumn++ )
                {
                    // If it's blank, there are more moves to play

                    if ( m_board[iRow][iColumn] == null )
                    {
                        bGameNotFinishedYet = true;
                        break;
                    }

                    // If it's not what we're looking for, we can't have won
                    // (so check next row)

                    if ( !m_board[iRow][iColumn].equals( lookFor[iLookFor] ))
                        break;

                    // If this is the last column, the whole row must be ours!

                    if ( iColumn == ( m_board[0].length - 1 ))
                        return lookFor[iLookFor];
                }
            }

            // Check vertical columns

            for( int iColumn = 0; iColumn < m_board[0].length; iColumn++ )
            {
                // Check each square

                for ( int iRow = 0; iRow < m_board.length; iRow++ )
                {
                    // If it's blank, there are more moves to play

                    if ( m_board[iRow][iColumn] == null )
                    {
                        bGameNotFinishedYet = true;
                        break;
                    }

                    // If it's not what we're looking for, we can't have won
                    // (so check next column)

                    if ( !m_board[iRow][iColumn].equals( lookFor[iLookFor] ))
                        break;

                    // If this is the last row, the whole column must be ours!

                    if ( iRow == ( m_board.length - 1 ))
                        return lookFor[iLookFor];
                }
            }

            // Check left-to-right diagonal

            for( int iRowAndColumn = 0; iRowAndColumn < m_board.length; iRowAndColumn++ )
            {
                // If it's blank, there are more moves to play

                if ( m_board[iRowAndColumn][iRowAndColumn] == null )
                {
                    bGameNotFinishedYet = true;
                    break;
                }

                // If it's not what we're looking for, we can't have won

                if ( !m_board[iRowAndColumn][iRowAndColumn].equals( lookFor[iLookFor] ))
                    break;

                // If this is the last row, the whole diagonal must be ours!

                if ( iRowAndColumn == ( m_board.length - 1 ))
                    return lookFor[iLookFor];
            }

            // Check right-to-left diagonal

            for( int iRowAndColumn = 0; iRowAndColumn < m_board.length; iRowAndColumn++ )
            {
                // If it's blank, there are more moves to play

                if ( m_board[iRowAndColumn][( m_board[0].length - 1 ) - iRowAndColumn] == null )
                {
                    bGameNotFinishedYet = true;
                    break;
                }

                // If it's not what we're looking for, we can't have won

                if ( !m_board[iRowAndColumn][( m_board[0].length - 1 ) - iRowAndColumn].equals( lookFor[iLookFor] ))
                    break;

                // If this is the last row, the whole diagonal must be ours!

                if ( iRowAndColumn == ( m_board.length - 1 ))
                    return lookFor[iLookFor];
            }
        }

        // Game not finished yet?

        if ( bGameNotFinishedYet )
            throw new Exception( "Game not finished yet!" );

        // Must be a draw!

        return null;
    }

    public double[] getBoardAsArray()
    {
        double[] dOutput = new double[ m_board.length * m_board[0].length ];
        double dAtSquare;

        for( int iRow = 0; iRow < m_board.length; iRow++ )
        {
            for ( int iColumn = 0; iColumn < m_board[0].length; iColumn++ )
            {
                if ( m_board[iRow][iColumn] == null )
                {
                    dAtSquare = 0;
                }
                else if ( m_board[iRow][iColumn].isNought() )
                {
                    dAtSquare = 1;
                }
                else
                {
                    dAtSquare = -1;
                }

                dOutput[ iColumn + ( iRow * m_board[0].length )] = dAtSquare;
            }
        }

        return dOutput;
    }

    //
    //
    // Private methods
    //
    //

    private String getHistoryAndCurrentState( int p_iRow )
    {
        StringBuffer strToReturn = new StringBuffer();

		// Return nothing if board is empty (saves log output)

		if ( m_turn != null )
		{
			// History

			if ( m_strHistory[p_iRow] != null )
			{
				strToReturn.append( m_strHistory[p_iRow] );
				strToReturn.append( ' ' );
			}

			// Current state

			strToReturn.append( ( m_board[p_iRow][0] == null ) ? " " : m_board[p_iRow][0].toString() );
			strToReturn.append( "|" );
			strToReturn.append( ( m_board[p_iRow][1] == null ) ? " " : m_board[p_iRow][1].toString() );
			strToReturn.append( "|" );
			strToReturn.append( ( m_board[p_iRow][2] == null ) ? " " : m_board[p_iRow][2].toString() );

			// Win, lose or draw?

			if ( p_iRow == 1 )
			{
				try
				{
					NoughtOrCross winner = getWinner();

					strToReturn.append( ' ' );

					if ( winner == null )
					{
						strToReturn.append( "DRAW!" );
					}
					else if ( winner.equals( NoughtOrCross.NOUGHT ))
					{
						strToReturn.append( "NOUGHTS WIN!" );
					}
					else
					{
						strToReturn.append( "CROSSES WIN!" );
					}
				}
				catch( Exception e )
				{
				}
			}
		}

        return strToReturn.toString();
    }
}
