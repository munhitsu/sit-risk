package org.joonegap.samples.noughtsandcrosses;

import org.apache.log4j.*;
import org.joonegap.samples.noughtsandcrosses.NoughtOrCross;
import org.joonegap.samples.noughtsandcrosses.NoughtsAndCrossesGame;
import org.joonegap.samples.noughtsandcrosses.NoughtsAndCrossesNeuralNetManager;
import org.joonegap.MeaningStrengthPair;

import java.util.Iterator;
import java.io.File;

public class NoughtsAndCrossesTest
{
	//
	//
	// Private statics
	//
	//

	private final static String		LOG_FILE = "c:\\NoughtsAndCrosses.log";

    //
    //
    // Public statics
    //
    //

    public static void main( String[] p_strArgs )
    {
        try
        {
            // Logging

			new File( LOG_FILE ).delete();

			System.setProperty( "log4j.defaultInitOverride", "true" );

            Logger logger = Logger.getLogger( "NoughtsAndCrosses" );
            Layout layout = new PatternLayout( "%d - %m%n" );
            logger.addAppender( new FileAppender( layout, LOG_FILE ));
            logger.setLevel( Level.INFO );

            // Neural network manager

            NoughtsAndCrossesNeuralNetManager manager = new NoughtsAndCrossesNeuralNetManager();
            manager.setLogger( logger );

			// 800 generations

            while( manager.getGenerations() != -1 )
            {
                // Set up the game

                double[] dBoard;
                Object[] objSquare;
				boolean bGameOver = false;

				// By convention, cross goes first

                NoughtOrCross[] players = new NoughtOrCross[]{ NoughtOrCross.CROSS, NoughtOrCross.NOUGHT };

                NoughtsAndCrossesGame game = new NoughtsAndCrossesGame();
                NoughtOrCross winner = null;

				// Hold the neural nets

				manager.hold( players[0] );
				manager.hold( players[1] );

				// Keep playing until the game is over

                while( !bGameOver )
                {
					// For each player...

                    for( int iPlayer = 0; iPlayer < players.length; iPlayer++ )
                    {
                        // ...play whatever is recommended by the network

						dBoard = game.getBoardAsArray();
						Iterator i = manager.cycle( players[iPlayer], dBoard ).iterator();

                        for( ; i.hasNext(); )
                        {
                            objSquare = (Object[]) ((MeaningStrengthPair) i.next()).getMeaning();

                            if ( game.play( players[iPlayer], ((Integer) objSquare[0] ).intValue(), ((Integer) objSquare[1] ).intValue() ))
                                break;
                        }

						// See if, because of that move, the game is over

						try
						{
							winner = game.getWinner();
							bGameOver = true;
							break;
						}
						catch( Exception e )
						{
						}
					}
                }

                // Log

                logger.info( manager.getName( players[0] ) +
							 " (" + players[0] + ") versus " +
							 manager.getName( players[1] ) +
							 " (" + players[1] + "):\n" +
							 game.toString() );

                // Release the neural nets

                if ( winner == null )
                {
                    manager.gameOver( players[0], null );
                    manager.gameOver( players[1], null );
                }
                else
                {
                    manager.gameOver( players[0], new Boolean( winner.equals( players[0] )));
					manager.gameOver( players[1], new Boolean( winner.equals( players[1] )));
                }

				manager.release( players[0] );
				manager.release( players[1] );
            }
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }
}
