package org.joonegap.samples.noughtsandcrosses;

import org.joone.engine.FullSynapse;
import org.joone.engine.SigmoidLayer;
import org.joone.net.NeuralNet;
import org.joonegap.NeuralNetManager;

import java.io.File;

/**
 * A neural network manager for playing noughts and crosses.<P>
 *
 * Based on the description by David B. Fogel in his book
 * Blondie24 (Morgan Kaufmann Publishers).<P>
 */

public class NoughtsAndCrossesNeuralNetManager
        extends NeuralNetManager
{
    //
    //
    // Private statics
    //
    //

    private final static int    TOTAL_NEURONS_FOR_INPUT = 9;

    private final static int    TOTAL_NEURONS_FOR_HIDDEN = 10;

    private final static int    TOTAL_NEURONS_FOR_OUTPUT = 9;

    //
    //
    // Constructor
    //
    //

    public NoughtsAndCrossesNeuralNetManager()
    {
		super( new File( "C:\\NoughtsAndCrossesGenes" ), true, 10, 50,
			   0, 0, 0, null, null );
    }

    //
    //
    // Protected methods
    //
    //

    protected NeuralNet createUninitializedNeuralNetwork()
    {
        // Layers

        SigmoidLayer layerInput = new SigmoidLayer( "Input" );
        SigmoidLayer layerHidden = new SigmoidLayer( "Hidden" );
        SigmoidLayer layerOutput = new SigmoidLayer( "Output" );
        layerInput.setRows( TOTAL_NEURONS_FOR_INPUT );
        layerHidden.setRows( TOTAL_NEURONS_FOR_HIDDEN );
        layerOutput.setRows( TOTAL_NEURONS_FOR_OUTPUT );

        // Synapses

        FullSynapse synapseInputToHidden = new FullSynapse();
        FullSynapse synapseHiddenToOutput = new FullSynapse();
        layerInput.addOutputSynapse( synapseInputToHidden );
        layerHidden.addInputSynapse( synapseInputToHidden );
        layerHidden.addOutputSynapse( synapseHiddenToOutput );
        layerOutput.addInputSynapse( synapseHiddenToOutput );

        // Over-arching NeuralNet object

        NeuralNet neuralNet = new NeuralNet();
        neuralNet.addLayer( layerInput, NeuralNet.INPUT_LAYER );
        neuralNet.addLayer( layerHidden, NeuralNet.HIDDEN_LAYER );
        neuralNet.addLayer( layerOutput, NeuralNet.OUTPUT_LAYER );

        // Return it

        return neuralNet;
    }

    /**
     * Output nodes are numbered such that:<P>
     *
     * 0..2 = first row<BR>
     * 3..5 = second row<BR>
     * 6..8 = third row<BR>
     */

    protected Object getMeaningOfOutputNodeAt( int p_iIndex )
    {
        int iColumn = p_iIndex % 3;
        int iRow = (int) Math.floor( p_iIndex / 3 );

        return new Object[]{ new Integer( iColumn ), new Integer( iRow ) };
    }
}
