package org.joonegap;

import org.apache.log4j.Logger;
import org.jgap.*;
import org.jgap.event.EventManager;
import org.jgap.impl.ChromosomePool;
import org.jgap.impl.ReproductionOperator;
import org.jgap.impl.StockRandomGenerator;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * ChromosomeManager manages the...
 *
 * <UL>
 * <LI>loading and saving (to disk)
 * <LI>pairing up for competition
 * <LI>evolving (when enough have competed)
 * </UL>
 *
 * ...of all Chromosomes in the Genotype. In this way, it
 * is a one-stop shop for clients wishing to get hold of
 * new Chromosomes and play them in matches, without
 * worrying about their being saved, or keeping score, or
 * when they need evolving.<P>
 *
 * <I>(note that all public methods are synchronized)</I>
 */

public class ChromosomeManager
{
	//
	//
	// Private statics
	//
	//

	private static String	GENES_PREFIX = "__";

	private static String	GENES_SUFFIX = ".genes";

	//
	//
	// Private members
	//
	//

	private HashMap			m_mapGeneScores = null;

	private File	    	m_fileGenes = null;

	private Logger		    m_logger = null;

    private Configuration   m_configuration = null;

    private int             m_iGeneration = 0;

	private int				m_iMinimumPopulationSize = 0;

	private int				m_iGamesPerGeneration = 0;

	private boolean			m_bRandomizeSampleGenes = false;

	//
	//
	// Constructor
	//
	//

	/**
	 * @param p_fileGenes	the folder in which to store the genes
	 * @param p_bAllowLoadingPreviouslySavedGenes	whether to load any genes found in p_fileGenes
	 * @param p_iMinimumPopulationSize		the desired population size (the population size may
	 * 								fluctuate above this at times)
	 * @param p_iGamesPerGeneration	the minimum number of games a chromosome must play
	 * 								(they may occasionally play more)
	 * @param p_configuration	the pre-initialized JGAP Configuration object, or null to have ChromosomeManager initialize a default configuration
	 * @param p_logger
	 */

	public ChromosomeManager( File p_fileGenes, boolean p_bAllowLoadingPreviouslySavedGenes, int p_iMinimumPopulationSize, int p_iGamesPerGeneration, Gene[] p_arraySampleGenes, boolean p_bRandomizeSampleGenes, Configuration p_configuration, Logger p_logger )
	{
		if ( m_logger == null )
		{
			m_logger = p_logger;
            m_fileGenes = p_fileGenes;
			m_logger.info( "Started ChromosomeManager, storing genes at '" + m_fileGenes.getAbsolutePath() + "'" );

			m_iMinimumPopulationSize = p_iMinimumPopulationSize;
			m_logger.info( "Minimum population size is " + m_iMinimumPopulationSize );

			m_iGamesPerGeneration = p_iGamesPerGeneration;
			m_logger.info( "Chromosomes will play " + m_iGamesPerGeneration + " game(s) each" );

			m_bRandomizeSampleGenes = p_bRandomizeSampleGenes;

			try
			{
				// Create our folder (if necessary)

				m_fileGenes.mkdir();

				// Set up our JGAP configuration

				if ( p_configuration == null )
				{
					m_configuration = new Configuration();
					m_configuration.setNaturalSelector( new RankedSelector() );
					m_configuration.setRandomGenerator( new StockRandomGenerator() );
					m_configuration.setEventManager( new EventManager() );
					m_configuration.setChromosomePool( new ChromosomePool() );

					m_configuration.addGeneticOperator( new ReproductionOperator() );
					m_configuration.addGeneticOperator( new GaussianMutationOperator( 2.0 ) );
					m_configuration.addGeneticOperator( new GaussianMutationOperator( 1.0 ) );
					m_configuration.addGeneticOperator( new GaussianMutationOperator( 0.5 ) );
					m_configuration.addGeneticOperator( new GaussianMutationOperator( 0.05 ) );
				}
				else
				{
					m_configuration = p_configuration;
				}

				// Set the population size

				m_configuration.setPopulationSize( m_iMinimumPopulationSize );

                // The sample chromosome is what all others get based on

                Chromosome chromosomeSample = new Chromosome( p_arraySampleGenes );
                m_configuration.setSampleChromosome( chromosomeSample );

                // Our fitness function simply uses our (already
                // computed) scores

                m_configuration.setFitnessFunction( new FitnessFunction()
                    {
                        protected int evaluate( Chromosome p_chromosome )
                        {
                            GenesScore score = (GenesScore) p_chromosome.getAttachment();

							// Fitness values MUST be positive integers, so we add the lowest
							// possible value (-m_iGamesPerGeneration) to the score. We know
							// this IS the lowest possible score, because all these classes
							// are 'final'

                            return ( score.getScore() + ( -m_iGamesPerGeneration * GenesScore.LOSING_SCORE ));
                        }
                    } );

                // Identify all chromosomes on disk...

                m_mapGeneScores = new HashMap();

				{
					String[] strGenes = m_fileGenes.list( new FilenameFilter()
						{
							public boolean accept( File dir, String name )
							{
								return ( name.endsWith( GENES_SUFFIX ));
							}
						} );

					// If we're allowed to, load them all...

					if ( p_bAllowLoadingPreviouslySavedGenes )
					{
						GenesScore score;

						for( int iLoop = 0; iLoop < strGenes.length; iLoop++ )
						{
							// (make sure we can load them)

							m_logger.info( "Found existing genes '" + strGenes[iLoop] + "'" );

							if ( createChromosomeFromGenes( strGenes[iLoop] ) == null )
							{
								deleteGenes( strGenes[iLoop] );
							}
							else
							{
								score = new GenesScore( strGenes[iLoop] );
								m_mapGeneScores.put( strGenes[iLoop], score );
							}
						}
					}

					// ...otherwise, delete them all

					else
					{
						for( int iLoop = 0; iLoop < strGenes.length; iLoop++ )
						{
							m_logger.info( "Deleting existing genes '" + strGenes[iLoop] + "'" );
							new File( m_fileGenes, strGenes[iLoop] ).delete();
						}
					}
				}

                // If we can, and if we need to, create some initial ones

				if ( p_arraySampleGenes != null )
				{
					int iCreated = 0;
					Chromosome chromosome;

					for( int iLoop = m_mapGeneScores.size(); iLoop < m_iMinimumPopulationSize ; iLoop++ )
					{
						if ( m_bRandomizeSampleGenes )
							chromosome = Chromosome.randomInitialChromosome( m_configuration );
						else
							chromosome = m_configuration.getSampleChromosome();

						storeGenes( chromosome.getGenes() );
						iCreated++;
					}

					if ( iCreated > 0 )
					{
						m_logger.info( "Created " + iCreated + " new chromosome(s)" );
					}
				}
				else
				{
					m_logger.warn( "Could not create any new chromosomes - no sample genes given" );
				}
            }
            catch( Exception e )
            {
                m_logger.warn( "Could not initialize ChromosomeManager", e );
            }
		}
	}

	//
	//
	// Public methods
	//
	//

	/**
	 * Get, at random, the next chromosome competitor. It
	 * is intended the client throw this chromosome object
	 * away after creating a neural network from it.<P>
     *
     * The chromosome is considered 'held' pending the
     * resulting score of any game it plays (passed
	 * back by calling <CODE>gameOver</CODE>), and being
	 * 'released' (by calling <CODE>releaseChromosome</CODE>).<P>
	 *
	 * If there are no more competitors waiting to play in
	 * a game, the genotype is evolved 'just in time', and an
	 * evolved chromosome is returned.
	 */

	public synchronized Chromosome holdChromosome()
	{
		// Fetch the next ID...

		String strID = getNameOfUnfinishedChromosome();

		// ...hold it...

		GenesScore score = (GenesScore) m_mapGeneScores.get( strID );
		score.hold();

		// ...then load it

		return createChromosomeFromGenes( strID );
	}

    /**
     * Increment/decrement the chromosome's score
     */

    public synchronized void gameOver( String p_strID, Boolean p_boolWon )
    {
        GenesScore score = (GenesScore) m_mapGeneScores.get( p_strID );

        score.gameOver( p_boolWon );

        if ( score.getGamesPlayed() >= m_iGamesPerGeneration )
        {
            m_logger.warn( "Chromosome '" + p_strID + "' scored " + score.getScore() + " (in " + score.getGamesPlayed() + " games)" );
        }
        else
        {
            m_logger.debug( "Chromosome '" + p_strID + "' scored " + score.getScore() + " (in " + score.getGamesPlayed() + " games)" );
        }
    }

    /**
     * Release the chromosome (so that it may be considered for evolution)
     */

	public synchronized void releaseChromosome( String p_strID )
	{
		GenesScore score = (GenesScore) m_mapGeneScores.get( p_strID );

		score.release();
	}

	/**
	 * @return number of generations completed since the class was instantiated
	 */

	public int getGenerations()
	{
		return m_iGeneration;
	}

	//
	//
	// Private methods
	//
	//

	/**
	 * Return, at random, the name of a chromosome that has yet
	 * to complete all its games, or null if there is no such chromosome.
 	 */

	private String getNameOfUnfinishedChromosome()
	{
		// Build a list of candidate Chromosomes

		List listChromosomes = new ArrayList();

		GenesScore score;
		boolean bAtLeastOneChromosomeIsInUse = false;

		for( Iterator i = m_mapGeneScores.values().iterator(); i.hasNext(); )
		{
			score = (GenesScore) i.next();

			// 'In use' Chromosomes don't count
			// (this also ensures we never play ourselves)

			if ( score.isInUse() )
			{
				bAtLeastOneChromosomeIsInUse = true;
				continue;
			}

			listChromosomes.add( score );
		}

		// Sort the Chromosomes by 'number of games played' (lowest first)...

		Collections.sort( listChromosomes, new Comparator()
			{
				public int compare( Object o1, Object o2 )
				{
					int iGamesPlayed1 = ((GenesScore) o1).getGamesPlayed();
					int iGamesPlayed2 = ((GenesScore) o2).getGamesPlayed();

					if ( iGamesPlayed1 < iGamesPlayed2 )
						return -1;

					if ( iGamesPlayed1 > iGamesPlayed2 )
						return 1;

					return 0;
				}
			} );

		// ...then choose the lowest one

		score = (GenesScore) listChromosomes.iterator().next();

		// If the lowest number of games played has reached
		// 'games per generation' already, evolve them all...

		if ( !bAtLeastOneChromosomeIsInUse && score.getGamesPlayed() >= m_iGamesPerGeneration )
		{
			evolveFinishedChromosomes();

			// ...and return the first one

			score = (GenesScore) m_mapGeneScores.values().iterator().next();
		}

		return score.getName();
	}

	private void evolveFinishedChromosomes()
	{
		try
		{
			// Load all the chromosomes we have

			Chromosome[] chromosomes = new Chromosome[ m_mapGeneScores.size() ];

            String strID;
			GenesScore score;
			int iChromosomePrefix = 0;

			int iTotalScore = 0;
			int iTotalGenes = 0;

			for( Iterator i = m_mapGeneScores.keySet().iterator(); i.hasNext(); )
			{
                strID = (String) i.next();

				chromosomes[iChromosomePrefix] = createChromosomeFromGenes( strID );

				score = (GenesScore) m_mapGeneScores.get( strID );

				if ( score.isInUse() )
				{
					throw new RuntimeException( "Chromosome '" + score.getName() + "' is in use!" );
				}

				m_logger.warn( "'" + strID + "' scored " + score.getScore() );

				iTotalScore += score.getScore();
				iTotalGenes++;

				chromosomes[iChromosomePrefix].setAttachment( score );
				iChromosomePrefix++;
			}

			m_iGeneration++;
			m_logger.warn( "Generation " + m_iGeneration );
			m_logger.info( "Mean score is " + ( iTotalScore / iTotalGenes ));

			// Put the configuration together with the chromosomes
			// into a genotype

			Genotype genotype = new NaturallySelectFirstGenotype( m_configuration, chromosomes );

			// Evolve the genotype

			m_logger.info( "Genotype before evolution is:\n" + genotype );
			genotype.evolve();
			m_logger.info( "Genotype after evolution is:\n" + genotype );

			// Extract the resulting chromosomes

			chromosomes = genotype.getChromosomes();

			ArrayList listOriginalChromosomeNames = new ArrayList( m_mapGeneScores.keySet() );

			// Save them (with new names)

            Chromosome chromosome;

			for( int iLoop = 0; iLoop < chromosomes.length; iLoop++ )
			{
                chromosome = chromosomes[iLoop];
				chromosome.setAttachment( null );

				storeGenes( chromosome.getGenes() );
			}

			// Delete the originals

			for( Iterator i = listOriginalChromosomeNames.iterator(); i.hasNext(); )
			{
				deleteGenes( (String) i.next() );
			}
		}
		catch( Exception e )
		{
			m_logger.error( "Could not evolve genotype", e );
            e.printStackTrace();
			System.exit( 0 );
		}
	}

	private Chromosome createChromosomeFromGenes( String p_strName )
	{
		m_logger.debug( "Creating Chromosome from genes '" + p_strName + "'" );

		ObjectInputStream streamIn = null;

		try
		{
			File fileChromosome = new File( m_fileGenes, p_strName );

			streamIn = new ObjectInputStream( new GZIPInputStream( new FileInputStream( fileChromosome )));
            Gene[] genes = (Gene[]) streamIn.readObject();

			Chromosome chromosome = new Chromosome( m_configuration, genes );
            streamIn.close();

			chromosome.setAttachment( m_mapGeneScores.get( p_strName ));

			// Update the generation count

			int iIndexOf = p_strName.indexOf( GENES_PREFIX );

			if ( iIndexOf != -1 )
			{
				m_iGeneration = Integer.parseInt( p_strName.substring( 0, iIndexOf ));
			}

			return chromosome;
		}
		catch( Exception e )
		{
			// If we could not load the file, create a new one

			m_logger.warn( "Could not create Chromosome from genes '" + p_strName + "'" );

			return null;
		}
	}

	private String storeGenes( Gene[] p_genes )
	{
		try
		{
			// Give them a name

			File fileChromosome = File.createTempFile( m_iGeneration + GENES_PREFIX, GENES_SUFFIX, m_fileGenes );
			String strName = fileChromosome.getName();

			m_logger.debug( "Storing genes '" + strName + "'" );

			// Important to call 'finish' on GZIPOutputStream

			GZIPOutputStream streamGZIP = new GZIPOutputStream( new FileOutputStream( fileChromosome ));
			ObjectOutputStream streamOut = new ObjectOutputStream( streamGZIP );
			streamOut.writeObject( p_genes );
			streamGZIP.finish();
			streamOut.close();

			// 'Just in time' score creation

			if ( m_mapGeneScores.containsKey( strName ))
			{
				m_logger.error( "Genes '" + strName + "' are already being scored!" );
				System.exit( 0 );
			}

			GenesScore score = new GenesScore( strName );
			m_mapGeneScores.put( strName, score );

			return strName;
		}
		catch( Exception e )
		{
			m_logger.error( "Could not store genes", e );
			System.exit( 0 );

			return null;
		}
	}

	private void deleteGenes( String p_strName )
	{
		File fileChromosome = new File( m_fileGenes, p_strName );

		if ( fileChromosome.delete() )
        {
            m_logger.debug( "Deleted genes '" + p_strName + "'" );
        }
        else
        {
            m_logger.warn( "Could not delete genes '" + fileChromosome.getAbsolutePath() + "'" );
        }

		m_mapGeneScores.remove( p_strName );
	}
}
