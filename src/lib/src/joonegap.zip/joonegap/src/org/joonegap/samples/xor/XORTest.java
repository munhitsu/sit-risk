package org.joonegap.samples.xor;

import org.apache.log4j.*;
import org.joonegap.MeaningStrengthPair;

import java.io.File;
import java.util.List;

/**
 * This test has a <CODE>main</CODE> method which runs
 * until a solution has been found for the XOR problem.
 */

public class XORTest
{
	//
	//
	// Private statics
	//
	//

	private final static String		LOG_FILE = "c:\\XORTest.log";

    //
    //
    // Public statics
    //
    //

    public static void main( String[] p_strArgs )
    {
        try
        {
            // Set up logging

			System.out.println( "Logging to file at '" + LOG_FILE + "'..." );

			new File( LOG_FILE ).delete();

			System.setProperty( "log4j.defaultInitOverride", "true" );

            Logger logger = Logger.getLogger( "XOR" );
            Layout layout = new PatternLayout( "%d - %m%n" );
            logger.addAppender( new FileAppender( layout, LOG_FILE ));
            logger.setLevel( Level.INFO );

            // Set up our neural network manager

            XORNeuralNetManager manager = new XORNeuralNetManager();
            manager.setLogger( logger );

			String strIdentity = "XOR";
			double[] dInput;
			double dOutput;
			List listOutput;

			// Set up our 'test sets'

			double[][] dInputSet = new double[][]{ { 0, 0 }, { 0, 1 }, { 1, 0 }, { 1, 1 } };
			double[] dOutputSet = new double[]{ 0, 1, 1, 0 };

			// Run until a solution is found

            while( true )
            {
				// Hold the neural net

				manager.hold( strIdentity );

				// Run all our tests

				int iScore = 0;
				String strName = manager.getName( strIdentity );

				for( int iLoop = 0; iLoop < dInputSet.length; iLoop++ )
				{
					dInput = dInputSet[ iLoop ];
					listOutput = manager.cycle( strIdentity, dInput );
					dOutput = ((Double) ((MeaningStrengthPair) listOutput.iterator().next()).getMeaning()).doubleValue();

					// Log

					String strRightOrWrong;

					if ( dOutput == dOutputSet[iLoop] )
					{
						strRightOrWrong = "RIGHT!";
						logger.info( strName + " has [" +
									 dInput[0] + "," + dInput[1] + "] as " +
									 dOutput + "\t-> " + strRightOrWrong );

						manager.gameOver( strIdentity, new Boolean( dOutput == dOutputSet[iLoop] ));

						iScore++;
					}
					else
					{
						strRightOrWrong = "WRONG :(";
						logger.info( strName + " has [" +
									 dInput[0] + "," + dInput[1] + "] as " +
									 dOutput + "\t-> " + strRightOrWrong );

						manager.gameOver( strIdentity, null );
					}
				}

				// Release the neural net

				manager.release( strIdentity );

				// See if we've found our winner

				if ( iScore == dInputSet.length )
				{
					logger.info( "Chromosome '" + strName + "' has passed the test after " + manager.getGenerations() + " generation(s)!" );
					break;
				}
			}
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }

		// All done!

		System.out.println( "...all done. Check the log file!" );
    }
}
