package org.joonegap.samples.noughtsandcrosses;

import java.awt.*;

public class NoughtOrCross
{
    //
    //
    // Public statics
    //
    //

    public final static NoughtOrCross   NOUGHT  = new NoughtOrCross( true );

    public final static NoughtOrCross   CROSS   = new NoughtOrCross( false );

    //
    //
    // Private statics
    //
    //

    public boolean  m_bIsNought = false;

    //
    //
    // Constructor
    //
    //

    private NoughtOrCross( boolean p_bIsNought )
    {
        m_bIsNought = p_bIsNought;
    }

    //
    //
    // Public methods
    //
    //

    public boolean isNought()
    {
        return m_bIsNought;
    }

    public String toString()
    {
        if ( isNought() )
            return "O";
        else
            return "X";
    }
}
