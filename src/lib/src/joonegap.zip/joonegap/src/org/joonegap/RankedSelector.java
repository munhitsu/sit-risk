package org.joonegap;

import org.jgap.Chromosome;
import org.jgap.Configuration;
import org.jgap.NaturalSelector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

/**
 * RankedSelector is a JGAP NaturalSelector that selects the
 * top 'n' (as given by the Genotype) ranked Chromosomes to go
 * on to the next population.<P>
 */

public class RankedSelector
		implements NaturalSelector
{
	//
	//
	// Private members
	//
	//

	private ArrayList m_listChromosomes = new ArrayList();

	//
	//
	// NaturalSelector methods
	//
	//

	public synchronized void add( Configuration a_activeConfigurator,
								  Chromosome a_chromosomeToAdd )
	{
		m_listChromosomes.add( a_chromosomeToAdd );
	}

	public synchronized Chromosome[] select( Configuration a_activeConfiguration,
											 int a_howManyToSelect )
	{
		// Sort the collection by score (highest first)

		Collections.sort( m_listChromosomes, new Comparator()
			{
				public int compare( Object o1, Object o2 )
				{
					int iFitness1 = ((Chromosome) o1).getFitnessValue();
					int iFitness2 = ((Chromosome) o2).getFitnessValue();

					if ( iFitness1 < iFitness2 )
						return 1;

					if ( iFitness1 > iFitness2 )
						return -1;

					return 0;
				}
			} );

		// Select the top 'a_howManyToSelect' ones

		Chromosome[] chromosomeToReturn = new Chromosome[a_howManyToSelect];

		Iterator i = m_listChromosomes.iterator();

		for ( int iLoop = 0; iLoop < chromosomeToReturn.length; iLoop++ )
		{
			chromosomeToReturn[iLoop] = (Chromosome) i.next();
		}

		return chromosomeToReturn;
	}

	public void empty()
	{
		m_listChromosomes.clear();
	}
}

