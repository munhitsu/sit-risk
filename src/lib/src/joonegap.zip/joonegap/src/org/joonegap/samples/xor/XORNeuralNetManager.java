package org.joonegap.samples.xor;

import org.joone.engine.FullSynapse;
import org.joone.engine.SigmoidLayer;
import org.joone.engine.LinearLayer;
import org.joone.net.NeuralNet;
import org.joonegap.NeuralNetManager;

import java.io.File;

/**
 * A neural network manager for figuring out the XOR problem.<P>
 *
 * This neural network extends <CODE>NeuralNetManager</CODE>, in
 * order to...
 *
 * <UL>
 * 	<LI>Create a uninitialised neural network for the XOR problem
 * 	<LI>Register that the first output node means '0', and the second means '1'
 * </UL>
 *
 * ...in addition, it demonstrates performing some initial back-prop
 * to help the network along.
 */

public class XORNeuralNetManager
        extends NeuralNetManager
{
    //
    //
    // Private statics
    //
    //

    private final static int    TOTAL_NEURONS_FOR_INPUT = 2;

    private final static int    TOTAL_NEURONS_FOR_HIDDEN = 4;

    private final static int    TOTAL_NEURONS_FOR_OUTPUT = 2;

	private final static double[][]	TRAINING_INPUT = new double[][] {
		{ 0.0, 0.0 },
		{ 0.0, 1.0 },
		{ 1.0, 0.0 },
		{ 1.0, 1.0 }
	};

	private final static double[][]	TRAINING_DESIRED_OUTPUT = new double[][] {
		{ 1.0, 0.0 },
		{ 0.0, 1.0 },
		{ 0.0, 1.0 },
		{ 0.0, 1.0 }	// <-- this result is intentionally wrong to start with
	};

    //
    //
    // Constructor
    //
    //

    public XORNeuralNetManager()
    {
		super( new File( "C:\\XORGenes" ), false, 4, 4,
			   0.8, 0.3, 1000, TRAINING_INPUT, TRAINING_DESIRED_OUTPUT );
    }

    //
    //
    // Protected methods
    //
    //

    protected NeuralNet createUninitializedNeuralNetwork()
    {
        // Layers

        LinearLayer layerInput = new LinearLayer( "Input" );
        SigmoidLayer layerHidden = new SigmoidLayer( "Hidden" );
        SigmoidLayer layerOutput = new SigmoidLayer( "Output" );
        layerInput.setRows( TOTAL_NEURONS_FOR_INPUT );
        layerHidden.setRows( TOTAL_NEURONS_FOR_HIDDEN );
        layerOutput.setRows( TOTAL_NEURONS_FOR_OUTPUT );

        // Synapses

        FullSynapse synapseInputToHidden = new FullSynapse();
        FullSynapse synapseHiddenToOutput = new FullSynapse();
        layerInput.addOutputSynapse( synapseInputToHidden );
        layerHidden.addInputSynapse( synapseInputToHidden );
        layerHidden.addOutputSynapse( synapseHiddenToOutput );
        layerOutput.addInputSynapse( synapseHiddenToOutput );

        // Over-arching NeuralNet object

        NeuralNet neuralNet = new NeuralNet();
        neuralNet.addLayer( layerInput, NeuralNet.INPUT_LAYER );
        neuralNet.addLayer( layerHidden, NeuralNet.HIDDEN_LAYER );
        neuralNet.addLayer( layerOutput, NeuralNet.OUTPUT_LAYER );

        // Return it

        return neuralNet;
    }

    /**
     * Output nodes are numbered such that:<P>
     *
     * 0 = a zero<BR>
     * 1 = a one<BR>
     */

    protected Object getMeaningOfOutputNodeAt( int p_iIndex )
    {
		return new Double( p_iIndex );
    }
}
