package org.joonegap;

import org.jgap.*;
import org.jgap.event.GeneticEvent;

import java.util.Iterator;
import java.util.Arrays;
import java.util.List;

/**
 * NaturallySelectFirstGenotype extends Genotype to override
 * its <CODE>evolve</CODE> method, such that evolution takes
 * place by doing natural selection <I>first</I>, <I>then</I>
 * evolving the genotype.<P>
 *
 * This is the opposite of the default behaviour, but is important
 * so that the chromosomes in the initial genotype are not
 * mutated before they have had a chance to be evaluated.
 */

public class NaturallySelectFirstGenotype
		extends Genotype
{
	//
	//
	// Constructor
	//
	//

	public NaturallySelectFirstGenotype( Configuration a_activeConfiguration, Chromosome[] a_initialChromosomes )
		   throws InvalidConfigurationException
	{
		super( a_activeConfiguration, a_initialChromosomes );
	}

	//
	//
	// Public methods
	//
	//

	/**
	 * Override evolve() to do the natural selection first, <I>then</I>
	 * the mutation. This allows us to pass in a genotype and not have
	 * it mutated before evaluation.
	 */

	public synchronized void evolve()
	{
		// Add the chromosomes pool to the natural selector.
		// ----------------------------------------------------------------
		Iterator iterator = Arrays.asList( m_chromosomes ).iterator();

		while ( iterator.hasNext() )
		{
			Chromosome currentChromosome = (Chromosome) iterator.next();

			m_activeConfiguration.getNaturalSelector().add(
					m_activeConfiguration,
					currentChromosome );
		}

		// Repopulate the population of chromosomes with those selected
		// by the natural selector.
		// ------------------------------------------------------------

		m_chromosomes = m_activeConfiguration.getNaturalSelector().select(
												  m_activeConfiguration,
												  m_activeConfiguration.getPopulationSize() );

		// Fire an event to indicate we've performed an evolution.
		// -------------------------------------------------------
		m_activeConfiguration.getEventManager().fireGeneticEvent(
				new GeneticEvent( GeneticEvent.GENOTYPE_EVOLVED_EVENT, this ) );

		// Clean up the natural selector.
		// ------------------------------
		m_activeConfiguration.getNaturalSelector().empty();

		// Execute all of the Genetic Operators.
		// -------------------------------------
		List geneticOperators = m_activeConfiguration.getGeneticOperators();
		Iterator operatorIterator = geneticOperators.iterator();

		while ( operatorIterator.hasNext() )
		{
			( (GeneticOperator) operatorIterator.next() ).operate(
					m_activeConfiguration, m_chromosomes, m_workingPool );
		}

		m_chromosomes = new Chromosome[ m_workingPool.size() ];
		m_workingPool.toArray( m_chromosomes );
	}
}
