package org.joonegap;

/**
 * A <CODE>MeaningStrengthPair</CODE> encapsulates
 * a 'meaning' (as defined by <CODE>NeuralNetManager.getMeaningOfOutputNodeAt</CODE>)
 * together with its strength of activation.<P>
 *
 * Sorting by strength is done largely 'behind the scenes',
 * but clients will find the 'meaning' object directly
 * useful.
 */

public class MeaningStrengthPair
{
	//
	//
	// Private members
	//
	//

	private	Object	m_objMeaning;

	private double	m_dStrength;

	//
	//
	// Constructor
	//
	//

	public MeaningStrengthPair( Object p_objMeaning, double p_dStrength )
	{
		m_objMeaning = p_objMeaning;
		m_dStrength = p_dStrength;
	}

	//
	//
	// Public methods
	//
	//

	public Object getMeaning()
	{
		return m_objMeaning;
	}

	public double getStrength()
	{
		return m_dStrength;
	}
}
