package org.joonegap.samples.nim;

import org.apache.log4j.*;
import org.joonegap.samples.nim.NIMNeuralNetManager;
import org.joonegap.MeaningStrengthPair;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.io.File;

/**
 * This test has a <CODE>main</CODE> method which runs
 * until a solution has been found to the game of NIM.
 *
 * Based on work by Mitchell Timin.
 */

public class NIMTest
{
	//
	//
	// Private statics
	//
	//

	private final static String		LOG_FILE = "c:\\NIM.log";

	// remainder: 15  14  13  12  11  10  9  8  7  6  5  4  3  2
	// take away:  2   1   x   3   2   1  x  3  2  1  x  3  2  1

	private final static double[][]	TESTING_INPUT = new double[][] {
		{ 15.0 }, { 14.0 }, { 12.0 }, { 11.0 }, { 10.0 },
		{  8.0 }, {  7.0 }, {  6.0 }, {  4.0 }, {  3.0 }, { 2.0 },
	};

	private final static double[][]	TESTING_DESIRED_OUTPUT = new double[][] {
		{ 0.0, 1.0, 0.0 }, { 1.0, 0.0, 0.0 }, { 0.0, 0.0, 1.0 }, { 0.0, 1.0, 0.0 },
		{ 1.0, 0.0, 0.0 }, { 0.0, 0.0, 1.0 }, { 0.0, 1.0, 0.0 }, { 1.0, 0.0, 0.0 },
		{ 0.0, 0.0, 1.0 }, { 0.0, 1.0, 0.0 }, { 1.0, 0.0, 0.0 },
	};

    //
    //
    // Public statics
    //
    //

    public static void main( String[] p_strArgs )
    {
        try
        {
            // Logging

			System.out.println( "Logging to file at '" + LOG_FILE + "'..." );

			new File( LOG_FILE ).delete();

			System.setProperty( "log4j.defaultInitOverride", "true" );

            Logger logger = Logger.getLogger( "NIM" );
            Layout layout = new PatternLayout( "%d - %m%n" );
            logger.addAppender( new FileAppender( layout, LOG_FILE ));
            logger.setLevel( Level.INFO );

            // Neural network manager

            NIMNeuralNetManager manager = new NIMNeuralNetManager();
            manager.setLogger( logger );

            while( true )
            {
                // Play the game

				int iBeansInPlay = 15;
				int iBeansToPlay;
				List listGameHistory = new ArrayList();
				double[] dBeansInPlay;
				boolean bGameOver = false;
                String[] players = new String[]{ "Player #1", "Player #2" };
				String strWinner = null;

				// Hold the neural nets

				manager.hold( players[0] );
				manager.hold( players[1] );

				// See if either has the solution already

				if ( testForPerfection( players[0], manager, logger )) break;
				if ( testForPerfection( players[1], manager, logger )) break;

				// Keep playing until the game is over

                while( !bGameOver )
                {
                    for( int iPlayer = 0; iPlayer < players.length; iPlayer++ )
                    {
                        // Play whatever is recommended by the network

						dBeansInPlay = new double[]{ iBeansInPlay };
						Iterator i = manager.cycle( players[iPlayer], dBeansInPlay ).iterator();

						iBeansToPlay = ((Integer) ((MeaningStrengthPair) i.next()).getMeaning()).intValue();

						// (cannot remove more than are in play)

						iBeansToPlay = Math.min( iBeansToPlay, iBeansInPlay );

						listGameHistory.add( new Integer( iBeansToPlay ));

						// Whoever removes the last bean, loses

						if ( iBeansToPlay == iBeansInPlay )
						{
							bGameOver = true;

							if ( iPlayer == 0 )
								strWinner = players[1];
							else
								strWinner = players[0];

							break;
						}

						// Remove those beans from the board

						iBeansInPlay -= iBeansToPlay;
                    }
                }

                // Log

				String strHistory = "";

				for( Iterator i = listGameHistory.iterator(); i.hasNext(); )
				{
					for( int iPlayer = 0; iPlayer < players.length; iPlayer++ )
					{
						if ( !i.hasNext() )
							break;

						strHistory += players[iPlayer] + "(" + i.next() + "), ";
					}
				}

				strHistory += " -> " + strWinner + " WINS!";

				logger.info( manager.getName( players[0] ) +
							 " (" + players[0] + ") versus " +
							 manager.getName( players[1] ) +
							 " (" + players[1] + "):\n" +
							 strHistory );

                // Release the neural nets

				manager.gameOver( players[0], new Boolean( strWinner.equals( players[0] )));
				manager.gameOver( players[1], new Boolean( strWinner.equals( players[1] )));

				manager.release( players[0] );
				manager.release( players[1] );
            }
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }

		System.out.println( "...all done. Check the log file!" );
	}

	//
	//
	// Private statics
	//
	//

	private static boolean testForPerfection( Object p_objIdentifier, NIMNeuralNetManager p_manager, Logger p_logger )
	{
		double[] dBeansInPlay;
		int iBeansToPlay;
		int iScore = 0;

		for( int iLoop = 0; iLoop < TESTING_INPUT.length; iLoop++ )
		{
			dBeansInPlay = TESTING_INPUT[iLoop];
			Iterator i = p_manager.cycle( p_objIdentifier, dBeansInPlay ).iterator();

			iBeansToPlay = ((Integer) ((MeaningStrengthPair) i.next()).getMeaning()).intValue();

			if ( TESTING_DESIRED_OUTPUT[iLoop][ (iBeansToPlay-1) ] == 1.0 )
				iScore++;
		}

		p_logger.info( "Neural network '" + p_manager.getName( p_objIdentifier ) + "' rates " + iScore + "/" + TESTING_INPUT.length );

		if ( iScore == TESTING_INPUT.length )
			return true;

		return false;
	}
}
