package org.joonegap;

import org.jgap.Gene;
import org.jgap.Configuration;
import org.jgap.UnsupportedRepresentationException;
import org.jgap.RandomGenerator;

/**
 * This Gene is used to model individual weights (or bias') in the
 * neural network.<P>
 *
 * It can take any <CODE>double</CODE> value, and in all respects
 * is very similar to a <CODE>DoubleGene</CODE>, except that it is
 * initialised with a uniform random distribution ranging over [-0.5, 0.5]
 */

public class WeightGene
        implements Gene
{
    /**
     * References the internal double value (allele) of this Gene.
     */

    protected Double m_value = null;

    /**
     * The current active configuration that is in use.
     */

    protected transient Configuration m_activeConfiguration = null;


    /**
     * Constructs a new DoubleGene with default settings. No bounds will
     * be put into effect for values (alleles) of this Gene instance, other
     * than the standard range of double values.
     */

    public WeightGene()
    {
    }

    /**
     * Constructs a new DoubleGene according to the given active
     * configuration.
     *
     * @param a_activeConfiguration The current active configuration.
     */

    public WeightGene( Configuration a_activeConfiguration )
    {
        m_activeConfiguration = a_activeConfiguration;
    }

    public Gene newGene( Configuration a_activeConfiguration )
    {
        return new WeightGene( a_activeConfiguration );
    }

    public void setAllele( Object a_newValue )
    {
        m_value = (Double) a_newValue;
    }

    public String getPersistentRepresentation() throws
			UnsupportedOperationException
    {
        return toString();
    }

    public void setValueFromPersistentRepresentation( String a_representation )
            throws UnsupportedRepresentationException

    {
        if( a_representation != null )
        {
            m_value = new Double( Double.parseDouble( a_representation ) );
        }
    }

    public Object getAllele()
    {
        return m_value;
    }

    public void setToRandomValue( RandomGenerator a_numberGenerator )
    {
		// Uniform distribution ranging over [-0.5, 0.5]

		double dValue = a_numberGenerator.nextDouble() - 0.5;

		m_value = new Double( dValue );
    }

    public int compareTo( Object other )
    {
        WeightGene otherDoubleGene = (WeightGene) other;

        if( otherDoubleGene == null )
        {
            return 1;
        }
        else if( otherDoubleGene.m_value == null )
        {
            return m_value == null ? 0 : 1;
        }
        else
        {
            try
            {
                return m_value.compareTo( otherDoubleGene.m_value );
            }
            catch( ClassCastException e )
            {
                e.printStackTrace();

                throw e;
            }
        }
    }

    public boolean equals( Object other )
    {
        try
        {
            return compareTo( other ) == 0;
        }
        catch( ClassCastException e )
        {
            return false;
        }

    }

    public int hashCode()
    {
        if( m_value == null )
        {
            return 0;
        }
        else
        {
            return m_value.hashCode();
        }
    }


    public String toString()
    {
        if( m_value == null )
        {
            return "null";
        }
        else
        {
            return m_value.toString();
        }
    }

    public void cleanup()
    {
    }
}

