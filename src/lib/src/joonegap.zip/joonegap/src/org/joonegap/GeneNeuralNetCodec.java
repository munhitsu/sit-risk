package org.joonegap;

import org.jgap.Gene;
import org.joone.engine.FullSynapse;
import org.joone.engine.Layer;
import org.joone.engine.Matrix;
import org.joone.net.NeuralNet;

import java.util.*;

/**
 * Serializes an array of JGAP <CODE>Gene</CODE>s to and
 * from a JOONE <CODE>NeuralNet</CODE>.<P>
 *
 * This class is not static so that subclasses may override
 * its protected methods.
 */

public class GeneNeuralNetCodec
{
    //
    //
    // Public methods
    //
    //

    /**
     * Use the given array of genes to initialize the given neural network.<P>
     *
     * The <I>structure</I> of the neural network (e.g. how many layers,
     * how many neurons per layer, etc.) is <I>not</I> described in
     * the genes, as this would make the array of genes very 'brittle'
     * (i.e. if those values were even slightly wrong, the network as
     * a whole could not be constructed), and 'brittle' things aren't
     * very suitable for genetic algorithms.<P>
     *
     * Instead, only weights and bias' are described in the genes, and
     * this function requires an 'empty' neural network (initialized with
     * the desired structure) that it will initialize with weights
     * and bias'.
     *
	 * @param p_genes	the array of genes
     * @param p_neuralNet the empty neural network
     */

    public void GenesToNeuralNet( Gene[] p_genes, NeuralNet p_neuralNet )
        throws Exception
    {
        try
        {
            // Start at the start of the Gene
            // (a very good place to start :)

            int iGeneIndex = 0;

            // For each layer in the neural net...

            Layer layer;

            // (this can simply be 'Synapse' once 'getConnections' is refactored)

            FullSynapse synapse;

            // ...(being careful to consider each set of synapses only once)...

            List listDoneSynapses = new LinkedList();

            for( Iterator iLayers = p_neuralNet.getLayers().iterator(); iLayers.hasNext(); )
            {
                layer = (Layer) iLayers.next();

				if ( layer.equals( p_neuralNet.getInputLayer() ))
				{
					// (clearing sets all bias values to zero, which effectively
					//  means 'no bias' in 'b + s1w1 + s2w2 + ... snwn')

					layer.getBias().clear();
				}
				else
				{
					// ...do its bias' (except for the input layer)...

					iGeneIndex = initializeMatrix( layer.getBias(), p_genes, iGeneIndex );

					// ...then its input synapses (except for the input layer)...

                    for( Iterator iSynapses = layer.getAllInputs().iterator(); iSynapses.hasNext(); )
                    {
                        synapse = (FullSynapse) iSynapses.next();

                        if ( !listDoneSynapses.contains( synapse ))
                        {
                            listDoneSynapses.add( synapse );
                            iGeneIndex = initializeMatrix( synapse.getWeights(), p_genes, iGeneIndex );
                        }
                    }
                }

                // ...then its output synapses (except for the output layer)...

                if ( !layer.equals( p_neuralNet.getOutputLayer() ))
                {
                    for( Iterator iSynapses = layer.getAllOutputs().iterator(); iSynapses.hasNext(); )
                    {
                        synapse = (FullSynapse) iSynapses.next();

                        if ( !listDoneSynapses.contains( synapse ))
                        {
                            listDoneSynapses.add( synapse );
                            iGeneIndex = initializeMatrix( synapse.getWeights(), p_genes, iGeneIndex );
                        }
                    }
                }
            }

            // Throw if still some genes left

            try
            {
                getWeight( p_genes, iGeneIndex );
                throw new Exception( "More Genes than needed to initialize NeuralNet (only need " + iGeneIndex + ")" );
            }
            catch( NoSuchWeightException e )
            {
            }
        }

        // Throw if too few genes

        catch( NoSuchWeightException e )
        {
            throw new Exception( "Too few Genes to initialize NeuralNet (send too many to be told exactly how many are needed)" );
        }
    }

	/**
	 * Convert the given neural network to an array of genes.<P>
	 *
	 * The <I>structure</I> of the neural network (e.g. how many layers,
	 * how many neurons per layer, etc.) is <I>not</I> described in
	 * the genes, as this would make the array of genes very 'brittle'
	 * (i.e. if those values were even slightly wrong, the network as
	 * a whole could not be constructed), and 'brittle' things aren't
	 * very suitable for genetic algorithms.<P>
	 *
	 * Instead, only weights and bias' are described in the returned genes.
	 *
	 * @param p_neuralNet the initialized neural network
	 */

	public Gene[] NeuralNetToGenes( NeuralNet p_neuralNet )
		throws Exception
	{
		try
		{
			// Start at the start of the Gene
			// (a very good place to start :)

			int iGeneIndex = 0;

			ArrayList listGenes = new ArrayList();

			// For each layer in the neural net...

			Layer layer;

			// (this can simply be 'Synapse' once 'getConnections' is refactored)

			FullSynapse synapse;

			// ...(being careful to consider each set of synapses only once)...

			List listDoneSynapses = new LinkedList();

			for( Iterator iLayers = p_neuralNet.getLayers().iterator(); iLayers.hasNext(); )
			{
				layer = (Layer) iLayers.next();

				// ...do its bias' (except for the input layer)...

				if ( !layer.equals( p_neuralNet.getInputLayer() ))
				{
					iGeneIndex = readMatrix( layer.getBias(), listGenes, iGeneIndex );

					// ...then its input synapses (except for the input layer)...

					for( Iterator iSynapses = layer.getAllInputs().iterator(); iSynapses.hasNext(); )
					{
						synapse = (FullSynapse) iSynapses.next();

						if ( !listDoneSynapses.contains( synapse ))
						{
							listDoneSynapses.add( synapse );
							iGeneIndex = readMatrix( synapse.getWeights(), listGenes, iGeneIndex );
						}
					}
				}

				// ...then its output synapses (except for the output layer)...

				if ( !layer.equals( p_neuralNet.getOutputLayer() ))
				{
					for( Iterator iSynapses = layer.getAllOutputs().iterator(); iSynapses.hasNext(); )
					{
						synapse = (FullSynapse) iSynapses.next();

						if ( !listDoneSynapses.contains( synapse ))
						{
							listDoneSynapses.add( synapse );
							iGeneIndex = readMatrix( synapse.getWeights(), listGenes, iGeneIndex );
						}
					}
				}
			}

			// Return the genes

			Gene[] arrayToReturn = new Gene[ listGenes.size() ];
			listGenes.toArray( arrayToReturn );

			return arrayToReturn;
		}

		// Throw if could not construct the genes

		catch( NoSuchWeightException e )
		{
			throw new Exception( "NeuralNet could not be modelled as a list of Genes" );
		}
	}

    //
    //
    // Protected methods
    //
    //

    /**
     * Return the weight (or bias) at the given index in the
	 * given gene array.<P>
     *
     * This method is protected because the 'index' is considered
     * to be a 'virtual' property: it <I>could</I> directly
     * reference an index in the gene array, but it could also
     * be a combination of genes from multiple places (after all,
	 * synapses in human brains do not have one gene per synapse).<P>
     *
     * In addition, subclasses can override this method to use
     * a different type of <CODE>Gene</CODE> than <CODE>WeightGene</CODE>
     * (though JOONE still ultimately requires a <CODE>double</CODE>).
     *
	 * @param p_genes	the array of genes
     * @param p_iIndex  the virtual index of the weight (guaranteed never to be
     *                  less than zero, but <I>not</I> guaranteed to be
     *                  less than the upper bounds of the gene array)
     * @return  the weight (or bias)
     * @throws org.joonegap.GeneNeuralNetCodec.NoSuchWeightException    if the gene array describes no such weight
     */

    protected double getWeight( Gene[] p_genes, int p_iIndex )
        throws NoSuchWeightException
    {
        if ( p_iIndex >= p_genes.length )
            throw new NoSuchWeightException();

        return ((Double) p_genes[ p_iIndex ].getAllele()).doubleValue();
    }

	/**
	 * Store the given weight in the given list of genes at the given
	 * virtual index.<P>
	 *
	 * This method is protected because the 'index' is considered
	 * to be a 'virtual' property: it <I>could</I> directly
	 * reference an index in the gene array, but it could also
	 * be a combination of genes from multiple places (after all,
	 * synapses in human brains do not have one gene per synapse).<P>
	 *
	 * In addition, subclasses can override this method to use
	 * a different type of <CODE>Gene</CODE> than <CODE>WeightGene</CODE>
	 * (though JOONE still passes a <CODE>double</CODE>).
	 *
	 * @param p_dWeight	the weight to store
	 * @param p_listGenes	the list of genes to store it in
	 * @param p_iIndex	the virtual index to store it at
	 * @throws org.joonegap.GeneNeuralNetCodec.NoSuchWeightException    if the gene array cannot store the weight
	 */

	protected void setWeight( double p_dWeight, List p_listGenes, int p_iIndex )
		throws NoSuchWeightException
	{
		if ( p_listGenes.size() != p_iIndex )
			throw new NoSuchWeightException();

		WeightGene gene = new WeightGene();
		gene.setAllele( new Double( p_dWeight ));

		p_listGenes.add( gene );
	}

    //
    //
    // Private methods
    //
    //

    /**
     * Initialize the given <CODE>Matrix</CODE> with values taken
     * from our chromosome.
     *
     * @param p_matrix  the matrix to initialize
	 * @param p_genes	the array of genes
	 * @param p_iGeneIndex	the gene index to start at
	 * @return	the new gene index
     * @throws org.joonegap.GeneNeuralNetCodec.NoSuchWeightException    if the chromosome does not fully describe the matrix
     */

    private int initializeMatrix( Matrix p_matrix, Gene[] p_genes, int p_iGeneIndex )
        throws NoSuchWeightException
    {
		// Clear the values and deltas

		p_matrix.clear();

		// Traverse the input/output array...

		double[][] arrayMatrix = p_matrix.value;

        int iRows = arrayMatrix.length;
        int iCols = arrayMatrix[0].length;

        if ( iCols == 0 )
            throw new RuntimeException( "Matrix has no outputs!" );

        // ...and populate it

        double dWeight;

        for( int iRow = 0; iRow < iRows; iRow++ )
        {
            for( int iCol = 0; iCol < iCols; iCol++ )
            {
                dWeight = getWeight( p_genes, p_iGeneIndex++ );

                arrayMatrix[iRow][iCol] = dWeight;
            }
        }

		return p_iGeneIndex;
    }

	/**
	 * Read the given Matrix into the give list of Genes, starting at
	 * the give gene index, and returning the new gene index.
	 *
	 * @return	the new gene index
     * @throws org.joonegap.GeneNeuralNetCodec.NoSuchWeightException    if the chromosome does not fully describe the matrix
	 */

	private int readMatrix( Matrix p_matrix, List p_listGenes, int p_iGeneIndex )
		throws NoSuchWeightException
	{
		// Traverse the input/output array...

		double[][] arrayMatrix = p_matrix.value;

        int iRows = arrayMatrix.length;
        int iCols = arrayMatrix[0].length;

        if ( iCols == 0 )
            throw new RuntimeException( "Matrix has no outputs!" );

        // ...and store it

		for( int iRow = 0; iRow < iRows; iRow++ )
		{
			for( int iCol = 0; iCol < iCols; iCol++ )
			{
				setWeight( arrayMatrix[iRow][iCol], p_listGenes, p_iGeneIndex++ );
			}
		}

		return p_iGeneIndex;
	}

    //
    //
    // Inner classes
    //
    //

    public static class NoSuchWeightException
        extends Exception
    {
    }
}
