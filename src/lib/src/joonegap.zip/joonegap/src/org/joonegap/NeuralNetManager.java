package org.joonegap;

import org.apache.log4j.Logger;
import org.jgap.Chromosome;
import org.jgap.Gene;
import org.jgap.Configuration;
import org.joone.engine.DirectSynapse;
import org.joone.engine.Layer;
import org.joone.engine.Monitor;
import org.joone.engine.Pattern;
import org.joone.engine.learning.TeachingSynapse;
import org.joone.io.MemoryInputSynapse;
import org.joone.io.MemoryOutputSynapse;
import org.joone.net.NeuralNet;

import java.io.File;
import java.util.*;

/**
 * NeuralNetManager manages the...
 *
 * <UL>
 * <LI>loading and saving (from chromosomes)
 * <LI>back-prop training of new networks (if desired)
 * <LI>cycling with input data
 * </UL>
 *
 * ...of all neural networks. In this way, it
 * is a one-stop shop for clients wishing to get hold of
 * new neural networks and play them in matches, without
 * worrying about their underlying genes or chromosomes.<P>
 *
 * This class is abstract. Clients must extend it and
 * implement <CODE>createUninitializedNeuralNetwork</CODE> (to
 * create the specific nodes/layers structure of their network)
 * and <CODE>getMeaningOfOutputNodeAt</CODE> to specify some
 * meaningful value for each output node in the neural net.<P>
 *
 * It is assumed that, for many problems, discrete values will be
 * required from the neural net, and in many cases this is best
 * achieved by having discrete output nodes (each with a specific
 * 'meaning', such as a person's name in a facial recognition
 * network), and sorting them by strength of activation.<P>
 *
 * If this is <I>not</I> the structure of your particular network,
 * you can safely return <CODE>null</CODE> from <CODE>getMeaningOfOutputNodeAt</CODE>.<P>
 *
 * <I>(note that all public methods are synchronized)</I>
 */

public abstract class NeuralNetManager
{
	//
	//
	// Private members
	//
	//

	private Logger 				m_logger = null;

	private HashMap 			m_mapNeuralNets = null;

	private ChromosomeManager	m_manager = null;

	private File	    		m_fileGenes = null;

	private int					m_iMinimumPopulationSize = 0;

	private int					m_iGamesPerGeneration = 0;

	private boolean				m_bAllowLoadingPreviouslySavedGenes = false;

	private double				m_dTrainingLearningRate = 0.0;

	private double				m_dTrainingMomentum = 0.0;

	private int					m_iTrainingEpochs = 0;

	private double[][]			m_arrayTrainingInput = null;

	private double[][]			m_arrayTrainingDesiredOutput = null;

	//
	//
	// Constructor
	//
	//

	/**
	 * Constructor (protected, to avoid accidental instantiation).<P>
	 */

	protected NeuralNetManager( File p_fileGenes,
								boolean p_bAllowLoadingPreviouslySavedGenes,
								int p_iGamesPerGeneration,
								int p_iMinimumPopulationSize )
	{
		this( p_fileGenes, p_bAllowLoadingPreviouslySavedGenes, p_iGamesPerGeneration,
			  p_iMinimumPopulationSize, 0.0, 0.0, 0, null, null );
	}

	/**
	 * Constructor (protected, to avoid accidental instantiation).<P>
	 */

	protected NeuralNetManager( File p_fileGenes,
								boolean p_bAllowLoadingPreviouslySavedGenes,
								int p_iGamesPerGeneration,
								int p_iMinimumPopulationSize,
								double p_dTrainingLearningRate,
								double p_dTrainingMomentum,
								int p_iTrainingEpochs,
								double[][] p_arrayTrainingInput,
								double[][] p_arrayTrainingDesiredOutput )
	{
		m_fileGenes = p_fileGenes;
		m_bAllowLoadingPreviouslySavedGenes = p_bAllowLoadingPreviouslySavedGenes;
		m_iGamesPerGeneration = p_iGamesPerGeneration;
		m_iMinimumPopulationSize = p_iMinimumPopulationSize;
		m_dTrainingLearningRate = p_dTrainingLearningRate;
		m_dTrainingMomentum = p_dTrainingMomentum;
		m_iTrainingEpochs = p_iTrainingEpochs;
		m_arrayTrainingInput = p_arrayTrainingInput;
		m_arrayTrainingDesiredOutput = p_arrayTrainingDesiredOutput;
	}

	//
	//
	// Public methods
	//
	//

	public final synchronized void setLogger( Logger p_logger )
	{
		if ( m_logger == null )
		{
			m_logger = p_logger;

			m_logger.info( "Started NeuralNetManager" );

			m_mapNeuralNets = new HashMap();
		}
	}

    /**
     * Hold the neural network with the given identity.<P>
	 *
     * If no such network exists, one will be created and will not be
     * re-created until this identity is released.<P>
     */

	public final synchronized void hold( Object p_objIdentity )
	{
		// Fetch the neural network

		NeuralNetTracker tracker = (NeuralNetTracker) m_mapNeuralNets.remove( p_objIdentity );

		// 'Just in time' neural network creation

		if ( tracker == null )
		{
			tracker = new NeuralNetTracker();

			Chromosome chromosome = getChromosomeManager().holdChromosome();
			tracker.initFromChromosome( chromosome );

			m_logger.debug( "Holding neural network '" + tracker.getName() + "' for player '" + p_objIdentity + "'" );
		}

		// Increase the usage

		tracker.hold();

		// Keep it in the Map

		m_mapNeuralNets.put( p_objIdentity, tracker );
	}

	/**
	 * Get the name of the object with the given identity. Can only
	 * be used while the given identity is held by calling <CODE>hold</CODE>.
	 */

	public final synchronized String getName( Object p_objIdentity )
	{
		NeuralNetTracker tracker = (NeuralNetTracker) m_mapNeuralNets.get( p_objIdentity );

		return tracker.getName();
	}

	/**
	 * Cycle the neural network, returning a sorted List of MeaningStrengthPairs for
	 * all output nodes.
	 *
	 * <H1>FAQ</H1><P>
	 *
	 * <B>Q: Ok, but what when 'getMeaningOfOutputNodeAt' returns 'null', as suggested by you
	 * elsewhere, for the neural networks having a 'continuous' output range?</B><P>
	 *
	 * Whatever value is returned by 'getMeaningOfOutputNodeAt' is, before it reaches the client, paired up into a MeaningStrengthPair (by way of a List after calling 'cycle'). The 'meaning' in the MeaningStrengthPair is whatever was set by 'getMeaningOfOutputNodeAt', and the 'strength' is the strength of activation.<P>
	 *
	 * For example, in a neural network designed to recognize people's faces, we might have two output nodes. The first output node might 'mean' a person Fred, and the second output node might 'mean' a person Wilma. Often in these situations, the clients will want to take whichever node has the highest activation as being the answer from the neural net. To assist in this process, the List returned by 'cycle' is sorted in order of strength of activation, so clients simply have to do...<P>
	 *
	 * <CODE>
	 * String strThePersonIdentifiedIs = (String) ((MeaningStrengthPair) list.get( 0 )).getMeaning();
	 * </CODE><P>
	 *
	 * ...even if the meaning of the nodes is just, say, an index value of some description, clients can return Integers in 'getMeaningOfOutputNodeAt'.<P>
	 *
	 * In cases where it is the strength of activation itself that the client is interested in, however (say for a XOR network with only one output node, where &gt;0.5 is a '1', and &lt;=0.5 is a '0') they can ignore this 'meaning' value altogether. They can simply do...<P>
	 *
	 * <CODE>
	 * double dTheActivationStrengthIs = ((MeaningStrengthPair) list.get( 0 )).getStrength();<BR>
	 * int iIConsiderThisValueA = dTheActivationStrengthIs > 0.5 ? 1 : 0
	 * </CODE><P>
	 *
	 * ...in this case, they don't even use 'getMeaning' so it can return anything for all they care (including null).<P>
	 *
	 * <B>Q: Is the Chromosomes' selection affected by this 'meaningful'?</B><P>
	 *
	 * The selection (or otherwise) of a given Chromosome is not related to the result of 'getMeaningOfOutputNodeAt'. It is decided entirely on the score as totalled up by 'gameOver'.<P>
	 *
	 * <B>Q: Why do you sort the meaning-rank list?</B><P>
	 *
	 * Because, for many purposes (though somewhat arbitrarily) clients will be choosing the highest strength of activation as the 'right' answer.<P>
	 *
	 * <B>Q: Why do you assert:  "Sorting by strength is done largely 'behind the
	 * scenes', but clients will find the 'meaning' object directly useful."
	 * Useful for what?</B><P>
	 *
	 * It is normally the 'meaning' object that conveys what the answer from the network actually means, such as 'Fred' or 'Wilma'.<P>
	 *
	 * @param p_objIdentity the identity under which this neural network was held when 'hold' was called
	 * @param p_dInput the input to cycle through the neural network
	 * @return a List of MeaningStrengthPairs for all output nodes
	 */

	public final synchronized List cycle( Object p_objIdentity, double[] p_dInput )
	{
		// Fetch the neural network

		NeuralNetTracker tracker = (NeuralNetTracker) m_mapNeuralNets.get( p_objIdentity );

		// Cycle it

		return tracker.cycle( p_dInput );
	}

	public final synchronized void gameOver( Object p_objIdentity, Boolean p_boolWon )
	{
		// Fetch the neural network

		NeuralNetTracker tracker = (NeuralNetTracker) m_mapNeuralNets.get( p_objIdentity );

		// Report on its score

        getChromosomeManager().gameOver( tracker.getName(), p_boolWon );
	}

	public final synchronized void release( Object p_objIdentity )
	{
		// Fetch the neural network

		NeuralNetTracker tracker = (NeuralNetTracker) m_mapNeuralNets.remove( p_objIdentity );

		// Decrement the usage

		tracker.release();

		// If no longer in use, let it go (it will be
		// replaced 'just in time' by a new chromosome later)...

		if ( !tracker.isInUse() )
		{
			m_logger.debug( "Releasing neural network '" + tracker.getName() + "' for player '" + p_objIdentity + "'" );

			getChromosomeManager().releaseChromosome( tracker.getName() );
			tracker.die();
		}

		// ...otherwise keep it in the Map

		else
		{
			m_mapNeuralNets.put( p_objIdentity, tracker );
		}
	}

	/**
	 * @return number of generations completed since the class was instantiated
	 */

	public int getGenerations()
	{
		return getChromosomeManager().getGenerations();
	}

	//
    //
    // Abstract methods
    //
    //

	/**
	 * Create an uninitialized neural network of the structure you desire.<P>
	 *
	 * Clients should not set the network's inputs or outputs, or any monitors, and
	 * should not train the network in any way.<P>
	 *
	 * @return a JOONE NeuralNet object
	 */

    protected abstract NeuralNet createUninitializedNeuralNetwork();

	/**
	 * Get the meaningful value of the neural network node at the given
	 * index. This value will be returned as part of a <CODE>MeaningStrengthPair</CODE>
	 * to your client.
	 *
	 * It is assumed that, for many problems, discrete values will be
	 * required from the neural net, and in many cases this is best
	 * achieved by having discrete output nodes (each with a specific
	 * 'meaning', such as a person's name in a facial recognition
	 * network).<P>
	 *
	 * When clients call <CODE>cycle</CODE>, JOONEGAP gathers the 'meaning' of each
	 * output node together with its strength of activation (for the given input), and
	 * puts them into a List of <CODE>MeaningStrengthPair</CODE>s, sorted by
	 * highest strength of activation. This is useful for many clients, who will wish
	 * to take the strongest activated output node as being the 'correct' answer
	 * from the neural network.<P>
	 *
	 * If your particular network does <I>not</I> use discrete output nodes, this method
	 * may not apply to you. For example, if you have a neural network for tackling the
	 * XOR problem, which has only one output node whose output is taken to be either 1
	 * or 0 depending on whether it is greater or less than 0.5, then you are more
	 * interested in raw strength of activation than any 'meaning'. In that case,
	 * you would read the strength from the <CODE>MeaningStrengthPair</CODE>, and
	 * ignore the meaning altogether, so you can safely have this method return null.<P>
	 *
	 * Either way, the value returned by this method has no effect on the Chromosome
	 * selection process.<P>
	 *
	 * @param p_iIndex	the index of the output node
	 * @return	the meaning of that node
	 */

    protected abstract Object getMeaningOfOutputNodeAt( int p_iIndex );

	/**
	 * In the majority of cases, clients can leave JOONEGAP to create and initialize
	 * its own JGAP Configuration object. However, for fine-grained control over
	 * selection and mutation operators, clients may override this method.
	 *
	 * @return	a custom Configuration object, with its natural selector, random generator, event manager, chromosome pool and all genetic operators set
	 */

	protected Configuration getCustomConfiguration()
	{
		return null;
	}

	//
	//
	// Private methods
	//
	//

	private synchronized ChromosomeManager getChromosomeManager()
	{
		if ( m_manager == null )
		{
			// Create the base neural net

			NeuralNet neuralNet = createUninitializedNeuralNetwork();

			// Train it (if given training data)

			boolean bRandomizeSampleGenes = !trainUninitializedNeuralNetwork( neuralNet );

			// Convert it to genes

			Gene[] arrayGenes;

			try
			{
				arrayGenes = new GeneNeuralNetCodec().NeuralNetToGenes( neuralNet );
			}
			catch( Exception e )
			{
				throw new RuntimeException( e.getMessage() );
			}

			// Pass it to our Chromosome manager

			m_manager = new ChromosomeManager( m_fileGenes, m_bAllowLoadingPreviouslySavedGenes, m_iMinimumPopulationSize, m_iGamesPerGeneration, arrayGenes, bRandomizeSampleGenes, getCustomConfiguration(), m_logger );
		}

		return m_manager;
	}

	/**
	 * @param p_neuralNet
	 * @return	true if the network was trained, false otherwise
	 */

	private boolean trainUninitializedNeuralNetwork( NeuralNet p_neuralNet )
	{
		// Don't train if  no epochs specified

		if ( m_iTrainingEpochs <= 0 )
		{
			m_logger.info( "Not training" );
			return false;
		}

		m_logger.info( "Initial training..." );

		// Set the inputs

		Layer layerInput = p_neuralNet.getInputLayer();
		layerInput.removeAllInputs();

		MemoryInputSynapse synapseInput = new MemoryInputSynapse();
		layerInput.addInputSynapse( synapseInput );

		{
			String strColumnSelector = null;

			for( int iLoop = 1; iLoop <= m_arrayTrainingInput[0].length; iLoop++ )
			{
				if ( strColumnSelector == null )
					strColumnSelector = "," + iLoop;
				else
					strColumnSelector += "," + iLoop;
			}

			synapseInput.setInputArray( m_arrayTrainingInput );
			synapseInput.setAdvancedColumnSelector( strColumnSelector );
		}

		// Set the desired outputs (also uses a MemoryInputSynapse)

		MemoryInputSynapse synapseDesiredOutput = new MemoryInputSynapse();

		TeachingSynapse trainer = new TeachingSynapse();
		trainer.setDesired( synapseDesiredOutput );
		p_neuralNet.setTeacher( trainer );

		Layer layerOutput = p_neuralNet.getOutputLayer();
		layerOutput.removeAllOutputs();
		layerOutput.addOutputSynapse( trainer );

		{
			String strColumnSelector = null;

			for( int iLoop = 1; iLoop <= m_arrayTrainingDesiredOutput[0].length; iLoop++ )
			{
				if ( strColumnSelector == null )
					strColumnSelector = "," + iLoop;
				else
					strColumnSelector += "," + iLoop;
			}

			synapseDesiredOutput.setInputArray( m_arrayTrainingDesiredOutput );
			synapseDesiredOutput.setAdvancedColumnSelector( strColumnSelector );
		}

		// Set the outputs

		MemoryOutputSynapse synapseOutput = new MemoryOutputSynapse();
		layerOutput.addOutputSynapse( synapseOutput );

		// Set the monitor parameters

		Monitor monitor = p_neuralNet.getMonitor();

		for ( Iterator i = p_neuralNet.getLayers().iterator(); i.hasNext(); )
		{
			((Layer) i.next()).setMonitor( monitor );
		}

		monitor.setLearningRate( m_dTrainingLearningRate );
		monitor.setMomentum( m_dTrainingMomentum );
		monitor.setTrainingPatterns( m_arrayTrainingInput.length );
		monitor.setTotCicles( m_iTrainingEpochs );
		monitor.setLearning( true );

		// Start learning

		p_neuralNet.start();
		p_neuralNet.getMonitor().Go();

		// Receive the output (this will make us block until learning is complete)

		synapseOutput.getAllPatterns();
		m_logger.info( "...trained initial network to an error of " + monitor.getGlobalError() );

		return true;
	}

    //
	//
	// Inner class
	//
	//

	private final class NeuralNetTracker
	{
		//
		//
		// Private members
		//
		//

		private String 				m_strName = null;

		private NeuralNet 			m_neuralNet = null;

		private DirectSynapse		m_synapseInput = null;

		private DirectSynapse		m_synapseOutput = null;

		private int 				m_iUsage = 0;

		//
		//
		// Constructor
		//
		//

		public NeuralNetTracker()
		{
			//
			// Create our neural network
			//

            m_neuralNet = createUninitializedNeuralNetwork();
		}

		//
		//
		// Public methods
		//
		//

		public void initFromChromosome( Chromosome p_chromosome )
		{
			// Remember our name

			m_strName = ((GenesScore) p_chromosome.getAttachment()).getName();

            // Initialize the neural network

            try
            {
                new GeneNeuralNetCodec().GenesToNeuralNet( p_chromosome.getGenes(), m_neuralNet );
            }
            catch( Exception e )
            {
                m_logger.error( "Could not initialize NeuralNet from Chromosome '" + m_strName + "'", e );
                System.exit( 0 );
            }

			// Input

			m_synapseInput = new DirectSynapse();

			Layer layerInput = m_neuralNet.getInputLayer();
			layerInput.removeAllInputs();
			layerInput.addInputSynapse( m_synapseInput );

			// Output

			m_synapseOutput = new DirectSynapse();

			Layer layerOutput = m_neuralNet.getOutputLayer();
			layerOutput.removeAllOutputs();
			layerOutput.addOutputSynapse( m_synapseOutput );

			// Controlling monitor (net is not learning)

			Monitor monitor = m_neuralNet.getMonitor();
			monitor.setLearning( false );

            // Start the neural net

			m_neuralNet.start();
		}

		public void die()
		{
            // Stop the neural net

			m_neuralNet.stop();
		}

		//
		//
		// Public methods
		//
		//

		public String getName()
		{
			return m_strName;
		}

		public boolean isInUse()
		{
			return ( m_iUsage != 0 );
		}

		public void hold()
		{
			m_iUsage++;
		}

		public void release()
		{
			if ( m_iUsage > 0 )
			{
				m_iUsage--;
			}
		}

		public List cycle( double[] p_dInput )
		{
			// Must have called 'initFromChromosome'

			if ( m_synapseInput == null )
			{
				m_logger.error( "Must call 'initFromChromosome' before 'cycle'" );
				System.exit( 0 );
			}

			// Prepare the input pattern

			Pattern pattern = new Pattern( p_dInput );
			pattern.setCount( p_dInput.length );

			// Send it

			m_synapseInput.fwdPut( pattern );

			// Receive the output

			double[] dOutput = m_synapseOutput.fwdGet().getArray();

			// Build a list of {meaning, strength} pairs

			List listNodes = new ArrayList();

			for( int iLoop = 0; iLoop < dOutput.length; iLoop++ )
			{
				listNodes.add( new MeaningStrengthPair( getMeaningOfOutputNodeAt( iLoop ), dOutput[iLoop] ));
			}

			// Sort the list (highest output first)

			Collections.sort( listNodes, new Comparator()
				{
					public int compare( Object o1, Object o2 )
					{
						double dStrength1 = ((MeaningStrengthPair) o1).getStrength();
						double dStrength2 = ((MeaningStrengthPair) o2).getStrength();

						if ( dStrength1 < dStrength2 )
							return 1;

						if ( dStrength1 > dStrength2 )
							return -1;

						return 0;
					}
				} );

			// Return it

			return listNodes;
		}
	}
}
