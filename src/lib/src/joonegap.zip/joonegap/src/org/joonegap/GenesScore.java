package org.joonegap;

/**
 * This simple class is used to track the activity
 * of a given gene. It is attached to chromosomes
 * as needed using the <CODE>Chromosome.attach</CODE>
 * method.
 */

public final class GenesScore
{
	//
	//
	// Public statics
	//
	//

	public final static int		WINNING_SCORE = 1;

	public final static int		LOSING_SCORE = -10;

	//
	//
	// Private members
	//
	//

	private String				m_strName = null;

	private boolean				m_bInUse = false;

	private int					m_iScore = 0;

	private int					m_iGamesPlayed = 0;

	//
	//
	// Constructor
	//
	//

	public GenesScore( String p_strName )
	{
		m_strName = p_strName;
	}

	//
	//
	// Public methods
	//
	//

	public String getName()
	{
		return m_strName;
	}

	public int getScore()
	{
		return m_iScore;
	}

	public int getGamesPlayed()
	{
		return m_iGamesPlayed;

	}

	/**
	 * Score is incremented if game is won, <I>decremented</I> if
	 * game is lost. This is important so that the score is
	 * still representative, regardless of whether one chromosome
	 * has played more games than others.<P>
	 *
	 * Number of games played is incremented either way.<P>
	 */

	public void gameOver( Boolean p_boolWon )
	{
		if ( p_boolWon != null )
		{
			if ( p_boolWon.booleanValue() )
				m_iScore += WINNING_SCORE;
			else
				m_iScore += LOSING_SCORE;
		}

        m_iGamesPlayed++;
	}

	public boolean isInUse()
	{
		return m_bInUse;
	}

	public void hold()
	{
		m_bInUse = true;
	}

    public void release()
    {
        m_bInUse = false;
    }
}
