
Thank-you for trying JGAP 1.0! We are very interested in any feedback
you might have, including details of how you're using JGAP, what you
like about it, and what you think needs improvement. You can leave this
feedback on the user's mailing list at jgap-users@lists.sourceforge.net
or, if you prefer to keep these details private, you can email the JGAP
project administrator at mrblah@users.sourceforge.net. The more feedback
we get, the more we can improve JGAP to better meet the needs of our 
users. Thanks for your support!

------------------------------------------------------------------------
About This Release:

This represents the first production release of JGAP, the Java Genetic
Algorithms Package. After two years of development, testing, and public
alpha and beta releases, we finally feel that JGAP has reached an
acceptable level of stability for the current feature set. Work has
already begun on JGAP version 1.1, which include some much-requested
features including support for real values, a richer selection of
stock gene types, pluggable "fitness evaluators," and various small
enhancements. 

For a general list of changes, fixes, and enhancements that have been
included in version 1.0, please see the CHANGELOG.txt file.

This software is OSI Certified Open Source Software. OSI Certified is
a certification mark of the Open Source Initiative.

JGAP documentation, including Javadocs and some basic introductory
documents to help get you started, can be found on the JGAP home page at
http://jgap.sourceforge.net. Javadocs can also be found in the javadocs/
directory of the JGAP distribution, and other documentation can be found
in the docs/ directory of the distribution. For a basic introduction to 
using JGAP, we highly recommend reading the tutorial that can be found 
both on the JGAP website and in the docs/ directory. Finally, a simple
example is also available in the src/examples directory.

JGAP 1.0 was compiled and tested with Java 1.4 on Linux, Mac OS X,
and Windows XP although the authors believe that Java 1.2 on any
platform should be sufficient for its use.

Please direct any questions, comments, problems, or inquiries to the
JGAP users mailing list at:

    jgap-users@lists.sourceforge.net

or to the JGAP developers mailing list at jgap-devl@lists.sourceforge.net.

Public announcements concerning JGAP, including any new release
announcements, are made on the jgap-announce mailing list. If you would
like to subscribe to this list, or to any other JGAP list, please visit 
the JGAP mailing list manager at:

    http://sourceforge.net/mail/?group_id=11618

Mailing list archives are also available for each of the lists.

Thanks again for trying out JGAP!
--The JGAP team

------------------------------------------------------------------------
Installation:

Please note that the latest public release of JGAP can always be found
by following the "Download" link on the JGAP home page. The home page 
is located at http://jgap.sourceforge.net

1. If you haven't already, untar or unzip the JGAP archive into your
directory of choice.

2. Simply add the jgap.jar to your classpath. If you wish to use the
examples, then also add the jgap-examples.jar to your classpath.

3. Finally, if you wish to view or modify the source code, it can
be found in the src/ directory of the archive. For convenience, an Ant
build script is included. For more information on Ant, please see the
Ant home page at http://ant.apache.org

4. Javadocs can be found in the javadocs/ directory. Other documentation,
including basic documents to help you get started, can be found in the
docs/ directory. A simple example can be found in the src/examples
directory.

If you have any questions, or run into any problems, please feel free
to send a message to the JGAP users mailing list at:

     jgap-users@lists.sourceforge.net

or to the developers mailing list at jgap-devl@lists.sourceforge.net.

------------------------------------------------------------------------
Special Thanks:

Thanks go to everyone who has been using JGAP, especially those who
have provided feedback and bug reports! Your support is invaluable.

Thanks also to Nghia Le, who designed the new JGAP logo.

And finally, thanks to the folks at Sourceforge who kindly host the
JGAP project. For more information on SourceForge, please visit
http://www.sourceforge.net.

